#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void tsvc_2_s319_fp64(
    double *restrict a,
    double *restrict b,
    const double *restrict c,
    const double *restrict d,
    const double *restrict e,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    int64_t n = LEN_1D;
    if (n <= 0) return;
    double total = 0.0;
    #pragma omp parallel for schedule(static) reduction(+:total)
    for (int64_t i = 0; i < n; ++i) {
        double ai = c[i] + d[i];
        a[i] = ai;
        double bi = c[i] + e[i];
        b[i] = bi;
        total += ai;
        total += bi;
    }
    b[0] = total;
}
