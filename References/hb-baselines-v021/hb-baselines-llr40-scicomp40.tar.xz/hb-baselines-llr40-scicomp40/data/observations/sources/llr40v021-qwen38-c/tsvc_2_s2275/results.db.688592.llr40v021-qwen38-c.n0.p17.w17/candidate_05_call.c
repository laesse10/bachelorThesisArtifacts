#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void tsvc_2_s2275_fp64(
    double *restrict a,
    double *restrict aa,
    const double *restrict b,
    const double *restrict bb,
    const double *restrict c,
    const double *restrict cc,
    const double *restrict d,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {

    (void)workspace;
    (void)workspace_size;
    if (LEN_2D <= 0) return;
    const int64_t n = LEN_2D * LEN_2D;
    int t = omp_get_max_threads();
    int nt = (t < 96) ? (t * 2) : t;

    #pragma omp parallel num_threads(nt)
    {
        #pragma omp for schedule(static, 4096)
        for (int64_t k = 0; k < n; ++k) {
            aa[k] = aa[k] + bb[k] * cc[k];
        }
        #pragma omp for schedule(static)
        for (int64_t i = 0; i < LEN_2D; ++i) {
            a[i] = b[i] + c[i] * d[i];
        }
    }
}
