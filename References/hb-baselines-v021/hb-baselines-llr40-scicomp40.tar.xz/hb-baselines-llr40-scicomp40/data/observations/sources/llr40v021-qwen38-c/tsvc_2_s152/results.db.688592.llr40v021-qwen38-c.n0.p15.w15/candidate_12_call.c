#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

void tsvc_2_s152_fp64(
    double *restrict a,
    double *restrict b,
    const double *restrict c,
    const double *restrict d,
    const double *restrict e,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {

  if (LEN_1D <= 0) return;
  (void)workspace;
  (void)workspace_size;

  #pragma omp parallel
  {
    const int nt = omp_get_num_threads();
    const int t = omp_get_thread_num();
    const int64_t n = LEN_1D;
    /* contiguous per-thread ranges, all starts at a multiple of 8 elements
       (64-byte aligned for page-aligned arrays) */
    const int64_t per = (n / (int64_t)nt) & ~7LL;
    const int64_t units = (n - per * (int64_t)nt) / 8; /* <= nt-1 */
    int64_t start, cnt;
    if (t == nt - 1) {
      start = per * (int64_t)t + 8 * units;
      cnt = n - start;
    } else {
      start = per * (int64_t)t + 8 * (t < units ? t : units);
      cnt = per + (t < units ? 8 : 0);
    }

    double *restrict a0 = a + start;
    double *restrict b0 = b + start;
    const double *restrict c0 = c + start;
    const double *restrict d0 = d + start;
    const double *restrict e0 = e + start;

    int64_t i = 0;
    const int64_t nvec = cnt & ~31LL;
    for (; i < nvec; i += 32) {
      _mm_prefetch((const char *)(d0 + i + 64), _MM_HINT_T0);
      _mm_prefetch((const char *)(e0 + i + 64), _MM_HINT_T0);
      _mm_prefetch((const char *)(c0 + i + 64), _MM_HINT_T0);
      _mm_prefetch((const char *)(a0 + i + 64), _MM_HINT_T0);
      __m512d bv0 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 0),  _mm512_loadu_pd(e0 + i + 0));
      __m512d bv1 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 8),  _mm512_loadu_pd(e0 + i + 8));
      __m512d bv2 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 16), _mm512_loadu_pd(e0 + i + 16));
      __m512d bv3 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 24), _mm512_loadu_pd(e0 + i + 24));
      _mm512_storeu_pd(b0 + i + 0,  bv0);
      _mm512_storeu_pd(b0 + i + 8,  bv1);
      _mm512_storeu_pd(b0 + i + 16, bv2);
      _mm512_storeu_pd(b0 + i + 24, bv3);
      _mm512_storeu_pd(a0 + i + 0,
          _mm512_fmadd_pd(bv0, _mm512_loadu_pd(c0 + i + 0),  _mm512_loadu_pd(a0 + i + 0)));
      _mm512_storeu_pd(a0 + i + 8,
          _mm512_fmadd_pd(bv1, _mm512_loadu_pd(c0 + i + 8),  _mm512_loadu_pd(a0 + i + 8)));
      _mm512_storeu_pd(a0 + i + 16,
          _mm512_fmadd_pd(bv2, _mm512_loadu_pd(c0 + i + 16), _mm512_loadu_pd(a0 + i + 16)));
      _mm512_storeu_pd(a0 + i + 24,
          _mm512_fmadd_pd(bv3, _mm512_loadu_pd(c0 + i + 24), _mm512_loadu_pd(a0 + i + 24)));
    }
    for (; i < cnt; ++i) {
      b0[i] = d0[i] * e0[i];
      a0[i] += b0[i] * c0[i];
    }
  }
}
