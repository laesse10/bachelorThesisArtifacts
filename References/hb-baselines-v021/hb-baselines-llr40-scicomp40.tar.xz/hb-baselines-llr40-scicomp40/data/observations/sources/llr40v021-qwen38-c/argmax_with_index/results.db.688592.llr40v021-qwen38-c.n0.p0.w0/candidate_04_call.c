#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/syscall.h>

/* glibc hides some declarations under -D_POSIX_C_SOURCE=199309L; declare what
   we need. */
extern long syscall(long number, ...);
extern long sysconf(int name);
#ifndef _SC_PAGESIZE
#define _SC_PAGESIZE 30
#endif

#define SLOT_MAX 1024
#define AM_MAX_NODES 32
#define AM_CPUWORDS 16 /* 1024 CPUs */

static inline void am_zero(unsigned long *m) { for (int i = 0; i < AM_CPUWORDS; i++) m[i] = 0; }
static inline void am_setbit(unsigned long *m, int c) { m[c >> 6] |= 1UL << (c & 63); }
static inline void am_and16(unsigned long *d, const unsigned long *a, const unsigned long *b) {
    for (int i = 0; i < AM_CPUWORDS; i++) d[i] = a[i] & b[i];
}
static inline int am_popcount(const unsigned long *m) {
    int n = 0;
    for (int i = 0; i < AM_CPUWORDS; i++) n += __builtin_popcountl(m[i]);
    return n;
}

struct Slot {
    double v;
    int64_t i;
};

/* node -> cpu mask, parsed once from /sys */
static _Alignas(64) unsigned long g_node_mask[AM_MAX_NODES][AM_CPUWORDS];
static _Atomic int g_nodes_valid = -1; /* -1 uninit, -2 none, else count */

static void am_init_nodes(void) {
    char path[64], buf[8192];
    int n;
    g_nodes_valid = 0;
    for (n = 0; n < AM_MAX_NODES; n++) {
        snprintf(path, sizeof path, "/sys/devices/system/node/node%d/cpulist", n);
        FILE *f = fopen(path, "r");
        if (!f) break;
        size_t r = fread(buf, 1, sizeof buf - 1, f);
        buf[r] = 0;
        fclose(f);
        am_zero(g_node_mask[n]);
        char *tok = buf;
        while (tok && *tok) {
            char *comma = strchr(tok, ',');
            if (comma) *comma = '\0';
            char *dash = strchr(tok, '-');
            int a = (int)strtol(tok, NULL, 10);
            int b = dash ? (int)strtol(dash + 1, NULL, 10) : a;
            if (a < 0) a = 0;
            if (b > 1023) b = 1023;
            for (int c = a; c <= b; c++) am_setbit(g_node_mask[n], c);
            tok = comma ? comma + 1 : NULL;
        }
        g_nodes_valid++;
    }
    if (g_nodes_valid == 0) g_nodes_valid = -2;
}

/* NUMA node that physically holds the 4 KiB page containing addr, from
   /proc/self/pagemap (node id in bits 55..60; valid only if the page entry
   reports a present/offset page). -1 if unknown. */
static _Atomic int g_pagemap_fd = -2; /* -2 uninit, -1 unavailable */
static int am_page_node(const void *addr) {
    int fd = g_pagemap_fd;
    if (fd < 0) {
        fd = open("/proc/self/pagemap", O_RDONLY);
        g_pagemap_fd = (fd < 0) ? -1 : fd;
        if (fd < 0) return -1;
    }
    unsigned long long e = (unsigned long long)(uintptr_t)addr / 4096ULL;
    if (lseek(fd, (off_t)(e * 8ULL), SEEK_SET) < 0) return -1;
    unsigned char b[8];
    if (read(fd, b, 8) != 8) return -1;
    uint64_t v;
    memcpy(&v, b, 8);
    int f = (int)((v >> 55) & 0x3FULL); /* node field, 1-based */
    if (!((v & 1ULL) || (v >> 63) & 1ULL)) return -1; /* no page found */
    if (f == 0) return -1;
    return f - 1;
}

/* Sequential numpy semantics over [lo, hi): start x = a[lo]; replace only when
   a[i] > x is TRUE (NaN never wins; the first occurrence of the max value kept). */

__attribute__((target("avx512f,avx512dq")))
static void scan_512(const double *restrict a, int64_t lo, int64_t hi,
                     double *out_v, int64_t *out_i) {
    const double *p = a + lo;
    const double *end = a + hi;
    double bv = p[0];
    int64_t bi = lo;
    p++;
    int64_t i = lo + 1;
    __m512d xv = _mm512_set1_pd(bv);
    const __m512d ninf = _mm512_set1_pd(-INFINITY);
    for (; p + 8 <= end; p += 8, i += 8) {
        __m512d v = _mm512_loadu_pd(p);
        __mmask8 m = _mm512_cmp_pd_mask(v, xv, _CMP_GT_OQ);
        if (m) {
            __m512d cand = _mm512_mask_max_pd(ninf, m, ninf, v);
            double hmax = _mm512_reduce_max_pd(cand);
            __mmask8 pm = _mm512_cmp_pd_mask(v, _mm512_set1_pd(hmax), _CMP_EQ_OQ);
            int q = __builtin_ctzll(pm);
            bv = hmax;
            bi = i + q;
            xv = _mm512_set1_pd(hmax);
        }
    }
    while (p < end) {
        if (*p > bv) {
            bv = *p;
            bi = i;
        }
        p++;
        i++;
    }
    *out_v = bv;
    *out_i = bi;
}

__attribute__((target("avx2,fma")))
static void scan_256(const double *restrict a, int64_t lo, int64_t hi,
                     double *out_v, int64_t *out_i) {
    const double *p = a + lo;
    const double *end = a + hi;
    double bv = p[0];
    int64_t bi = lo;
    p++;
    int64_t i = lo + 1;
    __m256d xv = _mm256_set1_pd(bv);
    const __m256d ninf = _mm256_set1_pd(-INFINITY);
    for (; p + 4 <= end; p += 4, i += 4) {
        __m256d v = _mm256_loadu_pd(p);
        __m256d gt = _mm256_cmp_pd(v, xv, _CMP_GT_OQ);
        if (_mm256_movemask_pd(gt)) {
            __m256d cand = _mm256_or_pd(_mm256_and_pd(gt, v),
                                        _mm256_andnot_pd(gt, ninf));
            __m256d p2 = _mm256_permute_pd(cand, 0x1e);
            __m256d p3 = _mm256_max_pd(cand, p2);
            __m256d p4 = _mm256_permute_pd(p3, 0x11);
            double hmax = _mm_cvtsd_f64(_mm256_castpd256_pd128(_mm256_max_pd(p3, p4)));
            __m256d eq = _mm256_cmp_pd(v, _mm256_set1_pd(hmax), _CMP_EQ_OQ);
            int q = __builtin_ctz((unsigned)_mm256_movemask_pd(eq));
            bv = hmax;
            bi = i + q;
            xv = _mm256_set1_pd(hmax);
        }
    }
    while (p < end) {
        if (*p > bv) {
            bv = *p;
            bi = i;
        }
        p++;
        i++;
    }
    *out_v = bv;
    *out_i = bi;
}

static void scan_scalar(const double *restrict a, int64_t lo, int64_t hi,
                        double *out_v, int64_t *out_i) {
    const double *p = a + lo;
    const double *end = a + hi;
    double bv = p[0];
    int64_t bi = lo;
    p++;
    for (int64_t i = lo + 1; p < end; p++, i++) {
        if (*p > bv) {
            bv = *p;
            bi = i;
        }
    }
    *out_v = bv;
    *out_i = bi;
}

void argmax_with_index_fp64(const double *restrict a, int64_t *restrict out_index,
                            double *restrict out_value, const int64_t LEN_1D,
                            uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    if (LEN_1D <= 0) {
        out_value[0] = 0.0;
        out_index[0] = 0;
        return;
    }
    if (LEN_1D == 1) {
        out_value[0] = a[0];
        out_index[0] = 0;
        return;
    }

    int nt = (int)omp_get_max_threads();
    if (nt > SLOT_MAX) nt = SLOT_MAX;
    if ((int64_t)nt > LEN_1D) nt = (int)LEN_1D;
    if (nt < 1) nt = 1;

    int use512 = __builtin_cpu_supports("avx512f") && __builtin_cpu_supports("avx512dq");
    int use256 = !use512 && __builtin_cpu_supports("avx2");
    _Alignas(64) struct Slot slot[SLOT_MAX];

    /* NUMA: if the array lives on one node and that node has >= 2 CPUs within
       our current affinity, bind the workers to those CPUs: local DRAM bandwidth
       beats the cross-node aggregate, which also contends on the interconnect. */
    unsigned long full[AM_CPUWORDS], bind_mask[AM_CPUWORDS];
    int do_bind = 0;
    {
        const char *first_pg = (const char *)(((unsigned long)a) & ~4095UL);
        const char *last_pg =
            (const char *)((((unsigned long)a) + (unsigned long)(LEN_1D * 8) - 1UL) & ~4095UL);
        int h0 = am_page_node(first_pg);
        int h1 = (h0 >= 0) ? am_page_node(last_pg) : -1;
        if (h0 >= 0 && h0 == h1 && h0 < AM_MAX_NODES &&
            syscall(SYS_sched_getaffinity, 0, sizeof(full), full) > 0) {
            int st = g_nodes_valid;
            if (st < 0) {
                am_init_nodes();
                st = g_nodes_valid;
            }
            if (st > h0) {
                am_and16(bind_mask, g_node_mask[h0], full);
                int k = am_popcount(bind_mask);
                if (k >= 3) {
                    do_bind = 1;
                    if (nt > k) nt = k;
                }
            }
        }
    }

    if (do_bind)
        syscall(SYS_sched_setaffinity, 0, sizeof(bind_mask), bind_mask);

    #pragma omp parallel num_threads(nt)
    {
        int64_t tid = omp_get_thread_num();
        int64_t nt64 = nt;
        int64_t slice = (LEN_1D + nt64 - 1) / nt64;
        int64_t lo = tid * slice;
        int64_t hi = lo + slice;
        if (hi > LEN_1D) hi = LEN_1D;
        if (use512)
            scan_512(a, lo, hi, &slot[tid].v, &slot[tid].i);
        else if (use256)
            scan_256(a, lo, hi, &slot[tid].v, &slot[tid].i);
        else
            scan_scalar(a, lo, hi, &slot[tid].v, &slot[tid].i);
    }

    if (do_bind)
        syscall(SYS_sched_setaffinity, 0, sizeof(full), full);

    /* Combine in left-to-right chunk order: a later (strictly) larger value wins,
       an equal value keeps the earlier index, and NaN in the left result swallows
       the right one, exactly matching the sequential numpy scan. */
    double bv = slot[0].v;
    int64_t bi = slot[0].i;
    for (int t = 1; t < nt; t++) {
        if (slot[t].v > bv) {
            bv = slot[t].v;
            bi = slot[t].i;
        }
    }
    out_value[0] = bv;
    out_index[0] = bi;
}
