#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void scatter_accum_dup_fp64(
    double *restrict bins,
    const int32_t *restrict ip,
    const double *restrict src,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    const int64_t n = LEN_1D;
    (void)workspace; (void)workspace_size;
    if (n <= 0) return;
    #pragma omp parallel for schedule(static, 1024)
    for (int64_t i = 0; i < n; i++) {
        const int32_t j = ip[i];
        const double v = src[i];
        #pragma omp atomic
        bins[j] += v;
    }
}
