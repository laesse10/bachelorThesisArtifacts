#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void scatter_accum_dup_fp64(
    double *restrict bins,
    const int32_t *restrict ip,
    const double *restrict src,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    const int64_t n = LEN_1D;
    if (n <= 0) return;

    uint64_t *bits = (uint64_t *)calloc((size_t)((n + 63) >> 6), sizeof(uint64_t));
    if (!bits) {
        #pragma omp parallel for schedule(static, 128)
        for (int64_t i = 0; i < n; i++) {
            #pragma omp atomic
            bins[ip[i]] += src[i];
        }
        return;
    }
    int dup = 0;
    #pragma omp parallel reduction(|:dup)
    {
        int my = 0;
        #pragma omp for schedule(static, 256)
        for (int64_t i = 0; i < n; i++) {
            uint64_t b = 1ULL << (ip[i] & 63);
            uint64_t old = __atomic_fetch_or(&bits[ip[i] >> 6], b, __ATOMIC_RELAXED);
            if (old & b) my = 1;
        }
        dup |= my;
    }
    free(bits);
    if (!dup) {
        #pragma omp parallel for schedule(static, 128)
        for (int64_t i = 0; i < n; i++) bins[ip[i]] += src[i];
    } else {
        #pragma omp parallel for schedule(static, 128)
        for (int64_t i = 0; i < n; i++) {
            #pragma omp atomic
            bins[ip[i]] += src[i];
        }
    }
}
