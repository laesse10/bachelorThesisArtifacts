/* tsvc_2 s1244, optimized.
 *
 * Semantics (numpy reference):
 *   for i in 0 .. LEN_1D-2:
 *       a[i] = b[i] + c[i]*c[i] + b[i]*b[i] + c[i]
 *       d[i] = a[i] + a[i+1]        (a[i+1] is still the ORIGINAL input value)
 *   a[LEN_1D-1] and d[LEN_1D-1] are left untouched.
 *
 * d[i] needs the original a[i+1], which the iteration for i+1 later overwrites, so a
 * naive `omp for` is a cross-thread race.  Fix: each thread saves the single boundary
 * element a[e] of its chunk before a barrier; iteration i = e-1 uses the saved value,
 * and the main loop only reads a[i+1] within its own chunk in ascending order (always
 * before this thread's own later write of a[i+1]).  One pass, five array-words per
 * element (minimum possible), fully vectorized and parallel.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void tsvc_2_s1244_fp64(double *restrict a, const double *restrict b, const double *restrict c,
                       double *restrict d, const int64_t LEN_1D, uint8_t *restrict workspace,
                       const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    const int64_t n = LEN_1D - 1; /* number of output elements */
    if (n < 1) return;
    #pragma omp parallel
    {
        const int nt = omp_get_num_threads();
        const int tid = omp_get_thread_num();
        const int64_t chunk = (n + nt - 1) / nt;
        const int64_t s = (int64_t)tid * chunk;
        int64_t e = s + chunk;
        if (e > n) e = n;
        double ae = 0.0;
        if (s < e) ae = a[e]; /* saved BEFORE any thread writes past its chunk start */
        #pragma omp barrier
        if (s < e) {
            const int64_t end = e - 1;
            int64_t i = s;
            for (; i < end; i++) {
                const double t = a[i + 1];
                const double v = b[i] + c[i] * c[i] + b[i] * b[i] + c[i];
                a[i] = v;
                d[i] = v + t;
            }
            /* boundary element: a[e] was consumed as `ae` before the barrier */
            {
                const double v = b[i] + c[i] * c[i] + b[i] * b[i] + c[i];
                a[i] = v;
                d[i] = v + ae;
            }
        }
    }
}
