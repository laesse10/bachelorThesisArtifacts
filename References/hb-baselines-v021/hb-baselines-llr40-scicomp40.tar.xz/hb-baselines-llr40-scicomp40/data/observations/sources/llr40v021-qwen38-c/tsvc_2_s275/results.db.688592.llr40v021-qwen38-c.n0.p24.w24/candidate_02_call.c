#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

/* TSVC s275: for each column i with aa[0,i] > 0:
     aa[j,i] = aa[j-1,i] + bb[j,i]*cc[j,i],  j = 1..LEN_2D-1
   Columns are independent -> parallel over groups of 8 columns (one AVX-512
   register per 8 columns, vector lane k = column k).  K column groups are
   scanned in lockstep per thread so many line loads stay in flight (the
   workload is DRAM-latency bound).  Each column is updated in exactly the
   reference order with one FMA per row, so results are bit-identical to a
   scalar FMA evaluation of the reference.
   NOTE: on this toolchain _mm512_mask_fmadd_pd(a,k,b,c) miscompiles to
   a*c+b (swapped args); use full fmadd + mask blend instead.
   _mm512_mask_blend_pd(k, x, y) == k ? y : x. */

#ifndef K
#define K 4   /* column groups (of 8 columns) scanned in lockstep per thread */
#endif

#define GSLOT(G)                                                                              \
    if (m[G]) {                                                                               \
        __m512d vcur = _mm512_loadu_pd(a[G]);                                                 \
        __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b[G]), _mm512_loadu_pd(c[G]), v[G]);     \
        __m512d vn = _mm512_mask_blend_pd(m[G], vcur, vf);                                    \
        _mm512_storeu_pd(a[G], vn);                                                           \
        v[G] = vn;                                                                            \
    }

#define GINC(G) do { a[G] += N; b[G] += N; c[G] += N; } while (0)

static inline void scan_groups4(double *restrict aa, const double *restrict bb,
                                const double *restrict cc, const int64_t N, const int64_t g0)
{
    __m512d v[4];
    __mmask8 m[4];
    double *a[4];
    const double *b[4];
    const double *c[4];
    for (int g = 0; g < 4; g++) {
        const int64_t col = 8 * (g0 + g);
        __m512d row0 = _mm512_loadu_pd(aa + col);
        m[g] = _mm512_cmp_pd_mask(row0, _mm512_setzero_pd(), _CMP_GT_OQ);
        v[g] = row0;
        a[g] = aa + col + N;
        b[g] = bb + col + N;
        c[g] = cc + col + N;
    }
    for (int64_t j = 1; j < N; j++) {
        GSLOT(0)
        GSLOT(1)
        GSLOT(2)
        GSLOT(3)
        GINC(0);
        GINC(1);
        GINC(2);
        GINC(3);
    }
}

static inline void scan_groups_small(double *restrict aa, const double *restrict bb,
                                     const double *restrict cc, const int64_t N,
                                     const int64_t g0, const int64_t cnt)
{
    for (int64_t g = 0; g < cnt; g++) {
        const int64_t col = 8 * (g0 + g);
        __m512d row0 = _mm512_loadu_pd(aa + col);
        __mmask8 m = _mm512_cmp_pd_mask(row0, _mm512_setzero_pd(), _CMP_GT_OQ);
        if (!m) continue;
        double *a = aa + col + N;
        const double *b = bb + col + N;
        const double *c = cc + col + N;
        __m512d v = row0;
        for (int64_t j = 1; j < N; j++) {
            __m512d vcur = _mm512_loadu_pd(a);
            __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b), _mm512_loadu_pd(c), v);
            __m512d vn = _mm512_mask_blend_pd(m, vcur, vf);
            _mm512_storeu_pd(a, vn);
            v = vn;
            a += N; b += N; c += N;
        }
    }
}

static inline void col_scan(double *restrict aa, const double *restrict bb, const double *restrict cc,
                            const int64_t N, const int64_t i)
{
    if (aa[i] <= 0.0) return;
    double *a = aa + i + N;
    const double *b = bb + i + N;
    const double *c = cc + i + N;
    double prev = aa[i];
    for (int64_t j = 1; j < N; j++) {
        prev = fma(*b, *c, prev);
        *a = prev;
        a += N; b += N; c += N;
    }
}

void tsvc_2_s275_fp64(
    double *restrict aa,
    const double *restrict bb,
    const double *restrict cc,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace; (void)workspace_size;
    const int64_t N = LEN_2D;
    if (N <= 1) return;
    const int64_t full = N / 8;          /* full 8-column groups */
    const int64_t tail0 = full * 8;      /* first tail column */

    #pragma omp parallel
    {
        #pragma omp for schedule(static)
        for (int64_t g = 0; g < full; g += K) {
            if (g + K <= full)
                scan_groups4(aa, bb, cc, N, g);
            else
                scan_groups_small(aa, bb, cc, N, g, full - g);
        }
        if (tail0 < N)
            for (int64_t i = tail0; i < N; i++) col_scan(aa, bb, cc, N, i);
    }
}
