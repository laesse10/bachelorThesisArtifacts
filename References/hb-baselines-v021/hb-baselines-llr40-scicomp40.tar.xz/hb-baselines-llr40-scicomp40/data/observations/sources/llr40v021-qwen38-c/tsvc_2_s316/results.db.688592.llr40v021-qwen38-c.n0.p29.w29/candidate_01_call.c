#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if defined(__AVX512F__)
#include <immintrin.h>
#elif defined(__AVX2__)
#include <immintrin.h>
#endif

/* Minimum of a, with the exact semantics of the sequential reference
 * `x = a[0]; for i: if (a[i] < x) x = a[i];`:
 *   - NaN elements never win (v < x is false for NaN v),
 *   - the result is NaN only when a[0] is NaN,
 *   - for non-NaN inputs this is the plain mathematical minimum, which is
 *     independent of evaluation order, so any chunking/fold is exact.
 * Per chunk we compute the min over non-NaN elements (INFINITY for an
 * all-NaN chunk) and fold chunk minima left-to-right; the last line makes
 * a[0]-NaN map to NaN, matching the reference bit-for-bit in value. */

#if defined(__AVX512F__)
static double chunk_min_avx512(const double *p, const double *e, double acc) {
    __m512d v0 = _mm512_set1_pd(acc), v1 = _mm512_set1_pd(acc),
            v2 = _mm512_set1_pd(acc), v3 = _mm512_set1_pd(acc),
            v4 = _mm512_set1_pd(acc), v5 = _mm512_set1_pd(acc),
            v6 = _mm512_set1_pd(acc), v7 = _mm512_set1_pd(acc);
    for (; p + 64 <= e; p += 64) {
        v0 = _mm512_min_pd(v0, _mm512_loadu_pd(p));
        v1 = _mm512_min_pd(v1, _mm512_loadu_pd(p + 8));
        v2 = _mm512_min_pd(v2, _mm512_loadu_pd(p + 16));
        v3 = _mm512_min_pd(v3, _mm512_loadu_pd(p + 24));
        v4 = _mm512_min_pd(v4, _mm512_loadu_pd(p + 32));
        v5 = _mm512_min_pd(v5, _mm512_loadu_pd(p + 40));
        v6 = _mm512_min_pd(v6, _mm512_loadu_pd(p + 48));
        v7 = _mm512_min_pd(v7, _mm512_loadu_pd(p + 56));
    }
    for (; p + 8 <= e; p += 8)
        v0 = _mm512_min_pd(v0, _mm512_loadu_pd(p));
    double tmp[64];
    _mm512_storeu_pd(tmp + 0, v0);
    _mm512_storeu_pd(tmp + 8, v1);
    _mm512_storeu_pd(tmp + 16, v2);
    _mm512_storeu_pd(tmp + 24, v3);
    _mm512_storeu_pd(tmp + 32, v4);
    _mm512_storeu_pd(tmp + 40, v5);
    _mm512_storeu_pd(tmp + 48, v6);
    _mm512_storeu_pd(tmp + 56, v7);
    for (int i = 0; i < 64; ++i) {
        double v = tmp[i];
        if (v < acc) acc = v;
    }
    for (; p < e; ++p) {
        double v = *p;
        if (v < acc) acc = v;
    }
    return acc;
}
#elif defined(__AVX2__)
static double __attribute__((unused)) chunk_min_avx2(const double *p, const double *e, double acc) {
    __m256d v0 = _mm256_set1_pd(acc), v1 = _mm256_set1_pd(acc),
            v2 = _mm256_set1_pd(acc), v3 = _mm256_set1_pd(acc);
    for (; p + 16 <= e; p += 16) {
        v0 = _mm256_min_pd(v0, _mm256_loadu_pd(p));
        v1 = _mm256_min_pd(v1, _mm256_loadu_pd(p + 4));
        v2 = _mm256_min_pd(v2, _mm256_loadu_pd(p + 8));
        v3 = _mm256_min_pd(v3, _mm256_loadu_pd(p + 12));
    }
    for (; p + 4 <= e; p += 4)
        v0 = _mm256_min_pd(v0, _mm256_loadu_pd(p));
    double tmp[16];
    _mm256_storeu_pd(tmp + 0, v0);
    _mm256_storeu_pd(tmp + 4, v1);
    _mm256_storeu_pd(tmp + 8, v2);
    _mm256_storeu_pd(tmp + 12, v3);
    for (int i = 0; i < 16; ++i) {
        double v = tmp[i];
        if (v < acc) acc = v;
    }
    for (; p < e; ++p) {
        double v = *p;
        if (v < acc) acc = v;
    }
    return acc;
}
#endif

static double __attribute__((unused)) chunk_min_scalar(const double *p, const double *e, double acc) {
    for (; p < e; ++p) {
        double v = *p;
        if (v < acc) acc = v;
    }
    return acc;
}

void tsvc_2_s316_fp64(const double *restrict a, double *restrict result,
                      const int64_t LEN_1D, uint8_t *restrict workspace,
                      const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    if (LEN_1D <= 0) { result[0] = 0.0; return; }
    if (LEN_1D == 1) { result[0] = a[0]; return; }

    int nt = omp_get_max_threads();
    if (nt < 1) nt = 1;
    nt *= 2; /* two per physical core: SMT pairs hide the memory latency */
    if ((int64_t)nt > LEN_1D) nt = (int)LEN_1D;

    double partial[nt];

    #pragma omp parallel num_threads(nt)
    {
        const int tid = omp_get_thread_num();
        const int n = omp_get_num_threads();
        int64_t chunk = (LEN_1D + n - 1) / n;
        int64_t begin = (int64_t)tid * chunk;
        int64_t end = begin + chunk;
        if (end > LEN_1D) end = LEN_1D;
        double acc = INFINITY;
#if defined(__AVX512F__)
        acc = chunk_min_avx512(a + begin, a + end, acc);
#elif defined(__AVX2__)
        acc = chunk_min_avx2(a + begin, a + end, acc);
#else
        acc = chunk_min_scalar(a + begin, a + end, acc);
#endif
        partial[tid] = acc;
    }

    double x = partial[0];
    for (int t = 1; t < nt; ++t)
        if (partial[t] < x) x = partial[t];
    if (a[0] != a[0]) x = a[0]; /* a[0] NaN: the sequential reference keeps it */
    result[0] = x;
}
