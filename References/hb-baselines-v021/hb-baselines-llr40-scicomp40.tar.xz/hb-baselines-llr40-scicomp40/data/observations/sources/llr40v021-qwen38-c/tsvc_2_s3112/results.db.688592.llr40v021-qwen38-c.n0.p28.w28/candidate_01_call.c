/* TSVC_2 s3112: prefix sum (scan)
 *   sum = 0; for i: sum += a[i]; b[i] = sum;
 *
 * The additions form a dependency chain, so a bit-exact result requires
 * the same left-to-right rounding at every position.  Reassociating (a
 * parallel block scan) changes the rounding: for random-sign data the
 * difference between two summation orders is ~eps*sigma*i in absolute
 * value, which exceeds (atol=1e-11 + rtol*|ref|) at the positions where
 * the running sum crosses zero -- unavoidable for sign-changing input.
 *
 * Strategy:
 *  - Sign-changing input (the common case here): run the exact serial
 *    scan, which is bit-identical to the reference.
 *  - All-same-sign input (monotone running sum): the reassociation error
 *    stays tiny relative to |ref|, so a parallel two-phase block scan is
 *    used: per-block sums (vectorized), serial block-start chain, then
 *    the in-block chain re-run from the block start in every thread.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

#define BLOCK 65536            /* elements per block (multiple of 8) */

static inline void serial_scan(const double *restrict a, double *restrict b, int64_t n) {
    double sum;
    sum = 0.0;
    for (int64_t i = 0; i < n; ++i) {
        sum = sum + a[i];
        b[i] = sum;
    }
}

void tsvc_2_s3112_fp64(const double *restrict a,
                       double *restrict b,
                       const int64_t LEN_1D,
                       uint8_t *restrict workspace,
                       const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    const int64_t n = LEN_1D;
    if (n <= 0) return;

    /* cheap front sample: does the input change sign? */
    int64_t ks = n < (1 << 14) ? n : (1 << 14);
    double smin = INFINITY, smax = -INFINITY;
    for (int64_t i = 0; i < ks; ++i) {
        double v = a[i];
        if (v < smin) smin = v;
        if (v > smax) smax = v;
    }
    if (n < (1 << 14) || (smin < 0.0 && smax > 0.0) || smax > 1e100 || -smin > 1e100) {
        serial_scan(a, b, n);
        return;
    }

    const int64_t nblk = (n + BLOCK - 1) / BLOCK;
    double *T   = malloc((size_t)nblk * sizeof(double));
    double *bmn = malloc((size_t)nblk * sizeof(double));
    double *bmx = malloc((size_t)nblk * sizeof(double));
    if (!T || !bmn || !bmx) { free(T); free(bmn); free(bmx); serial_scan(a, b, n); return; }

    /* phase 1: per-block sums and min/max (vectorized) */
    #pragma omp parallel for schedule(static)
    for (int64_t blk = 0; blk < nblk; ++blk) {
        int64_t s = blk * BLOCK;
        int64_t e = s + BLOCK; if (e > n) e = n;
        int64_t i = s;
        __m512d vsum = _mm512_setzero_pd();
        __m512d vmin = _mm512_set1_pd(INFINITY);
        __m512d vmax = _mm512_set1_pd(-INFINITY);
        for (; i + 8 <= e; i += 8) {
            __m512d v = _mm512_loadu_pd(a + i);
            vsum = _mm512_add_pd(vsum, v);
            vmin = _mm512_min_pd(vmin, v);
            vmax = _mm512_max_pd(vmax, v);
        }
        double sum = _mm512_reduce_add_pd(vsum);
        double mn  = _mm512_reduce_min_pd(vmin);
        double mx  = _mm512_reduce_max_pd(vmax);
        for (; i < e; ++i) {
            double v = a[i];
            sum += v;
            if (v < mn) mn = v;
            if (v > mx) mx = v;
        }
        T[blk]   = sum;
        bmn[blk] = mn;
        bmx[blk] = mx;
    }

    double gmin = INFINITY, gmax = -INFINITY;
    for (int64_t blk = 0; blk < nblk; ++blk) {
        if (bmn[blk] < gmin) gmin = bmn[blk];
        if (bmx[blk] > gmax) gmax = bmx[blk];
    }
    double mag = gmax > -gmin ? gmax : -gmin;
    bool mixed = (gmin < 0.0 && gmax > 0.0);

    if ((mixed && mag > 1e-5) || mag > 1e100) {
        free(T); free(bmn); free(bmx);
        serial_scan(a, b, n);
        return;
    }

    /* phase 2: block start values, exact left-to-right order */
    double *starts = malloc((size_t)(nblk + 1) * sizeof(double));
    if (!starts) { free(T); free(bmn); free(bmx); serial_scan(a, b, n); return; }
    starts[0] = 0.0;
    for (int64_t blk = 0; blk < nblk; ++blk)
        starts[blk + 1] = starts[blk] + T[blk];

    /* phase 3: re-run the in-block chain from the block start */
    #pragma omp parallel for schedule(static)
    for (int64_t blk = 0; blk < nblk; ++blk) {
        int64_t s = blk * BLOCK;
        int64_t e = s + BLOCK; if (e > n) e = n;
        double sum = starts[blk];
        for (int64_t i = s; i < e; ++i) {
            if ((i & 511) == 0)
                __builtin_prefetch(a + i + 512, 0, 1);
            sum = sum + a[i];
            b[i] = sum;
        }
    }

    free(starts); free(T); free(bmn); free(bmx);
}
