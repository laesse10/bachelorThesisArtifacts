#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

/* a[i] = 0.75*a[i-K] + b[i]*c[i]  for i = K..LEN-1 (in-place on a).
 *
 * Chains: for r in 0..K-1 the subsequence r, r+K, r+2K, ...  A row
 * (elements [mK, mK+K)) is contiguous, so rows are walked serially:
 *  - K = 1..2: scalar chain loops (FMA-latency bound, no vector win).
 *  - K = 3..8: one 512-bit register holds all K chains; one FMA per row.
 *  - K >= 9: 64B-aligned blocks (see dense_blocks); the HW prefetcher
 *    only boosts 64B-contiguous streams, so full rows are kept dense.
 *
 * Platform note: on this machine 512-bit MASKED loads/stores fault (#GP)
 * unless the base address is 64B aligned, so row traffic uses the
 * unaligned (loadu/storeu) forms (bases are always 8B aligned) and the
 * short tail of a chain is handled scalar.  The seed load sits at r0*8
 * (64B aligned), so a masked load is legal there.
 */

#define RD 0.75

/* ---------- scalar chain runner: K in {1,2} ---------- */
static void scalar_chains(double *restrict a, const double *restrict b,
                          const double *restrict c, int64_t K, int64_t LEN)
{
    if (K == 1) {
        double v = a[0];
        int64_t i = 1;
        const int64_t PF = 192;
        for (; i + PF < LEN; i++) {
            _mm_prefetch((const char *)(b + i + PF), _MM_HINT_T0);
            _mm_prefetch((const char *)(c + i + PF), _MM_HINT_T0);
            v = RD * v + b[i] * c[i];
            a[i] = v;
        }
        for (; i < LEN; i++) {
            v = RD * v + b[i] * c[i];
            a[i] = v;
        }
    } else {
        double v[2] = { a[0], a[1] };
        int64_t m = 1, mmax = (LEN - 1) / K;
        for (; m <= mmax; m++) {
            const int64_t base = m * K;
            const int64_t cc = LEN - base < K ? LEN - base : K;
            if (cc >= 2) {
                v[0] = RD * v[0] + b[base] * c[base];
                v[1] = RD * v[1] + b[base + 1] * c[base + 1];
                a[base] = v[0];
                a[base + 1] = v[1];
            } else if (cc == 1) {
                v[0] = RD * v[0] + b[base] * c[base];
                a[base] = v[0];
            }
        }
    }
}

/* ---------- one 8-lane group (chains r0..r0+7), rows walked serially ---------- */
static void run_group(double *restrict a, const double *restrict b,
                      const double *restrict c, int64_t K, int64_t LEN,
                      int64_t r0, int lanes)
{
    const int64_t nrows = (LEN - 1 - r0) / K + 1;
    const __m512d RV = _mm512_set1_pd(RD);
    /* seed: never a masked 512 load (base may not be 64B aligned on this VM) */
    double t0[8] = {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
    for (int l = 0; l < lanes && r0 + l < LEN; l++) t0[l] = a[r0 + l];
    __m512d v = _mm512_loadu_pd(t0);

    /* full rows: rem(m) = LEN - (m*K + r0) >= 8  ->  m <= mfull */
    const int64_t mfull = (LEN - r0 - 8) / K;
    /* keep ~256KB ahead of the consumer (DRAM latency ~200ns) */
    int64_t PFR = 256 * 1024 / (K * 8);
    if (PFR < 8) PFR = 8;
    if (PFR > 512) PFR = 512;
    int64_t m = 1;

    if (lanes == 8) {
        for (; m <= mfull; m++) {
            const int64_t base = m * K + r0;
            if (m + PFR <= mfull) {
                const int64_t pb = (m + PFR) * K + r0;
                _mm_prefetch((const char *)(b + pb), _MM_HINT_T0);
                _mm_prefetch((const char *)(c + pb), _MM_HINT_T0);
            }
            __m512d y = _mm512_loadu_pd(b + base);
            y = _mm512_mul_pd(y, _mm512_loadu_pd(c + base));
            v = _mm512_fmadd_pd(RV, v, y);
            _mm512_storeu_pd(a + base, v);
        }
    } else {
        for (; m <= mfull; m++) {
            const int64_t base = m * K + r0;
            if (m + PFR <= mfull) {
                const int64_t pb = (m + PFR) * K + r0;
                _mm_prefetch((const char *)(b + pb), _MM_HINT_T0);
                _mm_prefetch((const char *)(c + pb), _MM_HINT_T0);
            }
            __m512d y = _mm512_loadu_pd(b + base);
            y = _mm512_mul_pd(y, _mm512_loadu_pd(c + base));
            v = _mm512_fmadd_pd(RV, v, y);
            double t[8];
            _mm512_storeu_pd(t, v);
            switch (lanes) {
            case 7: a[base + 6] = t[6]; /* fall through */
            case 6: a[base + 5] = t[5]; /* fall through */
            case 5: a[base + 4] = t[4]; /* fall through */
            case 4: a[base + 3] = t[3]; /* fall through */
            case 3: a[base + 2] = t[2]; /* fall through */
            case 2: a[base + 1] = t[1]; /* fall through */
            case 1: a[base]     = t[0];
            }
        }
    }

    /* final short rows: valid elements only (row 0 is the seed, never updated;
       scalar loads so b/c are never read past LEN) */
    int64_t m2 = mfull + 1;
    if (m2 < 1) m2 = 1;
    for (; m2 < nrows; m2++) {
        const int64_t base = m2 * K + r0;
        int64_t cnt = LEN - base;
        if (cnt > lanes) cnt = lanes;
        double t[8];
        _mm512_storeu_pd(t, v);
        int64_t ulim = (m2 + 1 < nrows) ? lanes : cnt;  /* in-range lanes */
        for (int64_t l = 0; l < ulim; l++)
            t[l] = RD * t[l] + b[base + l] * c[base + l];
        v = _mm512_loadu_pd(t);
        for (int64_t l = 0; l < cnt; l++) a[base + l] = t[l];
    }
}

/* ---------- K >= 9: dense 64B-aligned blocks, single thread ----------
 * A row m = elements [mK, mK+K) is contiguous, so it is processed as
 * 64B blocks: block g = elements [8g, 8g+8), always 64B aligned.  For
 * each block: the a-old values are the K-stride-back 8 elements (row
 * m-1, already updated, L1-resident), b/c are read at aligned 512-bit
 * loads, one FMA, and one full aligned 512-bit store (no read-for-
 * ownership, no line spans).  The b/c product for the next block is
 * issued one block early to keep the DRAM pipeline full.
 *
 * Per row: the first block is partial at the row start (scalar when
 * K%8!=0 and m=1, so the a-old load never straddles a[0]), the middle
 * blocks are all full, the last block is partial at the row end (and
 * at LEN for the final short row).
 *
 * Why single thread: the rows form one dependency chain (row m+1 reads
 * row m's output), so splitting rows across threads serializes;
 * splitting columns lowers the per-thread stream density below what
 * the HW prefetcher can boost (this platform's prefetchers only help
 * 64B-contiguous runs).  One thread walking full rows keeps 100%
 * density on all three streams (~40 GB/s, the per-core ceiling here).
 */
/* ---------- K >= 9: dense 64B-blocks, single thread ----------
 * A row m = elements [mK, mK+K) is contiguous, so it is processed as
 * 64-byte blocks: block g = elements [8g, 8g+8).  For each block: the
 * a-old values are the K-stride-back 8 elements (row m-1, already
 * updated, L1-resident), b/c are read, one FMA, one full store.  The
 * b/c product for the next block is issued one block early to keep
 * the DRAM pipeline full.  Per row: the first block is partial at the
 * row start (scalar when K%8!=0 and m=1, so the a-old read never
 * straddles a[0]), the middle blocks are full, the last block is
 * partial at the row end (and at LEN for the final short row).
 *
 * Two instantiations: the aligned build uses 64B-aligned 512-bit
 * b/c loads and a stores (no read-for-ownership on the a stores);
 * the unaligned build uses the unaligned forms (always legal at 8B).
 * This platform faults on any 512-bit aligned access whose base is
 * not 64B aligned, so the dispatcher checks the array alignment.
 *
 * Why single thread: the rows form one dependency chain (row m+1
 * reads row m's output), so splitting rows across threads serializes;
 * splitting columns lowers the per-thread stream density below what
 * the HW prefetcher can boost (this platform's prefetchers only help
 * 64B-contiguous runs).  One thread walking full rows keeps 100%
 * density on all three streams (~40 GB/s, the per-core ceiling).
 */
#define VDU_DENSE_FUNC(NAME)                                               \
static void NAME(double *restrict a, const double *restrict b,             \
                 const double *restrict c, int64_t K, int64_t LEN)         \
{                                                                          \
    const int64_t nfull = LEN / K;             /* last row may be short */ \
    const int64_t gmax = (LEN + 7) / 8;        /* last 64B block used */   \
    const __m512d RV = _mm512_set1_pd(RD);                                         \
                                                                                 \
    for (int64_t m = 1; m <= nfull; m++) {                                             \
        const int64_t rk = m * K;                                                      \
        const int64_t g0 = rk / 8;             /* block containing element rk */       \
        int64_t g1 = (rk + K + 7) / 8;                                               \
        if (g1 > gmax) g1 = gmax;              /* final short row */                  \
        const int64_t last = g1 - 1;                                                  \
                                                                                       \
        /* ---- first block ---- */                                                   \
        {                                                                             \
            const int64_t loB = 8 * g0;                                               \
            int llo = (int)(rk - loB);         /* 0..7 */                             \
            int lhi = (int)(rk + K - loB);                                         \
            if (lhi > 8) lhi = 8;                                                    \
            if (lhi > LEN - loB) lhi = (int)(LEN - loB);                             \
            if (llo > lhi) llo = lhi;                                                \
            if (loB < K || 8 * g0 + 8 > LEN) { /* a[0] straddle / past LEN */         \
                for (int l = llo; l < lhi; l++)                                       \
                    a[loB + l] = RD * a[loB - K + l] + b[loB + l] * c[loB + l];       \
            } else if (llo == 0 && lhi == 8) {                                       \
                VDU_STA(a + loB, _mm512_fmadd_pd(RV,                                 \
                        _mm512_loadu_pd(a + loB - K), VDU_BC(b, c, g0)));                \
            } else {                                                                  \
                __m512d v = _mm512_fmadd_pd(RV, _mm512_loadu_pd(a + loB - K),         \
                                            VDU_BC(b, c, g0));                           \
                double t[8];                                                          \
                _mm512_storeu_pd(t, v);                                               \
                for (int l = llo; l < lhi; l++) a[loB + l] = t[l];                    \
            }                                                                         \
        }                                                                             \
                                                                                       \
        /* ---- middle blocks: full, in array, in row ---- */                          \
        if (g0 + 2 <= last) {                                                         \
            __m512d y = VDU_BC(b, c, g0 + 1);                                           \
            for (int64_t g = g0 + 1; g < last; g++) {                                 \
                const __m512d yn = VDU_BC(b, c, g + 1);                                \
                const __m512d v = _mm512_fmadd_pd(RV,                                \
                        _mm512_loadu_pd(a + 8 * g - K), y);                          \
                VDU_STA(a + 8 * g, v);                                                \
                y = yn;                                                               \
            }                                                                         \
        }                                                                             \
                                                                                       \
        /* ---- last block ---- */                                                    \
        if (last > g0) {                                                              \
            const int64_t loB = 8 * last;                                            \
            int64_t hi = rk + K - loB;                        /* 1..8 */              \
            if (hi > LEN - loB) hi = LEN - loB;               /* final short row */   \
            if (hi == 8) {                                                              \
                VDU_STA(a + loB, _mm512_fmadd_pd(RV,                                   \
                        _mm512_loadu_pd(a + loB - K), VDU_BC(b, c, last)));              \
            } else {                                                                    \
                for (int l = 0; l < hi; l++)                                          \
                    a[loB + l] = RD * a[loB - K + l] + b[loB + l] * c[loB + l];       \
            }                                                                           \
        }                                                                               \
    }                                                                                   \
}

#define VDU_BC(_b, _c, _g) _mm512_mul_pd(_mm512_load_pd(_b + 8 * (_g)), \
                                        _mm512_load_pd(_c + 8 * (_g)))
#define VDU_STA(_p, _v) _mm512_store_pd(_p, _v)
VDU_DENSE_FUNC(dense_blocks_aligned)
#undef VDU_BC
#undef VDU_STA
#define VDU_BC(_b, _c, _g) _mm512_mul_pd(_mm512_loadu_pd(_b + 8 * (_g)), \
                                        _mm512_loadu_pd(_c + 8 * (_g)))
#define VDU_STA(_p, _v) _mm512_storeu_pd(_p, _v)
VDU_DENSE_FUNC(dense_blocks_unaligned)
#undef VDU_BC
#undef VDU_STA
#undef VDU_DENSE_FUNC

void versioned_distance_update_fp64(
    double *restrict a, const double *restrict b, const double *restrict c,
    const int64_t K, const int64_t LEN_1D,
    uint8_t *restrict workspace, const int64_t workspace_size)
{
    (void)workspace; (void)workspace_size;
    if (LEN_1D <= 0) return;
    if (K <= 0) {
        /* Python range(K, LEN): i starts at K (<= 0); source index i-K >= 0
           always (no wrap on the read); only writes / b / c wrap for i<0. */
        int64_t i;
        for (i = K; i < LEN_1D; i++) {
            const int64_t idx = (i < 0) ? i + LEN_1D : i;
            a[idx] = RD * a[i - K] + b[idx] * c[idx];
        }
        return;
    }
    if (K >= LEN_1D) return;

    if (K == 1 || K == 2) {
        scalar_chains(a, b, c, K, LEN_1D);
    } else if (K <= 8) {
        run_group(a, b, c, K, LEN_1D, 0, (int)K);
    } else {
        if (((uintptr_t)a | (uintptr_t)b | (uintptr_t)c) & 63)
            dense_blocks_unaligned(a, b, c, K, LEN_1D);
        else
            dense_blocks_aligned(a, b, c, K, LEN_1D);
    }
}
