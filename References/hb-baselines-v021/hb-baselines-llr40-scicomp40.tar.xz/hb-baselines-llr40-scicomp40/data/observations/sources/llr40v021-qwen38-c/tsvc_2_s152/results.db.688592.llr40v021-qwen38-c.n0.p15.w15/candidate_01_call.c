#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void tsvc_2_s152_fp64(
    double *restrict a,
    double *restrict b,
    const double *restrict c,
    const double *restrict d,
    const double *restrict e,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {

  if (LEN_1D <= 0) return;
  (void)workspace;
  (void)workspace_size;

  #pragma omp parallel
  {
    #pragma omp for schedule(static) nowait
    for (int64_t i = 0; i < LEN_1D; ++i) {
      b[i] = d[i] * e[i];
      a[i] = a[i] + b[i] * c[i];
    }
  }
}
