#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void scatter_accum_dup_fp64(
    double *restrict bins,
    const int32_t *restrict ip,
    const double *restrict src,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    const int64_t n = LEN_1D;
    (void)workspace; (void)workspace_size;
    if (n <= 0) return;
    omp_set_num_threads(48);
    const int64_t n16 = n & ~15LL;
    #pragma omp parallel for schedule(static, 2048)
    for (int64_t i = 0; i < n16; i += 16) {
        int32_t j0=ip[i+0];
        int32_t j1=ip[i+1];
        int32_t j2=ip[i+2];
        int32_t j3=ip[i+3];
        int32_t j4=ip[i+4];
        int32_t j5=ip[i+5];
        int32_t j6=ip[i+6];
        int32_t j7=ip[i+7];
        int32_t j8=ip[i+8];
        int32_t j9=ip[i+9];
        int32_t j10=ip[i+10];
        int32_t j11=ip[i+11];
        int32_t j12=ip[i+12];
        int32_t j13=ip[i+13];
        int32_t j14=ip[i+14];
        int32_t j15=ip[i+15];
        double v0=src[i+0];
        double v1=src[i+1];
        double v2=src[i+2];
        double v3=src[i+3];
        double v4=src[i+4];
        double v5=src[i+5];
        double v6=src[i+6];
        double v7=src[i+7];
        double v8=src[i+8];
        double v9=src[i+9];
        double v10=src[i+10];
        double v11=src[i+11];
        double v12=src[i+12];
        double v13=src[i+13];
        double v14=src[i+14];
        double v15=src[i+15];
        #pragma omp atomic
        bins[j0]+=v0;
        #pragma omp atomic
        bins[j1]+=v1;
        #pragma omp atomic
        bins[j2]+=v2;
        #pragma omp atomic
        bins[j3]+=v3;
        #pragma omp atomic
        bins[j4]+=v4;
        #pragma omp atomic
        bins[j5]+=v5;
        #pragma omp atomic
        bins[j6]+=v6;
        #pragma omp atomic
        bins[j7]+=v7;
        #pragma omp atomic
        bins[j8]+=v8;
        #pragma omp atomic
        bins[j9]+=v9;
        #pragma omp atomic
        bins[j10]+=v10;
        #pragma omp atomic
        bins[j11]+=v11;
        #pragma omp atomic
        bins[j12]+=v12;
        #pragma omp atomic
        bins[j13]+=v13;
        #pragma omp atomic
        bins[j14]+=v14;
        #pragma omp atomic
        bins[j15]+=v15;
    }
    for (int64_t i = n16; i < n; i++) {
        #pragma omp atomic
        bins[ip[i]] += src[i];
    }
}
