#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

static inline void body_t(double *restrict aa, const double *restrict b,
                          const double *restrict c, int64_t k) {
    __m512d va = _mm512_loadu_pd(aa + k);
    __m512d vb = _mm512_loadu_pd(b + k);
    __m512d vc = _mm512_loadu_pd(c + k);
    _mm512_storeu_pd(aa + k, _mm512_fmadd_pd(vc, vb, va));
}

void tsvc_2_s2275_fp64(
    double *restrict a,
    double *restrict aa,
    const double *restrict b,
    const double *restrict bb,
    const double *restrict c,
    const double *restrict cc,
    const double *restrict d,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {

    (void)workspace;
    (void)workspace_size;
    if (LEN_2D <= 0) return;
    const int64_t n = LEN_2D * LEN_2D;

    #pragma omp parallel
    {
        #pragma omp for schedule(static, 4096)
        for (int64_t k = 0; k < n; k += 32) {
            if (k + 32 <= n) {
                body_t(aa, bb, cc, k);
                body_t(aa, bb, cc, k + 8);
                body_t(aa, bb, cc, k + 16);
                body_t(aa, bb, cc, k + 24);
            } else {
                for (int64_t q = k; q < n; ++q) aa[q] = aa[q] + bb[q] * cc[q];
            }
        }
        #pragma omp for schedule(static)
        for (int64_t i = 0; i < LEN_2D; ++i) {
            a[i] = b[i] + c[i] * d[i];
        }
    }
}
