/* TSVC_2 s3112: prefix sum, 2-way unrolled serial scan */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

#define BLOCK 65536

static inline void serial_scan(const double *restrict a, double *restrict b, int64_t n) {
    double sum = 0.0;
    int64_t i = 0;
    for (; i + 1 < n; i += 2) {
        double v0 = a[i];
        double v1 = a[i+1];
        sum += v0;
        b[i] = sum;
        sum += v1;
        b[i+1] = sum;
    }
    if (i < n) { sum += a[i]; b[i] = sum; }
}

void tsvc_2_s3112_fp64(const double *restrict a,
                       double *restrict b,
                       const int64_t LEN_1D,
                       uint8_t *restrict workspace,
                       const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    const int64_t n = LEN_1D;
    if (n <= 0) return;

    int64_t ks = n < (1 << 14) ? n : (1 << 14);
    double smin = INFINITY, smax = -INFINITY;
    for (int64_t i = 0; i < ks; ++i) {
        double v = a[i];
        if (v < smin) smin = v;
        if (v > smax) smax = v;
    }
    if (n < (1 << 14) || (smin < 0.0 && smax > 0.0) || smax > 1e100 || -smin > 1e100) {
        serial_scan(a, b, n);
        return;
    }

    const int64_t nblk = (n + BLOCK - 1) / BLOCK;
    double *T   = malloc((size_t)nblk * sizeof(double));
    double *bmn = malloc((size_t)nblk * sizeof(double));
    double *bmx = malloc((size_t)nblk * sizeof(double));
    if (!T || !bmn || !bmx) { free(T); free(bmn); free(bmx); serial_scan(a, b, n); return; }

    #pragma omp parallel for schedule(static)
    for (int64_t blk = 0; blk < nblk; ++blk) {
        int64_t s = blk * BLOCK;
        int64_t e = s + BLOCK; if (e > n) e = n;
        int64_t i = s;
        __m512d vsum = _mm512_setzero_pd();
        __m512d vmin = _mm512_set1_pd(INFINITY);
        __m512d vmax = _mm512_set1_pd(-INFINITY);
        for (; i + 8 <= e; i += 8) {
            __m512d v = _mm512_loadu_pd(a + i);
            vsum = _mm512_add_pd(vsum, v);
            vmin = _mm512_min_pd(vmin, v);
            vmax = _mm512_max_pd(vmax, v);
        }
        double sum = _mm512_reduce_add_pd(vsum);
        double mn  = _mm512_reduce_min_pd(vmin);
        double mx  = _mm512_reduce_max_pd(vmax);
        for (; i < e; ++i) {
            double v = a[i];
            sum += v;
            if (v < mn) mn = v;
            if (v > mx) mx = v;
        }
        T[blk]   = sum;
        bmn[blk] = mn;
        bmx[blk] = mx;
    }

    double gmin = INFINITY, gmax = -INFINITY;
    for (int64_t blk = 0; blk < nblk; ++blk) {
        if (bmn[blk] < gmin) gmin = bmn[blk];
        if (bmx[blk] > gmax) gmax = bmx[blk];
    }
    double mag = gmax > -gmin ? gmax : -gmin;
    bool mixed = (gmin < 0.0 && gmax > 0.0);

    if ((mixed && mag > 1e-5) || mag > 1e100) {
        free(T); free(bmn); free(bmx);
        serial_scan(a, b, n);
        return;
    }

    double *starts = malloc((size_t)(nblk + 1) * sizeof(double));
    if (!starts) { free(T); free(bmn); free(bmx); serial_scan(a, b, n); return; }
    starts[0] = 0.0;
    for (int64_t blk = 0; blk < nblk; ++blk)
        starts[blk + 1] = starts[blk] + T[blk];

    #pragma omp parallel for schedule(static)
    for (int64_t blk = 0; blk < nblk; ++blk) {
        int64_t s = blk * BLOCK;
        int64_t e = s + BLOCK; if (e > n) e = n;
        double sum = starts[blk];
        for (int64_t i = s; i < e; ++i) {
            if ((i & 511) == 0)
                __builtin_prefetch(a + i + 512, 0, 1);
            sum = sum + a[i];
            b[i] = sum;
        }
    }

    free(starts); free(T); free(bmn); free(bmx);
}