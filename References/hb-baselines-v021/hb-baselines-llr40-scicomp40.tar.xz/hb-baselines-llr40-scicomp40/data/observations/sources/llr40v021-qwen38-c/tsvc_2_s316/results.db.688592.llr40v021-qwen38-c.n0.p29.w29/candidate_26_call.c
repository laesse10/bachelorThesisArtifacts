#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <pthread.h>
#include <unistd.h>

#if defined(__AVX512F__)
#include <immintrin.h>
#elif defined(__AVX2__)
#include <immintrin.h>
#endif

/* Minimum of a[0..LEN-1] with the exact semantics of the sequential
 * reference `x = a[0]; for i: if (a[i] < x) x = a[i];` -- NaN elements
 * never win; the result is NaN only when a[0] is NaN; for non-NaN data
 * it is the mathematical minimum; when the minimum is zero the returned
 * zero is the first one encountered.
 *
 * Parallelized with worker threads (one pthread per chunk); if thread
 * creation is unavailable the exact sequential loop is run instead, so
 * the result is identical on every platform. */

#if defined(__AVX512F__)
static double chunk_min_avx512(const double *p, const double *e, double acc) {
    __m512d v[16];
    for (int k = 0; k < 16; ++k) v[k] = _mm512_set1_pd(acc);
    for (; p + 128 <= e; p += 128) {
        v[0] = _mm512_min_pd(v[0], _mm512_loadu_pd(p + 0));
        v[1] = _mm512_min_pd(v[1], _mm512_loadu_pd(p + 8));
        v[2] = _mm512_min_pd(v[2], _mm512_loadu_pd(p + 16));
        v[3] = _mm512_min_pd(v[3], _mm512_loadu_pd(p + 24));
        v[4] = _mm512_min_pd(v[4], _mm512_loadu_pd(p + 32));
        v[5] = _mm512_min_pd(v[5], _mm512_loadu_pd(p + 40));
        v[6] = _mm512_min_pd(v[6], _mm512_loadu_pd(p + 48));
        v[7] = _mm512_min_pd(v[7], _mm512_loadu_pd(p + 56));
        v[8] = _mm512_min_pd(v[8], _mm512_loadu_pd(p + 64));
        v[9] = _mm512_min_pd(v[9], _mm512_loadu_pd(p + 72));
        v[10] = _mm512_min_pd(v[10], _mm512_loadu_pd(p + 80));
        v[11] = _mm512_min_pd(v[11], _mm512_loadu_pd(p + 88));
        v[12] = _mm512_min_pd(v[12], _mm512_loadu_pd(p + 96));
        v[13] = _mm512_min_pd(v[13], _mm512_loadu_pd(p + 104));
        v[14] = _mm512_min_pd(v[14], _mm512_loadu_pd(p + 112));
        v[15] = _mm512_min_pd(v[15], _mm512_loadu_pd(p + 120));
    }
    for (; p + 8 <= e; p += 8)
        v[0] = _mm512_min_pd(v[0], _mm512_loadu_pd(p));
    double tmp[128];
    for (int k = 0; k < 16; ++k)
        _mm512_storeu_pd(tmp + 8 * k, v[k]);
    for (int i = 0; i < 128; ++i) {
        double v2 = tmp[i];
        if (v2 < acc) acc = v2;
    }
    for (; p < e; ++p) {
        double v2 = *p;
        if (v2 < acc) acc = v2;
    }
    return acc;
}

static double first_zero_avx512(const double *p, const double *e) {
    __m512d zero = _mm512_setzero_pd();
    for (; p + 8 <= e; p += 8) {
        __mmask16 m = _mm512_cmp_pd_mask(_mm512_loadu_pd(p), zero, _CMP_EQ_OQ);
        if (m) return p[_tzcnt_u32(m)];
    }
    for (; p < e; ++p)
        if (*p == 0.0) return *p;
    return 0.0; /* unreachable: caller guarantees a zero exists */
}
#elif defined(__AVX2__)
static double chunk_min_avx2(const double *p, const double *e, double acc) {
    __m256d v0 = _mm256_set1_pd(acc), v1 = _mm256_set1_pd(acc),
            v2 = _mm256_set1_pd(acc), v3 = _mm256_set1_pd(acc);
    for (; p + 16 <= e; p += 16) {
        v0 = _mm256_min_pd(v0, _mm256_loadu_pd(p));
        v1 = _mm256_min_pd(v1, _mm256_loadu_pd(p + 4));
        v2 = _mm256_min_pd(v2, _mm256_loadu_pd(p + 8));
        v3 = _mm256_min_pd(v3, _mm256_loadu_pd(p + 12));
    }
    for (; p + 4 <= e; p += 4)
        v0 = _mm256_min_pd(v0, _mm256_loadu_pd(p));
    double tmp[16];
    _mm256_storeu_pd(tmp + 0, v0);
    _mm256_storeu_pd(tmp + 4, v1);
    _mm256_storeu_pd(tmp + 8, v2);
    _mm256_storeu_pd(tmp + 12, v3);
    for (int i = 0; i < 16; ++i) {
        double v = tmp[i];
        if (v < acc) acc = v;
    }
    for (; p < e; ++p) {
        double v = *p;
        if (v < acc) acc = v;
    }
    return acc;
}

static double first_zero_avx2(const double *p, const double *e) {
    __m256d zero = _mm256_setzero_pd();
    for (; p + 4 <= e; p += 4) {
        unsigned m = (unsigned)_mm256_movemask_pd(_mm256_cmp_pd(_mm256_loadu_pd(p), zero, _CMP_EQ_OQ));
        if (m) return p[__builtin_ctz(m)];
    }
    for (; p < e; ++p)
        if (*p == 0.0) return *p;
    return 0.0;
}
#endif

static double __attribute__((unused)) chunk_min_scalar(const double *p, const double *e, double acc) {
    for (; p < e; ++p) {
        double v = *p;
        if (v < acc) acc = v;
    }
    return acc;
}

static double __attribute__((unused)) first_zero_scalar(const double *p, const double *e) {
    for (; p < e; ++p)
        if (*p == 0.0) return *p;
    return 0.0;
}

#define MAX_WORKERS 16

typedef struct {
    const double *a;
    int64_t begin, end;
    double out;
} worker_arg_t;

static void *worker_fn(void *arg) {
    worker_arg_t *w = (worker_arg_t *)arg;
    double acc = INFINITY;
#if defined(__AVX512F__)
    acc = chunk_min_avx512(w->a + w->begin, w->a + w->end, acc);
#elif defined(__AVX2__)
    acc = chunk_min_avx2(w->a + w->begin, w->a + w->end, acc);
#else
    acc = chunk_min_scalar(w->a + w->begin, w->a + w->end, acc);
#endif
    w->out = acc;
    return 0;
}

void tsvc_2_s316_fp64(const double *restrict a, double *restrict result,
                      const int64_t LEN_1D, uint8_t *restrict workspace,
                      const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    if (LEN_1D <= 0) { result[0] = a[0]; return; }
    if (LEN_1D == 1) { result[0] = a[0]; return; }

    /* exact sequential loop (the reference itself) */
    if (LEN_1D < 4096) {
        double x = a[0];
        for (int64_t i = 1; i < LEN_1D; ++i)
            if (a[i] < x) x = a[i];
        result[0] = x;
        return;
    }

    struct cpumask { unsigned long bits[16]; };
    extern int sched_getaffinity(int, unsigned long, struct cpumask *);
    long onln = 16;
    struct cpumask cm;
    memset(&cm, 0, sizeof cm);
    if (sched_getaffinity(0, sizeof cm, &cm) == 0) {
        onln = 0;
        for (int i = 0; i < 16; ++i)
            onln += __builtin_popcountl(cm.bits[i]);
    }
    if (onln < 1) onln = 1;
    int want = (int)(onln * 2);
    if (want > MAX_WORKERS) want = MAX_WORKERS;
    if ((int64_t)want >= LEN_1D) want = (int)LEN_1D - 1;
    if (want < 1) want = 1;

    worker_arg_t wargs[MAX_WORKERS];
    pthread_t wthr[MAX_WORKERS];
    double partial[MAX_WORKERS + 1];

    int nworkers = 0;
    pthread_attr_t attr;
    int have_attr = (pthread_attr_init(&attr) == 0);
    if (have_attr) pthread_attr_setstacksize(&attr, 512 * 1024);

    int64_t ntot = (int64_t)want + 1;
    int64_t chunk = (LEN_1D + ntot - 1) / ntot;
    for (int i = 0; i < want; ++i) {
        wargs[i].a = a;
        wargs[i].begin = (int64_t)i * chunk;
        wargs[i].end = wargs[i].begin + chunk;
        if (wargs[i].end > LEN_1D) wargs[i].end = LEN_1D;
        wargs[i].out = INFINITY;
        if (pthread_create(&wthr[i], have_attr ? &attr : 0, worker_fn, &wargs[i]) != 0)
            break;
        nworkers = i + 1;
    }
    if (have_attr) pthread_attr_destroy(&attr);

    /* master takes the remaining tail: from nworkers*chunk onwards */
    int64_t mbegin = (int64_t)nworkers * chunk;
    if (mbegin > LEN_1D) mbegin = LEN_1D;
    double acc = INFINITY;
#if defined(__AVX512F__)
    acc = chunk_min_avx512(a + mbegin, a + LEN_1D, acc);
#elif defined(__AVX2__)
    acc = chunk_min_avx2(a + mbegin, a + LEN_1D, acc);
#else
    acc = chunk_min_scalar(a + mbegin, a + LEN_1D, acc);
#endif
    partial[nworkers] = acc;

    for (int i = 0; i < nworkers; ++i) {
        pthread_join(wthr[i], 0);
        partial[i] = wargs[i].out;
    }

    double x = partial[0];
    for (int t = 1; t <= nworkers; ++t)
        if (partial[t] < x) x = partial[t];

    if (a[0] != a[0]) {
        x = a[0]; /* a[0] NaN: the sequential reference keeps it */
    } else if (x == 0.0) {
        /* the sequential reference returns the FIRST zero encountered */
#if defined(__AVX512F__)
        x = first_zero_avx512(a, a + LEN_1D);
#elif defined(__AVX2__)
        x = first_zero_avx2(a, a + LEN_1D);
#else
        x = first_zero_scalar(a, a + LEN_1D);
#endif
    }
    result[0] = x;
}
