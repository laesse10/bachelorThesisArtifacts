#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <omp.h>
#include <immintrin.h>

/* glibc symbols the forced -D_POSIX_C_SOURCE=199309L keeps hidden */
extern int sched_getcpu(void);
extern int sched_getaffinity(int pid, size_t cpusetsize, unsigned long *cpuset);

#define MAXCPU 256
static int grp_of_cpu[MAXCPU];          /* -1.. = group id, -2 = unknown */
static int grp_table_built = 0;
static char grp_sig[MAXCPU][128];

static void build_grp_table(void) {
  for (int i = 0; i < MAXCPU; ++i) grp_of_cpu[i] = -2;
  unsigned long mask[128];
  for (int i = 0; i < 128; ++i) mask[i] = 0;
  if (sched_getaffinity(0, sizeof mask, mask) != 0) return;
  int nxt = 0;
  for (int cpu = 0; cpu < 1024 && cpu < MAXCPU; ++cpu) {
    if (!((mask[cpu >> 6] >> (cpu & 63)) & 1UL)) continue;
    char path[110], buf[192];
    snprintf(path, sizeof path, "/sys/devices/system/cpu/cpu%d/cache/index3/shared_cpu_list", cpu);
    FILE *f = fopen(path, "r");
    if (!f || !fgets(buf, sizeof buf, f)) { if (f) fclose(f); return; }
    fclose(f);
    size_t L = strcspn(buf, "\n");
    buf[L] = 0;
    strcpy(grp_sig[cpu], buf);
    grp_of_cpu[cpu] = -1;
    for (int j = 0; j < cpu; ++j) {
      if (grp_of_cpu[j] >= 0 && strcmp(grp_sig[cpu], grp_sig[j]) == 0) {
        grp_of_cpu[cpu] = grp_of_cpu[j];
        break;
      }
    }
    if (grp_of_cpu[cpu] < 0) grp_of_cpu[cpu] = nxt++;
  }
  grp_table_built = 1;
}

void tsvc_2_s152_fp64(
    double *restrict a,
    double *restrict b,
    const double *restrict c,
    const double *restrict d,
    const double *restrict e,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {

  if (LEN_1D <= 0) return;
  (void)workspace;
  (void)workspace_size;

  if (!grp_table_built) build_grp_table();
  const int64_t n = LEN_1D;

  #pragma omp parallel
  {
    const int nt = omp_get_num_threads();
    const int t = omp_get_thread_num();

    /* group membership (CCD sharing an L3) for every thread */
    int cpus[MAXCPU];
    #pragma omp for
    for (int i = 0; i < nt; ++i) cpus[i] = sched_getcpu();
    int myg = -2;
    {
      int mc = cpus[t];
      myg = (mc < MAXCPU) ? grp_of_cpu[mc] : -2;
    }
    int all_ok = myg >= 0;
    int pos = 0, gsize = 0;
    for (int i = 0; i < nt; ++i) {
      int gi = (cpus[i] < MAXCPU) ? grp_of_cpu[cpus[i]] : -2;
      if (gi != myg) all_ok = 0;
      if (gi == myg) { if (i < t) pos++; gsize++; }
    }
    const int use_nt = all_ok && myg >= 0 && ((size_t)b & 63) == 0;

    /* per-thread contiguous range, starts 64B aligned */
    const int64_t per = (n / (int64_t)nt) & ~7LL;
    const int64_t units = (n - per * (int64_t)nt) / 8; /* <= nt-1 */
    int64_t start, cnt;
    if (t == nt - 1) {
      start = per * (int64_t)t + 8 * units;
      cnt = n - start;
    } else {
      start = per * (int64_t)t + 8 * (t < units ? t : units);
      cnt = per + (t < units ? 8 : 0);
    }

    if (use_nt) {
      /* invalidate every stale cached line of b from THIS cpu complex:
         the complex's threads collectively flush the whole array */
      const int64_t pg = n / (int64_t)gsize;
      const int64_t fb0 = pg * (int64_t)pos;
      const int64_t fb1 = (pos == gsize - 1) ? n : fb0 + pg;
      int64_t j = fb0 & ~7LL;
      for (; j + 8 <= fb1; j += 8) _mm_clflush(b + j);
    }

    double *restrict a0 = a + start;
    double *restrict b0 = b + start;
    const double *restrict c0 = c + start;
    const double *restrict d0 = d + start;
    const double *restrict e0 = e + start;

    int64_t i = 0;
    const int64_t nvec = cnt & ~31LL;
    if (use_nt) {
      for (; i < nvec; i += 32) {
        __m512d bv0 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 0),  _mm512_loadu_pd(e0 + i + 0));
        __m512d bv1 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 8),  _mm512_loadu_pd(e0 + i + 8));
        __m512d bv2 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 16), _mm512_loadu_pd(e0 + i + 16));
        __m512d bv3 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 24), _mm512_loadu_pd(e0 + i + 24));
        _mm512_stream_pd(b0 + i + 0,  bv0);
        _mm512_stream_pd(b0 + i + 8,  bv1);
        _mm512_stream_pd(b0 + i + 16, bv2);
        _mm512_stream_pd(b0 + i + 24, bv3);
        _mm512_storeu_pd(a0 + i + 0,
            _mm512_fmadd_pd(bv0, _mm512_loadu_pd(c0 + i + 0),  _mm512_loadu_pd(a0 + i + 0)));
        _mm512_storeu_pd(a0 + i + 8,
            _mm512_fmadd_pd(bv1, _mm512_loadu_pd(c0 + i + 8),  _mm512_loadu_pd(a0 + i + 8)));
        _mm512_storeu_pd(a0 + i + 16,
            _mm512_fmadd_pd(bv2, _mm512_loadu_pd(c0 + i + 16), _mm512_loadu_pd(a0 + i + 16)));
        _mm512_storeu_pd(a0 + i + 24,
            _mm512_fmadd_pd(bv3, _mm512_loadu_pd(c0 + i + 24), _mm512_loadu_pd(a0 + i + 24)));
      }
      _mm_sfence();
    } else {
      for (; i < nvec; i += 32) {
        __m512d bv0 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 0),  _mm512_loadu_pd(e0 + i + 0));
        __m512d bv1 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 8),  _mm512_loadu_pd(e0 + i + 8));
        __m512d bv2 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 16), _mm512_loadu_pd(e0 + i + 16));
        __m512d bv3 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 24), _mm512_loadu_pd(e0 + i + 24));
        _mm512_storeu_pd(b0 + i + 0,  bv0);
        _mm512_storeu_pd(b0 + i + 8,  bv1);
        _mm512_storeu_pd(b0 + i + 16, bv2);
        _mm512_storeu_pd(b0 + i + 24, bv3);
        _mm512_storeu_pd(a0 + i + 0,
            _mm512_fmadd_pd(bv0, _mm512_loadu_pd(c0 + i + 0),  _mm512_loadu_pd(a0 + i + 0)));
        _mm512_storeu_pd(a0 + i + 8,
            _mm512_fmadd_pd(bv1, _mm512_loadu_pd(c0 + i + 8),  _mm512_loadu_pd(a0 + i + 8)));
        _mm512_storeu_pd(a0 + i + 16,
            _mm512_fmadd_pd(bv2, _mm512_loadu_pd(c0 + i + 16), _mm512_loadu_pd(a0 + i + 16)));
        _mm512_storeu_pd(a0 + i + 24,
            _mm512_fmadd_pd(bv3, _mm512_loadu_pd(c0 + i + 24), _mm512_loadu_pd(a0 + i + 24)));
      }
    }
    for (; i < cnt; ++i) {
      b0[i] = d0[i] * e0[i];
      a0[i] += b0[i] * c0[i];
    }
  }
}
