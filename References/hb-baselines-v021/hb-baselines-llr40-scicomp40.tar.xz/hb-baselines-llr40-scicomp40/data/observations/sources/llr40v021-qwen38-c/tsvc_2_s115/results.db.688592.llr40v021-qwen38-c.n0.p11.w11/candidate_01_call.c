#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define KCH 64   /* chunk size (multiple of 8 for AVX-512) */
#define MAXT 8

static double g_partial[MAXT][KCH];
static double g_cbuf[KCH];

void tsvc_2_s115_fp64(
    double *restrict a,
    const double *restrict aa,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
  (void)workspace;
  (void)workspace_size;
  const int64_t N = LEN_2D;
  if (N <= 1) return;

  int T = omp_get_max_threads();
  if (T < 1) T = 1;
  if (T > MAXT) T = MAXT;

  #pragma omp parallel num_threads(T)
  {
    const int tid = omp_get_thread_num();
    const int64_t nb = (N + KCH - 1) / KCH;
    for (int64_t m = 0; m < nb; m++) {
      const int64_t i0 = m * (int64_t)KCH;
      const int64_t i1 = i0 + (int64_t)KCH < N ? i0 + (int64_t)KCH : N;
      const int Kt = (int)(i1 - i0);

      for (int t = 0; t < Kt; t++) g_partial[tid][t] = 0.0;

      /* cross-chunk: c[t] = a[i0+t] - sum_{j<i0} a[j]*aa[j, i0+t],
         split j across threads (contiguous row segments) */
      #pragma omp for
      for (int64_t j = 0; j < i0; j++) {
        const double aj = a[j];
        const double *row = aa + j * N + i0;
        for (int t = 0; t < Kt; t++) g_partial[tid][t] += aj * row[t];
      }

      #pragma omp single
      {
        for (int t = 0; t < Kt; t++) {
          double s = 0.0;
          for (int h = 0; h < T; h++) s += g_partial[h][t];
          g_cbuf[t] = a[i0 + t] - s;
        }
        for (int t = 0; t < Kt; t++) {
          double ct = g_cbuf[t];
          for (int s = 0; s < t; s++) ct -= g_cbuf[s] * aa[(i0 + s) * N + (i0 + t)];
          g_cbuf[t] = ct;
        }
        for (int t = 0; t < Kt; t++) a[i0 + t] = g_cbuf[t];
      }
    }
  }
}
