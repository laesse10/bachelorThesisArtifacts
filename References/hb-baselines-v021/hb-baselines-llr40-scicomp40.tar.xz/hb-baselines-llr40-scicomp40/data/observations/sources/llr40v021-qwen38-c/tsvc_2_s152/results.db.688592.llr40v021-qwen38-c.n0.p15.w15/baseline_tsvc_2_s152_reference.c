/* Hand port of the TSVC tsvc_2 C++ microkernel ``s152`` (s152_d_single.cpp), fp64
 * single-invocation variant, to C23 under the v2 C-ABI.
 *
 * Adapted from TSVC_2 -- Test Suite for Vectorizing Compilers (github.com/UoB-HPC/TSVC_2),
 * NCSA/MIT license (UIUC).
 *
 * DELIBERATELY CARRIES NO ``hpcagent_bench-autogen`` MARKER. emit_io treats an unmarked
 * reference as a hand-written override and never regenerates it, which is the point: this
 * corpus exists to ask whether compilers vectorize and parallelize human-written C where they
 * fail on translator-generated C. Regenerating this file from the numpy reference would compare
 * translator output against translator output and answer nothing. Edit it by hand, never
 * through the emitter.
 *
 * The numpy reference remains the correctness oracle. */

#include <stdint.h>

static inline void s152s_kernel(double *restrict a, const double *restrict b, const double *restrict c,
                                const int64_t i) {
  a[i] += b[i] * c[i];
}

void tsvc_2_s152_fp64(double *restrict a, double *restrict b, const double *restrict c, const double *restrict d,
                      const double *restrict e, const int64_t LEN_1D) {

  for (int64_t i = 0; i < LEN_1D; ++i) {
    b[i] = d[i] * e[i];
    s152s_kernel(a, b, c, i);
  }
}
