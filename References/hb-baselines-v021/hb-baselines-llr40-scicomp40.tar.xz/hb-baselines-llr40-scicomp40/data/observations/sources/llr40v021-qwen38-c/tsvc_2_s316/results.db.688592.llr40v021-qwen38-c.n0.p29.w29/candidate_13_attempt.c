#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void tsvc_2_s316_fp64(const double *restrict a, double *restrict result,
                      const int64_t LEN_1D, uint8_t *restrict workspace,
                      const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    if (LEN_1D <= 0) { result[0] = a[0]; return; }
    if (LEN_1D == 1) { result[0] = a[0]; return; }

    int nt = omp_get_max_threads();
    if (nt < 1) nt = 1;
    nt *= 2;
    if ((int64_t)nt > LEN_1D) nt = (int)LEN_1D;

    double partial[nt];

    #pragma omp parallel num_threads(nt)
    {
        const int tid = omp_get_thread_num();
        const int n = omp_get_num_threads();
        int64_t chunk = (LEN_1D + n - 1) / n;
        int64_t begin = (int64_t)tid * chunk;
        int64_t end = begin + chunk;
        if (end > LEN_1D) end = LEN_1D;
        double acc = INFINITY;
        const double *p = a + begin, *e = a + end;
        for (; p < e; ++p) {
            double v = *p;
            if (v < acc) acc = v;
        }
        partial[tid] = acc;
    }

    double x = partial[0];
    for (int t = 1; t < nt; ++t)
        if (partial[t] < x) x = partial[t];

    if (a[0] != a[0]) {
        x = a[0];
    } else if (x == 0.0) {
        const double *p = a;
        const double *e = a + LEN_1D;
        for (; p < e; ++p)
            if (*p == 0.0) { x = *p; goto done; }
    }
done:
    result[0] = x;
}
