/* variant F: 2-accum, BPC=1024, 64B-aligned non-temporal stream loads with a
 * <=3-element scalar prologue; pure loadu fallback when base is not 16B-aligned. */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

void quasi_affine_reduce_odd_fp64(
    const double *restrict a, double *restrict out, const int64_t LEN_1D,
    uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    const int64_t m = LEN_1D / 2;
    double acc = 0.0;
    if (m > 0) {
        const __m512i IDX_ODD  = _mm512_setr_epi64(1, 3, 5, 7, 9, 11, 13, 15);
        const __m512i IDX_EVEN = _mm512_setr_epi64(0, 2, 4, 6, 8, 10, 12, 14);
        const int64_t BPC = 1024;
        int64_t j0 = 0;
        int nt = (m >= 8) && (((unsigned long long)(uintptr_t)a & 15) == 0);
        if (nt) {
            j0 = (4 - (int64_t)(((unsigned long long)(uintptr_t)a & 63) / 16)) % 4;
            if (j0 > m) { j0 = 0; nt = (m >= 8); }
        }
        const int64_t nvec = (m >= 8 + j0) ? ((m - j0) >> 3) : 0;
        for (int64_t j = 0; j < j0; j++) acc += a[2 * j + 1];
        const int64_t nch = nvec / BPC;
        #pragma omp parallel for schedule(static) reduction(+:acc)
        for (int64_t c = 0; c < nch; c++) {
            __m512d v0 = _mm512_setzero_pd();
            __m512d v1 = _mm512_setzero_pd();
            if (nt) {
                const double *q = a + 2 * (j0 + 8 * c * BPC);
                for (int64_t t = 0; t < (BPC >> 1); t++) {
                    __m512d q0 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)q));
                    __m512d q1 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)(q + 8)));
                    v0 = _mm512_add_pd(v0, _mm512_permutex2var_pd(q0, IDX_ODD, q1));
                    q += 16;
                    q0 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)q));
                    q1 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)(q + 8)));
                    v1 = _mm512_add_pd(v1, _mm512_permutex2var_pd(q0, IDX_ODD, q1));
                    q += 16;
                }
            } else {
                const double *p = a + 16 * (c * BPC) + 1;
                for (int64_t t = 0; t < (BPC >> 1); t++) {
                    __m512d lo = _mm512_loadu_pd(p);
                    __m512d hi = _mm512_loadu_pd(p + 8);
                    p += 16;
                    v0 = _mm512_add_pd(v0, _mm512_permutex2var_pd(lo, IDX_EVEN, hi));
                    lo = _mm512_loadu_pd(p);
                    hi = _mm512_loadu_pd(p + 8);
                    p += 16;
                    v1 = _mm512_add_pd(v1, _mm512_permutex2var_pd(lo, IDX_EVEN, hi));
                }
            }
            acc += _mm512_reduce_add_pd(v0) + _mm512_reduce_add_pd(v1);
        }
        int64_t jrem = j0 + 8 * (nch * BPC);
        int64_t j8 = (jrem + 7) & ~7LL;
        for (int64_t j = jrem; j < j8 && j < m; j++) acc += a[2 * j + 1];
        __m512d v = _mm512_setzero_pd();
        for (int64_t j = j8; j + 8 <= m; j += 8) {
            const double *p = a + 2 * j + 1;
            __m512d lo = _mm512_loadu_pd(p);
            __m512d hi = _mm512_loadu_pd(p + 8);
            v = _mm512_add_pd(v, _mm512_permutex2var_pd(lo, IDX_EVEN, hi));
        }
        for (int64_t j = m & ~7LL; j < m; j++) acc += a[2 * j + 1];
        acc += _mm512_reduce_add_pd(v);
    }
    out[0] = acc;
}
