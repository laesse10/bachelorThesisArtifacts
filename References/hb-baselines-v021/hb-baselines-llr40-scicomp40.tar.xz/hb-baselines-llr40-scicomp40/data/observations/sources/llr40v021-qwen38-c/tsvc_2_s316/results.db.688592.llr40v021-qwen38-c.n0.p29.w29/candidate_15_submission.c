#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <stdio.h>
#include <errno.h>
#include <pthread.h>
#include <sys/resource.h>

/* Diagnostic probe: serial core + environment dump to shared folder. */

static void *noop_thr(void *arg) { (void)arg; return 0; }

static void diag_dump(const char *stage, const double *a, int64_t LEN_1D,
                      uint8_t *ws, int64_t wss, double result) {
    FILE *f = fopen("/shared/agent-29/diag.txt", "a");
    if (!f) return;
    fprintf(f, "=== %s ===\n", stage);
    fprintf(f, "t=%.3f LEN=%lld a=%p ws=%p wss=%lld result=%.17g a0=%.17g\n",
            omp_get_wtime(), (long long)LEN_1D, (const void *)a, (const void *)ws,
            (long long)wss, result, LEN_1D > 0 ? a[0] : 0.0);
    fprintf(f, "omp_max_threads=%d OMP_NUM_THREADS=%s OMP_THREAD_LIMIT=%s OMP_DYNAMIC=%s OMP_PLACES=%s OMP_PROC_BIND=%s\n",
            omp_get_max_threads(),
            getenv("OMP_NUM_THREADS") ? getenv("OMP_NUM_THREADS") : "(unset)",
            getenv("OMP_THREAD_LIMIT") ? getenv("OMP_THREAD_LIMIT") : "(unset)",
            getenv("OMP_DYNAMIC") ? getenv("OMP_DYNAMIC") : "(unset)",
            getenv("OMP_PLACES") ? getenv("OMP_PLACES") : "(unset)",
            getenv("OMP_PROC_BIND") ? getenv("OMP_PROC_BIND") : "(unset)");
    struct rlimit rl;
    if (getrlimit(RLIMIT_NPROC, &rl) == 0)
        fprintf(f, "RLIMIT_NPROC cur=%llu max=%llu\n",
                (unsigned long long)rl.rlim_cur, (unsigned long long)rl.rlim_max);
    FILE *s = fopen("/proc/self/status", "r");
    if (s) {
        char line[512];
        while (fgets(line, 512, s))
            if (strncmp(line, "Threads", 7) == 0 || strncmp(line, "VmPeak", 6) == 0 ||
                strncmp(line, "VmSize", 6) == 0 || strncmp(line, "Cpus_allowed_list", 17) == 0)
                fprintf(f, "status: %s", line);
        fclose(s);
    }
    /* pthread probe: try to create 14 worker threads */
    int created = 0;
    int lasterr = 0;
    pthread_t th[14];
    for (int i = 0; i < 14; ++i) {
        if (pthread_create(&th[i], 0, noop_thr, 0) == 0) created++;
        else { lasterr = errno; break; }
    }
    fprintf(f, "pthread_probe created=%d/14 lasterr=%d\n", created, lasterr);
    for (int i = 0; i < created; ++i) pthread_join(th[i], 0);
    fflush(f);
    fclose(f);
}

void tsvc_2_s316_fp64(const double *restrict a, double *restrict result,
                      const int64_t LEN_1D, uint8_t *restrict workspace,
                      const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    double x = a[0];
    for (int64_t i = 1; i < LEN_1D; ++i) {
        if (a[i] < x) {
            x = a[i];
        }
    }
    result[0] = x;
    diag_dump("serial-done", a, LEN_1D, workspace, workspace_size, x);
}
