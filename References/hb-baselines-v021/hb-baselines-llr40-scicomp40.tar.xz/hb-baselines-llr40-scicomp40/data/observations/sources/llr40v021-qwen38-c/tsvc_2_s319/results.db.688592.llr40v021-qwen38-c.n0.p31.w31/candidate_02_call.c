#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#if defined(__AVX2__)
#include <immintrin.h>
#endif

void tsvc_2_s319_fp64(
    double *restrict a,
    double *restrict b,
    const double *restrict c,
    const double *restrict d,
    const double *restrict e,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    int64_t n = LEN_1D;
    if (n <= 0) return;

#if defined(__AVX2__)
    if (((uintptr_t)a & 31) == 0 && ((uintptr_t)b & 31) == 0) {
        int nt = omp_get_max_threads();
        if (nt < 1) nt = 1;
        double *part = (double *)malloc((size_t)nt * sizeof(double));
        #pragma omp parallel num_threads(nt)
        {
            int tid = omp_get_thread_num();
            int64_t per = n / nt, rem = n % nt;
            int64_t s = (int64_t)tid * per + (tid < rem ? tid : rem);
            int64_t en = s + per + (tid < rem ? 1 : 0);
            double total = 0.0;
            int64_t i = s;
            /* scalar prefix until a+i is 32-byte aligned (a is 32-aligned, so i%4==0) */
            while (i + 4 <= en && (i & 3)) {
                double ai = c[i] + d[i]; a[i] = ai;
                double bi = c[i] + e[i]; b[i] = bi;
                total += ai; total += bi; i++;
            }
            for (; i + 4 <= en; i += 4) {
                __m256d vc = _mm256_loadu_pd(c + i), vd = _mm256_loadu_pd(d + i), ve = _mm256_loadu_pd(e + i);
                __m256d va = _mm256_add_pd(vc, vd), vb = _mm256_add_pd(vc, ve);
                _mm256_stream_pd(a + i, va);
                _mm256_stream_pd(b + i, vb);
                __m256d sv = _mm256_add_pd(va, vb);
                double tmp[4];
                _mm256_storeu_pd(tmp, sv);
                total += tmp[0] + tmp[1] + tmp[2] + tmp[3];
            }
            for (; i < en; i++) {
                double ai = c[i] + d[i]; a[i] = ai;
                double bi = c[i] + e[i]; b[i] = bi;
                total += ai; total += bi;
            }
            part[tid] = total;
        }
        double t = part[0];
        for (int k = 1; k < nt; k++) t += part[k];
        b[0] = t;
        free(part);
        return;
    }
#endif
    double total = 0.0;
    #pragma omp parallel for schedule(static) reduction(+:total)
    for (int64_t i = 0; i < n; ++i) {
        double ai = c[i] + d[i]; a[i] = ai;
        double bi = c[i] + e[i]; b[i] = bi;
        total += ai; total += bi;
    }
    b[0] = total;
}
