/* v13: v9 body (array+pragma U8 ascending, -O3-safe) + barrier-free
   interval waits: both bottom and top owner waits precede the work;
   flags set at level end. Backward-only or forward-only per level. */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <stdatomic.h>
#include <stdatomic.h>

static _Atomic long bar_cnt;
static _Atomic long bar_epoch;

static inline void fast_barrier(int P) {
    long t = atomic_fetch_add_explicit(&bar_cnt, 1, memory_order_relaxed);
    long e = t / P;
    if (t == (e + 1) * P - 1)
        atomic_store_explicit(&bar_epoch, e + 1, memory_order_release);
    while (atomic_load_explicit(&bar_epoch, memory_order_acquire) <= e) {
#if defined(__x86_64__)
        __builtin_ia32_pause();
#endif
    }
}

#define MAXP 8
static _Atomic long fl[MAXP][2];

void wf_triangular_fp64(double *restrict a, const int64_t LEN_2D,
                        uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace; (void)workspace_size;
    /* 4 threads is the measured optimum; libgomp clamps to the env max */
    omp_set_num_threads(4);
    const int64_t N = LEN_2D;
    if (N < 2) return;
    const double c = 1.0 / 3.0;
    for (int p = 0; p < MAXP; ++p)
        for (int q = 0; q < 2; ++q)
            atomic_store_explicit(&fl[p][q], 0, memory_order_relaxed);
    #pragma omp parallel
    {
        const int P = omp_get_num_threads();
        const int tid = omp_get_thread_num();
        int64_t lo_prev = -1, cnt_prev = -1, ilo_prev = -1, hi_prev = -1, ihi_prev = -1;
        for (int64_t s = 2; s <= 2 * N - 2; ++s) {
            int64_t ilo = s - N + 1; if (ilo < 1) ilo = 1;
            int64_t ihi = s / 2;      if (ihi > N - 1) ihi = N - 1;
            const int64_t W = ihi - ilo + 1;
            if (W > 0) {
                const int64_t cnt = (W + P - 1) / P;
                const int64_t lo = ilo + (int64_t)tid * cnt;
                int64_t hi = lo + cnt;
                if (hi > ihi + 1) hi = ihi + 1;
                int top_o[8], ntop = 0, bot_o[8], nbot = 0;
                if (s >= 3 && lo < hi) {
                    int last = -1;
                    int64_t r = hi_prev, re = hi - 1;
                    if (re > ihi_prev) re = ihi_prev;
                    for (; r <= re; ++r) {
                        int o = (int)((r - ilo_prev) / cnt_prev);
                        if (o != last) { last = o; top_o[ntop++] = o; }
                    }
                    r = lo - 1;
                    re = lo_prev - 1; if (re > hi - 1) re = hi - 1;
                    if (r < ilo_prev) r = ilo_prev;
                    last = -1;
                    for (; r <= re; ++r) {
                        int o = (int)((r - ilo_prev) / cnt_prev);
                        if (o != last) { last = o; bot_o[nbot++] = o; }
                    }
                }
                if (lo < hi) {
                    const int64_t str = N - 1;
                    int64_t idx = lo * N + (s - lo);
                    int64_t i = lo;
                    for (int k = 0; k < nbot; ++k) {
                        while (atomic_load_explicit(&fl[bot_o[k]][(s - 1) & 1], memory_order_acquire) < s - 1) {
#if defined(__x86_64__)
                            __builtin_ia32_pause();
#endif
                        }
                    }
                    for (int k = 0; k < ntop; ++k) {
                        while (atomic_load_explicit(&fl[top_o[k]][(s - 1) & 1], memory_order_acquire) < s - 1) {
#if defined(__x86_64__)
                            __builtin_ia32_pause();
#endif
                        }
                    }
                    for (; i + 7 < hi; i += 8, idx += 8 * str) {
                        double y[8], x[8], z[8];
                        #pragma GCC unroll 8
                        for (int k = 0; k < 8; ++k) y[k] = a[idx + k*str - N];
                        #pragma GCC unroll 8
                        for (int k = 0; k < 8; ++k) x[k] = a[idx + k*str];
                        #pragma GCC unroll 8
                        for (int k = 0; k < 8; ++k) z[k] = a[idx + k*str - 1];
                        #pragma GCC unroll 8
                        for (int k = 0; k < 8; ++k) a[idx + k*str] = (x[k] + y[k] + z[k]) * c;
                    }
                    for (; i < hi; ++i, idx += str) {
                        const double x = a[idx];
                        const double y = a[idx - N];
                        const double z = a[idx - 1];
                        a[idx] = (x + y + z) * c;
                    }
                }
                atomic_store_explicit(&fl[tid][s & 1], s, memory_order_release);
                lo_prev = lo; cnt_prev = cnt; ilo_prev = ilo; hi_prev = hi; ihi_prev = ihi;
            }
        }
    }
}
