/* TSVC tsvc_2 s233 -- optimized (v3b).
 *
 * Semantics (bit-identical to the serial reference):
 *   for i in 8..N-1:
 *     for j in 8..N-1: aa[j,i] = aa[j-1,i] + cc[j,i]
 *     for j in 8..N-1: bb[j,i] = bb[j,i-1] + cc[j,i]
 *
 * Parallelization:
 *   - aa: independent per column. Each worker owns 16 adjacent columns = two
 *     8-wide chains kept in registers (vectorized). 16 cols = 128B so every
 *     cache line touched is touched twice by the same thread (L1 reuse) even
 *     when rows are unaligned (odd N).
 *   - bb: independent per row. Workers own whole rows, scanning left to right.
 *   - The phases touch disjoint arrays, so they run as two loops in one team.
 *
 * Stores: non-temporal (no RFO of written lines; written rows are never
 * re-read -- scan values live in registers). Alignment-class dispatch keeps
 * the 16/32/64B NT stores legal at any row offset; 8B edges use plain stores.
 */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if defined(__AVX512F__)
#include <immintrin.h>
#define KFAST 1
#elif defined(__AVX2__)
#include <immintrin.h>
#define KFAST 1
#else
#define KFAST 0
#endif

#if defined(__AVX512F__)
static inline void ntwin16(double *dst, const double *t) {
    unsigned off = (unsigned)(uintptr_t)dst & 63u;
    if (off == 0) {
        _mm512_stream_pd(dst,     _mm512_loadu_pd(t));
        _mm512_stream_pd(dst + 8, _mm512_loadu_pd(t + 8));
    } else if (off == 32) {
        _mm256_stream_pd(dst,      _mm256_loadu_pd(t));
        _mm512_stream_pd(dst + 4,  _mm512_loadu_pd(t + 4));
        _mm256_stream_pd(dst + 12, _mm256_loadu_pd(t + 12));
    } else if ((off & 15) == 0) {
        for (int k = 0; k < 8; ++k)
            _mm_stream_pd(dst + 2 * k, _mm_loadu_pd(t + 2 * k));
    } else {
        /* 8B-misaligned: plain stores (keep the window NT-free / plain-only) */
        _mm512_storeu_pd(dst,      _mm512_loadu_pd(t));
        _mm512_storeu_pd(dst + 8,  _mm512_loadu_pd(t + 8));
    }
}
#endif

#if KFAST
void tsvc_2_s233_fp64(
    double *restrict aa,
    double *restrict bb,
    const double *restrict cc,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    const int64_t N = LEN_2D;
    if (N <= 8) return;

    const int64_t ncol = N - 8;
    const int64_t nw16 = ncol / 16;
    const int64_t rem  = ncol - nw16 * 16;

#pragma omp parallel
    {
        /* ---------------- phase 1: aa (per-column down-scan) ------------- */
#pragma omp for schedule(static, 1)
        for (int64_t u = 0; u < nw16 + rem; ++u) {
            if (u < nw16) {
#if defined(__AVX512F__)
                const int64_t i0 = 8 + 16 * u;
                __m512d rA = _mm512_loadu_pd(aa + (size_t)7 * N + i0);
                __m512d rB = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 8);
                double tmp[16];
                for (int64_t j = 8; j < N; ++j) {
                    rA = _mm512_add_pd(rA, _mm512_loadu_pd(cc + (size_t)j * N + i0));
                    rB = _mm512_add_pd(rB, _mm512_loadu_pd(cc + (size_t)j * N + i0 + 8));
                    _mm512_storeu_pd(tmp, rA);
                    _mm512_storeu_pd(tmp + 8, rB);
                    ntwin16(aa + (size_t)j * N + i0, tmp);
                }
#else
                const int64_t i0 = 8 + 16 * u;
                const double *cA = cc + (size_t)7 * N + i0;
                const double *cB = cc + (size_t)7 * N + i0 + 8;
                const double *a7 = aa + (size_t)7 * N + i0;
                double *aA       = aa + (size_t)7 * N + i0;
                double *aB       = aa + (size_t)7 * N + i0 + 8;
                double r0 = a7[0], r1 = a7[1], r2 = a7[2], r3 = a7[3];
                double r4 = a7[4], r5 = a7[5], r6 = a7[6], r7 = a7[7];
                double s0 = a7[8], s1 = a7[9], s2 = a7[10], s3 = a7[11];
                double s4 = a7[12], s5 = a7[13], s6 = a7[14], s7 = a7[15];
                for (int64_t j = 8; j < N; ++j) {
                    cA += N; cB += N;
                    aA += N; aB += N;
                    r0 += cA[0]; r1 += cA[1]; r2 += cA[2]; r3 += cA[3];
                    r4 += cA[4]; r5 += cA[5]; r6 += cA[6]; r7 += cA[7];
                    s0 += cB[0]; s1 += cB[1]; s2 += cB[2]; s3 += cB[3];
                    s4 += cB[4]; s5 += cB[5]; s6 += cB[6]; s7 += cB[7];
                    aA[0] = r0; aA[1] = r1; aA[2] = r2; aA[3] = r3;
                    aA[4] = r4; aA[5] = r5; aA[6] = r6; aA[7] = r7;
                    aB[0] = s0; aB[1] = s1; aB[2] = s2; aB[3] = s3;
                    aB[4] = s4; aB[5] = s5; aB[6] = s6; aB[7] = s7;
                }
#endif
            } else {
                const int64_t i0c = 8 + nw16 * 16 + (u - nw16); /* leftover column */
                double r = aa[(size_t)7 * N + i0c];
                for (int64_t j = 8; j < N; ++j) {
                    r += cc[(size_t)j * N + i0c];
                    aa[(size_t)j * N + i0c] = r;
                }
            }
        }

        /* ---------------- phase 2: bb (per-row left-to-right scan) ------- */
#pragma omp for schedule(static, 1)
        for (int64_t j = 8; j < N; ++j) {
            double *brow  = bb + (size_t)j * N;
            const double *crown = cc + (size_t)j * N;
            double r = brow[7];
            int64_t i = 8;
#if defined(__AVX512F__)
            unsigned off = (unsigned)((size_t)j * N * 8 + 64) & 31u;
            if (off == 0) {
                for (; i + 3 < N; i += 4) {
                    double r0 = r + crown[i];
                    double r1 = r0 + crown[i + 1];
                    double r2 = r1 + crown[i + 2];
                    double r3 = r2 + crown[i + 3];
                    double t4[4] = {r0, r1, r2, r3};
                    _mm256_stream_pd(brow + i, _mm256_loadu_pd(t4));
                    r = r3;
                }
            } else if (off == 16) {
                for (; i + 3 < N; i += 4) {
                    double r0 = r + crown[i];
                    double r1 = r0 + crown[i + 1];
                    double r2 = r1 + crown[i + 2];
                    double r3 = r2 + crown[i + 3];
                    double t2a[2] = {r0, r1}, t2b[2] = {r2, r3};
                    _mm_stream_pd(brow + i, _mm_loadu_pd(t2a));
                    _mm_stream_pd(brow + i + 2, _mm_loadu_pd(t2b));
                    r = r3;
                }
            } else {
                /* 8B-misaligned: plain-only window */
                for (; i + 3 < N; i += 4) {
                    double r0 = r + crown[i];
                    double r1 = r0 + crown[i + 1];
                    double r2 = r1 + crown[i + 2];
                    double r3 = r2 + crown[i + 3];
                    double t4[4] = {r0, r1, r2, r3};
                    _mm256_storeu_pd(brow + i, _mm256_loadu_pd(t4));
                    r = r3;
                }
            }
#endif
            for (; i + 3 < N; i += 4) {
                double r0 = r + crown[i];
                double r1 = r0 + crown[i + 1];
                double r2 = r1 + crown[i + 2];
                double r3 = r2 + crown[i + 3];
                brow[i] = r0; brow[i + 1] = r1;
                brow[i + 2] = r2; brow[i + 3] = r3;
                r = r3;
            }
            for (; i < N; ++i) {
                r = r + crown[i];
                brow[i] = r;
            }
        }
        _mm_sfence();
    }
}
#else
void tsvc_2_s233_fp64(
    double *restrict aa,
    double *restrict bb,
    const double *restrict cc,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    const int64_t N = LEN_2D;
    if (N <= 8) return;

    const int64_t ncol = N - 8;
    const int64_t nw16 = ncol / 16;
    const int64_t rem  = ncol - nw16 * 16;

#pragma omp parallel
    {
#pragma omp for schedule(static, 1)
        for (int64_t u = 0; u < nw16 + rem; ++u) {
            if (u < nw16) {
                const int64_t i0 = 8 + 16 * u;
                const double *cA = cc + (size_t)7 * N + i0;
                const double *cB = cc + (size_t)7 * N + i0 + 8;
                const double *a7 = aa + (size_t)7 * N + i0;
                double *aA       = aa + (size_t)7 * N + i0;
                double *aB       = aa + (size_t)7 * N + i0 + 8;
                double r0 = a7[0], r1 = a7[1], r2 = a7[2], r3 = a7[3];
                double r4 = a7[4], r5 = a7[5], r6 = a7[6], r7 = a7[7];
                double s0 = a7[8], s1 = a7[9], s2 = a7[10], s3 = a7[11];
                double s4 = a7[12], s5 = a7[13], s6 = a7[14], s7 = a7[15];
                for (int64_t j = 8; j < N; ++j) {
                    cA += N; cB += N;
                    aA += N; aB += N;
                    r0 += cA[0]; r1 += cA[1]; r2 += cA[2]; r3 += cA[3];
                    r4 += cA[4]; r5 += cA[5]; r6 += cA[6]; r7 += cA[7];
                    s0 += cB[0]; s1 += cB[1]; s2 += cB[2]; s3 += cB[3];
                    s4 += cB[4]; s5 += cB[5]; s6 += cB[6]; s7 += cB[7];
                    aA[0] = r0; aA[1] = r1; aA[2] = r2; aA[3] = r3;
                    aA[4] = r4; aA[5] = r5; aA[6] = r6; aA[7] = r7;
                    aB[0] = s0; aB[1] = s1; aB[2] = s2; aB[3] = s3;
                    aB[4] = s4; aB[5] = s5; aB[6] = s6; aB[7] = s7;
                }
            } else {
                const int64_t i0c = 8 + nw16 * 16 + (u - nw16);
                double r = aa[(size_t)7 * N + i0c];
                for (int64_t j = 8; j < N; ++j) {
                    r += cc[(size_t)j * N + i0c];
                    aa[(size_t)j * N + i0c] = r;
                }
            }
        }

#pragma omp for schedule(static, 1)
        for (int64_t j = 8; j < N; ++j) {
            double *brow  = bb + (size_t)j * N;
            const double *crown = cc + (size_t)j * N;
            double r = brow[7];
            int64_t i = 8;
            for (; i + 3 < N; i += 4) {
                double r0 = r + crown[i];
                double r1 = r0 + crown[i + 1];
                double r2 = r1 + crown[i + 2];
                double r3 = r2 + crown[i + 3];
                brow[i] = r0; brow[i + 1] = r1;
                brow[i + 2] = r2; brow[i + 3] = r3;
                r = r3;
            }
            for (; i < N; ++i) {
                r = r + crown[i];
                brow[i] = r;
            }
        }
    }
}
#endif
