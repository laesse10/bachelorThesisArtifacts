/* Hand port of the TSVC tsvc_2_5 C++ microkernel ``quasi_affine_reduce_odd`` (quasi_affine_reduce_odd_d.cpp), fp64
 * single-invocation variant, to C23 under the v2 C-ABI.
 *
 * Part of the TSVC-2.5 extension, written by SPCL (ETH Zurich) for HPCAgent-Bench; the loop
 * pattern is derived from TSVC_2 (github.com/UoB-HPC/TSVC_2).
 *
 * DELIBERATELY CARRIES NO ``hpcagent_bench-autogen`` MARKER. emit_io treats an unmarked
 * reference as a hand-written override and never regenerates it, which is the point: this
 * corpus exists to ask whether compilers vectorize and parallelize human-written C where they
 * fail on translator-generated C. Regenerating this file from the numpy reference would compare
 * translator output against translator output and answer nothing. Edit it by hand, never
 * through the emitter.
 *
 * The numpy reference remains the correctness oracle. */

#include <stdint.h>

void quasi_affine_reduce_odd_fp64(const double *restrict a, double *restrict out, const int64_t LEN_1D) {
  double acc = 0.0;
  for (int64_t i = 1; i < LEN_1D; i += 2) {
    acc += a[i];
  }
  out[0] = acc;
}
