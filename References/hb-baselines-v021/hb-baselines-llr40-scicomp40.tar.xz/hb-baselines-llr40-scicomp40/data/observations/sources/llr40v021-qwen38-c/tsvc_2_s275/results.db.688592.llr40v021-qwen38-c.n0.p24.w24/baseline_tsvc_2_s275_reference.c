/* Hand port of the TSVC tsvc_2 C++ microkernel ``s275`` (s275_d_single.cpp), fp64
 * single-invocation variant, to C23 under the v2 C-ABI.
 *
 * Adapted from TSVC_2 -- Test Suite for Vectorizing Compilers (github.com/UoB-HPC/TSVC_2),
 * NCSA/MIT license (UIUC).
 *
 * DELIBERATELY CARRIES NO ``hpcagent_bench-autogen`` MARKER. emit_io treats an unmarked
 * reference as a hand-written override and never regenerates it, which is the point: this
 * corpus exists to ask whether compilers vectorize and parallelize human-written C where they
 * fail on translator-generated C. Regenerating this file from the numpy reference would compare
 * translator output against translator output and answer nothing. Edit it by hand, never
 * through the emitter.
 *
 * The numpy reference remains the correctness oracle. */

#include <stdint.h>

void tsvc_2_s275_fp64(double *restrict aa, const double *restrict bb, const double *restrict cc, const int64_t LEN_2D) {

  for (int64_t i = 0; i < LEN_2D; i++) {
    if (aa[i] > 0.0) {
      for (int64_t j = 1; j < LEN_2D; j++) {
        aa[j * LEN_2D + i] = aa[(j - 1) * LEN_2D + i] + bb[j * LEN_2D + i] * cc[j * LEN_2D + i];
      }
    }
  }
}
