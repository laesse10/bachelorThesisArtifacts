#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if defined(__AVX512F__) && defined(__AVX512BW__) && defined(__AVX512DQ__) && \
    (defined(__AVX512_VPOPCNTDQ__) || defined(__AVX512VPOPCNTDQ__))
#define K_USE_AVX512 1
#include <immintrin.h>
#else
#define K_USE_AVX512 0
#endif

#define K_MAX_THREADS 16

static inline int64_t k_scalar(const double *restrict src, const double *restrict weight,
                               double *restrict packed, int64_t n, int64_t base)
{
    int64_t cur = base;
    for (int64_t i = 0; i < n; i++) {
        if (src[i] > 0.0)
            packed[cur++] = src[i] * weight[i];
    }
    return cur - base;
}

#if K_USE_AVX512

static inline __mmask8 k_flag8(const double *restrict src)
{
    const __m512d zero = _mm512_setzero_pd();
    __m512d sv = _mm512_loadu_pd(src);
    return _mm512_cmp_pd_mask(sv, zero, _CMP_GT_OQ);
}

/* scatter/store one chunk; f known nonzero by caller */
static inline void k_put8(const __m512d sv, const double *restrict weight,
                          double *restrict packed, int64_t o, __mmask8 f)
{
    const __m512i pm = _mm512_setr_epi32(0, 1, 3, 7, 15, 31, 63, 127,
                                         0, 1, 3, 7, 15, 31, 63, 127);
    __m512d w = _mm512_loadu_pd(weight);
    __m512d prod = _mm512_mul_pd(sv, w);
    if (f == 0xff) {
        _mm512_storeu_pd(packed + o, prod);
        return;
    }
    const __m512i frep = _mm512_set1_epi32((int)f);
    __m512i excl = _mm512_popcnt_epi32(_mm512_and_si512(frep, pm));
    __m256i idx = _mm256_add_epi32(_mm512_castsi512_si256(excl),
                                   _mm256_set1_epi32((int)o));
    _mm512_mask_i32scatter_pd(packed, f, idx, prod, 8);
}

/* 4 chunks using stored flags: skip src loads entirely when a chunk is empty */
static inline int k_scatter32f(uint32_t f4, const double *restrict src,
                               const double *restrict weight,
                               double *restrict packed, int64_t base)
{
    const __mmask8 f0 = (__mmask8)(f4 & 0xffu);
    const __mmask8 f1 = (__mmask8)((f4 >> 8) & 0xffu);
    const __mmask8 f2 = (__mmask8)((f4 >> 16) & 0xffu);
    const __mmask8 f3 = (__mmask8)((f4 >> 24) & 0xffu);
    if (!(f0 | f1 | f2 | f3))
        return 0;
    const int n0 = __builtin_popcountl((unsigned)f0);
    const int n1 = __builtin_popcountl((unsigned)f1);
    const int n2 = __builtin_popcountl((unsigned)f2);
    const int n3 = __builtin_popcountl((unsigned)f3);
    const int64_t o0 = base;
    const int64_t o1 = o0 + n0;
    const int64_t o2 = o1 + n1;
    const int64_t o3 = o2 + n2;
    __m512d s0 = _mm512_maskz_loadu_pd(f0, src + 0);
    __m512d s1 = _mm512_maskz_loadu_pd(f1, src + 8);
    __m512d s2 = _mm512_maskz_loadu_pd(f2, src + 16);
    __m512d s3 = _mm512_maskz_loadu_pd(f3, src + 24);
    if (f0) k_put8(s0, weight + 0, packed, o0, f0);
    if (f1) k_put8(s1, weight + 8, packed, o1, f1);
    if (f2) k_put8(s2, weight + 16, packed, o2, f2);
    if (f3) k_put8(s3, weight + 24, packed, o3, f3);
    return n0 + n1 + n2 + n3;
}

/* 4 chunks, no flags: compare-based, prefetch-gate out via *hot */
static inline int k_scatter32(const double *restrict src, const double *restrict weight,
                              double *restrict packed, int64_t base, int *hot)
{
    const __m512d zero = _mm512_setzero_pd();
    __m512d s0 = _mm512_loadu_pd(src + 0);
    __m512d s1 = _mm512_loadu_pd(src + 8);
    __m512d s2 = _mm512_loadu_pd(src + 16);
    __m512d s3 = _mm512_loadu_pd(src + 24);
    __mmask8 f0 = _mm512_cmp_pd_mask(s0, zero, _CMP_GT_OQ);
    __mmask8 f1 = _mm512_cmp_pd_mask(s1, zero, _CMP_GT_OQ);
    __mmask8 f2 = _mm512_cmp_pd_mask(s2, zero, _CMP_GT_OQ);
    __mmask8 f3 = _mm512_cmp_pd_mask(s3, zero, _CMP_GT_OQ);
    const int n0 = __builtin_popcountl((unsigned)f0);
    const int n1 = __builtin_popcountl((unsigned)f1);
    const int n2 = __builtin_popcountl((unsigned)f2);
    const int n3 = __builtin_popcountl((unsigned)f3);
    const int64_t o0 = base;
    const int64_t o1 = o0 + n0;
    const int64_t o2 = o1 + n1;
    const int64_t o3 = o2 + n2;
    *hot = (int)(f0 | f1 | f2 | f3);
    if (f0) k_put8(s0, weight + 0, packed, o0, f0);
    if (f1) k_put8(s1, weight + 8, packed, o1, f1);
    if (f2) k_put8(s2, weight + 16, packed, o2, f2);
    if (f3) k_put8(s3, weight + 24, packed, o3, f3);
    return n0 + n1 + n2 + n3;
}

static inline int k_scatter1(const double *restrict src, const double *restrict weight,
                             double *restrict packed, int64_t base)
{
    __mmask8 f = k_flag8(src);
    if (f == 0)
        return 0;
    k_put8(_mm512_loadu_pd(src), weight, packed, base, f);
    return __builtin_popcountl((unsigned)f);
}
#endif

void compact_threshold_pack_fp64(
    int64_t *restrict out_count,
    double *restrict packed,
    const double *restrict src,
    const double *restrict weight,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    if (LEN_1D <= 0) {
        *out_count = 0;
        return;
    }

    long nt = K_MAX_THREADS;
    long maxt = (long)omp_get_max_threads();
    if (nt > maxt) nt = maxt;
    if (nt < 1) nt = 1;

    const int64_t nch = LEN_1D / 8;
    const int64_t tail = LEN_1D & 7;

#if K_USE_AVX512
    uint8_t *fl = (workspace && workspace_size >= nch && nch > 0) ? workspace : NULL;
#else
    (void)workspace;
    (void)workspace_size;
    uint8_t *fl = NULL;
#endif

    if (nt == 1) {
        int64_t off = 0;
#if K_USE_AVX512
        int hot = 0;
        int64_t c = 0;
        for (; c + 4 <= nch; c += 4) {
            if (hot && c + 20 < nch) {
                __builtin_prefetch(src + (c + 16) * 8, 0, 1);
                __builtin_prefetch(weight + (c + 16) * 8, 0, 1);
                __builtin_prefetch(src + (c + 20) * 8, 0, 1);
                __builtin_prefetch(weight + (c + 20) * 8, 0, 1);
            }
            off += k_scatter32(src + c * 8, weight + c * 8, packed, off, &hot);
        }
        for (; c < nch; c++)
            off += k_scatter1(src + c * 8, weight + c * 8, packed, off);
        if (tail)
            off += k_scalar(src + nch * 8, weight + nch * 8, packed, tail, off);
#else
        off += k_scalar(src, weight, packed, LEN_1D, 0);
#endif
        *out_count = off;
        return;
    }

    /* G round-robin sub-spans per thread, one barrier total */
    long G = 1 + (140 / nt);
    const int64_t S = G * nt;
    const int64_t nsub0 = nch / S; /* chunks per sub-span */
    int64_t *scnt = (int64_t *)__builtin_malloc(sizeof(int64_t) * (size_t)S);
    int64_t total = 0;
    #pragma omp parallel num_threads((int)nt) reduction(+:total)
    {
        const long t = omp_get_thread_num();
        const long nt2 = omp_get_num_threads();
        int64_t off_all = 0;

        /* stage 1: count each sub-span (and store flags if we have workspace) */
        for (long g = 0; g < G; g++) {
            const int64_t m = t + g * nt2;
            const int64_t clo = m * nsub0;
            const int64_t chi = (m == S - 1) ? nch : (m + 1) * nsub0;
            int64_t cnt = 0;
#if K_USE_AVX512
            int64_t c = clo;
            for (; c + 16 <= chi; c += 16) {
                if (c + 32 < chi) {
                    for (int i = 16; i < 32; i++)
                        __builtin_prefetch(src + (c + i) * 8, 0, 1);
                }
                __mmask8 f8[16];
                f8[0] = k_flag8(src + c * 8);
                f8[1] = k_flag8(src + (c + 1) * 8);
                f8[2] = k_flag8(src + (c + 2) * 8);
                f8[3] = k_flag8(src + (c + 3) * 8);
                f8[4] = k_flag8(src + (c + 4) * 8);
                f8[5] = k_flag8(src + (c + 5) * 8);
                f8[6] = k_flag8(src + (c + 6) * 8);
                f8[7] = k_flag8(src + (c + 7) * 8);
                f8[8] = k_flag8(src + (c + 8) * 8);
                f8[9] = k_flag8(src + (c + 9) * 8);
                f8[10] = k_flag8(src + (c + 10) * 8);
                f8[11] = k_flag8(src + (c + 11) * 8);
                f8[12] = k_flag8(src + (c + 12) * 8);
                f8[13] = k_flag8(src + (c + 13) * 8);
                f8[14] = k_flag8(src + (c + 14) * 8);
                f8[15] = k_flag8(src + (c + 15) * 8);
                int acc = __builtin_popcountl((unsigned)f8[0]) +
                          __builtin_popcountl((unsigned)f8[1]) +
                          __builtin_popcountl((unsigned)f8[2]) +
                          __builtin_popcountl((unsigned)f8[3]) +
                          __builtin_popcountl((unsigned)f8[4]) +
                          __builtin_popcountl((unsigned)f8[5]) +
                          __builtin_popcountl((unsigned)f8[6]) +
                          __builtin_popcountl((unsigned)f8[7]) +
                          __builtin_popcountl((unsigned)f8[8]) +
                          __builtin_popcountl((unsigned)f8[9]) +
                          __builtin_popcountl((unsigned)f8[10]) +
                          __builtin_popcountl((unsigned)f8[11]) +
                          __builtin_popcountl((unsigned)f8[12]) +
                          __builtin_popcountl((unsigned)f8[13]) +
                          __builtin_popcountl((unsigned)f8[14]) +
                          __builtin_popcountl((unsigned)f8[15]);
                cnt += acc;
                if (fl) {
                    uint64_t w0 = (uint64_t)(unsigned int)f8[0] |
                                 ((uint64_t)(unsigned int)f8[1] << 8) |
                                 ((uint64_t)(unsigned int)f8[2] << 16) |
                                 ((uint64_t)(unsigned int)f8[3] << 24) |
                                 ((uint64_t)(unsigned int)f8[4] << 32) |
                                 ((uint64_t)(unsigned int)f8[5] << 40) |
                                 ((uint64_t)(unsigned int)f8[6] << 48) |
                                 ((uint64_t)(unsigned int)f8[7] << 56);
                    *(uint64_t *)(fl + c) = w0;
                }
                if (fl) {
                    uint64_t w1 = (uint64_t)(unsigned int)f8[8] |
                                 ((uint64_t)(unsigned int)f8[9] << 8) |
                                 ((uint64_t)(unsigned int)f8[10] << 16) |
                                 ((uint64_t)(unsigned int)f8[11] << 24) |
                                 ((uint64_t)(unsigned int)f8[12] << 32) |
                                 ((uint64_t)(unsigned int)f8[13] << 40) |
                                 ((uint64_t)(unsigned int)f8[14] << 48) |
                                 ((uint64_t)(unsigned int)f8[15] << 56);
                    *(uint64_t *)(fl + c + 8) = w1;
                }
            }
            for (; c + 8 <= chi; c += 8) {
                if (c + 16 < chi)
                    __builtin_prefetch(src + (c + 8) * 8, 0, 1);
                __mmask8 f8[8];
                f8[0] = k_flag8(src + c * 8);
                f8[1] = k_flag8(src + (c + 1) * 8);
                f8[2] = k_flag8(src + (c + 2) * 8);
                f8[3] = k_flag8(src + (c + 3) * 8);
                f8[4] = k_flag8(src + (c + 4) * 8);
                f8[5] = k_flag8(src + (c + 5) * 8);
                f8[6] = k_flag8(src + (c + 6) * 8);
                f8[7] = k_flag8(src + (c + 7) * 8);
                int acc = __builtin_popcountl((unsigned)f8[0]) +
                          __builtin_popcountl((unsigned)f8[1]) +
                          __builtin_popcountl((unsigned)f8[2]) +
                          __builtin_popcountl((unsigned)f8[3]) +
                          __builtin_popcountl((unsigned)f8[4]) +
                          __builtin_popcountl((unsigned)f8[5]) +
                          __builtin_popcountl((unsigned)f8[6]) +
                          __builtin_popcountl((unsigned)f8[7]);
                cnt += acc;
                if (fl) {
                    uint64_t w = (uint64_t)(unsigned int)f8[0] |
                                 ((uint64_t)(unsigned int)f8[1] << 8) |
                                 ((uint64_t)(unsigned int)f8[2] << 16) |
                                 ((uint64_t)(unsigned int)f8[3] << 24) |
                                 ((uint64_t)(unsigned int)f8[4] << 32) |
                                 ((uint64_t)(unsigned int)f8[5] << 40) |
                                 ((uint64_t)(unsigned int)f8[6] << 48) |
                                 ((uint64_t)(unsigned int)f8[7] << 56);
                    *(uint64_t *)(fl + c) = w;
                }
            }
            for (; c < chi; c++) {
                __mmask8 f = k_flag8(src + c * 8);
                if (fl)
                    fl[c] = (uint8_t)(unsigned int)f;
                cnt += __builtin_popcountl((unsigned)f);
            }
#else
            for (int64_t i = clo * 8; i < chi * 8; i++)
                cnt += (src[i] > 0.0);
#endif
            scnt[m] = cnt;
        }

        #pragma omp barrier
        {
            /* stage 2: scatter each sub-span with its global base */
            for (long g = 0; g < G; g++) {
                const int64_t m = t + g * nt2;
                const int64_t clo = m * nsub0;
                const int64_t chi = (m == S - 1) ? nch : (m + 1) * nsub0;
                int64_t base = 0;
                for (int64_t j = 0; j < m; j++)
                    base += scnt[j];
                int64_t off = 0;
#if K_USE_AVX512
                if (fl) {
                    int64_t c = clo;
                    for (; c + 4 <= chi; c += 4) {
                        uint32_t f4 = *(const uint32_t *)(fl + c);
                        if (f4) {
                            if (c + 20 < chi) {
                                uint32_t ff = *(const uint32_t *)(fl + c + 16);
                                if (ff) {
                                    __builtin_prefetch(src + (c + 16) * 8, 0, 1);
                                    __builtin_prefetch(weight + (c + 16) * 8, 0, 1);
                                    if (c + 20 < chi) {
                                        uint32_t ff2 = *(const uint32_t *)(fl + c + 20);
                                        if (ff2) {
                                            __builtin_prefetch(src + (c + 20) * 8, 0, 1);
                                            __builtin_prefetch(weight + (c + 20) * 8, 0, 1);
                                        }
                                    }
                                }
                            }
                            off += k_scatter32f(f4, src + c * 8, weight + c * 8,
                                                packed, base + off);
                        }
                    }
                    for (; c < chi; c++)
                        if (fl[c])
                            off += k_scatter1(src + c * 8, weight + c * 8, packed, base + off);
                } else {
                    int hot = 0;
                    int64_t c = clo;
                    for (; c + 4 <= chi; c += 4) {
                        if (hot && c + 20 < chi) {
                            __builtin_prefetch(src + (c + 16) * 8, 0, 1);
                            __builtin_prefetch(weight + (c + 16) * 8, 0, 1);
                            __builtin_prefetch(src + (c + 20) * 8, 0, 1);
                            __builtin_prefetch(weight + (c + 20) * 8, 0, 1);
                        }
                        off += k_scatter32(src + c * 8, weight + c * 8, packed, base + off, &hot);
                    }
                    for (; c < chi; c++)
                        off += k_scatter1(src + c * 8, weight + c * 8, packed, base + off);
                }
#else
                off += k_scalar(src + clo * 8, weight + clo * 8, packed, chi * 8 - clo * 8, base);
#endif
                if (m == S -1) {
                    if (nsub0 == 0)
                        off = k_scalar(src, weight, packed, LEN_1D, 0);
                    else if (tail)
                        off += k_scalar(src + nch * 8, weight + nch * 8, packed, tail, base + off);
                }
                off_all += off;
            }
        }
        total += off_all;
    }
    *out_count = total;
    __builtin_free(scnt);
}
