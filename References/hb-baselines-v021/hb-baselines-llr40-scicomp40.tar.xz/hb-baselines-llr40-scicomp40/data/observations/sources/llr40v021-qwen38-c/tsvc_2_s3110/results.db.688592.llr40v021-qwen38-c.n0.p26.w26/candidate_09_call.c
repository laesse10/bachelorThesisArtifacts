#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if defined(__AVX512F__)
#include <immintrin.h>
#endif

#ifndef KTHREADS
#define KTHREADS 0
#endif

/* Scan a contiguous element range [e, end) of a, finding the maximum value and
 * the position of its FIRST occurrence (linear row-major order).
 * Semantics:  if (v > maxv) { maxv = v; pos = k; }  over the range, merged with
 * an existing (lv, lp) candidate that is strictly better (ties -> smaller pos). */
static void scan_range(const double *restrict a, int64_t e, int64_t end,
                       double *outv, int64_t *outp)
{
    /* Candidate result for the range [e, end).
     * Semantics (must match the reference fold "replace only when v > maxv"):
     *  - NaN is never adopted;
     *  - the returned (v, p) is the first occurrence of the maximum over all
     *    finite values in the range, p == -1 if the range has none (all-NaN).
     * -inf participates as an ordinary value. */
    const int64_t start = e;
    double lv = 0.0;
    int64_t lp = -1;
    if (e >= end) { *outv = lv; *outp = lp; return; }

    int have_real = 0;

#if defined(__AVX512F__)
    if (e + 8 <= end) {
        const int64_t vec_end = e + ((end - e) / 8) * 8;
        __m512d m   = _mm512_set1_pd(-HUGE_VAL);
        __m512d cur = _mm512_add_pd(_mm512_set1_pd((double)e),
                                    _mm512_setr_pd(0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0));
        __m512d idx = cur;
        __m512d inc = _mm512_set1_pd(8.0);
        for (; e < vec_end; e += 8) {
            __m512d v   = _mm512_loadu_pd(a + e);
            __mmask8 gt = _mm512_cmp_pd_mask(v, m, _CMP_GT_OQ);
            m   = _mm512_mask_blend_pd(gt, m, v);
            idx = _mm512_mask_blend_pd(gt, idx, cur);
            cur = _mm512_add_pd(cur, inc);
        }
        {
            double tmp[16];
            _mm512_storeu_pd(tmp, m);
            _mm512_storeu_pd(tmp + 8, idx);
            for (int k = 0; k < 8; ++k) {
                /* lane is "real" iff it saw a value > -HUGE_VAL (always finite);
                 * a stale lane (-HUGE_VAL) means all-(-inf/NaN) in that lane */
                if (tmp[k] > -HUGE_VAL) {
                    have_real = 1;
                    double p = tmp[8 + k];
                    if (lp < 0 || tmp[k] > lv || (tmp[k] == lv && p < (double)lp)) {
                        lv = tmp[k];
                        lp = (int64_t)p;
                    }
                }
            }
        }
    }
#endif

    if (!have_real) {
        /* No value > -HUGE_VAL anywhere in the vector part: the whole range
         * contains only NaN and/or -inf (and possibly -HUGE_VAL itself).
         * A scalar rescan is exact and this path is essentially never taken
         * on ordinary data. */
        for (e = start; e < end; ++e) {
            double v = a[e];
            if (!isnan(v) && (lp < 0 || v > lv)) { lv = v; lp = e; }
        }
        *outv = lv;
        *outp = lp;
        return;
    }

    for (; e < end; ++e) {
        double v = a[e];
        if (!isnan(v) && (lp < 0 || v > lv || (v == lv && e < lp))) { lv = v; lp = e; }
    }
    *outv = lv;
    *outp = lp;
}

void tsvc_2_s3110_fp64(
    const double *restrict aa,
    double *restrict bb,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
#if KTHREADS > 0
    omp_set_num_threads(KTHREADS);
#endif
    const int64_t n = LEN_2D;
    const int64_t total = n * n;

    double best = aa[0];
    int64_t best_pos = 0;

    if (total > 1) {
        const int MAXT = 512;
        double tv[MAXT];
        int64_t tp[MAXT];

        #pragma omp parallel
        {
            const int nt = omp_get_num_threads();
            const int tid = omp_get_thread_num();
            const int64_t range = total - 1;          /* elements 1..total-1 */
            const int64_t base  = range / nt;
            const int64_t rem   = range % nt;
            const int64_t start = 1 + (tid < rem ? (int64_t)tid * (base + 1)
                                                 : (int64_t)rem * (base + 1) + (int64_t)(tid - rem) * base);
            const int64_t cnt   = tid < rem ? base + 1 : base;
            if (tid < MAXT)
                scan_range(aa, start, start + cnt, &tv[tid], &tp[tid]);
        }

        const int nt = omp_get_max_threads();
        for (int t = 0; t < nt && t < MAXT; ++t) {
            if (tp[t] < 0)
                continue; /* all-NaN chunk: no finite maximum */
            /* best may itself be NaN (aa[0] is NaN): comparisons with NaN
             * are false, so it is never replaced -- exactly the reference
             * fold. */
            if (tv[t] > best || (tv[t] == best && tp[t] < best_pos)) {
                best = tv[t];
                best_pos = tp[t];
            }
        }
    }

    const int64_t x = best_pos / n;
    const int64_t y = best_pos - x * n;
    bb[0] = best + (double)x + (double)y;
}
