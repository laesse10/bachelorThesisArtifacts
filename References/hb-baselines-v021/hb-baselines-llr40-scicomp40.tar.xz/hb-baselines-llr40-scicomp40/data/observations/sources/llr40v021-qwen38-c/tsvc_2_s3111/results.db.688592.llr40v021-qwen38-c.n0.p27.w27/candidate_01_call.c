/* tsvc_2_s3111: b[0] = sum of a[i] over i in [0, LEN_1D) with a[i] > 0.0
 *
 * Memory-bandwidth-bound streaming reduction. OpenMP threads each sum a
 * contiguous 64B-aligned chunk of the array with 8 independent 512-bit
 * partial sums (AVX-512 masked adds); AVX2 and scalar fallbacks included.
 * Only positive elements are accumulated, exactly as in the reference:
 * a value is added iff a[i] > 0.0 (NaN and -0.0 excluded, +0.0 excluded).
 */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if defined(__AVX512F__) || defined(__AVX2__)
#include <immintrin.h>
#endif

#define TSV_MAX_THREADS 8192

/* Sum positive elements of p[0..n). Precondition: n % 8 == 0 and p is
 * 64-byte aligned. Returns a scalar double. */
static inline double tsvc_sum_pos_aligned(const double *restrict p, int64_t n) {
#if defined(__AVX512F__)
    __m512d v0 = _mm512_setzero_pd();
    __m512d v1 = _mm512_setzero_pd();
    __m512d v2 = _mm512_setzero_pd();
    __m512d v3 = _mm512_setzero_pd();
    __m512d v4 = _mm512_setzero_pd();
    __m512d v5 = _mm512_setzero_pd();
    __m512d v6 = _mm512_setzero_pd();
    __m512d v7 = _mm512_setzero_pd();
    __m512d vr = _mm512_setzero_pd();
    const __m512d z = _mm512_setzero_pd();
    const double *pe = p + n;
    const double *pb = pe - 64;
    for (; p < pb; p += 64) {
        __m512d x;
        __mmask8 m;
        x = _mm512_load_pd(p);
        m = _mm512_cmp_pd_mask(x, z, _CMP_GT_OQ);
        v0 = _mm512_mask_add_pd(v0, m, v0, x);
        x = _mm512_load_pd(p + 8);
        m = _mm512_cmp_pd_mask(x, z, _CMP_GT_OQ);
        v1 = _mm512_mask_add_pd(v1, m, v1, x);
        x = _mm512_load_pd(p + 16);
        m = _mm512_cmp_pd_mask(x, z, _CMP_GT_OQ);
        v2 = _mm512_mask_add_pd(v2, m, v2, x);
        x = _mm512_load_pd(p + 24);
        m = _mm512_cmp_pd_mask(x, z, _CMP_GT_OQ);
        v3 = _mm512_mask_add_pd(v3, m, v3, x);
        x = _mm512_load_pd(p + 32);
        m = _mm512_cmp_pd_mask(x, z, _CMP_GT_OQ);
        v4 = _mm512_mask_add_pd(v4, m, v4, x);
        x = _mm512_load_pd(p + 40);
        m = _mm512_cmp_pd_mask(x, z, _CMP_GT_OQ);
        v5 = _mm512_mask_add_pd(v5, m, v5, x);
        x = _mm512_load_pd(p + 48);
        m = _mm512_cmp_pd_mask(x, z, _CMP_GT_OQ);
        v6 = _mm512_mask_add_pd(v6, m, v6, x);
        x = _mm512_load_pd(p + 56);
        m = _mm512_cmp_pd_mask(x, z, _CMP_GT_OQ);
        v7 = _mm512_mask_add_pd(v7, m, v7, x);
    }
    for (; p < pe; p += 8) {
        __m512d x = _mm512_load_pd(p);
        __mmask8 m = _mm512_cmp_pd_mask(x, z, _CMP_GT_OQ);
        vr = _mm512_mask_add_pd(vr, m, vr, x);
    }
    __m512d s = (v0 + v1) + (v2 + v3);
    __m512d t = (v4 + v5) + (v6 + v7);
    return _mm512_reduce_add_pd((s + t) + vr);
#elif defined(__AVX2__)
    __m256d v0 = _mm256_setzero_pd();
    __m256d v1 = _mm256_setzero_pd();
    __m256d v2 = _mm256_setzero_pd();
    __m256d v3 = _mm256_setzero_pd();
    __m256d v4 = _mm256_setzero_pd();
    __m256d v5 = _mm256_setzero_pd();
    __m256d v6 = _mm256_setzero_pd();
    __m256d v7 = _mm256_setzero_pd();
    const __m256d z = _mm256_setzero_pd();
    const double *pe = p + n;
    const double *pb = pe - 32;
    for (; p < pb; p += 32) {
        __m256d x, m;
        x = _mm256_load_pd(p);
        m = _mm256_cmp_pd(x, z, _CMP_GT_OQ);
        v0 += _mm256_and_pd(x, m);
        x = _mm256_load_pd(p + 4);
        m = _mm256_cmp_pd(x, z, _CMP_GT_OQ);
        v1 += _mm256_and_pd(x, m);
        x = _mm256_load_pd(p + 8);
        m = _mm256_cmp_pd(x, z, _CMP_GT_OQ);
        v2 += _mm256_and_pd(x, m);
        x = _mm256_load_pd(p + 12);
        m = _mm256_cmp_pd(x, z, _CMP_GT_OQ);
        v3 += _mm256_and_pd(x, m);
        x = _mm256_load_pd(p + 16);
        m = _mm256_cmp_pd(x, z, _CMP_GT_OQ);
        v4 += _mm256_and_pd(x, m);
        x = _mm256_load_pd(p + 20);
        m = _mm256_cmp_pd(x, z, _CMP_GT_OQ);
        v5 += _mm256_and_pd(x, m);
        x = _mm256_load_pd(p + 24);
        m = _mm256_cmp_pd(x, z, _CMP_GT_OQ);
        v6 += _mm256_and_pd(x, m);
        x = _mm256_load_pd(p + 28);
        m = _mm256_cmp_pd(x, z, _CMP_GT_OQ);
        v7 += _mm256_and_pd(x, m);
    }
    for (; p < pe; p += 4) {
        __m256d x = _mm256_load_pd(p);
        __m256d m = _mm256_cmp_pd(x, z, _CMP_GT_OQ);
        v0 += _mm256_and_pd(x, m);
    }
    {
        __m256d s = (v0 + v1) + (v2 + v3);
        __m256d t = (v4 + v5) + (v6 + v7);
        double r[4];
        _mm256_store_pd(r, s + t);
        return (r[0] + r[1]) + (r[2] + r[3]);
    }
#else
    double s0 = 0.0, s1 = 0.0, s2 = 0.0, s3 = 0.0;
    double s4 = 0.0, s5 = 0.0, s6 = 0.0, s7 = 0.0;
    const double *pe = p + n;
    for (; p < pe; p += 8) {
        double x0 = p[0], x1 = p[1], x2 = p[2], x3 = p[3];
        double x4 = p[4], x5 = p[5], x6 = p[6], x7 = p[7];
        if (x0 > 0.0) s0 += x0;
        if (x1 > 0.0) s1 += x1;
        if (x2 > 0.0) s2 += x2;
        if (x3 > 0.0) s3 += x3;
        if (x4 > 0.0) s4 += x4;
        if (x5 > 0.0) s5 += x5;
        if (x6 > 0.0) s6 += x6;
        if (x7 > 0.0) s7 += x7;
    }
    return ((s0 + s1) + (s2 + s3)) + ((s4 + s5) + (s6 + s7));
#endif
}

void tsvc_2_s3111_fp64(const double *restrict a,
                       double *restrict b,
                       const int64_t LEN_1D,
                       uint8_t *restrict workspace,
                       const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;

    if (LEN_1D <= 0) {
        b[0] = 0.0;
        return;
    }

    /* align up to the first 64-byte boundary: at most 7 scalar elements */
    size_t off = (size_t)(uintptr_t)a & 63u;
    int64_t head = off ? (8 - (int)(off >> 3)) : 0;
    if (head > LEN_1D) head = LEN_1D;

    double total = 0.0;
    for (int64_t i = 0; i < head; ++i)
        if (a[i] > 0.0)
            total += a[i];

    const int64_t rem = LEN_1D - head;
    const int64_t tail = rem & 7; /* elements left so that mid % 8 == 0 */
    const int64_t mid = rem - tail;
    const double *p = a + head;

    if (mid > 0) {
        static double partials[TSV_MAX_THREADS];
        int nt = omp_get_max_threads();
        if (nt > TSV_MAX_THREADS) nt = TSV_MAX_THREADS;

#pragma omp parallel num_threads(nt)
        {
            const int tid = omp_get_thread_num();
            const int n = omp_get_num_threads();
            int64_t chunk = mid / n;
            chunk = (chunk + 7) & ~(int64_t)7; /* round up to a multiple of 8 */
            const int64_t s = (int64_t)tid * chunk;
            int64_t e = s + chunk;
            if (e > mid) e = mid;
            partials[tid] = tsvc_sum_pos_aligned(p + s, e - s);
        }

        for (int i = 0; i < nt; ++i)
            total += partials[i];
    }

    for (int64_t i = mid; i < rem; ++i)
        if (a[head + i] > 0.0)
            total += a[head + i];

    b[0] = total;
}
