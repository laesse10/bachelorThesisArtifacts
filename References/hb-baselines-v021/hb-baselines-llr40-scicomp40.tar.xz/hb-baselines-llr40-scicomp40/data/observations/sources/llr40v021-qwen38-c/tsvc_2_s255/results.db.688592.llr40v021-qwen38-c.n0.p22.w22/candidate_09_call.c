/* TSVC tsvc_2 s255 (optimized).
 *
 * Reference semantics: x = b[N-1], y = b[N-2]; for i: a[i] = (b[i] + x + y) * 0.333,
 * y = x, x = b[i]. The recurrence merely tracks x = b[i-1], y = b[i-2] (with
 * wrap-around), so the kernel is a plain 3-tap sum:
 *     a[i] = ((b[i] + b[i-1]) + b[i-2]) * 0.333,   b[-1] = b[N-1], b[-2] = b[N-2]
 * which is fully parallel and is computed here with the identical floating-point
 * operation order, so results are bit-identical to the reference.
 *
 * Optimizations:
 *  - OpenMP over 16-element blocks (AVX-512): the three shifted 8-wide b-windows
 *    per 16 outputs are built from 64B loads, permutes and masked loads, so the
 *    taps of neighbouring windows reuse already-fetched cache lines.
 *  - non-temporal stores for a (written once, never read back) to skip the
 *    write-allocate line fetch.
 *  - NUMA-aware thread placement: /proc/self/numa_maps gives the node of the
 *    pages holding a and b; the OpenMP team is pinned to the CPUs of those
 *    nodes (intersected with the process's original affinity), because on this
 *    multi-socket machine remote memory traffic is several times slower.
 */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

/* ------------------------------------------------------------------ */
/* Raw syscalls (no libc dependency beyond OpenMP)                     */
/* ------------------------------------------------------------------ */

#define SYS_openat 257L
#define SYS_read 0L
#define SYS_close 3L

static inline long sys2(long nr, long a1, long a2, long a3, long a4, long a5, long a6) {
    long ret;
    __asm__ volatile (
        "syscall"
        : "=a"(ret)
        : "0"(nr), "D"(a1), "S"(a2), "d"(a3), "r"(a4), "r"(a5), "r"(a6)
        : "rcx", "r11", "memory");
    return ret;
}

static inline long sys_openat(const char *path) {
    return sys2(SYS_openat, -100L, (long)path, 0L, 0, 0, 0);
}
static inline long sys_read(long fd, void *buf, long n) {
    return sys2(SYS_read, fd, (long)buf, n, 0, 0, 0);
}
static inline long sys_close(long fd) {
    return sys2(SYS_close, fd, 0, 0, 0, 0, 0);
}
/* Affinity goes through the glibc wrappers (raw sched_setaffinity(2) can be
 * intercepted in sandboxed environments; the libc entry points are not). */
extern int sched_getaffinity(int pid, size_t cpusetsize, void *mask);
extern int sched_setaffinity(int pid, size_t cpusetsize, const void *mask);

static inline int sys_getaffinity(unsigned long *mask128) {
    return sched_getaffinity(0, 1024, mask128);
}
static inline int sys_setaffinity(const unsigned long *mask128) {
    return sched_setaffinity(0, 1024, mask128);
}

/* ------------------------------------------------------------------ */
/* NUMA helpers                                                        */
/* ------------------------------------------------------------------ */

#define MAXNODES 64

static int cpuset_count(const unsigned long *m) {
    int n = 0;
    for (int i = 0; i < 128; i++) n += (int)__builtin_popcountl(m[i]);
    return n;
}

static unsigned long g_node_cpus[MAXNODES][128];
static char g_node_tried[MAXNODES];

/* Fill g_node_cpus[node] with the CPUs of one NUMA node, parsed from
 * /sys/devices/system/node/node<N>/cpulist. Returns 0 on success. */
static int node_cpu_mask(int node) {
    char path[64];
    char buf[1024];
    if (node < 0 || node >= MAXNODES) return -1;
    const char *pre = "/sys/devices/system/node/node";
    int len = 0;
    for (; pre[len] != '\0'; len++) path[len] = pre[len];
    char digits[8];
    int n = node, d = 0;
    if (n == 0) digits[d++] = '0';
    while (n > 0) { digits[d++] = (char)('0' + n % 10); n /= 10; }
    while (d > 0) path[len++] = digits[--d];
    path[len++] = '/';
    path[len++] = 'c'; path[len++] = 'p'; path[len++] = 'u';
    path[len++] = 'l'; path[len++] = 'i'; path[len++] = 's'; path[len++] = 't';
    path[len] = '\0';

    long fd = sys_openat(path);
    if (fd < 0) return -1;
    long got = sys_read(fd, buf, (long)(sizeof(buf) - 1));
    sys_close(fd);
    if (got <= 0) return -1;
    buf[got] = '\0';

    unsigned long *mask = g_node_cpus[node];
    memset(mask, 0, 1024);
    const char *p = buf;
    while (*p && *p != '\n') {
        long lo = 0, hi = 0;
        if (*p < '0' || *p > '9') return -1;
        while (*p >= '0' && *p <= '9') { lo = lo * 10 + (*p - '0'); p++; }
        hi = lo;
        if (*p == '-') {
            p++;
            hi = 0;
            while (*p >= '0' && *p <= '9') { hi = hi * 10 + (*p - '0'); p++; }
        }
        if (hi < lo) return -1;
        for (long c = lo; c <= hi; c++) {
            if (c >= 0 && c < 1024) mask[c >> 6] |= 1UL << (c & 63);
        }
        if (*p == ',') p++;
        else if (*p != '\0' && *p != '\n') return -1;
    }
    return cpuset_count(mask) > 0 ? 0 : -1;
}

static int node_cpu_mask_cached(int node, unsigned long *dst) {
    if (g_node_tried[node]) {
        memcpy(dst, g_node_cpus[node], 1024);
        return g_node_tried[node] == 1 ? 0 : -1;
    }
    int r = node_cpu_mask(node);
    g_node_tried[node] = (char)(r == 0 ? 1 : -1);
    if (r == 0) memcpy(dst, g_node_cpus[node], 1024);
    return r;
}

/* Sum the N<k>= page counts of every VMA in /proc/self/numa_maps that
 * overlaps [lo, hi). numa_maps lines carry only the VMA start address
 * ("start policy fields..."); a VMA ends where the next one begins.
 * Returns the set of nodes with at least one page in the range and, if
 * cnts is non-NULL, accumulates the per-node page counts there. */
#define MAXLINEFIELDS 8
static unsigned long numa_hist(unsigned long lo, unsigned long hi,
                               unsigned long *cnts) {
    static char buf[262144];
    long fd = sys_openat("/proc/self/numa_maps");
    if (fd < 0) return 0;
    long total = 0;
    for (;;) {
        long got = sys_read(fd, buf + total, (long)(sizeof(buf) - 1) - total);
        if (got <= 0) break;
        total += got;
        if (total >= (long)sizeof(buf) - 8) break;
    }
    sys_close(fd);
    if (total <= 0) return 0;
    buf[total] = '\0';

    static unsigned long starts[8192];
    static unsigned long linenodes[8192];
    static unsigned char linek[8192][MAXLINEFIELDS];
    static unsigned int linev[8192][MAXLINEFIELDS];
    static unsigned char linefc[8192];
    int nl = 0;
    char *p = buf;
    while (*p && nl < 8192) {
        long long s = 0;
        int i = 0, dig = 0;
        while (i < 16) {
            char ch = p[i];
            int v;
            if (ch >= '0' && ch <= '9') v = ch - '0';
            else if (ch >= 'a' && ch <= 'f') v = ch - 'a' + 10;
            else break;
            s = s * 16 + v;
            dig = 1;
            i++;
        }
        if (!dig || (p[i] != ' ' && p[i] != '\n')) { goto skip_line; }
        starts[nl] = (unsigned long)s;
        linenodes[nl] = 0;
        linefc[nl] = 0;
        char *q = p + i;
        while (*q && *q != '\n') {
            if (*q == 'N') {
                int k = 0;
                char *r = q + 1;
                while (*r >= '0' && *r <= '9') { k = k * 10 + (*r - '0'); r++; }
                if (*r == '=' && k >= 0 && k < MAXNODES) {
                    r++;
                    long v = 0;
                    while (*r >= '0' && *r <= '9') { v = v * 10 + (*r - '0'); r++; }
                    if (v > 0) {
                        linenodes[nl] |= 1UL << k;
                        int fc = (int)linefc[nl], merged = 0;
                        for (int t = 0; t < fc; t++)
                            if (linek[nl][t] == (unsigned char)k) {
                                linev[nl][t] += (unsigned int)v;
                                merged = 1;
                                break;
                            }
                        if (!merged && fc < MAXLINEFIELDS) {
                            linek[nl][fc] = (unsigned char)k;
                            linev[nl][fc] = (unsigned int)v;
                            linefc[nl] = (unsigned char)(fc + 1);
                        }
                    }
                    q = r;
                    continue;
                }
            }
            q++;
        }
        nl++;
        while (*p && *p != '\n') p++;
        if (*p == '\n') p++;
        continue;
      skip_line:
        while (*p && *p != '\n') p++;
        if (*p == '\n') p++;
    }
    unsigned long nodes = 0;
    for (int i = 0; i < nl; i++) {
        unsigned long e = (i + 1 < nl) ? starts[i + 1] : ~0UL;
        if (starts[i] < hi && e > lo) {
            nodes |= linenodes[i];
            if (cnts) {
                for (int j = 0; j < (int)linefc[i]; j++)
                    cnts[linek[i][j]] += linev[i][j];
            }
        }
    }
    return nodes;
}

/* ------------------------------------------------------------------ */
/* Vector body                                                         */
/* ------------------------------------------------------------------ */

#if defined(__AVX512F__)

/* a8 = a + i0 with i0 % 8 == 0, 16 outputs [i0, i0+16) valid, a8 64B aligned,
 * i0 >= 2. Computes a[i] = ((b[i] + b[i-1]) + b[i-2]) * 0.333 for i0..i0+15. */
static void block16(double *restrict a8, const double *restrict b, int64_t i0) {
    /* Masked-load semantics: enabled lane i reads ptr[8i..8i+8), so the fill
     * pointers for the top lanes are shifted back by the lane index. */
    const double *bp = b + i0;
    __m512d L0 = _mm512_loadu_pd(b + i0 - 2); /* b[i0-2 .. i0+5]  */
    __m512d L1 = _mm512_loadu_pd(b + i0 + 6); /* b[i0+6 .. i0+13] */
    const __m512d C = _mm512_set1_pd(0.333);

    const __m512i idx1 = _mm512_set_epi64(127, 7, 6, 5, 4, 3, 2, 1);
    const __m512i idx2 = _mm512_set_epi64(127, 127, 7, 6, 5, 4, 3, 2);

    /* outputs i0..i0+7:  s2 = b[i..], s1 = b[i-1..], L0 = b[i-2..] */
    __m512d s1 = _mm512_mask_loadu_pd(_mm512_permutexvar_pd(idx1, L0), 0x80, bp - 1);
    __m512d s2 = _mm512_mask_loadu_pd(_mm512_permutexvar_pd(idx2, L0), 0xC0, bp);
    _mm512_stream_pd(a8, _mm512_mul_pd(_mm512_add_pd(_mm512_add_pd(s2, s1), L0), C));

    /* outputs i0+8..i0+15: t2 = b[i..], t1 = b[i-1..], L1 = b[i-2..] */
    __m512d t1 = _mm512_mask_loadu_pd(_mm512_permutexvar_pd(idx1, L1), 0x80, bp + 7);
    __m512d t2 = _mm512_mask_loadu_pd(_mm512_permutexvar_pd(idx2, L1), 0xC0, bp + 8);
    _mm512_stream_pd(a8 + 8, _mm512_mul_pd(_mm512_add_pd(_mm512_add_pd(t2, t1), L1), C));
}

#endif

void tsvc_2_s255_fp64(double *restrict a,
                      const double *restrict b,
                      const int64_t LEN_1D,
                      uint8_t *restrict workspace,
                      const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    const int64_t N = LEN_1D;
    if (N <= 0) return;
    const double c = 0.333;

    if (N == 1) { a[0] = (b[0] + b[0] + b[0]) * c; return; }
    a[0] = (b[0] + b[N - 1] + b[N - 2]) * c;
    a[1] = (b[1] + b[0] + b[N - 1]) * c;
    if (N <= 2) return;

    if (N <= 4096) {
        for (int64_t i = 2; i < N; i++) a[i] = (b[i] + b[i - 1] + b[i - 2]) * c;
        return;
    }

    /* Body: 16-element blocks starting at ib, where ib % 8 == 0 and a[ib] is
     * 64B-aligned (for the non-temporal 64B stores). */
    const int64_t a64off = (int64_t)((-(uintptr_t)a / 8) & 7ULL);
    const int64_t ib = (a64off >= 2) ? a64off : a64off + 8;
    const int64_t nb = (N - 16 >= ib) ? ((N - ib) >> 4) : 0;
    const int64_t iend = ib + (nb << 4);

    /* Scalar prologue (at most 7 elements). */
    for (int64_t i = 2; i < ib && i < N; i++) a[i] = (b[i] + b[i - 1] + b[i - 2]) * c;

#if defined(__AVX512F__)
    /* ---- NUMA-aware thread placement (only for big inputs) ---- */
    static unsigned long orig_mask[128];
    static int orig_saved = 0;
    static int orig_nt = 0;
    static int aff_dirty = 0;   /* pool threads carry a non-original mask */
    unsigned long target[128];
    unsigned long maskA[128];   /* CPUs of the node holding a (split mode) */
    unsigned long maskB[128];   /* CPUs of the node holding b (split mode) */
    int bind = 0;
    int nth = 0;
    int split = 0;
    int cntA = 0, cntB = 0;
    if (N >= (1LL << 23)) {
        if (!orig_saved) {
            if (sys_getaffinity(orig_mask) == 0) {
                orig_saved = 1;
                orig_nt = omp_get_max_threads();
                if (orig_nt < 1) orig_nt = 1;
            }
        }
        if (orig_saved) {
            /* The buffers do not move between calls for the same input,
             * so cache the placement result keyed on (a, b, N). */
            static unsigned long c_a = 0, c_b = 0, c_nodesA = 0, c_nodesB = 0;
            static unsigned long c_cntsA[MAXNODES], c_cntsB[MAXNODES];
            static int64_t c_n = -1;
            unsigned long cntsA[MAXNODES];
            unsigned long cntsB[MAXNODES];
            const unsigned long a_lo = (unsigned long)(uintptr_t)a;
            const unsigned long b_lo = (unsigned long)(uintptr_t)b;
            unsigned long nodesA, nodesB;
            if (a_lo == c_a && b_lo == c_b && N == c_n &&
                (c_nodesA | c_nodesB)) {
                memcpy(cntsA, c_cntsA, sizeof cntsA);
                memcpy(cntsB, c_cntsB, sizeof cntsB);
                nodesA = c_nodesA;
                nodesB = c_nodesB;
            } else {
                memset(cntsA, 0, sizeof cntsA);
                memset(cntsB, 0, sizeof cntsB);
                const unsigned long span8 = 8UL * (unsigned long)N;
                nodesA = numa_hist(a_lo, a_lo + span8, cntsA);
                nodesB = numa_hist(b_lo, b_lo + span8, cntsB);
                c_a = a_lo;
                c_b = b_lo;
                c_n = N;
                c_nodesA = nodesA;
                c_nodesB = nodesB;
                memcpy(c_cntsA, cntsA, sizeof c_cntsA);
                memcpy(c_cntsB, cntsB, sizeof c_cntsB);
            }
            const unsigned long dnodes = nodesA | nodesB;
            if (dnodes) {
                memset(target, 0, 1024);
                for (int nd = 0; nd < MAXNODES; nd++) {
                    if ((dnodes >> nd) & 1UL) {
                        unsigned long tmp[128];
                        if (node_cpu_mask_cached(nd, tmp) == 0) {
                            for (int i = 0; i < 128; i++) target[i] |= tmp[i];
                        }
                    }
                }
                for (int i = 0; i < 128; i++) target[i] &= orig_mask[i];
                int cnt = cpuset_count(target);
                if (cnt >= 2 && cnt < cpuset_count(orig_mask)) {
                    bind = 1;
                    nth = cnt;
                }
                /* Split mode: pick, for each buffer, a node holding at
                 * least half of its pages (on an exact tie the first
                 * such node). If the two chosen nodes differ, run the
                 * split schedule below: threads on b's node take the
                 * larger share (their remote traffic is the 128 B/block
                 * write to a); threads on a's node take ~40% (their
                 * remote traffic is the 192 B/block read from b).
                 * Measured optimum on this machine; beats the union
                 * binding for every skew tested (100/0 down to 50/50). */
                {
                    unsigned long totA = 0, totB = 0;
                    int an = -1, bn = -1;
                    for (int nd2 = 0; nd2 < MAXNODES; nd2++) {
                        totA += cntsA[nd2];
                        totB += cntsB[nd2];
                    }
                    for (int nd2 = 0; nd2 < MAXNODES; nd2++) {
                        if (an < 0 && totA && cntsA[nd2] * 2 >= totA) an = nd2;
                        if (bn < 0 && totB && cntsB[nd2] * 2 >= totB) bn = nd2;
                    }
                    if (an >= 0 && bn >= 0 && an != bn) {
                        unsigned long tmp[128];
                        if (node_cpu_mask_cached(an, tmp) == 0) {
                            for (int i = 0; i < 128; i++)
                                maskA[i] = tmp[i] & orig_mask[i];
                        } else {
                            memset(maskA, 0, 1024);
                        }
                        if (node_cpu_mask_cached(bn, tmp) == 0) {
                            for (int i = 0; i < 128; i++)
                                maskB[i] = tmp[i] & orig_mask[i];
                        } else {
                            memset(maskB, 0, 1024);
                        }
                        cntA = cpuset_count(maskA);
                        cntB = cpuset_count(maskB);
                        if (cntA >= 2 && cntB >= 2) {
                            split = 1;
                            bind = 1;
                            nth = cntA + cntB;
                        }
                    }
                }
            }
        }
    }
    const int restore = (!bind && aff_dirty);
    if (bind) {
        omp_set_num_threads(nth);
    } else if (restore) {
        omp_set_num_threads(orig_nt);
    }

    #pragma omp parallel
    {
        if (split) {
            const int tid = omp_get_thread_num();
            const int64_t nA = (nb * 2) / 5;   /* a-node share, ~40% */
            const int64_t kB = nb - nA;
            if (tid < cntB) {
                sys_setaffinity(maskB);
                const int64_t ch = (kB + cntB - 1) / cntB;
                int64_t ks = (int64_t)tid * ch;
                int64_t ke = ks + ch;
                if (ke > kB) ke = kB;
                for (int64_t k = ks; k < ke; k++)
                    block16(a + ib + 16 * k, b, ib + 16 * k);
            } else {
                sys_setaffinity(maskA);
                const int j = tid - cntB;
                const int64_t ch = (nA + cntA - 1) / cntA;
                int64_t ks = kB + (int64_t)j * ch;
                int64_t ke = ks + ch;
                if (ke > nb) ke = nb;
                for (int64_t k = ks; k < ke; k++)
                    block16(a + ib + 16 * k, b, ib + 16 * k);
            }
        } else {
            if (bind || restore) sys_setaffinity(bind ? target : orig_mask);
            #pragma omp for schedule(static)
            for (int64_t k = 0; k < nb; k++) {
                block16(a + ib + 16 * k, b, ib + 16 * k);
            }
        }
    }
    if (bind || restore) aff_dirty = bind;
#else
    #pragma omp parallel for schedule(static)
    for (int64_t i = 2; i < N; i++) a[i] = (b[i] + b[i - 1] + b[i - 2]) * c;
    return;
#endif

    /* Scalar tail (at most 15 elements). */
    for (int64_t i = iend; i < N; i++) a[i] = (b[i] + b[i - 1] + b[i - 2]) * c;
}
