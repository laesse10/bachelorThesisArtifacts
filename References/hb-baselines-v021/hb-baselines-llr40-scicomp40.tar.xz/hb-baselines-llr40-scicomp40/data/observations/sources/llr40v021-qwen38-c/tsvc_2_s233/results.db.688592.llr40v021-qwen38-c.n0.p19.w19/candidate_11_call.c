/* TSVC tsvc_2 s233 -- v4: 32-column units (4x 512b chains), NT stores. */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if defined(__AVX512F__)
#include <immintrin.h>

static inline void nt8m(double *dst, const double *src) {
    /* 8-byte non-temporal store (movntsd); dst 8B-aligned. */
    __asm__ volatile (
        "movsd %1, %%xmm1\n\t"
        "movntsd %%xmm1, %0\n\t"
        :
        : "m"(*dst), "m"(*src)
        : "xmm1", "memory");
}

static inline void ntwin32(double *dst, const double *t) {
    unsigned off = (unsigned)(uintptr_t)dst & 63u;
    if (off == 0) {
        _mm512_stream_pd(dst,     _mm512_loadu_pd(t));
        _mm512_stream_pd(dst + 8, _mm512_loadu_pd(t + 8));
        _mm512_stream_pd(dst + 16, _mm512_loadu_pd(t + 16));
        _mm512_stream_pd(dst + 24, _mm512_loadu_pd(t + 24));
    } else if (off == 32) {
        _mm256_stream_pd(dst,     _mm256_loadu_pd(t));
        _mm512_stream_pd(dst + 4, _mm512_loadu_pd(t + 4));
        _mm512_stream_pd(dst + 12, _mm512_loadu_pd(t + 12));
        _mm512_stream_pd(dst + 20, _mm512_loadu_pd(t + 20));
        _mm256_stream_pd(dst + 28, _mm256_loadu_pd(t + 28));
    } else if ((off & 15) == 0) {
        for (int k = 0; k < 16; ++k)
            _mm_stream_pd(dst + 2 * k, _mm_loadu_pd(t + 2 * k));
    } else {
        /* 8B-misaligned: pure-NT via 8B edges + 16B chunks */
        nt8m(dst, t);
        for (int k = 0; k < 15; ++k)
            _mm_stream_pd(dst + 1 + 2 * k, _mm_loadu_pd(t + 1 + 2 * k));
        nt8m(dst + 31, t + 31);
    }
}


static inline void ntwin64(double *dst, const double *t) {
    unsigned off = (unsigned)(uintptr_t)dst & 63u;
    if (off == 0) {
        for (int k = 0; k < 8; ++k)
            _mm512_stream_pd(dst + 8 * k, _mm512_loadu_pd(t + 8 * k));
    } else if (off == 32) {
        _mm256_stream_pd(dst, _mm256_loadu_pd(t));
        for (int k = 0; k < 7; ++k)
            _mm512_stream_pd(dst + 4 + 8 * k, _mm512_loadu_pd(t + 4 + 8 * k));
        _mm256_stream_pd(dst + 60, _mm256_loadu_pd(t + 60));
    } else if ((off & 15) == 0) {
        for (int k = 0; k < 32; ++k)
            _mm_stream_pd(dst + 2 * k, _mm_loadu_pd(t + 2 * k));
    } else {
        nt8m(dst, t);
        for (int k = 0; k < 31; ++k)
            _mm_stream_pd(dst + 1 + 2 * k, _mm_loadu_pd(t + 1 + 2 * k));
        nt8m(dst + 63, t + 63);
    }
}

static inline void ntwin16b(double *dst, const double *t) {
    unsigned off = (unsigned)(uintptr_t)dst & 63u;
    if (off == 0) {
        _mm512_stream_pd(dst,     _mm512_loadu_pd(t));
        _mm512_stream_pd(dst + 8, _mm512_loadu_pd(t + 8));
    } else if (off == 32) {
        _mm256_stream_pd(dst,      _mm256_loadu_pd(t));
        _mm512_stream_pd(dst + 4,  _mm512_loadu_pd(t + 4));
        _mm256_stream_pd(dst + 12, _mm256_loadu_pd(t + 12));
    } else if ((off & 15) == 0) {
        for (int k = 0; k < 8; ++k)
            _mm_stream_pd(dst + 2 * k, _mm_loadu_pd(t + 2 * k));
    } else {
        /* 8B-misaligned: pure-NT via 8B edges + 16B chunks */
        nt8m(dst, t);
        for (int k = 0; k < 7; ++k)
            _mm_stream_pd(dst + 1 + 2 * k, _mm_loadu_pd(t + 1 + 2 * k));
        nt8m(dst + 15, t + 15);
    }
}

void tsvc_2_s233_fp64(
    double *restrict aa,
    double *restrict bb,
    const double *restrict cc,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    const int64_t N = LEN_2D;
    if (N <= 8) return;

    const int64_t ncol = N - 8;
    const int64_t nw64 = ncol / 64;
    const int64_t rem64 = ncol - nw64 * 64;   /* 0..63 */
    const int64_t nw32 = rem64 / 32;          /* 0..1 */
    const int64_t rem32 = rem64 - nw32 * 32;  /* 0..31 */
    const int64_t nw16 = rem32 / 16;          /* 0..1 */
    const int64_t rem16 = rem32 - nw16 * 16;  /* 0..15 single columns */
    const int64_t nunits = nw64 + nw32 + nw16 + rem16;

#pragma omp parallel
    {
        /* ---------------- phase 1: aa (per-column down-scan) ------------- */
#pragma omp for schedule(static, 1)
        for (int64_t u = 0; u < nunits; ++u) {
            if (u < nw64) {
                const int64_t i0 = 8 + 64 * u;
                __m512d rA = _mm512_loadu_pd(aa + (size_t)7 * N + i0);
                __m512d rB = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 8);
                __m512d rC = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 16);
                __m512d rD = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 24);
                __m512d rE = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 32);
                __m512d rF = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 40);
                __m512d rG = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 48);
                __m512d rH = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 56);
                double tmp[64];
                const int64_t P = (N & 1) ? 32 : 16;
                int64_t j = 8;
                const int64_t jend = (N > P) ? (N - P) : N;
                for (; j < jend; ++j) {
                    const double *cj = cc + (size_t)j * N + i0;
                    const double *cp = cc + (size_t)(j + P) * N + i0;
                    __builtin_prefetch(cp, 0, 3);   __builtin_prefetch(cp + 8, 0, 3);
                    __builtin_prefetch(cp + 16, 0, 3); __builtin_prefetch(cp + 24, 0, 3);
                    __builtin_prefetch(cp + 32, 0, 3); __builtin_prefetch(cp + 40, 0, 3);
                    __builtin_prefetch(cp + 48, 0, 3); __builtin_prefetch(cp + 56, 0, 3);
                    rA = _mm512_add_pd(rA, _mm512_loadu_pd(cj));
                    rB = _mm512_add_pd(rB, _mm512_loadu_pd(cj + 8));
                    rC = _mm512_add_pd(rC, _mm512_loadu_pd(cj + 16));
                    rD = _mm512_add_pd(rD, _mm512_loadu_pd(cj + 24));
                    rE = _mm512_add_pd(rE, _mm512_loadu_pd(cj + 32));
                    rF = _mm512_add_pd(rF, _mm512_loadu_pd(cj + 40));
                    rG = _mm512_add_pd(rG, _mm512_loadu_pd(cj + 48));
                    rH = _mm512_add_pd(rH, _mm512_loadu_pd(cj + 56));
                    _mm512_storeu_pd(tmp, rA);      _mm512_storeu_pd(tmp + 8, rB);
                    _mm512_storeu_pd(tmp + 16, rC); _mm512_storeu_pd(tmp + 24, rD);
                    _mm512_storeu_pd(tmp + 32, rE); _mm512_storeu_pd(tmp + 40, rF);
                    _mm512_storeu_pd(tmp + 48, rG); _mm512_storeu_pd(tmp + 56, rH);
                    ntwin64(aa + (size_t)j * N + i0, tmp);
                }
                for (; j < N; ++j) {
                    const double *cj = cc + (size_t)j * N + i0;
                    rA = _mm512_add_pd(rA, _mm512_loadu_pd(cj));
                    rB = _mm512_add_pd(rB, _mm512_loadu_pd(cj + 8));
                    rC = _mm512_add_pd(rC, _mm512_loadu_pd(cj + 16));
                    rD = _mm512_add_pd(rD, _mm512_loadu_pd(cj + 24));
                    rE = _mm512_add_pd(rE, _mm512_loadu_pd(cj + 32));
                    rF = _mm512_add_pd(rF, _mm512_loadu_pd(cj + 40));
                    rG = _mm512_add_pd(rG, _mm512_loadu_pd(cj + 48));
                    rH = _mm512_add_pd(rH, _mm512_loadu_pd(cj + 56));
                    _mm512_storeu_pd(tmp, rA);      _mm512_storeu_pd(tmp + 8, rB);
                    _mm512_storeu_pd(tmp + 16, rC); _mm512_storeu_pd(tmp + 24, rD);
                    _mm512_storeu_pd(tmp + 32, rE); _mm512_storeu_pd(tmp + 40, rF);
                    _mm512_storeu_pd(tmp + 48, rG); _mm512_storeu_pd(tmp + 56, rH);
                    ntwin64(aa + (size_t)j * N + i0, tmp);
                }
            } else if (u < nw64 + nw32) {
                const int64_t i0 = 8 + nw64 * 64 + 32 * (u - nw64);
                __m512d rA = _mm512_loadu_pd(aa + (size_t)7 * N + i0);
                __m512d rB = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 8);
                __m512d rC = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 16);
                __m512d rD = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 24);
                double tmp[32];
                int64_t j = 8;
                const int64_t jend = (N > 32) ? (N - 32) : N;
                for (; j < jend; ++j) {
                    const double *cj = cc + (size_t)j * N + i0;
                    const double *cp = cc + (size_t)(j + 32) * N + i0;
                    __builtin_prefetch(cp, 0, 3);
                    __builtin_prefetch(cp + 8, 0, 3);
                    __builtin_prefetch(cp + 16, 0, 3);
                    __builtin_prefetch(cp + 24, 0, 3);
                    rA = _mm512_add_pd(rA, _mm512_loadu_pd(cj));
                    rB = _mm512_add_pd(rB, _mm512_loadu_pd(cj + 8));
                    rC = _mm512_add_pd(rC, _mm512_loadu_pd(cj + 16));
                    rD = _mm512_add_pd(rD, _mm512_loadu_pd(cj + 24));
                    _mm512_storeu_pd(tmp,     rA);
                    _mm512_storeu_pd(tmp + 8, rB);
                    _mm512_storeu_pd(tmp + 16, rC);
                    _mm512_storeu_pd(tmp + 24, rD);
                    ntwin32(aa + (size_t)j * N + i0, tmp);
                }
                for (; j < N; ++j) {
                    const double *cj = cc + (size_t)j * N + i0;
                    rA = _mm512_add_pd(rA, _mm512_loadu_pd(cj));
                    rB = _mm512_add_pd(rB, _mm512_loadu_pd(cj + 8));
                    rC = _mm512_add_pd(rC, _mm512_loadu_pd(cj + 16));
                    rD = _mm512_add_pd(rD, _mm512_loadu_pd(cj + 24));
                    _mm512_storeu_pd(tmp,     rA);
                    _mm512_storeu_pd(tmp + 8, rB);
                    _mm512_storeu_pd(tmp + 16, rC);
                    _mm512_storeu_pd(tmp + 24, rD);
                    ntwin32(aa + (size_t)j * N + i0, tmp);
                }
            } else if (u < nw64 + nw32 + nw16) {
                const int64_t i0 = 8 + nw64 * 64 + nw32 * 32 + 16 * (u - nw64 - nw32);
                __m512d rA = _mm512_loadu_pd(aa + (size_t)7 * N + i0);
                __m512d rB = _mm512_loadu_pd(aa + (size_t)7 * N + i0 + 8);
                double tmp[16];
                for (int64_t j = 8; j < N; ++j) {
                    const double *cj = cc + (size_t)j * N + i0;
                    rA = _mm512_add_pd(rA, _mm512_loadu_pd(cj));
                    rB = _mm512_add_pd(rB, _mm512_loadu_pd(cj + 8));
                    _mm512_storeu_pd(tmp, rA);
                    _mm512_storeu_pd(tmp + 8, rB);
                    ntwin16b(aa + (size_t)j * N + i0, tmp);
                }
            } else {
                const int64_t i0c = 8 + nw64 * 64 + nw32 * 32 + nw16 * 16 + (u - nw64 - nw32 - nw16);
                double r = aa[(size_t)7 * N + i0c];
                for (int64_t j = 8; j < N; ++j) {
                    r += cc[(size_t)j * N + i0c];
                    nt8m(aa + (size_t)j * N + i0c, &r);
                }
            }
        }

        /* ---------------- phase 2: bb (per-row left-to-right scan) ------- */
#pragma omp for schedule(static, 1)
        for (int64_t j = 8; j < N; ++j) {
            double *brow  = bb + (size_t)j * N;
            const double *crown = cc + (size_t)j * N;
            double r = brow[7];
            int64_t i = 8;
            unsigned off = (unsigned)((size_t)j * N * 8 + 64) & 31u;
            if (off == 0) {
                for (; i + 3 < N; i += 4) {
                    double r0 = r + crown[i];
                    double r1 = r0 + crown[i + 1];
                    double r2 = r1 + crown[i + 2];
                    double r3 = r2 + crown[i + 3];
                    double t4[4] = {r0, r1, r2, r3};
                    _mm256_stream_pd(brow + i, _mm256_loadu_pd(t4));
                    r = r3;
                }
            } else if (off == 16) {
                for (; i + 3 < N; i += 4) {
                    double r0 = r + crown[i];
                    double r1 = r0 + crown[i + 1];
                    double r2 = r1 + crown[i + 2];
                    double r3 = r2 + crown[i + 3];
                    double t2a[2] = {r0, r1}, t2b[2] = {r2, r3};
                    _mm_stream_pd(brow + i, _mm_loadu_pd(t2a));
                    _mm_stream_pd(brow + i + 2, _mm_loadu_pd(t2b));
                    r = r3;
                }
            } else {
                for (; i + 3 < N; i += 4) {
                    double r0 = r + crown[i];
                    double r1 = r0 + crown[i + 1];
                    double r2 = r1 + crown[i + 2];
                    double r3 = r2 + crown[i + 3];
                    double t4[4] = {r0, r1, r2, r3};
                    nt8m(brow + i, &t4[0]);
                    _mm_stream_pd(brow + i + 1, _mm_loadu_pd(&t4[1]));
                    nt8m(brow + i + 3, &t4[3]);
                    r = r3;
                }
            }
            for (; i < N; ++i) {
                r = r + crown[i];
                nt8m(brow + i, &r);
            }
        }
        _mm_sfence();
    }
}
#else
#include <stddef.h>
void tsvc_2_s233_fp64(
    double *restrict aa, double *restrict bb, const double *restrict cc,
    const int64_t LEN_2D, uint8_t *restrict workspace, const int64_t workspace_size)
{
    (void)workspace; (void)workspace_size;
    const int64_t N = LEN_2D;
    if (N <= 8) return;
    const int64_t ncol = N - 8;
    const int64_t nw16 = ncol / 16;
    const int64_t rem  = ncol - nw16 * 16;
#pragma omp parallel
    {
#pragma omp for schedule(static, 1)
        for (int64_t u = 0; u < nw16 + rem; ++u) {
            if (u < nw16) {
                const int64_t i0 = 8 + 16 * u;
                const double *cA = cc + (size_t)7 * N + i0;
                const double *cB = cc + (size_t)7 * N + i0 + 8;
                const double *a7 = aa + (size_t)7 * N + i0;
                double *aA = aa + (size_t)7 * N + i0;
                double *aB = aa + (size_t)7 * N + i0 + 8;
                double r0=a7[0],r1=a7[1],r2=a7[2],r3=a7[3];
                double r4=a7[4],r5=a7[5],r6=a7[6],r7=a7[7];
                double s0=a7[8],s1=a7[9],s2=a7[10],s3=a7[11];
                double s4=a7[12],s5=a7[13],s6=a7[14],s7=a7[15];
                for (int64_t j = 8; j < N; ++j) {
                    cA+=N; cB+=N; aA+=N; aB+=N;
                    r0+=cA[0];r1+=cA[1];r2+=cA[2];r3+=cA[3];
                    r4+=cA[4];r5+=cA[5];r6+=cA[6];r7+=cA[7];
                    s0+=cB[0];s1+=cB[1];s2+=cB[2];s3+=cB[3];
                    s4+=cB[4];s5+=cB[5];s6+=cB[6];s7+=cB[7];
                    aA[0]=r0;aA[1]=r1;aA[2]=r2;aA[3]=r3;aA[4]=r4;aA[5]=r5;aA[6]=r6;aA[7]=r7;
                    aB[0]=s0;aB[1]=s1;aB[2]=s2;aB[3]=s3;aB[4]=s4;aB[5]=s5;aB[6]=s6;aB[7]=s7;
                }
            } else {
                const int64_t i0c = 8 + nw16 * 16 + (u - nw16);
                double r = aa[(size_t)7 * N + i0c];
                for (int64_t j = 8; j < N; ++j) { r += cc[(size_t)j * N + i0c]; aa[(size_t)j * N + i0c] = r; }
            }
        }
#pragma omp for schedule(static, 1)
        for (int64_t j = 8; j < N; ++j) {
            double *brow = bb + (size_t)j * N;
            const double *crown = cc + (size_t)j * N;
            double r = brow[7];
            int64_t i = 8;
            for (; i + 3 < N; i += 4) {
                double r0=r+crown[i]; double r1=r0+crown[i+1];
                double r2=r1+crown[i+2]; double r3=r2+crown[i+3];
                brow[i]=r0; brow[i+1]=r1; brow[i+2]=r2; brow[i+3]=r3;
                r = r3;
            }
            for (; i < N; ++i) { r = r + crown[i]; brow[i] = r; }
        }
    }
}
#endif
