#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

/* TSVC s275: for each column i with aa[0,i] > 0:
     aa[j,i] = aa[j-1,i] + bb[j,i]*cc[j,i],  j = 1..LEN_2D-1
   Columns are independent -> parallel over groups of 8 columns; vector lane
   k of one AVX-512 register holds column k, so one FMA per row per 8 columns
   and one cache line per row per stream.  Each column is updated in exactly
   the reference order with one FMA per row, so results are bit-identical to
   a scalar FMA evaluation of the reference.
   NOTE: on this toolchain _mm512_mask_fmadd_pd(a,k,b,c) miscompiles to
   a*c+b (swapped args); use full fmadd + mask blend instead.
   _mm512_mask_blend_pd(k, x, y) == k ? y : x. */

static inline void group8_fast(double *restrict a0, const double *restrict b0,
                               const double *restrict c0, const int64_t N)
{
    __m512d v = _mm512_loadu_pd(a0);
    double *a = a0 + N;
    const double *b = b0 + N;
    const double *c = c0 + N;
    const int64_t lim = N - 128;
    int64_t j = 1;
    for (; j < lim; j++) {
        __builtin_prefetch(b + 128 * N, 0, 3);
        __builtin_prefetch(c + 128 * N, 0, 3);
        __builtin_prefetch(a + 128 * N, 1, 3);
        v = _mm512_fmadd_pd(_mm512_loadu_pd(b), _mm512_loadu_pd(c), v);
        _mm512_storeu_pd(a, v);
        a += N; b += N; c += N;
    }
    for (; j < N; j++) {
        v = _mm512_fmadd_pd(_mm512_loadu_pd(b), _mm512_loadu_pd(c), v);
        _mm512_storeu_pd(a, v);
        a += N; b += N; c += N;
    }
}

static inline void group8_mixed(double *restrict a0, const double *restrict b0,
                                const double *restrict c0, const int64_t N, __mmask8 m)
{
    __m512d v = _mm512_loadu_pd(a0);
    double *a = a0 + N;
    const double *b = b0 + N;
    const double *c = c0 + N;
    const int64_t lim = N - 128;
    int64_t j = 1;
    for (; j < lim; j++) {
        __builtin_prefetch(b + 128 * N, 0, 3);
        __builtin_prefetch(c + 128 * N, 0, 3);
        __builtin_prefetch(a + 128 * N, 1, 3);
        __m512d vcur = _mm512_loadu_pd(a);
        __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b), _mm512_loadu_pd(c), v);
        __m512d vn = _mm512_mask_blend_pd(m, vcur, vf); /* active: vf, inactive: vcur */
        _mm512_storeu_pd(a, vn);
        v = vn;
        a += N; b += N; c += N;
    }
    for (; j < N; j++) {
        __m512d vcur = _mm512_loadu_pd(a);
        __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b), _mm512_loadu_pd(c), v);
        __m512d vn = _mm512_mask_blend_pd(m, vcur, vf);
        _mm512_storeu_pd(a, vn);
        v = vn;
        a += N; b += N; c += N;
    }
}

static inline void col_scan(double *restrict aa, const double *restrict bb, const double *restrict cc,
                            const int64_t N, const int64_t i)
{
    if (aa[i] <= 0.0) return;
    double *a = aa + i + N;
    const double *b = bb + i + N;
    const double *c = cc + i + N;
    double prev = aa[i];
    const int64_t lim = N - 128;
    int64_t j = 1;
    for (; j < lim; j++) {
        __builtin_prefetch(b + 128 * N, 0, 3);
        __builtin_prefetch(c + 128 * N, 0, 3);
        __builtin_prefetch(a + 128 * N, 1, 3);
        prev = fma(*b, *c, prev);
        *a = prev;
        a += N; b += N; c += N;
    }
    for (; j < N; j++) {
        prev = fma(*b, *c, prev);
        *a = prev;
        a += N; b += N; c += N;
    }
}

void tsvc_2_s275_fp64(
    double *restrict aa,
    const double *restrict bb,
    const double *restrict cc,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace; (void)workspace_size;
    {
        int avail = omp_get_max_threads();
        int target = avail * 2;
        if (target < 1) target = 1;
        omp_set_num_threads(target);
    }
    const int64_t N = LEN_2D;
    if (N <= 1) return;

    #pragma omp parallel
    {
        #pragma omp for schedule(static)
        for (int64_t i = 0; i < N; i += 8) {
            const int64_t cnt = N - i < 8 ? N - i : 8;
            if (cnt < 8) {
                for (int64_t k = 0; k < cnt; k++) col_scan(aa, bb, cc, N, i + k);
                continue;
            }
            __m512d row0 = _mm512_loadu_pd(aa + i);
            __mmask8 m = _mm512_cmp_pd_mask(row0, _mm512_setzero_pd(), _CMP_GT_OQ);
            if (m == 0) continue;
            if (m == 0xff)
                group8_fast(aa + i, bb + i, cc + i, N);
            else
                group8_mixed(aa + i, bb + i, cc + i, N, m);
        }
    }
}
