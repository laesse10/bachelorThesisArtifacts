#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void scatter_accum_dup_fp64(
    double *restrict bins,
    const int32_t *restrict ip,
    const double *restrict src,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    const int64_t n = LEN_1D;
    (void)workspace; (void)workspace_size;
    if (n <= 0) return;
    omp_set_num_threads(48);
    const int64_t n8 = n & ~7LL;
    #pragma omp parallel for schedule(static, 4096)
    for (int64_t i = 0; i < n8; i += 8) {
        int32_t j0=ip[i],j1=ip[i+1],j2=ip[i+2],j3=ip[i+3];
        int32_t j4=ip[i+4],j5=ip[i+5],j6=ip[i+6],j7=ip[i+7];
        double v0=src[i],v1=src[i+1],v2=src[i+2],v3=src[i+3];
        double v4=src[i+4],v5=src[i+5],v6=src[i+6],v7=src[i+7];
        #pragma omp atomic
        bins[j0]+=v0;
        #pragma omp atomic
        bins[j1]+=v1;
        #pragma omp atomic
        bins[j2]+=v2;
        #pragma omp atomic
        bins[j3]+=v3;
        #pragma omp atomic
        bins[j4]+=v4;
        #pragma omp atomic
        bins[j5]+=v5;
        #pragma omp atomic
        bins[j6]+=v6;
        #pragma omp atomic
        bins[j7]+=v7;
    }
    for (int64_t i = n8; i < n; i++) {
        #pragma omp atomic
        bins[ip[i]] += src[i];
    }
}
