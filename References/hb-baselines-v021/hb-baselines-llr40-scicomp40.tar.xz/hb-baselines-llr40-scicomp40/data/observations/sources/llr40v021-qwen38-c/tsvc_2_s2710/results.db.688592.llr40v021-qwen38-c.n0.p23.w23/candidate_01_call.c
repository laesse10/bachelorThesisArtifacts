/* TSVC tsvc_2 s2710 (fp64) -- optimized.
 *
 * Semantics (numpy oracle):
 *   for i in range(LEN_1D):
 *     if a[i] > b[i]:
 *        a[i] = a[i] + b[i]*d[i]
 *        c[i] = (LEN_1D > 10) ? c[i] + d[i]*d[i] : d[i]*e[i] + 1.0
 *     else:
 *        b[i] = a[i] + e[i]*e[i]
 *        c[i] = (x[0] > 0.0) ? a[i] + d[i]*d[i] : c[i] + e[i]*e[i]
 *
 * Both LEN_1D > 10 and x[0] > 0.0 are loop invariants: hoisted and the loop
 * is fully specialized into 4 variants. The element-level branch is removed
 * (select/blend) so the loop vectorizes cleanly; all updates are independent
 * per i, so OpenMP parallelizes it.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

static void run_variant(double *restrict a, double *restrict b, double *restrict c,
                        const double *restrict d, const double *restrict e,
                        int64_t n, int xpos) {
    if (xpos) {
#pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < n; i++) {
            const double av = a[i], bv = b[i], cv = c[i], dv = d[i], ev = e[i];
            const int gt = av > bv;
            a[i] = gt ? av + bv * dv : av;
            b[i] = gt ? bv : av + ev * ev;
            c[i] = gt ? cv + dv * dv : av + dv * dv;
        }
    } else {
#pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < n; i++) {
            const double av = a[i], bv = b[i], dv = d[i], ev = e[i];
            const int gt = av > bv;
            a[i] = gt ? av + bv * dv : av;
            b[i] = gt ? bv : av + ev * ev;
            c[i] = c[i] + (gt ? dv * dv : ev * ev);
        }
    }
}

static void run_small(double *restrict a, double *restrict b, double *restrict c,
                      const double *restrict d, const double *restrict e,
                      int64_t n, int xpos) {
    if (xpos) {
        for (int64_t i = 0; i < n; i++) {
            if (a[i] > b[i]) {
                a[i] = a[i] + b[i] * d[i];
                c[i] = d[i] * e[i] + 1.0;
            } else {
                b[i] = a[i] + e[i] * e[i];
                c[i] = a[i] + d[i] * d[i];
            }
        }
    } else {
        for (int64_t i = 0; i < n; i++) {
            if (a[i] > b[i]) {
                a[i] = a[i] + b[i] * d[i];
                c[i] = d[i] * e[i] + 1.0;
            } else {
                b[i] = a[i] + e[i] * e[i];
                c[i] = c[i] + e[i] * e[i];
            }
        }
    }
}

void tsvc_2_s2710_fp64(double *restrict a, double *restrict b, double *restrict c,
                       const double *restrict d, const double *restrict e,
                       const double *restrict x, const int64_t LEN_1D,
                       uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    if (LEN_1D <= 0) return;
    const int xpos = x[0] > 0.0;
    if (LEN_1D > 10)
        run_variant(a, b, c, d, e, LEN_1D, xpos);
    else
        run_small(a, b, c, d, e, LEN_1D, xpos);
}
