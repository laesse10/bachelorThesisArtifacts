#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

/* TSVC s275: for each column i with aa[0,i] > 0:
     aa[j,i] = aa[j-1,i] + bb[j,i]*cc[j,i],  j = 1..LEN_2D-1
   Columns are independent -> scan groups of 8 columns (one AVX-512 register
   per group, lane k = column k) with K=8 contiguous groups per thread so each
   row touch is a 512-byte contiguous run (better DRAM row-buffer behavior than
   64-byte strided chunks).  Work chunks (K groups) are scheduled dynamically
   so threads stay balanced.  Each column is updated in exactly the reference
   order with one FMA per row: results are bit-identical to a scalar FMA
   evaluation of the reference.
   NOTE: on this toolchain _mm512_mask_fmadd_pd(a,k,b,c) miscompiles to
   a*c+b (swapped args); use full fmadd + mask blend instead.
   _mm512_mask_blend_pd(k, x, y) == k ? y : x. */

#define K 8
#define D 48

static inline void col_scan(double *restrict aa, const double *restrict bb,
                            const double *restrict cc, const int64_t N, const int64_t col)
{
    if (aa[col] <= 0.0) return;
    double prev = aa[col];
    double *a = aa + col + N;
    const double *b = bb + col + N;
    const double *c = cc + col + N;
    for (int64_t j = 1; j < N; j++) {
        prev = fma(*b, *c, prev);
        *a = prev;
        a += N; b += N; c += N;
    }
}

static void runK(double *restrict aa, const double *restrict bb, const double *restrict cc,
                 const int64_t N, const int64_t c0, const int64_t ng)
{
    const int64_t nrow = N - 1;
    __m512d v[K];
    __mmask8 m[K];
    double *a[K];
    const double *b[K];
    const double *c[K];
    int have[K];
    for (int g = 0; g < ng; g++) {
        const int64_t col = c0 + 8 * g;
        have[g] = 0;
        if (col + 8 > N) {
            for (int64_t cc2 = col; cc2 < N; cc2++) col_scan(aa, bb, cc, N, cc2);
            continue;
        }
        __m512d row0 = _mm512_loadu_pd(aa + col);
        m[g] = _mm512_cmp_pd_mask(row0, _mm512_setzero_pd(), _CMP_GT_OQ);
        v[g] = row0;
        a[g] = aa + col + N;
        b[g] = bb + col + N;
        c[g] = cc + col + N;
        if (m[g] != 0) have[g] = 1;
    }
    int64_t lim = N - 1 - D > 0 ? N - 1 - D : 0;
    for (int64_t j = 1; j <= lim; j++) {
        for (int g = 0; g < ng; g++) {
            if (!have[g]) continue;
            __builtin_prefetch(b[g] + D * N, 0, 3);
            __builtin_prefetch(c[g] + D * N, 0, 3);
        }
        for (int g = 0; g < ng; g++) {
            if (!have[g]) continue;
            if (m[g] == 0xff) {
                v[g] = _mm512_fmadd_pd(_mm512_loadu_pd(b[g]), _mm512_loadu_pd(c[g]), v[g]);
                _mm512_storeu_pd(a[g], v[g]);
            } else {
                __m512d vcur = _mm512_loadu_pd(a[g]);
                __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b[g]), _mm512_loadu_pd(c[g]), v[g]);
                __m512d vn = _mm512_mask_blend_pd(m[g], vcur, vf);
                v[g] = vn;
                _mm512_storeu_pd(a[g], vn);
            }
            a[g] += N; b[g] += N; c[g] += N;
        }
    }
    for (int64_t j = lim + 1; j <= nrow; j++) {
        for (int g = 0; g < ng; g++) {
            if (!have[g]) continue;
            if (m[g] == 0xff) {
                v[g] = _mm512_fmadd_pd(_mm512_loadu_pd(b[g]), _mm512_loadu_pd(c[g]), v[g]);
                _mm512_storeu_pd(a[g], v[g]);
            } else {
                __m512d vcur = _mm512_loadu_pd(a[g]);
                __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b[g]), _mm512_loadu_pd(c[g]), v[g]);
                __m512d vn = _mm512_mask_blend_pd(m[g], vcur, vf);
                v[g] = vn;
                _mm512_storeu_pd(a[g], vn);
            }
            a[g] += N; b[g] += N; c[g] += N;
        }
    }
}

void tsvc_2_s275_fp64(
    double *restrict aa,
    const double *restrict bb,
    const double *restrict cc,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace; (void)workspace_size;
    const int64_t N = LEN_2D;
    if (N <= 1) return;
    const int64_t ngmax = (N + 7) / 8;   /* total 8-column groups (last may be partial) */

    #pragma omp parallel
    {
        #pragma omp for schedule(dynamic, 1)
        for (int64_t g0 = 0; g0 < ngmax; g0 += K) {
            const int64_t ng = ngmax - g0 < K ? ngmax - g0 : K;
            runK(aa, bb, cc, N, 8 * g0, ng);
        }
    }
}
