/* v9: custom barrier + U8 grouped-load unroll (y, x, z order) */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <stdatomic.h>

static _Atomic long bar_cnt;
static _Atomic long bar_epoch;

static inline void fast_barrier(int P) {
    long t = atomic_fetch_add_explicit(&bar_cnt, 1, memory_order_relaxed);
    long e = t / P;
    if (t == (e + 1) * P - 1)
        atomic_store_explicit(&bar_epoch, e + 1, memory_order_release);
    while (atomic_load_explicit(&bar_epoch, memory_order_acquire) <= e) {
#if defined(__x86_64__)
        __builtin_ia32_pause();
#endif
    }
}


void wf_triangular_fp64(double *restrict a, const int64_t LEN_2D,
                        uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace; (void)workspace_size;
    /* 4 threads is the measured optimum; libgomp clamps to the env max */
    omp_set_num_threads(4);
    const int64_t N = LEN_2D;
    if (N < 2) return;
    const double c = 1.0 / 3.0;
    #pragma omp parallel
    {
        const int P = omp_get_num_threads();
        const int tid = omp_get_thread_num();
        for (int64_t s = 2; s <= 2 * N - 2; ++s) {
            int64_t ilo = s - N + 1; if (ilo < 1) ilo = 1;
            int64_t ihi = s / 2;      if (ihi > N - 1) ihi = N - 1;
            const int64_t W = ihi - ilo + 1;
            if (W > 0) {
                const int64_t cnt = (W + P - 1) / P;
                const int64_t lo = ilo + (int64_t)tid * cnt;
                int64_t hi = lo + cnt;
                if (hi > ihi + 1) hi = ihi + 1;
                if (lo < hi) {
                    const int64_t str = N - 1;
                    int64_t idx = lo * N + (s - lo);
                    int64_t i = lo;
                    for (; i + 7 < hi; i += 8, idx += 8 * str) {
                        double y[8], x[8], z[8];
                        #pragma GCC unroll 8
                        for (int k = 0; k < 8; ++k) y[k] = a[idx + k*str - N];
                        #pragma GCC unroll 8
                        for (int k = 0; k < 8; ++k) x[k] = a[idx + k*str];
                        #pragma GCC unroll 8
                        for (int k = 0; k < 8; ++k) z[k] = a[idx + k*str - 1];
                        #pragma GCC unroll 8
                        for (int k = 0; k < 8; ++k) a[idx + k*str] = (x[k] + y[k] + z[k]) * c;
                    }
                    for (; i < hi; ++i, idx += str) {
                        const double x = a[idx];
                        const double y = a[idx - N];
                        const double z = a[idx - 1];
                        a[idx] = (x + y + z) * c;
                    }
                }
            }
            fast_barrier(P);
        }
    }
}
