/* TSVC tsvc_2 s2710 (fp64) -- optimized AVX-512 + OpenMP.
 *
 * Semantics (numpy oracle):
 *   for i in range(LEN_1D):
 *     if a[i] > b[i]:
 *        a[i] = a[i] + b[i]*d[i]
 *        c[i] = (LEN_1D > 10) ? c[i] + d[i]*d[i] : d[i]*e[i] + 1.0
 *     else:
 *        b[i] = a[i] + e[i]*e[i]
 *        c[i] = (x[0] > 0.0) ? a[i] + d[i]*d[i] : c[i] + e[i]*e[i]
 *
 * Loop invariants LEN_1D>10 and x[0]>0 are hoisted; the element branch is
 * turned into masked selects so each 8-wide group is 5 vector loads +
 * a handful of FMA/blend ops + 3 masked vector stores.  Independent per i,
 * so OpenMP parallelizes the block loop.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

#define NT_STORES 0

static inline void vec8_xpos(double *a, double *b, double *c,
                             const double *d, const double *e) {
    __m512d va = _mm512_loadu_pd(a);
    __m512d vb = _mm512_loadu_pd(b);
    __m512d vc = _mm512_loadu_pd(c);
    __m512d vd = _mm512_loadu_pd(d);
    __m512d ve = _mm512_loadu_pd(e);
    __mmask8 k = _mm512_cmp_pd_mask(va, vb, _CMP_GT_OQ);
    _mm512_mask_storeu_pd(a, k, _mm512_fmadd_pd(vb, vd, va));
    _mm512_mask_storeu_pd(b, (__mmask8)~k, _mm512_fmadd_pd(ve, ve, va));
#if NT_STORES
    {
        __m512d vc2 = _mm512_mask_blend_pd(k, _mm512_fmadd_pd(vd, vd, va),
                                           _mm512_fmadd_pd(vd, vd, vc));
        _mm_stream_pd(c,     _mm512_extractf64x2_pd(vc2, 0));
        _mm_stream_pd(c + 2, _mm512_extractf64x2_pd(vc2, 1));
        _mm_stream_pd(c + 4, _mm512_extractf64x2_pd(vc2, 2));
        _mm_stream_pd(c + 6, _mm512_extractf64x2_pd(vc2, 3));
    }
#else
    _mm512_mask_storeu_pd(c, 0xff, _mm512_mask_blend_pd(k, _mm512_fmadd_pd(vd, vd, va),
                                                        _mm512_fmadd_pd(vd, vd, vc)));
#endif
}

static inline void vec8_noxpos(double *a, double *b, double *c,
                               const double *d, const double *e) {
    __m512d va = _mm512_loadu_pd(a);
    __m512d vb = _mm512_loadu_pd(b);
    __m512d vc = _mm512_loadu_pd(c);
    __m512d vd = _mm512_loadu_pd(d);
    __m512d ve = _mm512_loadu_pd(e);
    __mmask8 k = _mm512_cmp_pd_mask(va, vb, _CMP_GT_OQ);
    _mm512_mask_storeu_pd(a, k, _mm512_fmadd_pd(vb, vd, va));
    _mm512_mask_storeu_pd(b, (__mmask8)~k, _mm512_fmadd_pd(ve, ve, va));
#if NT_STORES
    {
        __m512d vc2 = _mm512_add_pd(_mm512_mask_blend_pd(k, _mm512_mul_pd(ve, ve),
                                                         _mm512_mul_pd(vd, vd)), vc);
        _mm_stream_pd(c,     _mm512_extractf64x2_pd(vc2, 0));
        _mm_stream_pd(c + 2, _mm512_extractf64x2_pd(vc2, 1));
        _mm_stream_pd(c + 4, _mm512_extractf64x2_pd(vc2, 2));
        _mm_stream_pd(c + 6, _mm512_extractf64x2_pd(vc2, 3));
    }
#else
    _mm512_mask_storeu_pd(c, 0xff, _mm512_add_pd(_mm512_mask_blend_pd(k, _mm512_mul_pd(ve, ve),
                                                                      _mm512_mul_pd(vd, vd)), vc));
#endif
}

static void scalar_loop(double *a, double *b, double *c, const double *d,
                        const double *e, int64_t i0, int64_t n, int xpos) {
    for (int64_t i = i0; i < n; i++) {
        const double av = a[i], bv = b[i], dv = d[i], ev = e[i];
        if (av > bv) {
            a[i] = av + bv * dv;
            c[i] = c[i] + dv * dv;
        } else {
            b[i] = av + ev * ev;
            c[i] = xpos ? av + dv * dv : c[i] + ev * ev;
        }
    }
}

void tsvc_2_s2710_fp64(double *restrict a, double *restrict b, double *restrict c,
                       const double *restrict d, const double *restrict e,
                       const double *restrict x, const int64_t LEN_1D,
                       uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
#ifdef THREADS_OVERRIDE
    omp_set_num_threads(THREADS_OVERRIDE);
#endif
    if (LEN_1D <= 0) return;
    if (LEN_1D <= 10) {  /* small: keep exact reference form */
        const int xpos = x[0] > 0.0;
        if (xpos) {
            for (int64_t i = 0; i < LEN_1D; i++)
                if (a[i] > b[i]) { a[i] = a[i] + b[i] * d[i]; c[i] = d[i] * e[i] + 1.0; }
                else { b[i] = a[i] + e[i] * e[i]; c[i] = a[i] + d[i] * d[i]; }
        } else {
            for (int64_t i = 0; i < LEN_1D; i++)
                if (a[i] > b[i]) { a[i] = a[i] + b[i] * d[i]; c[i] = d[i] * e[i] + 1.0; }
                else { b[i] = a[i] + e[i] * e[i]; c[i] = c[i] + e[i] * e[i]; }
        }
        return;
    }
    const int64_t n = LEN_1D;
    const int64_t nb = n >> 3;
    const int xpos = x[0] > 0.0;
    if (xpos) {
#pragma omp parallel for schedule(static)
        for (int64_t j = 0; j < nb; j++) {
            if (j + 8 < nb) {
                const double *p = a + 8 * (j + 8);
                _mm_prefetch((const char *)p, _MM_HINT_T0);
                _mm_prefetch((const char *)(b + 8 * (j + 8)), _MM_HINT_T0);
                _mm_prefetch((const char *)(c + 8 * (j + 8)), _MM_HINT_T0);
                _mm_prefetch((const char *)(d + 8 * (j + 8)), _MM_HINT_T0);
                _mm_prefetch((const char *)(e + 8 * (j + 8)), _MM_HINT_T0);
            }
            vec8_xpos(a + 8 * j, b + 8 * j, c + 8 * j, d + 8 * j, e + 8 * j);
        }
    } else {
#pragma omp parallel for schedule(static)
        for (int64_t j = 0; j < nb; j++) {
            if (j + 8 < nb) {
                _mm_prefetch((const char *)(a + 8 * (j + 8)), _MM_HINT_T0);
                _mm_prefetch((const char *)(b + 8 * (j + 8)), _MM_HINT_T0);
                _mm_prefetch((const char *)(c + 8 * (j + 8)), _MM_HINT_T0);
                _mm_prefetch((const char *)(d + 8 * (j + 8)), _MM_HINT_T0);
                _mm_prefetch((const char *)(e + 8 * (j + 8)), _MM_HINT_T0);
            }
            vec8_noxpos(a + 8 * j, b + 8 * j, c + 8 * j, d + 8 * j, e + 8 * j);
        }
    }
    scalar_loop(a, b, c, d, e, nb << 3, n, xpos);
}
