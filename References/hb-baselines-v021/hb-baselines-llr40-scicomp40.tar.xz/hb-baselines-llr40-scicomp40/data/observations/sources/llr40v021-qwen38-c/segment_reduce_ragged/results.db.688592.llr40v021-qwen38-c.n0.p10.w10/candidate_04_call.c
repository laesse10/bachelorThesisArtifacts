#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

/* Segmented dot product over a ragged CSR-style structure.
 * out[s] = sum_{e in [row_ptr[s], row_ptr[s+1])} val[e] * w[e]
 *
 * Segments are independent.  Chunks are grabbed from a shared counter so a
 * thread can carry the segment start in a register across iterations and
 * prefetch the next segment's data while processing the current one.
 *
 * The inner reduction is data-driven (no branch whose taken-ness depends on
 * the random segment length, which the branch predictor cannot see):
 *   - a fixed-count 16-element AVX-512 loop, n >> 4 iterations;
 *   - the remaining 0..15 elements through two masked 8-element blocks.
 *
 * v6 vs v4 (submitted, 6.65x):
 *   - `next` is initialized before the region; the region-entry barrier
 *     publishes it, so the `omp single` (and its implicit barrier) is gone;
 *   - prefetch is one extra cache-line deeper in val/w and one extra row
 *     pointer ahead, widening the open window of the memory stream.
 */
void segment_reduce_ragged_fp64(
    double *restrict out,
    const int64_t *restrict row_ptr,
    const double *restrict val,
    const double *restrict w,
    const int64_t NSEG,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    if (NSEG <= 0) return;

    const int64_t CHUNK = 2048;
    const int64_t nchunks = (NSEG + CHUNK - 1) / CHUNK;
    int64_t next = 0;

#pragma omp parallel shared(next)
    {
        for (;;) {
            int64_t c;
#pragma omp atomic capture
            { c = next; next = next + 1; }
            if (c >= nchunks) break;

            int64_t s0 = c * CHUNK;
            int64_t s1 = s0 + CHUNK;
            if (s1 > NSEG) s1 = NSEG;

            int64_t cur_start = row_ptr[s0];
            for (int64_t s = s0; s < s1; s++) {
                const int64_t cur_end = row_ptr[s + 1];
                __builtin_prefetch(val + cur_end, 0, 3);
                __builtin_prefetch(w + cur_end, 0, 3);
                __builtin_prefetch(val + cur_end + 16, 0, 3);
                __builtin_prefetch(w + cur_end + 16, 0, 3);
                __builtin_prefetch(row_ptr + s + 2, 0, 3);
                __builtin_prefetch(row_ptr + s + 3, 0, 3);

                const int64_t n = cur_end - cur_start;
                const double *vp = val + cur_start;
                const double *wp = w + cur_start;
                double acc;
#if defined(__AVX512F__)
                __m512d a0 = _mm512_setzero_pd();
                __m512d a1 = _mm512_setzero_pd();
                __m512d a2 = _mm512_setzero_pd();
                __m512d a3 = _mm512_setzero_pd();
                int64_t i = 0;
                int64_t nb = n >> 4;
                for (int64_t b = 0; b < nb; b++) {
                    a0 = _mm512_fmadd_pd(_mm512_loadu_pd(vp + i),      _mm512_loadu_pd(wp + i),      a0);
                    a1 = _mm512_fmadd_pd(_mm512_loadu_pd(vp + i + 8),  _mm512_loadu_pd(wp + i + 8),  a1);
                    i += 16;
                }
                const int64_t r = n - i;            /* 0..15 */
                const int64_t k0 = r > 8 ? 8 : r;   /* branchless min(8, r) */
                const int64_t k1 = r > 8 ? r - 8 : 0;
                const __mmask8 m0 = (__mmask8)((1u << k0) - 1u);
                const __mmask8 m1 = (__mmask8)((1u << k1) - 1u);
                a2 = _mm512_maskz_mul_pd(m0, _mm512_maskz_loadu_pd(m0, vp + i),      _mm512_maskz_loadu_pd(m0, wp + i));
                a3 = _mm512_maskz_mul_pd(m1, _mm512_maskz_loadu_pd(m1, vp + i + 8),  _mm512_maskz_loadu_pd(m1, wp + i + 8));
                acc = _mm512_reduce_add_pd(_mm512_add_pd(_mm512_add_pd(a0, a1), _mm512_add_pd(a2, a3)));
#elif defined(__AVX2__)
                __m256d a0 = _mm256_setzero_pd();
                __m256d a1 = _mm256_setzero_pd();
                __m256d a2 = _mm256_setzero_pd();
                __m256d a3 = _mm256_setzero_pd();
                int64_t i = 0;
                for (int64_t b = 0; b < (n >> 4); b++) {
                    a0 = _mm256_fmadd_pd(_mm256_loadu_pd(vp + i),      _mm256_loadu_pd(wp + i),      a0);
                    a1 = _mm256_fmadd_pd(_mm256_loadu_pd(vp + i + 4),  _mm256_loadu_pd(wp + i + 4),  a1);
                    a2 = _mm256_fmadd_pd(_mm256_loadu_pd(vp + i + 8),  _mm256_loadu_pd(wp + i + 8),  a2);
                    a3 = _mm256_fmadd_pd(_mm256_loadu_pd(vp + i + 12), _mm256_loadu_pd(wp + i + 12),a3);
                    i += 16;
                }
                for (int64_t t = i; t + 4 <= n; t += 4) {
                    double x0 = vp[t] * wp[t], x1 = vp[t + 1] * wp[t + 1];
                    double x2 = vp[t + 2] * wp[t + 2], x3 = vp[t + 3] * wp[t + 3];
                    a0 = _mm256_add_pd(a0, _mm256_set_pd(x3, x2, x1, x0));
                }
                for (int64_t t = i; t < n; t++)
                    a0 = _mm256_add_pd(a0, _mm256_set_pd(0.0, 0.0, 0.0, vp[t] * wp[t]));
                __m256d all = _mm256_add_pd(_mm256_add_pd(a0, a1), _mm256_add_pd(a2, a3));
                alignas(32) double d[4];
                _mm256_store_pd(d, all);
                acc = (d[0] + d[1]) + (d[2] + d[3]);
#else
                double tacc = 0.0;
                int64_t i = 0;
                for (; i + 8 <= n; i += 8) {
                    double t0 = vp[i] * wp[i], t1 = vp[i + 1] * wp[i + 1];
                    double t2 = vp[i + 2] * wp[i + 2], t3 = vp[i + 3] * wp[i + 3];
                    double t4 = vp[i + 4] * wp[i + 4], t5 = vp[i + 5] * wp[i + 5];
                    double t6 = vp[i + 6] * wp[i + 6], t7 = vp[i + 7] * wp[i + 7];
                    tacc += ((t0 + t1) + (t2 + t3)) + ((t4 + t5) + (t6 + t7));
                }
                for (; i < n; i++)
                    tacc += vp[i] * wp[i];
                acc = tacc;
#endif
                out[s] = acc;
                cur_start = cur_end;
            }
        }
    }
}
