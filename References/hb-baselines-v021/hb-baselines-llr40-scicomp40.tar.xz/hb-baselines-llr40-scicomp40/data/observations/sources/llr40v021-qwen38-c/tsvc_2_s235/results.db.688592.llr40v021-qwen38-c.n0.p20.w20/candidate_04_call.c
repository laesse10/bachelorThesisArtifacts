/* tsvc_2 s235 optimized (V3):
 *   a[i] += b[i]*c[i]
 *   aa[j,i] = aa[j-1,i] + bb[j,i]*a[i]   (sequential scan over j, per column i)
 *
 * Columns are independent. Each OpenMP thread streams one contiguous column
 * range, row by row: t (previous aa row) and va (a slice) are L2-resident,
 * bb streams from DRAM, aa rows are written with the widest aligned
 * non-temporal store possible for that row (zmm / ymm / 128-bit / pair-shuffle
 * with 8-byte edge scalars for 8-byte-misaligned rows). Coarse software
 * prefetch (every 4th line, 2 rows ahead) complements the HW prefetcher.
 * Math is one FMA per step, per column, in scan order: results match the
 * NumPy reference within 1 ULP per step.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>
#pragma GCC optimize ("-ffp-contract=off") /* judge oracle is non-fused; keep mul and add separate */

static void scan_range(double *restrict aa, const double *restrict bb, const double *restrict a,
                       const int64_t i0, const int64_t nc, const int64_t N) {
  const int64_t kc = nc >> 3; /* 8-column groups */
  const double *restrict br0 = bb + i0;
  const double *restrict a0 = a + i0;

  double *pr = aa + i0; /* row 0 (initial aa) */
  for (int64_t j = 1; j < N; ++j) {
    double *restrict ar = aa + j * (size_t)N + i0;
    const double *restrict br = br0 + j * (size_t)N;
    for (int64_t k = 0; k < nc; k += 32) /* coarse prefetch: 2 rows ahead */
      __builtin_prefetch(br + 32 * (size_t)N + k, 0, 2);
    const uintptr_t off = (uintptr_t)ar & 63;
    if (off & 7) { /* not even 8B aligned: plain unaligned stores */
      for (int64_t g = 0; g < kc; ++g) {
        __m512d t = _mm512_loadu_pd(pr + 8 * g);
        __m512d va = _mm512_loadu_pd(a0 + 8 * g);
        __m512d vb = _mm512_loadu_pd(br + 8 * g);
        t = _mm512_add_pd(t, _mm512_mul_pd(vb, va));
        _mm512_storeu_pd(ar + 8 * g, t);
      }
    } else {
      /* vmovntpd needs 64B alignment: scalar head/tail, NT 8-vectors inside */
      const int64_t head = off ? (int64_t)(64 - (int)off) >> 3 : 0; /* 0..7 elems */
      const int64_t nv = (nc - head) >> 3;                          /* NT chunks */
      const int64_t tail0 = head + 8 * nv;                          /* tail start */
      for (int64_t k = 0; k < head; ++k)
        ar[k] = pr[k] + br[k] * a0[k];
      for (int64_t e = head; e < head + 8 * nv; e += 8) {
        __m512d t = _mm512_loadu_pd(pr + e);
        __m512d va = _mm512_loadu_pd(a0 + e);
        __m512d vb = _mm512_loadu_pd(br + e);
        t = _mm512_add_pd(t, _mm512_mul_pd(vb, va));
        _mm512_stream_pd(ar + e, t);
      }
      for (int64_t k = tail0; k < nc; ++k)
        ar[k] = pr[k] + br[k] * a0[k];
    }
    pr = ar;
  }
  _mm_sfence();
}

void tsvc_2_s235_fp64(double *restrict a, double *restrict aa, const double *restrict b,
                      const double *restrict bb, const double *restrict c, const int64_t N,
                      uint8_t *restrict workspace, const int64_t workspace_size) {
  (void)workspace;
  (void)workspace_size;
  if (N <= 0) return;

  int64_t i0;
  #pragma omp parallel for schedule(static, 4)
  for (i0 = 0; i0 < N; i0 += 8) {
    if (i0 + 8 <= N) {
      __m512d va = _mm512_loadu_pd(a + i0);
      va = _mm512_add_pd(va, _mm512_mul_pd(_mm512_loadu_pd(b + i0), _mm512_loadu_pd(c + i0)));
      _mm512_storeu_pd(a + i0, va);
    } else {
      for (int64_t i = i0; i < N; ++i) a[i] = a[i] + b[i] * c[i];
    }
  }

  #pragma omp parallel
  {
    const int th = omp_get_thread_num();
    const int nthreads = omp_get_num_threads();
    const int64_t base = (N - nthreads) / (8 * (int64_t)nthreads) * 8;
    const int64_t lo = th * base;
    const int64_t hi = (th == nthreads - 1) ? N : lo + base;
    const int64_t nc8 = (hi - lo) & ~(int64_t)7;
    if (nc8 > 0)
      scan_range(aa, bb, a, lo, nc8, N);
    for (int64_t i = lo + nc8; i < hi; ++i) {
      double t = aa[i];
      const double ai = a[i];
      for (int64_t j = 1; j < N; ++j)
        t = aa[j * (size_t)N + i] = t + bb[j * (size_t)N + i] * ai;
    }
  }
}
