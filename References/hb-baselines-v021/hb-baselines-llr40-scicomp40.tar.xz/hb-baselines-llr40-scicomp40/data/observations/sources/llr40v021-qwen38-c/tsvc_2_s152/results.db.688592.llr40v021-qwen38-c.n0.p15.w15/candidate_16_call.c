#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

void tsvc_2_s152_fp64(
    double *restrict a,
    double *restrict b,
    const double *restrict c,
    const double *restrict d,
    const double *restrict e,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {

  if (LEN_1D <= 0) return;
  (void)workspace;
  (void)workspace_size;

  #pragma omp parallel for schedule(static)
  for (int64_t base = 0; base < LEN_1D; base += 64) {
    const int64_t cnt = (LEN_1D - base < 64) ? (LEN_1D - base) : 64;
    double *restrict a0 = a + base;
    double *restrict b0 = b + base;
    const double *restrict c0 = c + base;
    const double *restrict d0 = d + base;
    const double *restrict e0 = e + base;

    int64_t i = 0;
    const int64_t nvec = cnt & ~31LL;
    for (; i < nvec; i += 32) {
      __m512d bv0 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 0),  _mm512_loadu_pd(e0 + i + 0));
      __m512d bv1 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 8),  _mm512_loadu_pd(e0 + i + 8));
      __m512d bv2 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 16), _mm512_loadu_pd(e0 + i + 16));
      __m512d bv3 = _mm512_mul_pd(_mm512_loadu_pd(d0 + i + 24), _mm512_loadu_pd(e0 + i + 24));
      _mm512_storeu_pd(b0 + i + 0,  bv0);
      _mm512_storeu_pd(b0 + i + 8,  bv1);
      _mm512_storeu_pd(b0 + i + 16, bv2);
      _mm512_storeu_pd(b0 + i + 24, bv3);
      _mm512_storeu_pd(a0 + i + 0,
          _mm512_fmadd_pd(bv0, _mm512_loadu_pd(c0 + i + 0),  _mm512_loadu_pd(a0 + i + 0)));
      _mm512_storeu_pd(a0 + i + 8,
          _mm512_fmadd_pd(bv1, _mm512_loadu_pd(c0 + i + 8),  _mm512_loadu_pd(a0 + i + 8)));
      _mm512_storeu_pd(a0 + i + 16,
          _mm512_fmadd_pd(bv2, _mm512_loadu_pd(c0 + i + 16), _mm512_loadu_pd(a0 + i + 16)));
      _mm512_storeu_pd(a0 + i + 24,
          _mm512_fmadd_pd(bv3, _mm512_loadu_pd(c0 + i + 24), _mm512_loadu_pd(a0 + i + 24)));
    }
    for (; i < cnt; ++i) {
      b0[i] = d0[i] * e0[i];
      a0[i] += b0[i] * c0[i];
    }
  }
}
