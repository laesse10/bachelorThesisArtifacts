/* Hand port of the TSVC tsvc_2 C++ microkernel ``s255`` (s255_d_single.cpp), fp64
 * single-invocation variant, to C23 under the v2 C-ABI.
 *
 * Adapted from TSVC_2 -- Test Suite for Vectorizing Compilers (github.com/UoB-HPC/TSVC_2),
 * NCSA/MIT license (UIUC).
 *
 * DELIBERATELY CARRIES NO ``hpcagent_bench-autogen`` MARKER. emit_io treats an unmarked
 * reference as a hand-written override and never regenerates it, which is the point: this
 * corpus exists to ask whether compilers vectorize and parallelize human-written C where they
 * fail on translator-generated C. Regenerating this file from the numpy reference would compare
 * translator output against translator output and answer nothing. Edit it by hand, never
 * through the emitter.
 *
 * The numpy reference remains the correctness oracle. */

#include <stdint.h>

void tsvc_2_s255_fp64(double *restrict a, const double *restrict b, const int64_t LEN_1D) {

  double x = b[LEN_1D - 1];
  double y = b[LEN_1D - 2];
  for (int64_t i = 0; i < LEN_1D; i++) {
    a[i] = (b[i] + x + y) * 0.333;
    y = x;
    x = b[i];
  }
}
