/* tsvc_2 s4112: a[i] += b[ip[i]] * 2.0  (elementwise gather)
 *
 * Optimized: AVX-512 8-wide gather (VPGATHERQPD) over a per-thread
 * contiguous static partition, with AVX2 4-wide gather and scalar
 * fallbacks selected at runtime. */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if defined(__AVX512F__) || defined(__AVX2__)
#include <immintrin.h>
#endif

/* per-thread [beg,end) range helper */
typedef struct { int64_t beg, end; } range_t;

static range_t thread_range(int64_t n) {
  int t = omp_get_thread_num();
  int nt = omp_get_num_threads();
  int64_t chunk = (n + nt - 1) / nt;
  int64_t beg = (int64_t)t * chunk;
  if (beg > n) beg = n;
  int64_t end = beg + chunk;
  if (end > n) end = n;
  return (range_t){beg, end};
}

#if defined(__AVX512F__) && defined(__AVX512DQ__)
static void k_avx512(double *restrict a, const double *restrict b,
                     const int32_t *restrict ip, int64_t n) {
#pragma omp parallel
  {
    range_t r = thread_range(n);
    const __m512d two = _mm512_set1_pd(2.0);
    int64_t i = r.beg;
    while (i < r.end && (i & 7)) { a[i] = a[i] + b[ip[i]] * 2.0; ++i; }
    for (; i + 32 <= r.end; i += 32) {
      __m256i i0 = _mm256_loadu_si256((const __m256i *)(ip + i));
      __m256i i1 = _mm256_loadu_si256((const __m256i *)(ip + i + 8));
      __m256i i2 = _mm256_loadu_si256((const __m256i *)(ip + i + 16));
      __m256i i3 = _mm256_loadu_si256((const __m256i *)(ip + i + 24));
      __m512d vb0 = _mm512_i64gather_pd(_mm512_cvtepi32_epi64(i0), b, 8);
      __m512d vb1 = _mm512_i64gather_pd(_mm512_cvtepi32_epi64(i1), b, 8);
      __m512d vb2 = _mm512_i64gather_pd(_mm512_cvtepi32_epi64(i2), b, 8);
      __m512d vb3 = _mm512_i64gather_pd(_mm512_cvtepi32_epi64(i3), b, 8);
      __m512d va0 = _mm512_loadu_pd(a + i);
      __m512d va1 = _mm512_loadu_pd(a + i + 8);
      __m512d va2 = _mm512_loadu_pd(a + i + 16);
      __m512d va3 = _mm512_loadu_pd(a + i + 24);
      va0 = _mm512_add_pd(va0, _mm512_mul_pd(vb0, two));
      va1 = _mm512_add_pd(va1, _mm512_mul_pd(vb1, two));
      va2 = _mm512_add_pd(va2, _mm512_mul_pd(vb2, two));
      va3 = _mm512_add_pd(va3, _mm512_mul_pd(vb3, two));
      _mm512_storeu_pd(a + i, va0);
      _mm512_storeu_pd(a + i + 8, va1);
      _mm512_storeu_pd(a + i + 16, va2);
      _mm512_storeu_pd(a + i + 24, va3);
    }
    for (; i + 8 <= r.end; i += 8) {
      __m256i i0 = _mm256_loadu_si256((const __m256i *)(ip + i));
      __m512d vb = _mm512_i64gather_pd(_mm512_cvtepi32_epi64(i0), b, 8);
      __m512d va = _mm512_loadu_pd(a + i);
      va = _mm512_add_pd(va, _mm512_mul_pd(vb, two));
      _mm512_storeu_pd(a + i, va);
    }
    for (; i < r.end; ++i) a[i] = a[i] + b[ip[i]] * 2.0;
  }
}
#endif

#if defined(__AVX2__)
static void k_avx2(double *restrict a, const double *restrict b,
                   const int32_t *restrict ip, int64_t n) {
#pragma omp parallel
  {
    range_t r = thread_range(n);
    const __m256d two = _mm256_set1_pd(2.0);
    int64_t i = r.beg;
    while (i < r.end && (i & 3)) { a[i] = a[i] + b[ip[i]] * 2.0; ++i; }
    for (; i + 8 <= r.end; i += 8) {
      __m256d vb0 = _mm256_i32gather_pd(b, _mm_loadu_si128((const __m128i *)(ip + i)), 8);
      __m256d vb1 = _mm256_i32gather_pd(b, _mm_loadu_si128((const __m128i *)(ip + i + 4)), 8);
      __m256d va0 = _mm256_loadu_pd(a + i);
      __m256d va1 = _mm256_loadu_pd(a + i + 4);
      va0 = _mm256_add_pd(va0, _mm256_mul_pd(vb0, two));
      va1 = _mm256_add_pd(va1, _mm256_mul_pd(vb1, two));
      _mm256_storeu_pd(a + i, va0);
      _mm256_storeu_pd(a + i + 4, va1);
    }
    for (; i + 4 <= r.end; i += 4) {
      __m256d vb = _mm256_i32gather_pd(b, _mm_loadu_si128((const __m128i *)(ip + i)), 8);
      __m256d va = _mm256_loadu_pd(a + i);
      va = _mm256_add_pd(va, _mm256_mul_pd(vb, two));
      _mm256_storeu_pd(a + i, va);
    }
    for (; i < r.end; ++i) a[i] = a[i] + b[ip[i]] * 2.0;
  }
}
#endif

static void k_scalar(double *restrict a, const double *restrict b,
                     const int32_t *restrict ip, int64_t n) {
#pragma omp parallel for schedule(static)
  for (int64_t i = 0; i < n; ++i) a[i] = a[i] + b[ip[i]] * 2.0;
}

void tsvc_2_s4112_fp64(double *restrict a, const double *restrict b,
                       const int32_t *restrict ip, const int64_t LEN_1D,
                       uint8_t *restrict workspace, const int64_t workspace_size) {
  (void)workspace;
  (void)workspace_size;
  if (LEN_1D <= 0) return;
#if defined(__AVX512F__) && defined(__AVX512DQ__)
  if (__builtin_cpu_supports("avx512f")) { k_avx512(a, b, ip, LEN_1D); return; }
#endif
#if defined(__AVX2__)
  if (__builtin_cpu_supports("avx2")) { k_avx2(a, b, ip, LEN_1D); return; }
#endif
  k_scalar(a, b, ip, LEN_1D);
}
