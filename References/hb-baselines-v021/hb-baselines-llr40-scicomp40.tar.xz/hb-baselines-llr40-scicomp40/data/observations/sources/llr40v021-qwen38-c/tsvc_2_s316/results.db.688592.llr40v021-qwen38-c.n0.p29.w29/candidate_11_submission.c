#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void tsvc_2_s316_fp64(const double *restrict a, double *restrict result,
                      const int64_t LEN_1D, uint8_t *restrict workspace,
                      const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    double x = a[0];
    for (int64_t i = 1; i < LEN_1D; ++i) {
        if (a[i] < x) {
            x = a[i];
        }
    }
    result[0] = x;
}
