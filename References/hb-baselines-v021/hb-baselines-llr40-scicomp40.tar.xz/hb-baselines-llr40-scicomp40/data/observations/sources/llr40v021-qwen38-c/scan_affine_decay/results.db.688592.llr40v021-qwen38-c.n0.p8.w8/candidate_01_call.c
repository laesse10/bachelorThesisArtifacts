#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

void scan_affine_decay_fp64(
    const double *restrict c,
    const double *restrict x,
    double *restrict y,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    (void)workspace; (void)workspace_size;
    int64_t n = LEN_1D;
    if (n <= 1) return;

    int nt = omp_get_max_threads();
    if (nt < 1) nt = 1;
    if ((int64_t)nt > n) nt = (int)n;
    if (nt > 64) nt = 64;

    const int K = 4;
    double At[64], Bt[64];

    #pragma omp parallel num_threads(nt)
    {
        int tid = omp_get_thread_num();
        int64_t per = n / nt, rem = n % nt;
        int64_t r0 = tid * per + (tid < rem ? tid : rem);
        int64_t r1 = r0 + per + (tid < rem ? 1 : 0);
        int64_t s0 = (tid == 0) ? 1 : r0;
        int64_t w = r1 - s0;

        double Amap[8], Bmap[8], yin[8];
        int64_t off[8];
        int kk = 0;
        if (w > 0) {
            kk = K;
            if ((int64_t)kk > w) kk = (int)w;
            int64_t L = w / kk, R = w % kk;
            int64_t o = 0;
            for (int k = 0; k < kk; k++) { off[k] = o; o += L + (k < R ? 1 : 0); }

            for (int k = 0; k < kk; k++) {
                int64_t i0 = s0 + off[k], i1 = i0 + L + (k < R ? 1 : 0);
                double A = 1.0, B = 0.0;
                for (int64_t i = i0; i < i1; i++) {
                    double ci = c[i];
                    A = ci * A;
                    B = ci * B + x[i];
                }
                Amap[k] = A; Bmap[k] = B;
            }
        }
        double At2 = 1.0, Bt2 = 0.0;
        for (int k = 0; k < kk; k++) {
            At2 = Amap[k] * At2;
            Bt2 = Amap[k] * Bt2 + Bmap[k];
        }
        At[tid] = At2; Bt[tid] = Bt2;
        #pragma omp barrier
        double v = y[0];
        for (int t = 0; t < tid; t++) {
            v = At[t] * v + Bt[t];
        }

        for (int k = 0; k < kk; k++) {
            yin[k] = v;
            v = Amap[k] * v + Bmap[k];
        }

        if (w > 0) {
            int64_t L = w / kk, R = w % kk;
            for (int64_t s = 0; s < L; s++) {
                for (int k = 0; k < kk; k++) {
                    int64_t i = s0 + off[k] + s;
                    double vv = c[i] * yin[k] + x[i];
                    yin[k] = vv;
                    y[i] = vv;
                }
            }
            for (int k = 0; k < R; k++) {
                int64_t i = s0 + off[k] + L;
                double vv = c[i] * yin[k] + x[i];
                yin[k] = vv;
                y[i] = vv;
            }
        }
    }
}
