#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
void fuse_stencil_through_transient_fp64(const double *restrict a, double *restrict out, const int64_t LEN_1D, uint8_t *restrict workspace, const int64_t workspace_size)
{
    (void)workspace; (void)workspace_size;
    int maxt = omp_get_max_threads();
    int t = maxt < 8 ? maxt : 8;
    if (omp_get_num_threads() != t) omp_set_num_threads(t);
    if (LEN_1D < 4) return;
    #pragma omp parallel for schedule(static)
    for (int64_t i = 1; i < LEN_1D - 2; ++i) {
        out[i] = (a[i - 1] + a[i] + a[i + 1]) * (a[i] + a[i + 1] + a[i + 2]);
    }
}
