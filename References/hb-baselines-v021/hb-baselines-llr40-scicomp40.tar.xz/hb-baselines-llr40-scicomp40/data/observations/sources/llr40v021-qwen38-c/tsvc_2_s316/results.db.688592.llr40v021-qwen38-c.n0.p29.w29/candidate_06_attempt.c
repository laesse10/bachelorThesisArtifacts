#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if defined(__AVX512F__)
#include <immintrin.h>
#elif defined(__AVX2__)
#include <immintrin.h>
#endif

/* Exact semantics of the sequential reference
 *     x = a[0]; for i in 1..n-1: if (a[i] < x) x = a[i];  result[0] = x
 * which is: NaN elements never win; the result is NaN only when a[0] is
 * NaN; for non-NaN data it is the mathematical minimum; and when that
 * minimum is zero, the zero that is returned is the first one encountered
 * (zero is its own identity element, so once x is zero it is never
 * replaced, and nothing strictly negative can exist). */

#if defined(__AVX512F__)
static double chunk_min_avx512(const double *p, const double *e, double acc) {
    __m512d v0 = _mm512_set1_pd(acc), v1 = _mm512_set1_pd(acc),
            v2 = _mm512_set1_pd(acc), v3 = _mm512_set1_pd(acc),
            v4 = _mm512_set1_pd(acc), v5 = _mm512_set1_pd(acc),
            v6 = _mm512_set1_pd(acc), v7 = _mm512_set1_pd(acc);
    for (; p + 64 <= e; p += 64) {
        v0 = _mm512_min_pd(v0, _mm512_loadu_pd(p));
        v1 = _mm512_min_pd(v1, _mm512_loadu_pd(p + 8));
        v2 = _mm512_min_pd(v2, _mm512_loadu_pd(p + 16));
        v3 = _mm512_min_pd(v3, _mm512_loadu_pd(p + 24));
        v4 = _mm512_min_pd(v4, _mm512_loadu_pd(p + 32));
        v5 = _mm512_min_pd(v5, _mm512_loadu_pd(p + 40));
        v6 = _mm512_min_pd(v6, _mm512_loadu_pd(p + 48));
        v7 = _mm512_min_pd(v7, _mm512_loadu_pd(p + 56));
    }
    for (; p + 8 <= e; p += 8)
        v0 = _mm512_min_pd(v0, _mm512_loadu_pd(p));
    double tmp[64];
    _mm512_storeu_pd(tmp + 0, v0);
    _mm512_storeu_pd(tmp + 8, v1);
    _mm512_storeu_pd(tmp + 16, v2);
    _mm512_storeu_pd(tmp + 24, v3);
    _mm512_storeu_pd(tmp + 32, v4);
    _mm512_storeu_pd(tmp + 40, v5);
    _mm512_storeu_pd(tmp + 48, v6);
    _mm512_storeu_pd(tmp + 56, v7);
    for (int i = 0; i < 64; ++i) {
        double v = tmp[i];
        if (v < acc) acc = v;
    }
    for (; p < e; ++p) {
        double v = *p;
        if (v < acc) acc = v;
    }
    return acc;
}

static double first_zero_avx512(const double *p, const double *e, double fallback) {
    __m512d zero = _mm512_setzero_pd();
    for (; p + 8 <= e; p += 8) {
        __mmask16 m = _mm512_cmp_pd_mask(_mm512_loadu_pd(p), zero, _CMP_EQ_OQ);
        if (m) return p[_tzcnt_u32(m)];
    }
    for (; p < e; ++p)
        if (*p == 0.0) return *p;
    return fallback;
}
#elif defined(__AVX2__)
static double chunk_min_avx2(const double *p, const double *e, double acc) {
    __m256d v0 = _mm256_set1_pd(acc), v1 = _mm256_set1_pd(acc),
            v2 = _mm256_set1_pd(acc), v3 = _mm256_set1_pd(acc);
    for (; p + 16 <= e; p += 16) {
        v0 = _mm256_min_pd(v0, _mm256_loadu_pd(p));
        v1 = _mm256_min_pd(v1, _mm256_loadu_pd(p + 4));
        v2 = _mm256_min_pd(v2, _mm256_loadu_pd(p + 8));
        v3 = _mm256_min_pd(v3, _mm256_loadu_pd(p + 12));
    }
    for (; p + 4 <= e; p += 4)
        v0 = _mm256_min_pd(v0, _mm256_loadu_pd(p));
    double tmp[16];
    _mm256_storeu_pd(tmp + 0, v0);
    _mm256_storeu_pd(tmp + 4, v1);
    _mm256_storeu_pd(tmp + 8, v2);
    _mm256_storeu_pd(tmp + 12, v3);
    for (int i = 0; i < 16; ++i) {
        double v = tmp[i];
        if (v < acc) acc = v;
    }
    for (; p < e; ++p) {
        double v = *p;
        if (v < acc) acc = v;
    }
    return acc;
}

static double first_zero_avx2(const double *p, const double *e, double fallback) {
    __m256d zero = _mm256_setzero_pd();
    for (; p + 4 <= e; p += 4) {
        unsigned m = (unsigned)_mm256_movemask_pd(_mm256_cmp_pd(_mm256_loadu_pd(p), zero, _CMP_EQ_OQ));
        if (m) return p[__builtin_ctz(m)];
    }
    for (; p < e; ++p)
        if (*p == 0.0) return *p;
    return fallback;
}
#endif

static double __attribute__((unused)) chunk_min_scalar(const double *p, const double *e, double acc) {
    for (; p < e; ++p) {
        double v = *p;
        if (v < acc) acc = v;
    }
    return acc;
}

static double __attribute__((unused)) first_zero_scalar(const double *p, const double *e, double fallback) {
    for (; p < e; ++p)
        if (*p == 0.0) return *p;
    return fallback;
}

void tsvc_2_s316_fp64(const double *restrict a, double *restrict result,
                      const int64_t LEN_1D, uint8_t *restrict workspace,
                      const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    if (LEN_1D <= 0) { result[0] = a[0]; return; } /* same read the reference makes */
    if (LEN_1D == 1) { result[0] = a[0]; return; }

    int nt = omp_get_max_threads();
    if (nt < 1) nt = 1;
    nt *= 2; /* two per physical core: SMT pairs hide the memory latency */
    if ((int64_t)nt > LEN_1D) nt = (int)LEN_1D;

    double partial[nt];

    #pragma omp parallel num_threads(nt)
    {
        const int tid = omp_get_thread_num();
        const int n = omp_get_num_threads();
        int64_t chunk = (LEN_1D + n - 1) / n;
        int64_t begin = (int64_t)tid * chunk;
        int64_t end = begin + chunk;
        if (end > LEN_1D) end = LEN_1D;
        double acc = INFINITY;
#if defined(__AVX512F__)
        acc = chunk_min_avx512(a + begin, a + end, acc);
#elif defined(__AVX2__)
        acc = chunk_min_avx2(a + begin, a + end, acc);
#else
        acc = chunk_min_scalar(a + begin, a + end, acc);
#endif
        partial[tid] = acc;
    }

    double x = partial[0];
    for (int t = 1; t < nt; ++t)
        if (partial[t] < x) x = partial[t];

    if (a[0] != a[0]) {
        x = a[0]; /* a[0] NaN: the sequential reference keeps it */
    } else if (x == 0.0) {
        /* the sequential reference returns the FIRST zero encountered */
#if defined(__AVX512F__)
        x = first_zero_avx512(a, a + LEN_1D, x);
#elif defined(__AVX2__)
        x = first_zero_avx2(a, a + LEN_1D, x);
#else
        x = first_zero_scalar(a, a + LEN_1D, x);
#endif
    }
    result[0] = x;
}
