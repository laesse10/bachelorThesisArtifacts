#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
void fuse_stencil_through_transient_fp64(const double *restrict a, double *restrict out, const int64_t LEN_1D, uint8_t *restrict workspace, const int64_t workspace_size)
{
    (void)workspace; (void)workspace_size;
    if (LEN_1D < 4) return;
    int64_t n = LEN_1D - 3;
    #pragma omp parallel for schedule(dynamic, 65536)
    for (int64_t i = 0; i < n; ++i) {
        int64_t j = i + 1;
        out[j] = (a[j - 1] + a[j] + a[j + 1]) * (a[j] + a[j + 1] + a[j + 2]);
    }
}
