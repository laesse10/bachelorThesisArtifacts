/* tsvc_2 vag: a[i] = b[ip[i]]  (random 8-byte gather)
 *
 * Optimizations vs the naive loop:
 *  - OpenMP: each thread owns a contiguous, BLK-aligned block.
 *  - AVX-512: 2x256-bit vpgatherdd of 4 doubles per 8-element block.
 *  - 2-stage software pipeline: the 8 b-lines of the block P blocks
 *    ahead are prefetched (data + TLB), so by the time the gather runs
 *    the lines are in L1; the ip stream is read far enough ahead that
 *    it is always cache-resident.  P*BLK lines stay in flight, which
 *    is what covers DRAM+page-walk latency on a random gather.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#if defined(__AVX512F__) && defined(__AVX512VL__)
#include <immintrin.h>
#endif

#define VAG_BLK 8
#define VAG_P 10

void tsvc_2_vag_fp64(
    double *restrict a,
    const double *restrict b,
    const int32_t *restrict ip,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace; (void)workspace_size;
    const int64_t n = LEN_1D;
    if (n <= 0) return;

#if defined(__AVX512F__) && defined(__AVX512VL__)
    #pragma omp parallel
    {
        const int64_t nth = omp_get_num_threads();
        const int64_t tid = omp_get_thread_num();
        int64_t base = (n / (nth * (int64_t)VAG_BLK)) * (int64_t)VAG_BLK;
        int64_t lo = tid * base;
        int64_t hi = (tid + 1) * base;
        if (tid == nth - 1) hi = n;
        /* The body reads ip up to i + (P+1)*BLK - 1; keep i within range. */
        int64_t lim = n - ((int64_t)VAG_P + 1) * (int64_t)VAG_BLK;
        int64_t iend = hi - ((int64_t)VAG_BLK - 1);
        if (lim + 1 < iend) iend = lim + 1;
        int64_t i = lo;
        for (; i < iend; i += VAG_BLK) {
            int32_t pf[VAG_BLK];
            _Pragma("GCC unroll 8")
            for (int k = 0; k < VAG_BLK; ++k) pf[k] = ip[i + VAG_P * VAG_BLK + k];
            _Pragma("GCC unroll 8")
            for (int k = 0; k < VAG_BLK; ++k) __builtin_prefetch(&b[pf[k]], 0, 1);
            __m128i c0 = _mm_loadu_si128((const __m128i*)(ip + i));
            __m128i c1 = _mm_loadu_si128((const __m128i*)(ip + i + 4));
            _mm256_storeu_pd(a + i,     _mm256_i32gather_pd(b, c0, 8));
            _mm256_storeu_pd(a + i + 4, _mm256_i32gather_pd(b, c1, 8));
        }
        for (; i < hi; ++i) a[i] = b[ip[i]];
    }
#else
    _Pragma("omp parallel for schedule(static)")
    for (int64_t i = 0; i < n; ++i) a[i] = b[ip[i]];
#endif
}
