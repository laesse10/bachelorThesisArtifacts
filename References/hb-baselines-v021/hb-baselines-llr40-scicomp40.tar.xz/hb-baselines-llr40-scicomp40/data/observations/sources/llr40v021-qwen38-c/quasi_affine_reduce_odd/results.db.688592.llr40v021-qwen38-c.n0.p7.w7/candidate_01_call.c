/* quasi_affine_reduce_odd: out[0] = sum(a[i] for i in 1, 3, 5, ..., < LEN_1D)
 *
 * Memory-bandwidth-bound streaming reduction over the odd-indexed elements.
 * AVX-512: every 8 consecutive wanted elements span 128 bytes of `a`
 * (a[2j+1 .. 2j+15]); two 512-bit loads + one vpermt2pd (select even lanes)
 * + one add. OpenMP static partitioning, one vector accumulator per chunk.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

void quasi_affine_reduce_odd_fp64(
    const double *restrict a, double *restrict out, const int64_t LEN_1D,
    uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    const int64_t m = LEN_1D / 2; /* count of odd subscripts i < LEN_1D */
    double acc = 0.0;
    if (m > 0) {
        const __m512i IDX_EVEN = _mm512_setr_epi64(0, 2, 4, 6, 8, 10, 12, 14);
        const int64_t nvec = (m >= 8) ? (m >> 3) : 0; /* 8-element blocks */
        const int64_t BPC = 512;                      /* blocks per chunk (4096 elems) */
        const int64_t nch = nvec / BPC;
        #pragma omp parallel for schedule(static) reduction(+:acc)
        for (int64_t c = 0; c < nch; c++) {
            const double *p = a + 16 * (c * BPC) + 1;
            __m512d v = _mm512_setzero_pd();
            for (int64_t b = c * BPC, b1 = (c + 1) * BPC; b < b1; b++) {
                __m512d lo = _mm512_loadu_pd(p);
                __m512d hi = _mm512_loadu_pd(p + 8);
                v = _mm512_add_pd(v, _mm512_permutex2var_pd(lo, IDX_EVEN, hi));
                p += 16;
            }
            acc += _mm512_reduce_add_pd(v);
        }
        /* remainder: elements [8*nch*BPC, m) */
        int64_t jv = 8 * (nch * BPC) & ~7LL;
        __m512d v = _mm512_setzero_pd();
        for (int64_t j = jv; j + 8 <= m; j += 8) {
            const double *p = a + 2 * j + 1;
            __m512d lo = _mm512_loadu_pd(p);
            __m512d hi = _mm512_loadu_pd(p + 8);
            v = _mm512_add_pd(v, _mm512_permutex2var_pd(lo, IDX_EVEN, hi));
        }
        for (int64_t j = m & ~7LL; j < m; j++) acc += a[2 * j + 1];
        acc += _mm512_reduce_add_pd(v);
    }
    out[0] = acc;
}
