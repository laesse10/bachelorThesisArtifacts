#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#if defined(__AVX512F__)
#include <immintrin.h>
#endif

void scan_affine_decay_fp64(
    const double *restrict c,
    const double *restrict x,
    double *restrict y,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    (void)workspace; (void)workspace_size;
    int64_t n = LEN_1D;
    if (n <= 1) return;

    int nt = omp_get_max_threads();
    if (nt < 1) nt = 1;
    if ((int64_t)nt > n) nt = (int)n;

    const int K = 4;
    double *At = malloc((size_t)nt * sizeof(double));
    double *Bt = malloc((size_t)nt * sizeof(double));

    #pragma omp parallel num_threads(nt)
    {
        int tid = omp_get_thread_num();
        int64_t per = n / nt, rem = n % nt;
        int64_t r0 = tid * per + (tid < rem ? tid : rem);
        int64_t r1 = r0 + per + (tid < rem ? 1 : 0);
        int64_t s0 = (tid == 0) ? 1 : r0;
        int64_t w = r1 - s0;

        double Amap[8], Bmap[8], yin[8];
        int64_t off[8];
        int kk = 0;
        if (w > 0) {
            kk = K;
            if ((int64_t)kk > w) kk = (int)w;
            int64_t L = w / kk, R = w % kk;
            int64_t o = 0;
            for (int k = 0; k < kk; k++) { off[k] = o; o += L + (k < R ? 1 : 0); }

            /* pass 1: per sub-range affine map */
            for (int k = 0; k < kk; k++) {
                int64_t i0 = s0 + off[k], i1 = i0 + L + (k < R ? 1 : 0);
                double A = 1.0, B = 0.0;
                int64_t i = i0;
#if defined(__AVX512F__)
                for (; i + 8 <= i1; i += 8) {
                    double cd[8], xd[8];
                    _mm512_storeu_pd(cd, _mm512_loadu_pd(c + i));
                    _mm512_storeu_pd(xd, _mm512_loadu_pd(x + i));
                    A = cd[0] * A; B = fma(cd[0], B, xd[0]);
                    A = cd[1] * A; B = fma(cd[1], B, xd[1]);
                    A = cd[2] * A; B = fma(cd[2], B, xd[2]);
                    A = cd[3] * A; B = fma(cd[3], B, xd[3]);
                    A = cd[4] * A; B = fma(cd[4], B, xd[4]);
                    A = cd[5] * A; B = fma(cd[5], B, xd[5]);
                    A = cd[6] * A; B = fma(cd[6], B, xd[6]);
                    A = cd[7] * A; B = fma(cd[7], B, xd[7]);
                }
#endif
                for (; i < i1; i++) {
                    double ci = c[i];
                    A = ci * A;
                    B = ci * B + x[i];
                }
                Amap[k] = A; Bmap[k] = B;
            }
        }
        double At2 = 1.0, Bt2 = 0.0;
        for (int k = 0; k < kk; k++) {
            At2 = Amap[k] * At2;
            Bt2 = Amap[k] * Bt2 + Bmap[k];
        }
        At[tid] = At2; Bt[tid] = Bt2;
        #pragma omp barrier
        double v = y[0];
        for (int t = 0; t < tid; t++) {
            v = At[t] * v + Bt[t];
        }
        for (int k = 0; k < kk; k++) {
            yin[k] = v;
            v = Amap[k] * v + Bmap[k];
        }

        /* pass 2 */
        if (w > 0) {
            int64_t L = w / kk, R = w % kk;
            int vec_done = 0;
#if defined(__AVX512F__)
            if (((uintptr_t)y & 63) == 0) {
                int64_t base[8], q[8];
                for (int k = 0; k < kk; k++) {
                    int64_t i0 = s0 + off[k];
                    int64_t len = L + (k < R ? 1 : 0);
                    int64_t p = (-i0) & 7;
                    if (p > len) p = len;
                    for (int64_t t = 0; t < p; t++) {
                        double vv = c[i0] * yin[k] + x[i0];
                        yin[k] = vv;
                        y[i0] = vv;
                        i0++;
                    }
                    base[k] = i0;
                    q[k] = (len - p) >> 3;
                }
                int64_t qmin = q[0];
                for (int k = 1; k < kk; k++) if (q[k] < qmin) qmin = q[k];
                for (int64_t j = 0; j < qmin; j++) {
                    for (int k_ = 0; k_ < kk; k_++) {
                        int64_t i = base[k_] + 8 * j;
                        double cd[8], xd[8];
                        _mm512_storeu_pd(cd, _mm512_loadu_pd(c + i));
                        _mm512_storeu_pd(xd, _mm512_loadu_pd(x + i));
                        double res[8];
                        double vv = yin[k_];
                        res[0] = fma(cd[0], vv, xd[0]);
                        res[1] = fma(cd[1], res[0], xd[1]);
                        res[2] = fma(cd[2], res[1], xd[2]);
                        res[3] = fma(cd[3], res[2], xd[3]);
                        res[4] = fma(cd[4], res[3], xd[4]);
                        res[5] = fma(cd[5], res[4], xd[5]);
                        res[6] = fma(cd[6], res[5], xd[6]);
                        res[7] = fma(cd[7], res[6], xd[7]);
                        yin[k_] = res[7];
                        _mm512_stream_pd(y + i, _mm512_loadu_pd(res));
                    }
                }
                for (int k_ = 0; k_ < kk; k_++) {
                    for (int64_t j = qmin; j < q[k_]; j++) {
                        int64_t i = base[k_] + 8 * j;
                        double cd[8], xd[8];
                        _mm512_storeu_pd(cd, _mm512_loadu_pd(c + i));
                        _mm512_storeu_pd(xd, _mm512_loadu_pd(x + i));
                        double res[8];
                        double vv = yin[k_];
                        res[0] = fma(cd[0], vv, xd[0]);
                        res[1] = fma(cd[1], res[0], xd[1]);
                        res[2] = fma(cd[2], res[1], xd[2]);
                        res[3] = fma(cd[3], res[2], xd[3]);
                        res[4] = fma(cd[4], res[3], xd[4]);
                        res[5] = fma(cd[5], res[4], xd[5]);
                        res[6] = fma(cd[6], res[5], xd[6]);
                        res[7] = fma(cd[7], res[6], xd[7]);
                        yin[k_] = res[7];
                        _mm512_stream_pd(y + i, _mm512_loadu_pd(res));
                    }
                    int64_t iend = s0 + off[k_] + L + (k_ < R ? 1 : 0);
                    for (int64_t i = base[k_] + 8 * q[k_]; i < iend; i++) {
                        double vv = c[i] * yin[k_] + x[i];
                        yin[k_] = vv;
                        y[i] = vv;
                    }
                }
                __builtin_ia32_sfence();
                vec_done = 1;
            }
#endif
            if (!vec_done) {
                for (int64_t s = 0; s < L; s++) {
                    for (int k = 0; k < kk; k++) {
                        int64_t i = s0 + off[k] + s;
                        double vv = c[i] * yin[k] + x[i];
                        yin[k] = vv;
                        y[i] = vv;
                    }
                }
                for (int k = 0; k < R; k++) {
                    int64_t i = s0 + off[k] + L;
                    double vv = c[i] * yin[k] + x[i];
                    yin[k] = vv;
                    y[i] = vv;
                }
            }
        }
    }
    free(At); free(Bt);
}
