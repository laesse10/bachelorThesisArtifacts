#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if defined(__AVX512F__) && defined(__AVX512BW__) && defined(__AVX512DQ__) && \
    defined(__AVX512_VPOPCNTDQ__)
#define K_USE_AVX512 1
#include <immintrin.h>
#else
#define K_USE_AVX512 0
#endif

#define K_MAX_THREADS 128
#define K_SUBCH 65536 /* chunks (8 elements, 64B) per sub-span = 4 MiB */

static inline int64_t k_scalar(const double *restrict src, const double *restrict weight,
                               double *restrict packed, int64_t n, int64_t base)
{
    int64_t cur = base;
    for (int64_t i = 0; i < n; i++) {
        if (src[i] > 0.0)
            packed[cur++] = src[i] * weight[i];
    }
    return cur - base;
}

#if K_USE_AVX512
static inline int k_count8(const double *restrict src)
{
    const __m512d zero = _mm512_setzero_pd();
    __m512d sv = _mm512_load_pd(src);
    __mmask8 f = _mm512_cmp_pd_mask(sv, zero, _CMP_GT_OQ);
    return __builtin_popcountl((unsigned)f);
}

static inline int k_scatter8(const double *restrict src, const double *restrict weight,
                             double *restrict packed, int64_t base)
{
    const __m512d zero = _mm512_setzero_pd();
    const __m512i pm = _mm512_setr_epi32(0, 1, 3, 7, 15, 31, 63, 127,
                                         0, 1, 3, 7, 15, 31, 63, 127);
    __m512d sv = _mm512_load_pd(src);
    __m512d wv = _mm512_load_pd(weight);
    __mmask8 f = _mm512_cmp_pd_mask(sv, zero, _CMP_GT_OQ);
    const __m512i frep = _mm512_set1_epi32((int)f);
    __m512i excl = _mm512_popcnt_epi32(_mm512_and_si512(frep, pm));
    __m256i idx = _mm256_add_epi32(_mm512_castsi512_si256(excl),
                                   _mm256_set1_epi32((int)base));
    __m512d prod = _mm512_maskz_mul_pd(f, sv, wv);
    _mm512_mask_i32scatter_pd(packed, f, idx, prod, 8);
    return __builtin_popcountl((unsigned)f);
}
#endif

void compact_threshold_pack_fp64(
    int64_t *restrict out_count,
    double *restrict packed,
    const double *restrict src,
    const double *restrict weight,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    if (LEN_1D <= 0) {
        *out_count = 0;
        return;
    }

    long nt = K_MAX_THREADS;
    long maxt = (long)omp_get_max_threads();
    if (nt > maxt) nt = maxt;
    if (nt < 1) nt = 1;

    const int64_t nch = LEN_1D / 8;
    const int64_t tail = LEN_1D & 7;

    if (nt == 1) {
        int64_t off = 0;
#if K_USE_AVX512
        for (int64_t c = 0; c < nch; c++)
            off += k_scatter8(src + c * 8, weight + c * 8, packed, off);
        if (tail)
            off += k_scalar(src + nch * 8, weight + nch * 8, packed, tail, off);
#else
        off += k_scalar(src, weight, packed, LEN_1D, 0);
#endif
        *out_count = off;
        return;
    }

    /* NUMA-balanced: G round-robin sub-spans per thread, one barrier total */
    long G = 1 + (140 / nt); /* ~140 sub-spans total (sub-span ~8 MiB) */
    if (G < 1) G = 1;
    const int64_t S = G * nt;
    const int64_t nsub0 = nch / S; /* chunks per sub-span (>= 1 when nch >= S) */
    int64_t *scnt = (int64_t *)__builtin_malloc(sizeof(int64_t) * (size_t)S);
    int64_t total = 0;
    #pragma omp parallel num_threads((int)nt) reduction(+:total)
    {
        const long t = omp_get_thread_num();
        const long nt2 = omp_get_num_threads();
        int64_t off_all = 0;

        /* stage 1: count each sub-span */
        for (long g = 0; g < G; g++) {
            const int64_t m = t + g * nt2;
            const int64_t clo = m * nsub0;
            int64_t chi = (m == S - 1) ? nch : (m + 1) * nsub0;
            int64_t cnt = 0;
#if K_USE_AVX512
            for (int64_t c = clo; c < chi; c++)
                cnt += k_count8(src + c * 8);
#else
            for (int64_t i = clo * 8; i < chi * 8; i++)
                cnt += (src[i] > 0.0);
#endif
            scnt[m] = cnt;
        }

        #pragma omp barrier
        {
            /* stage 2: scatter each sub-span with its global base */
            for (long g = 0; g < G; g++) {
                const int64_t m = t + g * nt2;
                const int64_t clo = m * nsub0;
                int64_t chi = (m == S - 1) ? nch : (m + 1) * nsub0;
                int64_t base = 0;
                for (int64_t j = 0; j < m; j++)
                    base += scnt[j];
                int64_t off = 0;
#if K_USE_AVX512
                for (int64_t c = clo; c < chi; c++)
                    off += k_scatter8(src + c * 8, weight + c * 8, packed, base + off);
#else
                off += k_scalar(src + clo * 8, weight + clo * 8, packed, chi * 8 - clo * 8, base);
#endif
                if (m == S - 1) {
                    if (nsub0 == 0)
                        off = k_scalar(src, weight, packed, LEN_1D, 0);
                    else if (tail)
                        off += k_scalar(src + nch * 8, weight + nch * 8, packed, tail, base + off);
                }
                off_all += off;
            }
        }
        total += off_all;
    }
    *out_count = total;
    __builtin_free(scnt);
}
