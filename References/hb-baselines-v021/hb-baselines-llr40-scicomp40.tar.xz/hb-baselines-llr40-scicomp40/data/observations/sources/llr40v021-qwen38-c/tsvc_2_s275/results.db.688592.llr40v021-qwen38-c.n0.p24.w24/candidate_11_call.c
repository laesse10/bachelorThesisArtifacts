#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

/* TSVC s275, K=8 contiguous groups per thread, D=48 prefetch.
   Hot loop uses three running base pointers; group offsets are immediates,
   masks/active-flags are hoisted out of the row loop.  See tsvc notes. */

#define D 48

static inline void col_scan(double *restrict aa, const double *restrict bb,
                            const double *restrict cc, const int64_t N, const int64_t col)
{
    if (aa[col] <= 0.0) return;
    double prev = aa[col];
    double *a = aa + col + N;
    const double *b = bb + col + N;
    const double *c = cc + col + N;
    for (int64_t j = 1; j < N; j++) {
        prev = fma(*b, *c, prev);
        *a = prev;
        a += N; b += N; c += N;
    }
}

/* ng groups starting at column c0 (c0 multiple of 8); ng <= 8 */
static void runK(double *restrict aa, const double *restrict bb, const double *restrict cc,
                 const int64_t N, const int64_t c0, const int64_t ng)
{
    const int64_t nrow = N - 1;
    double *a0 = aa + c0 + N;
    const double *b0 = bb + c0 + N;
    const double *c0p = cc + c0 + N;
    double *apf = a0; /* unused; kept for symmetry */
    const double *bpf = b0 + D * N;
    const double *cpf = c0p + D * N;
    (void)apf;

    if (ng == 8 && c0 + 64 <= N) {
        __m512d v[8];
        __mmask8 m[8];
        int have[8];
        for (int g = 0; g < 8; g++) {
            __m512d row0 = _mm512_loadu_pd(aa + c0 + 8 * g);
            m[g] = _mm512_cmp_pd_mask(row0, _mm512_setzero_pd(), _CMP_GT_OQ);
            v[g] = row0;
            have[g] = (m[g] != 0);
        }
        const int64_t lim = N - 1 - D > 0 ? N - 1 - D : 0;
        for (int64_t j = 1; j <= lim; j++) {
            if (have[0]) __builtin_prefetch(bpf + 0, 0, 3);
            if (have[1]) __builtin_prefetch(bpf + 8, 0, 3);
            if (have[2]) __builtin_prefetch(bpf + 16, 0, 3);
            if (have[3]) __builtin_prefetch(bpf + 24, 0, 3);
            if (have[4]) __builtin_prefetch(bpf + 32, 0, 3);
            if (have[5]) __builtin_prefetch(bpf + 40, 0, 3);
            if (have[6]) __builtin_prefetch(bpf + 48, 0, 3);
            if (have[7]) __builtin_prefetch(bpf + 56, 0, 3);
            if (have[0]) __builtin_prefetch(cpf + 0, 0, 3);
            if (have[1]) __builtin_prefetch(cpf + 8, 0, 3);
            if (have[2]) __builtin_prefetch(cpf + 16, 0, 3);
            if (have[3]) __builtin_prefetch(cpf + 24, 0, 3);
            if (have[4]) __builtin_prefetch(cpf + 32, 0, 3);
            if (have[5]) __builtin_prefetch(cpf + 40, 0, 3);
            if (have[6]) __builtin_prefetch(cpf + 48, 0, 3);
            if (have[7]) __builtin_prefetch(cpf + 56, 0, 3);

            if (have[0]) {
                if (m[0] == 0xff) {
                    v[0] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 0), _mm512_loadu_pd(c0p + 0), v[0]);
                    _mm512_storeu_pd(a0 + 0, v[0]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 0);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 0), _mm512_loadu_pd(c0p + 0), v[0]);
                    __m512d vn = _mm512_mask_blend_pd(m[0], vcur, vf);
                    v[0] = vn;
                    _mm512_storeu_pd(a0 + 0, vn);
                }
            }
            if (have[1]) {
                if (m[1] == 0xff) {
                    v[1] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 8), _mm512_loadu_pd(c0p + 8), v[1]);
                    _mm512_storeu_pd(a0 + 8, v[1]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 8);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 8), _mm512_loadu_pd(c0p + 8), v[1]);
                    __m512d vn = _mm512_mask_blend_pd(m[1], vcur, vf);
                    v[1] = vn;
                    _mm512_storeu_pd(a0 + 8, vn);
                }
            }
            if (have[2]) {
                if (m[2] == 0xff) {
                    v[2] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 16), _mm512_loadu_pd(c0p + 16), v[2]);
                    _mm512_storeu_pd(a0 + 16, v[2]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 16);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 16), _mm512_loadu_pd(c0p + 16), v[2]);
                    __m512d vn = _mm512_mask_blend_pd(m[2], vcur, vf);
                    v[2] = vn;
                    _mm512_storeu_pd(a0 + 16, vn);
                }
            }
            if (have[3]) {
                if (m[3] == 0xff) {
                    v[3] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 24), _mm512_loadu_pd(c0p + 24), v[3]);
                    _mm512_storeu_pd(a0 + 24, v[3]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 24);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 24), _mm512_loadu_pd(c0p + 24), v[3]);
                    __m512d vn = _mm512_mask_blend_pd(m[3], vcur, vf);
                    v[3] = vn;
                    _mm512_storeu_pd(a0 + 24, vn);
                }
            }
            if (have[4]) {
                if (m[4] == 0xff) {
                    v[4] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 32), _mm512_loadu_pd(c0p + 32), v[4]);
                    _mm512_storeu_pd(a0 + 32, v[4]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 32);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 32), _mm512_loadu_pd(c0p + 32), v[4]);
                    __m512d vn = _mm512_mask_blend_pd(m[4], vcur, vf);
                    v[4] = vn;
                    _mm512_storeu_pd(a0 + 32, vn);
                }
            }
            if (have[5]) {
                if (m[5] == 0xff) {
                    v[5] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 40), _mm512_loadu_pd(c0p + 40), v[5]);
                    _mm512_storeu_pd(a0 + 40, v[5]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 40);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 40), _mm512_loadu_pd(c0p + 40), v[5]);
                    __m512d vn = _mm512_mask_blend_pd(m[5], vcur, vf);
                    v[5] = vn;
                    _mm512_storeu_pd(a0 + 40, vn);
                }
            }
            if (have[6]) {
                if (m[6] == 0xff) {
                    v[6] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 48), _mm512_loadu_pd(c0p + 48), v[6]);
                    _mm512_storeu_pd(a0 + 48, v[6]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 48);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 48), _mm512_loadu_pd(c0p + 48), v[6]);
                    __m512d vn = _mm512_mask_blend_pd(m[6], vcur, vf);
                    v[6] = vn;
                    _mm512_storeu_pd(a0 + 48, vn);
                }
            }
            if (have[7]) {
                if (m[7] == 0xff) {
                    v[7] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 56), _mm512_loadu_pd(c0p + 56), v[7]);
                    _mm512_storeu_pd(a0 + 56, v[7]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 56);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 56), _mm512_loadu_pd(c0p + 56), v[7]);
                    __m512d vn = _mm512_mask_blend_pd(m[7], vcur, vf);
                    v[7] = vn;
                    _mm512_storeu_pd(a0 + 56, vn);
                }
            }
            a0 += N; b0 += N; c0p += N;
            bpf += N; cpf += N;
        }
        for (int64_t j = lim + 1; j <= nrow; j++) {
            if (have[0]) {
                if (m[0] == 0xff) {
                    v[0] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 0), _mm512_loadu_pd(c0p + 0), v[0]);
                    _mm512_storeu_pd(a0 + 0, v[0]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 0);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 0), _mm512_loadu_pd(c0p + 0), v[0]);
                    __m512d vn = _mm512_mask_blend_pd(m[0], vcur, vf);
                    v[0] = vn;
                    _mm512_storeu_pd(a0 + 0, vn);
                }
            }
            if (have[1]) {
                if (m[1] == 0xff) {
                    v[1] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 8), _mm512_loadu_pd(c0p + 8), v[1]);
                    _mm512_storeu_pd(a0 + 8, v[1]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 8);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 8), _mm512_loadu_pd(c0p + 8), v[1]);
                    __m512d vn = _mm512_mask_blend_pd(m[1], vcur, vf);
                    v[1] = vn;
                    _mm512_storeu_pd(a0 + 8, vn);
                }
            }
            if (have[2]) {
                if (m[2] == 0xff) {
                    v[2] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 16), _mm512_loadu_pd(c0p + 16), v[2]);
                    _mm512_storeu_pd(a0 + 16, v[2]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 16);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 16), _mm512_loadu_pd(c0p + 16), v[2]);
                    __m512d vn = _mm512_mask_blend_pd(m[2], vcur, vf);
                    v[2] = vn;
                    _mm512_storeu_pd(a0 + 16, vn);
                }
            }
            if (have[3]) {
                if (m[3] == 0xff) {
                    v[3] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 24), _mm512_loadu_pd(c0p + 24), v[3]);
                    _mm512_storeu_pd(a0 + 24, v[3]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 24);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 24), _mm512_loadu_pd(c0p + 24), v[3]);
                    __m512d vn = _mm512_mask_blend_pd(m[3], vcur, vf);
                    v[3] = vn;
                    _mm512_storeu_pd(a0 + 24, vn);
                }
            }
            if (have[4]) {
                if (m[4] == 0xff) {
                    v[4] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 32), _mm512_loadu_pd(c0p + 32), v[4]);
                    _mm512_storeu_pd(a0 + 32, v[4]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 32);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 32), _mm512_loadu_pd(c0p + 32), v[4]);
                    __m512d vn = _mm512_mask_blend_pd(m[4], vcur, vf);
                    v[4] = vn;
                    _mm512_storeu_pd(a0 + 32, vn);
                }
            }
            if (have[5]) {
                if (m[5] == 0xff) {
                    v[5] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 40), _mm512_loadu_pd(c0p + 40), v[5]);
                    _mm512_storeu_pd(a0 + 40, v[5]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 40);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 40), _mm512_loadu_pd(c0p + 40), v[5]);
                    __m512d vn = _mm512_mask_blend_pd(m[5], vcur, vf);
                    v[5] = vn;
                    _mm512_storeu_pd(a0 + 40, vn);
                }
            }
            if (have[6]) {
                if (m[6] == 0xff) {
                    v[6] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 48), _mm512_loadu_pd(c0p + 48), v[6]);
                    _mm512_storeu_pd(a0 + 48, v[6]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 48);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 48), _mm512_loadu_pd(c0p + 48), v[6]);
                    __m512d vn = _mm512_mask_blend_pd(m[6], vcur, vf);
                    v[6] = vn;
                    _mm512_storeu_pd(a0 + 48, vn);
                }
            }
            if (have[7]) {
                if (m[7] == 0xff) {
                    v[7] = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 56), _mm512_loadu_pd(c0p + 56), v[7]);
                    _mm512_storeu_pd(a0 + 56, v[7]);
                } else {
                    __m512d vcur = _mm512_loadu_pd(a0 + 56);
                    __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b0 + 56), _mm512_loadu_pd(c0p + 56), v[7]);
                    __m512d vn = _mm512_mask_blend_pd(m[7], vcur, vf);
                    v[7] = vn;
                    _mm512_storeu_pd(a0 + 56, vn);
                }
            }
            a0 += N; b0 += N; c0p += N;
        }
        return;
    }

    /* ng < 8: general path (only the last chunk) */
    for (int g = 0; g < ng; g++) {
        const int64_t col = c0 + 8 * g;
        if (col + 8 > N) {
            for (int64_t cc2 = col; cc2 < N; cc2++) col_scan(aa, bb, cc, N, cc2);
            continue;
        }
        __m512d row0 = _mm512_loadu_pd(aa + col);
        __mmask8 m = _mm512_cmp_pd_mask(row0, _mm512_setzero_pd(), _CMP_GT_OQ);
        if (m == 0) continue;
        __m512d v = row0;
        double *a = aa + col + N;
        const double *b = bb + col + N;
        const double *c = cc + col + N;
        const int64_t lim = N - 1 - D > 0 ? N - 1 - D : 0;
        for (int64_t j = 1; j <= lim; j++) {
            __builtin_prefetch(b + D * N, 0, 3);
            __builtin_prefetch(c + D * N, 0, 3);
            if (m == 0xff) {
                v = _mm512_fmadd_pd(_mm512_loadu_pd(b), _mm512_loadu_pd(c), v);
                _mm512_storeu_pd(a, v);
            } else {
                __m512d vcur = _mm512_loadu_pd(a);
                __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b), _mm512_loadu_pd(c), v);
                __m512d vn = _mm512_mask_blend_pd(m, vcur, vf);
                v = vn;
                _mm512_storeu_pd(a, vn);
            }
            a += N; b += N; c += N;
        }
        for (int64_t j = lim + 1; j <= nrow; j++) {
            if (m == 0xff) {
                v = _mm512_fmadd_pd(_mm512_loadu_pd(b), _mm512_loadu_pd(c), v);
                _mm512_storeu_pd(a, v);
            } else {
                __m512d vcur = _mm512_loadu_pd(a);
                __m512d vf = _mm512_fmadd_pd(_mm512_loadu_pd(b), _mm512_loadu_pd(c), v);
                __m512d vn = _mm512_mask_blend_pd(m, vcur, vf);
                v = vn;
                _mm512_storeu_pd(a, vn);
            }
            a += N; b += N; c += N;
        }
    }
}

void tsvc_2_s275_fp64(
    double *restrict aa,
    const double *restrict bb,
    const double *restrict cc,
    const int64_t LEN_2D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace; (void)workspace_size;
    const int64_t N = LEN_2D;
    if (N <= 1) return;
    const int64_t ngmax = (N + 7) / 8;

    #pragma omp parallel
    {
        #pragma omp for schedule(dynamic, 1)
        for (int64_t g0 = 0; g0 < ngmax; g0 += 8) {
            const int64_t ng = ngmax - g0 < 8 ? ngmax - g0 : 8;
            runK(aa, bb, cc, N, 8 * g0, ng);
        }
    }
}
