/* fuse_diamond: out[i] = (a[i]*a[i] + 1) * (a[i]*a[i] - 1)
 *
 * Optimization: the work is pure read+write streaming, so it is memory-bandwidth
 * bound.  The kernel:
 *   - splits LEN_1D into contiguous per-thread chunks (one OpenMP team),
 *   - runs 8 independent 8-element AVX-512 chains per iteration (512B in flight)
 *     for maximum memory-level parallelism,
 *   - uses non-temporal (streaming) loads/stores so the one-shot buffers do not
 *     churn L1/L2/L3, when the pointers are 64B-aligned (guarded at runtime),
 *   - uses 2x the available threads (hyperthread pairs) to double per-core MLP.
 * Falls back to unaligned normal-load/store paths when pointers are not
 * 64B-aligned, so it is safe for any buffer placement.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

static inline void fd_chunk_nt(const double *restrict a, double *restrict out,
                               int64_t i0, int64_t i1)
{
    /* full streaming path: (a+i) and (out+i) are 64B-aligned at the vector start */
    const __m512d one = _mm512_set1_pd(1.0);
    int64_t i = i0;
    while (i < i1 && (((uintptr_t)(a + i)) & 63)) {
        double t = a[i] * a[i];
        out[i] = (t + 1.0) * (t - 1.0);
        ++i;
    }
    for (; i + 64 <= i1; i += 64) {
        __m512d x0 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)(a + i)));
        __m512d x1 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)(a + i + 8)));
        __m512d x2 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)(a + i + 16)));
        __m512d x3 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)(a + i + 24)));
        __m512d x4 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)(a + i + 32)));
        __m512d x5 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)(a + i + 40)));
        __m512d x6 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)(a + i + 48)));
        __m512d x7 = _mm512_castsi512_pd(_mm512_stream_load_si512((void *)(a + i + 56)));
        __m512d t0 = _mm512_mul_pd(x0, x0);
        __m512d t1 = _mm512_mul_pd(x1, x1);
        __m512d t2 = _mm512_mul_pd(x2, x2);
        __m512d t3 = _mm512_mul_pd(x3, x3);
        __m512d t4 = _mm512_mul_pd(x4, x4);
        __m512d t5 = _mm512_mul_pd(x5, x5);
        __m512d t6 = _mm512_mul_pd(x6, x6);
        __m512d t7 = _mm512_mul_pd(x7, x7);
        _mm512_stream_pd(out + i, _mm512_mul_pd(_mm512_add_pd(t0, one), _mm512_sub_pd(t0, one)));
        _mm512_stream_pd(out + i + 8, _mm512_mul_pd(_mm512_add_pd(t1, one), _mm512_sub_pd(t1, one)));
        _mm512_stream_pd(out + i + 16, _mm512_mul_pd(_mm512_add_pd(t2, one), _mm512_sub_pd(t2, one)));
        _mm512_stream_pd(out + i + 24, _mm512_mul_pd(_mm512_add_pd(t3, one), _mm512_sub_pd(t3, one)));
        _mm512_stream_pd(out + i + 32, _mm512_mul_pd(_mm512_add_pd(t4, one), _mm512_sub_pd(t4, one)));
        _mm512_stream_pd(out + i + 40, _mm512_mul_pd(_mm512_add_pd(t5, one), _mm512_sub_pd(t5, one)));
        _mm512_stream_pd(out + i + 48, _mm512_mul_pd(_mm512_add_pd(t6, one), _mm512_sub_pd(t6, one)));
        _mm512_stream_pd(out + i + 56, _mm512_mul_pd(_mm512_add_pd(t7, one), _mm512_sub_pd(t7, one)));
    }
    for (; i < i1; ++i) {
        double t = a[i] * a[i];
        out[i] = (t + 1.0) * (t - 1.0);
    }
    _mm_sfence();
}

static inline void fd_chunk_ntst(const double *restrict a, double *restrict out,
                                 int64_t i0, int64_t i1)
{
    /* out is 64B-aligned at vector start; a may be unaligned (normal loads) */
    const __m512d one = _mm512_set1_pd(1.0);
    int64_t i = i0;
    while (i < i1 && (((uintptr_t)(out + i)) & 63)) {
        double t = a[i] * a[i];
        out[i] = (t + 1.0) * (t - 1.0);
        ++i;
    }
    for (; i + 64 <= i1; i += 64) {
        __m512d x0 = _mm512_loadu_pd(a + i);
        __m512d x1 = _mm512_loadu_pd(a + i + 8);
        __m512d x2 = _mm512_loadu_pd(a + i + 16);
        __m512d x3 = _mm512_loadu_pd(a + i + 24);
        __m512d x4 = _mm512_loadu_pd(a + i + 32);
        __m512d x5 = _mm512_loadu_pd(a + i + 40);
        __m512d x6 = _mm512_loadu_pd(a + i + 48);
        __m512d x7 = _mm512_loadu_pd(a + i + 56);
        __m512d t0 = _mm512_mul_pd(x0, x0);
        __m512d t1 = _mm512_mul_pd(x1, x1);
        __m512d t2 = _mm512_mul_pd(x2, x2);
        __m512d t3 = _mm512_mul_pd(x3, x3);
        __m512d t4 = _mm512_mul_pd(x4, x4);
        __m512d t5 = _mm512_mul_pd(x5, x5);
        __m512d t6 = _mm512_mul_pd(x6, x6);
        __m512d t7 = _mm512_mul_pd(x7, x7);
        _mm512_stream_pd(out + i, _mm512_mul_pd(_mm512_add_pd(t0, one), _mm512_sub_pd(t0, one)));
        _mm512_stream_pd(out + i + 8, _mm512_mul_pd(_mm512_add_pd(t1, one), _mm512_sub_pd(t1, one)));
        _mm512_stream_pd(out + i + 16, _mm512_mul_pd(_mm512_add_pd(t2, one), _mm512_sub_pd(t2, one)));
        _mm512_stream_pd(out + i + 24, _mm512_mul_pd(_mm512_add_pd(t3, one), _mm512_sub_pd(t3, one)));
        _mm512_stream_pd(out + i + 32, _mm512_mul_pd(_mm512_add_pd(t4, one), _mm512_sub_pd(t4, one)));
        _mm512_stream_pd(out + i + 40, _mm512_mul_pd(_mm512_add_pd(t5, one), _mm512_sub_pd(t5, one)));
        _mm512_stream_pd(out + i + 48, _mm512_mul_pd(_mm512_add_pd(t6, one), _mm512_sub_pd(t6, one)));
        _mm512_stream_pd(out + i + 56, _mm512_mul_pd(_mm512_add_pd(t7, one), _mm512_sub_pd(t7, one)));
    }
    for (; i < i1; ++i) {
        double t = a[i] * a[i];
        out[i] = (t + 1.0) * (t - 1.0);
    }
    _mm_sfence();
}

static inline void fd_chunk_plain(const double *restrict a, double *restrict out,
                                  int64_t i0, int64_t i1)
{
    /* no alignment assumptions: unaligned loads and normal stores */
    const __m512d one = _mm512_set1_pd(1.0);
    int64_t i = i0;
    for (; i + 64 <= i1; i += 64) {
        __m512d x0 = _mm512_loadu_pd(a + i);
        __m512d x1 = _mm512_loadu_pd(a + i + 8);
        __m512d x2 = _mm512_loadu_pd(a + i + 16);
        __m512d x3 = _mm512_loadu_pd(a + i + 24);
        __m512d x4 = _mm512_loadu_pd(a + i + 32);
        __m512d x5 = _mm512_loadu_pd(a + i + 40);
        __m512d x6 = _mm512_loadu_pd(a + i + 48);
        __m512d x7 = _mm512_loadu_pd(a + i + 56);
        __m512d t0 = _mm512_mul_pd(x0, x0);
        __m512d t1 = _mm512_mul_pd(x1, x1);
        __m512d t2 = _mm512_mul_pd(x2, x2);
        __m512d t3 = _mm512_mul_pd(x3, x3);
        __m512d t4 = _mm512_mul_pd(x4, x4);
        __m512d t5 = _mm512_mul_pd(x5, x5);
        __m512d t6 = _mm512_mul_pd(x6, x6);
        __m512d t7 = _mm512_mul_pd(x7, x7);
        _mm512_storeu_pd(out + i, _mm512_mul_pd(_mm512_add_pd(t0, one), _mm512_sub_pd(t0, one)));
        _mm512_storeu_pd(out + i + 8, _mm512_mul_pd(_mm512_add_pd(t1, one), _mm512_sub_pd(t1, one)));
        _mm512_storeu_pd(out + i + 16, _mm512_mul_pd(_mm512_add_pd(t2, one), _mm512_sub_pd(t2, one)));
        _mm512_storeu_pd(out + i + 24, _mm512_mul_pd(_mm512_add_pd(t3, one), _mm512_sub_pd(t3, one)));
        _mm512_storeu_pd(out + i + 32, _mm512_mul_pd(_mm512_add_pd(t4, one), _mm512_sub_pd(t4, one)));
        _mm512_storeu_pd(out + i + 40, _mm512_mul_pd(_mm512_add_pd(t5, one), _mm512_sub_pd(t5, one)));
        _mm512_storeu_pd(out + i + 48, _mm512_mul_pd(_mm512_add_pd(t6, one), _mm512_sub_pd(t6, one)));
        _mm512_storeu_pd(out + i + 56, _mm512_mul_pd(_mm512_add_pd(t7, one), _mm512_sub_pd(t7, one)));
    }
    for (; i < i1; ++i) {
        double t = a[i] * a[i];
        out[i] = (t + 1.0) * (t - 1.0);
    }
}

void fuse_diamond_fp64(
    const double *restrict a,
    double *restrict out,
    const int64_t LEN_1D,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    if (LEN_1D <= 0) return;

    const uintptr_t aa = (uintptr_t)a & 63u;
    const uintptr_t oa = (uintptr_t)out & 63u;
    const int nt_mode = (aa == oa) ? 2 : ((oa == 0) ? 1 : 0);

    int nt = 2 * omp_get_max_threads();
    if (nt < 1) nt = 1;
    int64_t maxt = LEN_1D / 8;
    if ((int64_t)nt > maxt) nt = (int)(maxt > 0 ? maxt : 1);

    #pragma omp parallel num_threads(nt)
    {
        int tid = omp_get_thread_num();
        int T = omp_get_num_threads();
        int64_t base = LEN_1D / T;
        int64_t rem = LEN_1D % T;
        int64_t i0 = base * tid + (tid < rem ? tid : rem);
        int64_t i1 = i0 + base + (tid < rem);
        switch (nt_mode) {
        case 2: fd_chunk_nt(a, out, i0, i1); break;
        case 1: fd_chunk_ntst(a, out, i0, i1); break;
        default: fd_chunk_plain(a, out, i0, i1); break;
        }
    }
}
