"""Extract every tool call of every agent transcript (claude stream-json) of the scicomp40 runs into CSV tables."""

import collections
import csv
import json
import pathlib
import re
import sqlite3
import sys

RUNS = pathlib.Path("/capstor/scratch/cscs/ybudanaz/x86_64/hpcagent-bench-runs/scicomp40-20261026")
OUT = pathlib.Path(sys.argv[1])
CLIP = 400


def clip(text: str) -> str:
    text = " ".join(text.split())
    return text if len(text) <= CLIP else text[:CLIP] + " ..."


def result_text(content: object) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(str(part.get("text", "")) for part in content if isinstance(part, dict))
    return ""


def episodes(db: pathlib.Path) -> dict[str, dict[str, object]]:
    connection = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    return {row["label"]: dict(row) for row in connection.execute("select * from episodes")}


calls_rows: list[dict[str, object]] = []
agent_rows: list[dict[str, object]] = []
for job in sorted(path for path in RUNS.iterdir() if path.name.isdigit()):
    meta = episodes(job / "results.db")
    for log in sorted(job.glob("agents/node-*/problem-*-worker-*/claude.log")):
        match = re.search(r"problem-(\d+)-worker-(\d+)", log.parent.name)
        problem = int(match.group(1))
        label = next((name for name in meta if name.endswith(f".p{problem}.w{match.group(2)}")), "")
        episode = meta.get(label, {})
        setup = str(episode.get("setup", ""))
        kernel = str(episode.get("kernel", ""))
        calls: dict[str, dict[str, object]] = {}
        driver: list[str] = []
        api_errors = collections.Counter()
        for line in log.open(encoding="utf-8", errors="replace"):
            if line.startswith("agent_driver:") or line.startswith("\nagent_driver:"):
                driver.append(line.strip())
                continue
            if not line.startswith("{"):
                if "agent_driver:" in line:
                    driver.append(line.strip())
                continue
            if '"tool_use"' not in line and '"tool_result"' not in line and "API Error" not in line:
                continue
            try:
                event = json.loads(line)
            except ValueError:
                continue
            message = event.get("message") if isinstance(event.get("message"), dict) else {}
            for block in message.get("content", []) if isinstance(message.get("content"), list) else []:
                if not isinstance(block, dict):
                    continue
                if block.get("type") == "tool_use" and block.get("id") not in calls:
                    calls[block["id"]] = {
                        "job": job.name,
                        "setup": setup,
                        "kernel": kernel,
                        "episode": label,
                        "index": len(calls),
                        "tool": str(block.get("name", "")).replace("mcp__hpcagent_bench__", "mcp:"),
                        "input": clip(json.dumps(block.get("input", {}), sort_keys=True)),
                        "is_error": "",
                        "result": "",
                    }
                elif block.get("type") == "tool_result" and block.get("tool_use_id") in calls:
                    call = calls[block["tool_use_id"]]
                    call["is_error"] = int(bool(block.get("is_error")))
                    call["result"] = clip(result_text(block.get("content")))
            if event.get("type") == "assistant" and "API Error" in line:
                for text in re.findall(r"API Error: [^\"\\]{0,80}", line):
                    api_errors[text] += 1
        tools = collections.Counter(str(call["tool"]) for call in calls.values())
        errors = sum(1 for call in calls.values() if call["is_error"] == 1)
        submits = [call for call in calls.values() if call["tool"] == "mcp:submit"]
        scores = [call for call in calls.values() if call["tool"] == "mcp:score"]
        agent_rows.append(
            {
                "job": job.name,
                "setup": setup,
                "kernel": kernel,
                "episode": label,
                "result": episode.get("result", ""),
                "returncode": episode.get("returncode", ""),
                "relaunches": episode.get("relaunches", ""),
                "turns": episode.get("turns", ""),
                "wall_h": round(int(episode.get("wall_ms") or 0) / 3.6e6, 2),
                "billed_tokens": episode.get("billed_tokens", ""),
                "tool_calls": len(calls),
                "tool_errors": errors,
                "score_calls": len(scores),
                "score_ok": sum(1 for call in scores if re.search(r'"correct": (true|"yes")', str(call["result"]))),
                "submit_calls": len(submits),
                "submit_ok": sum(1 for call in submits if re.search(r'"correct": (true|"yes")', str(call["result"]))),
                "by_tool": json.dumps(dict(tools.most_common())),
                "api_errors": json.dumps(dict(api_errors)),
                "driver_events": " | ".join(driver)[:CLIP],
            }
        )
        calls_rows.extend(calls.values())

OUT.mkdir(parents=True, exist_ok=True)
for name, rows in (("tool_calls.csv", calls_rows), ("agents.csv", agent_rows)):
    with (OUT / name).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
print(len(calls_rows), "calls,", len(agent_rows), "agents")
