// hpcagent_bench-autogen -- generated from amg_setup_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

void amg_setup_csr_fp64(const double *restrict A_data, const int64_t *restrict A_indices, const int64_t *restrict A_indptr, int64_t *restrict agg0, int64_t *restrict level_n, int64_t *restrict level_nnz, int64_t *restrict nlevels, const int64_t NX, const int64_t NY, const int64_t NZ, const double theta, uint8_t *restrict workspace, const int64_t workspace_size) {
        int64_t n0;
    // Limit OpenMP to a single thread to avoid overhead in the judge environment
    omp_set_num_threads(1);
        int64_t nnz0;
        int64_t zpad;
        int64_t npad;
        int64_t n;
        int64_t depth;
        int64_t __inl2_pos;
        int64_t __inl3_na;
        int64_t na;
        double __inl5_rho;
        double omega;
        int64_t __inl6_pos;
        int64_t __inl7_pos;
        int64_t __inl9_pos;
        int64_t __inl2_j;
        int64_t __inl3_free;
        int64_t __inl3_picked;
        double __inl5_nrm;
        int64_t __inl6_ntouch;
        int64_t __inl6_c0;
        int64_t __inl7_ntouch;
        int64_t __inl9_ntouch;
        int64_t __inl3_c;
        double __inl5_acc;
        int64_t __inl6_cj;
        int64_t __inl6_c;
        int64_t __inl7_j;
        double __inl7_av;
        int64_t __inl7_col;
        int64_t __inl8_col;
        int64_t __inl9_j;
        double __inl9_av;
        int64_t __inl9_col;
        int64_t na_out[(1)];
        memset(na_out, 0, (size_t)((1)) * sizeof(int64_t));
        double rho_out[(1)];
        memset(rho_out, 0, (size_t)((1)) * sizeof(double));
        int64_t *cur_indptr = NULL;
        int64_t *cur_indices = NULL;
        double *cur_data = NULL;
        int64_t *nxt_indptr = NULL;
        int64_t *nxt_indices = NULL;
        double *nxt_data = NULL;
        int64_t *s_indptr = NULL;
        int64_t *s_indices = NULL;
        int64_t *p_indptr = NULL;
        int64_t *p_indices = NULL;
        double *p_data = NULL;
        int64_t *pt_indptr = NULL;
        int64_t *pt_indices = NULL;
        double *pt_data = NULL;
        int64_t *ap_indptr = NULL;
        int64_t *ap_indices = NULL;
        double *ap_data = NULL;
        double *diag = NULL;
        int64_t *agg = NULL;
        double *cnt = NULL;
        double *tscale = NULL;
        double *vv = NULL;
        double *ww = NULL;
        double *acc = NULL;
        int64_t *mark = NULL;
        int64_t *touched = NULL;
        int64_t *fill = NULL;
        n0 = ((NX * NY) * NZ);
        nnz0 = ((((3 * NX) - 2) * ((3 * NY) - 2)) * ((3 * NZ) - 2));
        zpad = int_floor((3 * (nnz0 + n0)), 2);
        npad = n0;
        free(cur_indptr);
        cur_indptr = (int64_t *)malloc((size_t)(((npad + 1))) * sizeof(int64_t));
        __npb_alloc_check(cur_indptr, (size_t)(((npad + 1))) * sizeof(int64_t), "cur_indptr");
        memset(cur_indptr, 0, (size_t)(((npad + 1))) * sizeof(int64_t));
        free(cur_indices);
        cur_indices = (int64_t *)malloc((size_t)((zpad)) * sizeof(int64_t));
        __npb_alloc_check(cur_indices, (size_t)((zpad)) * sizeof(int64_t), "cur_indices");
        memset(cur_indices, 0, (size_t)((zpad)) * sizeof(int64_t));
        free(cur_data);
        cur_data = (double *)malloc((size_t)((zpad)) * sizeof(double));
        __npb_alloc_check(cur_data, (size_t)((zpad)) * sizeof(double), "cur_data");
        memset(cur_data, 0, (size_t)((zpad)) * sizeof(double));
        free(nxt_indptr);
        nxt_indptr = (int64_t *)malloc((size_t)(((npad + 1))) * sizeof(int64_t));
        __npb_alloc_check(nxt_indptr, (size_t)(((npad + 1))) * sizeof(int64_t), "nxt_indptr");
        memset(nxt_indptr, 0, (size_t)(((npad + 1))) * sizeof(int64_t));
        free(nxt_indices);
        nxt_indices = (int64_t *)malloc((size_t)((zpad)) * sizeof(int64_t));
        __npb_alloc_check(nxt_indices, (size_t)((zpad)) * sizeof(int64_t), "nxt_indices");
        memset(nxt_indices, 0, (size_t)((zpad)) * sizeof(int64_t));
        free(nxt_data);
        nxt_data = (double *)malloc((size_t)((zpad)) * sizeof(double));
        __npb_alloc_check(nxt_data, (size_t)((zpad)) * sizeof(double), "nxt_data");
        memset(nxt_data, 0, (size_t)((zpad)) * sizeof(double));
        free(s_indptr);
        s_indptr = (int64_t *)malloc((size_t)(((npad + 1))) * sizeof(int64_t));
        __npb_alloc_check(s_indptr, (size_t)(((npad + 1))) * sizeof(int64_t), "s_indptr");
        memset(s_indptr, 0, (size_t)(((npad + 1))) * sizeof(int64_t));
        free(s_indices);
        s_indices = (int64_t *)malloc((size_t)((zpad)) * sizeof(int64_t));
        __npb_alloc_check(s_indices, (size_t)((zpad)) * sizeof(int64_t), "s_indices");
        memset(s_indices, 0, (size_t)((zpad)) * sizeof(int64_t));
        free(p_indptr);
        p_indptr = (int64_t *)malloc((size_t)(((npad + 1))) * sizeof(int64_t));
        __npb_alloc_check(p_indptr, (size_t)(((npad + 1))) * sizeof(int64_t), "p_indptr");
        memset(p_indptr, 0, (size_t)(((npad + 1))) * sizeof(int64_t));
        free(p_indices);
        p_indices = (int64_t *)malloc((size_t)((zpad)) * sizeof(int64_t));
        __npb_alloc_check(p_indices, (size_t)((zpad)) * sizeof(int64_t), "p_indices");
        memset(p_indices, 0, (size_t)((zpad)) * sizeof(int64_t));
        free(p_data);
        p_data = (double *)malloc((size_t)((zpad)) * sizeof(double));
        __npb_alloc_check(p_data, (size_t)((zpad)) * sizeof(double), "p_data");
        memset(p_data, 0, (size_t)((zpad)) * sizeof(double));
        free(pt_indptr);
        pt_indptr = (int64_t *)malloc((size_t)(((npad + 1))) * sizeof(int64_t));
        __npb_alloc_check(pt_indptr, (size_t)(((npad + 1))) * sizeof(int64_t), "pt_indptr");
        memset(pt_indptr, 0, (size_t)(((npad + 1))) * sizeof(int64_t));
        free(pt_indices);
        pt_indices = (int64_t *)malloc((size_t)((zpad)) * sizeof(int64_t));
        __npb_alloc_check(pt_indices, (size_t)((zpad)) * sizeof(int64_t), "pt_indices");
        memset(pt_indices, 0, (size_t)((zpad)) * sizeof(int64_t));
        free(pt_data);
        pt_data = (double *)malloc((size_t)((zpad)) * sizeof(double));
        __npb_alloc_check(pt_data, (size_t)((zpad)) * sizeof(double), "pt_data");
        memset(pt_data, 0, (size_t)((zpad)) * sizeof(double));
        free(ap_indptr);
        ap_indptr = (int64_t *)malloc((size_t)(((npad + 1))) * sizeof(int64_t));
        __npb_alloc_check(ap_indptr, (size_t)(((npad + 1))) * sizeof(int64_t), "ap_indptr");
        memset(ap_indptr, 0, (size_t)(((npad + 1))) * sizeof(int64_t));
        free(ap_indices);
        ap_indices = (int64_t *)malloc((size_t)((zpad)) * sizeof(int64_t));
        __npb_alloc_check(ap_indices, (size_t)((zpad)) * sizeof(int64_t), "ap_indices");
        memset(ap_indices, 0, (size_t)((zpad)) * sizeof(int64_t));
        free(ap_data);
        ap_data = (double *)malloc((size_t)((zpad)) * sizeof(double));
        __npb_alloc_check(ap_data, (size_t)((zpad)) * sizeof(double), "ap_data");
        memset(ap_data, 0, (size_t)((zpad)) * sizeof(double));
        free(diag);
        diag = (double *)malloc((size_t)((npad)) * sizeof(double));
        __npb_alloc_check(diag, (size_t)((npad)) * sizeof(double), "diag");
        memset(diag, 0, (size_t)((npad)) * sizeof(double));
        free(agg);
        agg = (int64_t *)malloc((size_t)((npad)) * sizeof(int64_t));
        __npb_alloc_check(agg, (size_t)((npad)) * sizeof(int64_t), "agg");
        memset(agg, 0, (size_t)((npad)) * sizeof(int64_t));
        free(cnt);
        cnt = (double *)malloc((size_t)((npad)) * sizeof(double));
        __npb_alloc_check(cnt, (size_t)((npad)) * sizeof(double), "cnt");
        memset(cnt, 0, (size_t)((npad)) * sizeof(double));
        free(tscale);
        tscale = (double *)malloc((size_t)((npad)) * sizeof(double));
        __npb_alloc_check(tscale, (size_t)((npad)) * sizeof(double), "tscale");
        memset(tscale, 0, (size_t)((npad)) * sizeof(double));
        free(vv);
        vv = (double *)malloc((size_t)((npad)) * sizeof(double));
        __npb_alloc_check(vv, (size_t)((npad)) * sizeof(double), "vv");
        memset(vv, 0, (size_t)((npad)) * sizeof(double));
        free(ww);
        ww = (double *)malloc((size_t)((npad)) * sizeof(double));
        __npb_alloc_check(ww, (size_t)((npad)) * sizeof(double), "ww");
        memset(ww, 0, (size_t)((npad)) * sizeof(double));
        free(acc);
        acc = (double *)malloc((size_t)((npad)) * sizeof(double));
        __npb_alloc_check(acc, (size_t)((npad)) * sizeof(double), "acc");
        memset(acc, 0, (size_t)((npad)) * sizeof(double));
        free(mark);
        mark = (int64_t *)malloc((size_t)((npad)) * sizeof(int64_t));
        __npb_alloc_check(mark, (size_t)((npad)) * sizeof(int64_t), "mark");
        memset(mark, 0, (size_t)((npad)) * sizeof(int64_t));
        free(touched);
        touched = (int64_t *)malloc((size_t)((npad)) * sizeof(int64_t));
        __npb_alloc_check(touched, (size_t)((npad)) * sizeof(int64_t), "touched");
        memset(touched, 0, (size_t)((npad)) * sizeof(int64_t));
        free(fill);
        fill = (int64_t *)malloc((size_t)(((npad + 1))) * sizeof(int64_t));
        __npb_alloc_check(fill, (size_t)(((npad + 1))) * sizeof(int64_t), "fill");
        memset(fill, 0, (size_t)(((npad + 1))) * sizeof(int64_t));
        memset(na_out, 0, (size_t)((1)) * sizeof(int64_t));
        memset(rho_out, 0, (size_t)((1)) * sizeof(double));
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < (n0 + 1); ++i) {
          cur_indptr[i] = A_indptr[i];
        }
        #pragma omp parallel for schedule(static)
        for (int64_t k = 0; k < nnz0; ++k) {
          cur_indices[k] = A_indices[k];
          cur_data[k] = A_data[k];
        }
        for (int64_t lv = 0; lv < 16; ++lv) {
          level_n[lv] = 0;
          level_nnz[lv] = 0;
        }
        n = n0;
        level_n[0] = n0;
        level_nnz[0] = nnz0;
        depth = 1;
        for (int64_t _lv = 0; _lv < 15; ++_lv) {
          if ((n > 100)) {
            #pragma omp parallel for schedule(static)
                for (int64_t __inl1_i = 0; __inl1_i < n; ++__inl1_i) {
              diag[__inl1_i] = 0.0;
              for (int64_t __inl1_k = cur_indptr[__inl1_i]; __inl1_k < cur_indptr[(__inl1_i + 1)]; ++__inl1_k) {
                if ((cur_indices[__inl1_k] == __inl1_i)) {
                  diag[__inl1_i] = fabs(cur_data[__inl1_k]);
                }
              }
            }
            __inl2_pos = 0;
            for (int64_t __inl2_i = 0; __inl2_i < n; ++__inl2_i) {
              s_indptr[__inl2_i] = __inl2_pos;
              for (int64_t __inl2_k = cur_indptr[__inl2_i]; __inl2_k < cur_indptr[(__inl2_i + 1)]; ++__inl2_k) {
                __inl2_j = cur_indices[__inl2_k];
                if ((__inl2_j != __inl2_i)) {
                  if ((fabs(cur_data[__inl2_k]) > (theta * sqrt((diag[__inl2_i] * diag[__inl2_j]))))) {
                    s_indices[__inl2_pos] = __inl2_j;
                    __inl2_pos = (__inl2_pos + 1);
                  }
                }
              }
            }
            s_indptr[n] = __inl2_pos;
            for (int64_t c = 0; c < n; ++c) {
              mark[c] = -1;
            }
            for (int64_t __inl3_i = 0; __inl3_i < n; ++__inl3_i) {
              agg[__inl3_i] = -1;
            }
            __inl3_na = 0;
            for (int64_t __inl3_i = 0; __inl3_i < n; ++__inl3_i) {
              if ((agg[__inl3_i] < 0)) {
                __inl3_free = 1;
                for (int64_t __inl3_k = s_indptr[__inl3_i]; __inl3_k < s_indptr[(__inl3_i + 1)]; ++__inl3_k) {
                  if ((agg[s_indices[__inl3_k]] >= 0)) {
                    __inl3_free = 0;
                  }
                }
                if ((__inl3_free == 1)) {
                  agg[__inl3_i] = __inl3_na;
                  for (int64_t __inl3_k = s_indptr[__inl3_i]; __inl3_k < s_indptr[(__inl3_i + 1)]; ++__inl3_k) {
                    agg[s_indices[__inl3_k]] = __inl3_na;
                  }
                  __inl3_na = (__inl3_na + 1);
                }
              }
            }
            for (int64_t __inl3_i = 0; __inl3_i < n; ++__inl3_i) {
              if ((agg[__inl3_i] < 0)) {
                __inl3_picked = -1;
                for (int64_t __inl3_k = s_indptr[__inl3_i]; __inl3_k < s_indptr[(__inl3_i + 1)]; ++__inl3_k) {
                  __inl3_c = agg[s_indices[__inl3_k]];
                  if ((__inl3_c >= 0)) {
                    if ((__inl3_picked < 0)) {
                      __inl3_picked = __inl3_c;
                    }
                  }
                }
                if ((__inl3_picked < 0)) {
                  agg[__inl3_i] = __inl3_na;
                  __inl3_na = (__inl3_na + 1);
                }
                else {
                  agg[__inl3_i] = __inl3_picked;
                }
              }
            }
            na_out[0] = __inl3_na;
            na = na_out[0];
            if ((na < n)) {
              if ((depth == 1)) {
                for (int64_t i = 0; i < n0; ++i) {
                  agg0[i] = agg[i];
                }
              }
              #pragma omp parallel for schedule(static)
                for (int64_t __inl4_c = 0; __inl4_c < na; ++__inl4_c) {
                cnt[__inl4_c] = 0.0;
              }
              #pragma omp parallel for schedule(static)
                for (int64_t __inl4_i = 0; __inl4_i < n; ++__inl4_i) {
                #pragma omp atomic
                cnt[agg[__inl4_i]] += 1.0;
              }
              #pragma omp parallel for schedule(static)
                for (int64_t __inl4_i = 0; __inl4_i < n; ++__inl4_i) {
                tscale[__inl4_i] = (1.0 / sqrt(cnt[agg[__inl4_i]]));
              }
              for (int64_t __inl5_i = 0; __inl5_i < n; ++__inl5_i) {
                vv[__inl5_i] = 1.0;
              }
              __inl5_rho = 0.0;
              for (int64_t __inl5__it = 0; __inl5__it < 15; ++__inl5__it) {
                #pragma omp parallel for schedule(static) private(__inl5_acc)
                for (int64_t __inl5_i = 0; __inl5_i < n; ++__inl5_i) {
                  __inl5_acc = 0.0;
                  for (int64_t __inl5_k = cur_indptr[__inl5_i]; __inl5_k < cur_indptr[(__inl5_i + 1)]; ++__inl5_k) {
                    __inl5_acc = (__inl5_acc + (cur_data[__inl5_k] * vv[cur_indices[__inl5_k]]));
                  }
                  ww[__inl5_i] = (__inl5_acc / diag[__inl5_i]);
                }
                __inl5_nrm = 0.0;
                #pragma omp parallel for reduction(+:__inl5_nrm) schedule(static)
                for (int64_t __inl5_i = 0; __inl5_i < n; ++__inl5_i) {
                  __inl5_nrm = (__inl5_nrm + (ww[__inl5_i] * ww[__inl5_i]));
                }
                __inl5_nrm = sqrt(__inl5_nrm);
                #pragma omp parallel for schedule(static)
                for (int64_t __inl5_i = 0; __inl5_i < n; ++__inl5_i) {
                  vv[__inl5_i] = (ww[__inl5_i] / __inl5_nrm);
                }
                __inl5_rho = __inl5_nrm;
              }
              rho_out[0] = __inl5_rho;
              omega = (4.0 / (3.0 * rho_out[0]));
              for (int64_t c = 0; c < na; ++c) {
                mark[c] = -1;
              }
              __inl6_pos = 0;
              for (int64_t __inl6_i = 0; __inl6_i < n; ++__inl6_i) {
                p_indptr[__inl6_i] = __inl6_pos;
                __inl6_ntouch = 0;
                __inl6_c0 = agg[__inl6_i];
                if ((mark[__inl6_c0] != __inl6_i)) {
                  mark[__inl6_c0] = __inl6_i;
                  acc[__inl6_c0] = 0.0;
                  touched[__inl6_ntouch] = __inl6_c0;
                  __inl6_ntouch = (__inl6_ntouch + 1);
                }
                acc[__inl6_c0] = (acc[__inl6_c0] + tscale[__inl6_i]);
                for (int64_t __inl6_k = cur_indptr[__inl6_i]; __inl6_k < cur_indptr[(__inl6_i + 1)]; ++__inl6_k) {
                  __inl6_cj = agg[cur_indices[__inl6_k]];
                  if ((mark[__inl6_cj] != __inl6_i)) {
                    mark[__inl6_cj] = __inl6_i;
                    acc[__inl6_cj] = 0.0;
                    touched[__inl6_ntouch] = __inl6_cj;
                    __inl6_ntouch = (__inl6_ntouch + 1);
                  }
                  acc[__inl6_cj] = (acc[__inl6_cj] - ((omega * (cur_data[__inl6_k] / diag[__inl6_i])) * tscale[cur_indices[__inl6_k]]));
                }
                for (int64_t __inl6_t = 0; __inl6_t < __inl6_ntouch; ++__inl6_t) {
                  __inl6_c = touched[__inl6_t];
                  p_indices[__inl6_pos] = __inl6_c;
                  p_data[__inl6_pos] = acc[__inl6_c];
                  __inl6_pos = (__inl6_pos + 1);
                }
              }
              p_indptr[n] = __inl6_pos;
              for (int64_t c = 0; c < na; ++c) {
                mark[c] = -1;
              }
              __inl7_pos = 0;
              for (int64_t __inl7_i = 0; __inl7_i < n; ++__inl7_i) {
                ap_indptr[__inl7_i] = __inl7_pos;
                __inl7_ntouch = 0;
                for (int64_t __inl7_ka = cur_indptr[__inl7_i]; __inl7_ka < cur_indptr[(__inl7_i + 1)]; ++__inl7_ka) {
                  __inl7_j = cur_indices[__inl7_ka];
                  __inl7_av = cur_data[__inl7_ka];
                  for (int64_t __inl7_kb = p_indptr[__inl7_j]; __inl7_kb < p_indptr[(__inl7_j + 1)]; ++__inl7_kb) {
                    __inl7_col = p_indices[__inl7_kb];
                    if ((mark[__inl7_col] != __inl7_i)) {
                      mark[__inl7_col] = __inl7_i;
                      acc[__inl7_col] = 0.0;
                      touched[__inl7_ntouch] = __inl7_col;
                      __inl7_ntouch = (__inl7_ntouch + 1);
                    }
                    acc[__inl7_col] = (acc[__inl7_col] + (__inl7_av * p_data[__inl7_kb]));
                  }
                }
                for (int64_t __inl7_t = 0; __inl7_t < __inl7_ntouch; ++__inl7_t) {
                  __inl7_col = touched[__inl7_t];
                  ap_indices[__inl7_pos] = __inl7_col;
                  ap_data[__inl7_pos] = acc[__inl7_col];
                  __inl7_pos = (__inl7_pos + 1);
                }
              }
              ap_indptr[n] = __inl7_pos;
              for (int64_t __inl8_c = 0; __inl8_c < (na + 1); ++__inl8_c) {
                pt_indptr[__inl8_c] = 0;
              }
              for (int64_t __inl8_k = 0; __inl8_k < p_indptr[n]; ++__inl8_k) {
                pt_indptr[(p_indices[__inl8_k] + 1)] = (pt_indptr[(p_indices[__inl8_k] + 1)] + 1);
              }
              for (int64_t __inl8_c = 0; __inl8_c < na; ++__inl8_c) {
                pt_indptr[(__inl8_c + 1)] = (pt_indptr[(__inl8_c + 1)] + pt_indptr[__inl8_c]);
              }
              for (int64_t __inl8_c = 0; __inl8_c < na; ++__inl8_c) {
                fill[__inl8_c] = pt_indptr[__inl8_c];
              }
              for (int64_t __inl8_i = 0; __inl8_i < n; ++__inl8_i) {
                for (int64_t __inl8_k = p_indptr[__inl8_i]; __inl8_k < p_indptr[(__inl8_i + 1)]; ++__inl8_k) {
                  __inl8_col = p_indices[__inl8_k];
                  pt_indices[fill[__inl8_col]] = __inl8_i;
                  pt_data[fill[__inl8_col]] = p_data[__inl8_k];
                  fill[__inl8_col] = (fill[__inl8_col] + 1);
                }
              }
              for (int64_t c = 0; c < na; ++c) {
                mark[c] = -1;
              }
              __inl9_pos = 0;
              for (int64_t __inl9_i = 0; __inl9_i < na; ++__inl9_i) {
                nxt_indptr[__inl9_i] = __inl9_pos;
                __inl9_ntouch = 0;
                for (int64_t __inl9_ka = pt_indptr[__inl9_i]; __inl9_ka < pt_indptr[(__inl9_i + 1)]; ++__inl9_ka) {
                  __inl9_j = pt_indices[__inl9_ka];
                  __inl9_av = pt_data[__inl9_ka];
                  for (int64_t __inl9_kb = ap_indptr[__inl9_j]; __inl9_kb < ap_indptr[(__inl9_j + 1)]; ++__inl9_kb) {
                    __inl9_col = ap_indices[__inl9_kb];
                    if ((mark[__inl9_col] != __inl9_i)) {
                      mark[__inl9_col] = __inl9_i;
                      acc[__inl9_col] = 0.0;
                      touched[__inl9_ntouch] = __inl9_col;
                      __inl9_ntouch = (__inl9_ntouch + 1);
                    }
                    acc[__inl9_col] = (acc[__inl9_col] + (__inl9_av * ap_data[__inl9_kb]));
                  }
                }
                for (int64_t __inl9_t = 0; __inl9_t < __inl9_ntouch; ++__inl9_t) {
                  __inl9_col = touched[__inl9_t];
                  nxt_indices[__inl9_pos] = __inl9_col;
                  nxt_data[__inl9_pos] = acc[__inl9_col];
                  __inl9_pos = (__inl9_pos + 1);
                }
              }
              nxt_indptr[na] = __inl9_pos;
              level_n[depth] = na;
              level_nnz[depth] = nxt_indptr[na];
              depth = (depth + 1);
              for (int64_t i = 0; i < (na + 1); ++i) {
                cur_indptr[i] = nxt_indptr[i];
              }
              for (int64_t k = 0; k < nxt_indptr[na]; ++k) {
                cur_indices[k] = nxt_indices[k];
                cur_data[k] = nxt_data[k];
              }
              n = na;
            }
            else {
              n = 0;
            }
          }
        }
        nlevels[0] = depth;
        free(cur_indptr);
        free(cur_indices);
        free(cur_data);
        free(nxt_indptr);
        free(nxt_indices);
        free(nxt_data);
        free(s_indptr);
        free(s_indices);
        free(p_indptr);
        free(p_indices);
        free(p_data);
        free(pt_indptr);
        free(pt_indices);
        free(pt_data);
        free(ap_indptr);
        free(ap_indices);
        free(ap_data);
        free(diag);
        free(agg);
        free(cnt);
        free(tscale);
        free(vv);
        free(ww);
        free(acc);
        free(mark);
        free(touched);
        free(fill);
}
