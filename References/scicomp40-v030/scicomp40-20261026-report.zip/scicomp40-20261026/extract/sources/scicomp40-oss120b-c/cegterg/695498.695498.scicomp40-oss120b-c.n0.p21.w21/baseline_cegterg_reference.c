// hpcagent_bench-autogen -- generated from cegterg_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}
#include <fftw3.h>

void cegterg_fp64(const int32_t *restrict btype, const double *restrict deeq, double *restrict e, double _Complex *restrict evc, const double *restrict g2kin, const double *restrict h_diag, const int64_t *restrict nlk, const int64_t *restrict npw, const double *restrict qq, const double *restrict s_diag, const double _Complex *restrict vkb, const double *restrict vrs, const int64_t current_k, const double ethr, bool lrot, int64_t n1, int64_t n2, int64_t n3, int64_t nkb, int64_t nks, int64_t npol, int64_t npwx, int64_t nvec, int64_t nvecx, bool uspp, uint8_t *restrict workspace, const int64_t workspace_size) {
        int64_t __swap1_0;
        int64_t __swap1_1;
        int64_t __swap1_2;
        int64_t __swap1_3;
        int64_t __swap2_0;
        int64_t __swap2_1;
        int64_t __swap2_2;
        int64_t __swap2_3;
        int64_t __swap2_4;
        int64_t ck0;
        int64_t npw_k;
        int64_t noncolin;
        int64_t domag;
        int64_t nnr;
        int64_t kdim;
        double empty_ethr;
        int64_t nhpsi;
        int64_t notcnv;
        int64_t nbase;
        int64_t dav_iter;
        int64_t __inl8_nb1_0;
        int64_t np_;
        int64_t nb1;
        int64_t nend;
        int64_t __cb64;
        double _Complex __inl5_acc;
        double _Complex __s;
        int64_t __inv_p;
        double _Complex __inv_factor;
        double __inl9___eigh0_off;
        int64_t __inl9___eigh0_mn;
        int64_t __inl9_max_i;
        double __inl9_max_val;
        double _Complex __inl9_phase;
        int64_t __sol_p;
        double _Complex __sol_factor;
        int64_t idx;
        double __inl18___eigh0_off;
        int64_t __inl18___eigh0_mn;
        int64_t __inl18_max_i;
        double __inl18_max_val;
        double _Complex __inl18_phase;
        double _Complex __inl6_acc;
        double _Complex __inl7_acc;
        double _Complex __inl9_val_a;
        double _Complex __inl9_val_b;
        double _Complex __inv_tmp;
        double _Complex __inl9_val;
        double __inl9___eigh0_tw;
        double __inl9_av;
        double _Complex __sol_tmp;
        double x;
        double pow_base2;
        double denm;
        double _Complex __inl14_acc;
        double _Complex __inl18_val_a;
        double _Complex __inl18_val_b;
        double _Complex __inl18_val;
        double __inl18___eigh0_tw;
        double __inl18_av;
        double _Complex __inl28_acc;
        double _Complex __inl9___eigh0_apq;
        double __inl9___eigh0_m;
        double __inl9___eigh0_app;
        double __inl9___eigh0_aqq;
        double __inl9___eigh0_s;
        double _Complex __inl9___eigh0_tv;
        double _Complex __inl15_acc;
        double _Complex __inl16_acc;
        double _Complex __inl18___eigh0_apq;
        double __inl18___eigh0_m;
        double __inl18___eigh0_app;
        double __inl18___eigh0_aqq;
        double __inl18___eigh0_s;
        double _Complex __inl18___eigh0_tv;
        double _Complex __inl32_acc;
        double _Complex __inl9___eigh0_akp;
        double _Complex __inl9___eigh0_akq;
        double _Complex __inl9___eigh0_apk;
        double _Complex __inl9___eigh0_aqk;
        double _Complex __inl9___eigh0_vkp;
        double _Complex __inl9___eigh0_vkq;
        double _Complex __inl44_acc;
        double _Complex __inl18___eigh0_akp;
        double _Complex __inl18___eigh0_akq;
        double _Complex __inl18___eigh0_apk;
        double _Complex __inl18___eigh0_aqk;
        double _Complex __inl18___eigh0_vkp;
        double _Complex __inl18___eigh0_vkq;
        double _Complex __inl48_acc;
        double _Complex *psi = (double _Complex *)malloc((size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex));
        __npb_alloc_check(psi, (size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex), "psi");
        memset(psi, 0, (size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex));
        double _Complex *hpsi = (double _Complex *)malloc((size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex));
        __npb_alloc_check(hpsi, (size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex), "hpsi");
        memset(hpsi, 0, (size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex));
        double _Complex *spsi = (double _Complex *)malloc((size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex));
        __npb_alloc_check(spsi, (size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex), "spsi");
        memset(spsi, 0, (size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex));
        double _Complex *hc = (double _Complex *)malloc((size_t)((nvecx) * (nvecx)) * sizeof(double _Complex));
        __npb_alloc_check(hc, (size_t)((nvecx) * (nvecx)) * sizeof(double _Complex), "hc");
        memset(hc, 0, (size_t)((nvecx) * (nvecx)) * sizeof(double _Complex));
        double _Complex *sc = (double _Complex *)malloc((size_t)((nvecx) * (nvecx)) * sizeof(double _Complex));
        __npb_alloc_check(sc, (size_t)((nvecx) * (nvecx)) * sizeof(double _Complex), "sc");
        memset(sc, 0, (size_t)((nvecx) * (nvecx)) * sizeof(double _Complex));
        double _Complex *vc = (double _Complex *)malloc((size_t)((nvecx) * (nvecx)) * sizeof(double _Complex));
        __npb_alloc_check(vc, (size_t)((nvecx) * (nvecx)) * sizeof(double _Complex), "vc");
        memset(vc, 0, (size_t)((nvecx) * (nvecx)) * sizeof(double _Complex));
        double *ew = (double *)malloc((size_t)((nvecx)) * sizeof(double));
        __npb_alloc_check(ew, (size_t)((nvecx)) * sizeof(double), "ew");
        memset(ew, 0, (size_t)((nvecx)) * sizeof(double));
        bool *conv = (bool *)malloc((size_t)((nvec)) * sizeof(bool));
        __npb_alloc_check(conv, (size_t)((nvec)) * sizeof(bool), "conv");
        memset(conv, 0, (size_t)((nvec)) * sizeof(bool));
        double _Complex *__inl3_H = (double _Complex *)malloc((size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex));
        __npb_alloc_check(__inl3_H, (size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex), "__inl3_H");
        memset(__inl3_H, 0, (size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex));
        double _Complex *__inl28_C = (double _Complex *)malloc((size_t)((nvec) * (nkb)) * sizeof(double _Complex));
        __npb_alloc_check(__inl28_C, (size_t)((nvec) * (nkb)) * sizeof(double _Complex), "__inl28_C");
        memset(__inl28_C, 0, (size_t)((nvec) * (nkb)) * sizeof(double _Complex));
        double _Complex *__inl32_C = (double _Complex *)malloc((size_t)((nvec) * (nkb)) * sizeof(double _Complex));
        __npb_alloc_check(__inl32_C, (size_t)((nvec) * (nkb)) * sizeof(double _Complex), "__inl32_C");
        memset(__inl32_C, 0, (size_t)((nvec) * (nkb)) * sizeof(double _Complex));
        int64_t *unconv = (int64_t *)malloc((size_t)((nvec)) * sizeof(int64_t));
        __npb_alloc_check(unconv, (size_t)((nvec)) * sizeof(int64_t), "unconv");
        memset(unconv, 0, (size_t)((nvec)) * sizeof(int64_t));
        int64_t *__cb1 = (int64_t *)malloc((size_t)((nks)) * sizeof(int64_t));
        __npb_alloc_check(__cb1, (size_t)((nks)) * sizeof(int64_t), "__cb1");
        int64_t *__cb2 = (int64_t *)malloc((size_t)((nks)) * sizeof(int64_t));
        __npb_alloc_check(__cb2, (size_t)((nks)) * sizeof(int64_t), "__cb2");
        double *__cb9 = (double *)malloc((size_t)((nks) * (npwx)) * sizeof(double));
        __npb_alloc_check(__cb9, (size_t)((nks) * (npwx)) * sizeof(double), "__cb9");
        int64_t *__cb10 = (int64_t *)malloc((size_t)((nks) * (npwx)) * sizeof(int64_t));
        __npb_alloc_check(__cb10, (size_t)((nks) * (npwx)) * sizeof(int64_t), "__cb10");
        double _Complex *__cb11 = (double _Complex *)malloc((size_t)((nks) * (nkb) * (npwx)) * sizeof(double _Complex));
        __npb_alloc_check(__cb11, (size_t)((nks) * (nkb) * (npwx)) * sizeof(double _Complex), "__cb11");
        double _Complex *__cb12 = (double _Complex *)malloc((size_t)((nvec) * (n3) * (n2) * (n1)) * sizeof(double _Complex));
        __npb_alloc_check(__cb12, (size_t)((nvec) * (n3) * (n2) * (n1)) * sizeof(double _Complex), "__cb12");
        double _Complex *__cb13 = (double _Complex *)malloc((size_t)((nvec) * (n3) * (n2) * (n1)) * sizeof(double _Complex));
        __npb_alloc_check(__cb13, (size_t)((nvec) * (n3) * (n2) * (n1)) * sizeof(double _Complex), "__cb13");
        double _Complex *__cb15 = (double _Complex *)malloc((size_t)((nvec) * (n3) * (n2) * (n1)) * sizeof(double _Complex));
        __npb_alloc_check(__cb15, (size_t)((nvec) * (n3) * (n2) * (n1)) * sizeof(double _Complex), "__cb15");
        double _Complex *__cb16 = (double _Complex *)malloc((size_t)((nvec) * (n3) * (n2) * (n1)) * sizeof(double _Complex));
        __npb_alloc_check(__cb16, (size_t)((nvec) * (n3) * (n2) * (n1)) * sizeof(double _Complex), "__cb16");
        double _Complex *__mm18 = (double _Complex *)malloc((size_t)((nvec) * (nkb)) * sizeof(double _Complex));
        __npb_alloc_check(__mm18, (size_t)((nvec) * (nkb)) * sizeof(double _Complex), "__mm18");
        double _Complex *__mm21 = (double _Complex *)malloc((size_t)((nvec) * (nkb)) * sizeof(double _Complex));
        __npb_alloc_check(__mm21, (size_t)((nvec) * (nkb)) * sizeof(double _Complex), "__mm21");
        double *__cb39 = (double *)malloc((size_t)((nks) * (npwx)) * sizeof(double));
        __npb_alloc_check(__cb39, (size_t)((nks) * (npwx)) * sizeof(double), "__cb39");
        int64_t *__cb40 = (int64_t *)malloc((size_t)((nks) * (npwx)) * sizeof(int64_t));
        __npb_alloc_check(__cb40, (size_t)((nks) * (npwx)) * sizeof(int64_t), "__cb40");
        double _Complex *__cb41 = (double _Complex *)malloc((size_t)((nks) * (nkb) * (npwx)) * sizeof(double _Complex));
        __npb_alloc_check(__cb41, (size_t)((nks) * (nkb) * (npwx)) * sizeof(double _Complex), "__cb41");
        double _Complex *__cb50 = (double _Complex *)malloc((size_t)((nks) * (nkb) * (npwx)) * sizeof(double _Complex));
        __npb_alloc_check(__cb50, (size_t)((nks) * (nkb) * (npwx)) * sizeof(double _Complex), "__cb50");
        double *__cb62 = (double *)malloc((size_t)((nvec)) * sizeof(double));
        __npb_alloc_check(__cb62, (size_t)((nvec)) * sizeof(double), "__cb62");
        bool *__cb63 = (bool *)malloc((size_t)((nvec)) * sizeof(bool));
        __npb_alloc_check(__cb63, (size_t)((nvec)) * sizeof(bool), "__cb63");
        double *__inl3_vrs2 = (double *)malloc((size_t)((npol) * (((n1 * n2) * n3))) * sizeof(double));
        __npb_alloc_check(__inl3_vrs2, (size_t)((npol) * (((n1 * n2) * n3))) * sizeof(double), "__inl3_vrs2");
        double _Complex *__inl3_ps = (double _Complex *)malloc((size_t)((nvec) * (nkb)) * sizeof(double _Complex));
        __npb_alloc_check(__inl3_ps, (size_t)((nvec) * (nkb)) * sizeof(double _Complex), "__inl3_ps");
        double _Complex *__hpsi0 = (double _Complex *)malloc((size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex));
        __npb_alloc_check(__hpsi0, (size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex), "__hpsi0");
        double _Complex *__inl4_ps = (double _Complex *)malloc((size_t)((nvec) * (nkb)) * sizeof(double _Complex));
        __npb_alloc_check(__inl4_ps, (size_t)((nvec) * (nkb)) * sizeof(double _Complex), "__inl4_ps");
        double *__inl12_vrs2 = (double *)malloc((size_t)((npol) * (((n1 * n2) * n3))) * sizeof(double));
        __npb_alloc_check(__inl12_vrs2, (size_t)((npol) * (((n1 * n2) * n3))) * sizeof(double), "__inl12_vrs2");
        double *thr = (double *)malloc((size_t)((nvec)) * sizeof(double));
        __npb_alloc_check(thr, (size_t)((nvec)) * sizeof(double), "thr");
        double _Complex *psi0 = (double _Complex *)malloc((size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex));
        __npb_alloc_check(psi0, (size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex), "psi0");
        double *hd = NULL;
        double *sd = NULL;
        double _Complex *__inl26_psic = NULL;
        double _Complex *__inl5_C = NULL;
        double _Complex *__inl6_C = NULL;
        double _Complex *__inl7_C = NULL;
        double *__inl9_w = NULL;
        double _Complex *__inl9_v = NULL;
        double _Complex *__inl33_C = NULL;
        double _Complex *__inl34_C = NULL;
        double _Complex *__inl9___eigh0_Cm = NULL;
        double _Complex *__inl9___eigh0_jv = NULL;
        double *__inl9___eigh0_wa = NULL;
        double _Complex *ritz_s = NULL;
        double _Complex *__inl12_H = NULL;
        double _Complex *__inl42_psic = NULL;
        double _Complex *__inl44_C = NULL;
        double _Complex *__inl13_S = NULL;
        double _Complex *__inl48_C = NULL;
        double _Complex *__inl14_C = NULL;
        double _Complex *__inl15_C = NULL;
        double _Complex *__inl16_C = NULL;
        double *__inl18_w = NULL;
        double _Complex *__inl18_v = NULL;
        double _Complex *__inl49_C = NULL;
        double _Complex *__inl50_C = NULL;
        double _Complex *__inl18___eigh0_Cm = NULL;
        double _Complex *__inl18___eigh0_jv = NULL;
        double *__inl18___eigh0_wa = NULL;
        double _Complex *__cb14 = NULL;
        double _Complex *__cb17 = NULL;
        double _Complex *__mm19 = NULL;
        double _Complex *__mm22 = NULL;
        double _Complex *__cb23 = NULL;
        double _Complex *__cb24 = NULL;
        double _Complex *__cb25 = NULL;
        double _Complex *__cb26 = NULL;
        double _Complex *__cb27 = NULL;
        double _Complex *__cb28 = NULL;
        double _Complex *__mm29 = NULL;
        double _Complex *__mm30 = NULL;
        double _Complex *__cb31 = NULL;
        double _Complex *__mm32 = NULL;
        double _Complex *__mm33 = NULL;
        double _Complex *__mm34 = NULL;
        double *__cb35 = NULL;
        double *__cb36 = NULL;
        double *__cb37 = NULL;
        double *__cb38 = NULL;
        double _Complex *__cb42 = NULL;
        double _Complex *__cb43 = NULL;
        double _Complex *__cb44 = NULL;
        double _Complex *__cb45 = NULL;
        double _Complex *__cb46 = NULL;
        double _Complex *__cb47 = NULL;
        double _Complex *__mm48 = NULL;
        double _Complex *__mm49 = NULL;
        double _Complex *__mm51 = NULL;
        double _Complex *__mm52 = NULL;
        double _Complex *__cb53 = NULL;
        double _Complex *__cb54 = NULL;
        double _Complex *__cb55 = NULL;
        double _Complex *__cb56 = NULL;
        double _Complex *__cb57 = NULL;
        double _Complex *__cb58 = NULL;
        double _Complex *__mm59 = NULL;
        double _Complex *__mm60 = NULL;
        double _Complex *__cb61 = NULL;
        double _Complex *__mm65 = NULL;
        double _Complex *__mm66 = NULL;
        double _Complex *__mm67 = NULL;
        double _Complex *__inv_aw0 = NULL;
        double _Complex *__sol_aw1 = NULL;
        double _Complex *__inv_aw2 = NULL;
        double _Complex *__sol_aw3 = NULL;
        double _Complex *__inl3_r = NULL;
        double _Complex *__inl27_g = NULL;
        double _Complex *__inl3___h_tmp2 = NULL;
        double _Complex *__inl4___s_tmp = NULL;
        double _Complex *__inl9_a = NULL;
        double _Complex *__inl9_b = NULL;
        double _Complex *__inl9_chol = NULL;
        double _Complex *__inl9_chol_inv = NULL;
        double _Complex *__inl9_chol_h = NULL;
        double _Complex *__inl9_chol_inv_h = NULL;
        double _Complex *__inl9___t = NULL;
        double _Complex *__inl9_reduced = NULL;
        double _Complex *__inl9___eigh0_ya = NULL;
        double *__inl9_ws = NULL;
        double _Complex *__inl9_ys = NULL;
        double _Complex *__inl9_vs = NULL;
        double _Complex *resid = NULL;
        double _Complex *__inl12_r = NULL;
        double _Complex *__inl43_g = NULL;
        double _Complex *__inl12_ps = NULL;
        double _Complex *__inl12___h_tmp2 = NULL;
        double _Complex *__hpsi1 = NULL;
        double _Complex *__inl13_ps = NULL;
        double _Complex *__inl13___s_tmp = NULL;
        double _Complex *__spsi1 = NULL;
        double _Complex *__inl18_a = NULL;
        double _Complex *__inl18_b = NULL;
        double _Complex *__inl18_chol = NULL;
        double _Complex *__inl18_chol_inv = NULL;
        double _Complex *__inl18_chol_h = NULL;
        double _Complex *__inl18_chol_inv_h = NULL;
        double _Complex *__inl18___t = NULL;
        double _Complex *__inl18_reduced = NULL;
        double _Complex *__inl18___eigh0_ya = NULL;
        double *__inl18_ws = NULL;
        double _Complex *__inl18_ys = NULL;
        double _Complex *__inl18_vs = NULL;
        double _Complex *__evc = NULL;
        double _Complex *__spsi_block = NULL;
        double _Complex *__hpsi_block = NULL;
        double *__inl3_g2 = NULL;
        int64_t *__inl3_gmap = NULL;
        double _Complex *psi_k = NULL;
        double _Complex *hpsi_k = NULL;
        double _Complex *__inl3_X_b = NULL;
        double _Complex *__inl3___h_tmp = NULL;
        double _Complex *spsi_k = NULL;
        double _Complex *vc_u = NULL;
        double _Complex *cv = NULL;
        double _Complex *psi1 = NULL;
        double *__inl12_g2 = NULL;
        int64_t *__inl12_gmap = NULL;
        double _Complex *hpsi_b = NULL;
        double _Complex *psi_b = NULL;
        double _Complex *__inl12_X_b = NULL;
        double _Complex *__inl12___h_tmp = NULL;
        double _Complex *spsi_b = NULL;
        double _Complex *psi_b2 = NULL;
        double _Complex *vc_v = NULL;
        double _Complex *__inl4_X_b = NULL;
        double _Complex *__inl13_X_b = NULL;
        __swap1_0 = ((int64_t)(npwx));
        __swap1_1 = ((int64_t)(nvec));
        __swap1_2 = ((int64_t)(nvecx));
        __swap1_3 = ((int64_t)(npol));
        npwx = __swap1_0;
        nvec = __swap1_1;
        nvecx = __swap1_2;
        npol = __swap1_3;
        __swap2_0 = ((int64_t)(n1));
        __swap2_1 = ((int64_t)(n2));
        __swap2_2 = ((int64_t)(n3));
        __swap2_3 = ((int64_t)(nkb));
        __swap2_4 = ((int64_t)(nks));
        n1 = __swap2_0;
        n2 = __swap2_1;
        n3 = __swap2_2;
        nkb = __swap2_3;
        nks = __swap2_4;
        ck0 = (((int64_t)(current_k)) - 1);
        /* numpy: np.asarray(npw) */
        for (int64_t __r0 = 0; __r0 < nks; ++__r0) {
          __cb1[__r0] = npw[__r0];
        }
        /* numpy: np.reshape(__cb1, (-1,)) */
        for (int64_t __rs0 = 0; __rs0 < nks; ++__rs0) {
          __cb2[__rs0] = __cb1[__rs0];
        }
        npw_k = ((int64_t)(__cb2[ck0]));
        uspp = (uspp ? 1 : 0);
        lrot = (lrot ? 1 : 0);
        noncolin = 0;
        domag = 0;
        nnr = ((n1 * n2) * n3);
        kdim = ((npol == 1) ? npw_k : (npwx * npol));
        free(hd);
        hd = (double *)malloc((size_t)((kdim)) * sizeof(double));
        __npb_alloc_check(hd, (size_t)((kdim)) * sizeof(double), "hd");
        memset(hd, 0, (size_t)((kdim)) * sizeof(double));
        free(sd);
        sd = (double *)malloc((size_t)((kdim)) * sizeof(double));
        __npb_alloc_check(sd, (size_t)((kdim)) * sizeof(double), "sd");
        for (int64_t __zf = 0; __zf < ((kdim)); ++__zf) sd[__zf] = 1;
        if ((npol == 1)) {
          double *__cb3 = (double *)malloc((size_t)((npol) * (npwx)) * sizeof(double));
          __npb_alloc_check(__cb3, (size_t)((npol) * (npwx)) * sizeof(double), "__cb3");
          /* numpy: np.asarray(h_diag) */
          for (int64_t __r0 = 0; __r0 < npol; ++__r0) {
            for (int64_t __r1 = 0; __r1 < npwx; ++__r1) {
              __cb3[(__r0)*(npwx) + (__r1)] = h_diag[(__r0)*(npwx) + (__r1)];
            }
          }
          for (int64_t si0 = 0; si0 < npw_k; ++si0) {
            hd[si0] = __cb3[(0)*(npwx) + (si0)];
          }
          double *__cb4 = (double *)malloc((size_t)((npol) * (npwx)) * sizeof(double));
          __npb_alloc_check(__cb4, (size_t)((npol) * (npwx)) * sizeof(double), "__cb4");
          /* numpy: np.asarray(s_diag) */
          for (int64_t __r0 = 0; __r0 < npol; ++__r0) {
            for (int64_t __r1 = 0; __r1 < npwx; ++__r1) {
              __cb4[(__r0)*(npwx) + (__r1)] = s_diag[(__r0)*(npwx) + (__r1)];
            }
          }
          for (int64_t si0 = 0; si0 < npw_k; ++si0) {
            sd[si0] = __cb4[(0)*(npwx) + (si0)];
          }
          free(__cb3);
          free(__cb4);
        }
        else {
          double *__cb5 = (double *)malloc((size_t)((npol) * (npwx)) * sizeof(double));
          __npb_alloc_check(__cb5, (size_t)((npol) * (npwx)) * sizeof(double), "__cb5");
          /* numpy: np.asarray(h_diag) */
          for (int64_t __r0 = 0; __r0 < npol; ++__r0) {
            for (int64_t __r1 = 0; __r1 < npwx; ++__r1) {
              __cb5[(__r0)*(npwx) + (__r1)] = h_diag[(__r0)*(npwx) + (__r1)];
            }
          }
          for (int64_t si0 = 0; si0 < npw_k; ++si0) {
            hd[si0] = __cb5[(0)*(npwx) + (si0)];
          }
          double *__cb6 = (double *)malloc((size_t)((npol) * (npwx)) * sizeof(double));
          __npb_alloc_check(__cb6, (size_t)((npol) * (npwx)) * sizeof(double), "__cb6");
          /* numpy: np.asarray(s_diag) */
          for (int64_t __r0 = 0; __r0 < npol; ++__r0) {
            for (int64_t __r1 = 0; __r1 < npwx; ++__r1) {
              __cb6[(__r0)*(npwx) + (__r1)] = s_diag[(__r0)*(npwx) + (__r1)];
            }
          }
          for (int64_t si0 = 0; si0 < npw_k; ++si0) {
            sd[si0] = __cb6[(0)*(npwx) + (si0)];
          }
          double *__cb7 = (double *)malloc((size_t)((npol) * (npwx)) * sizeof(double));
          __npb_alloc_check(__cb7, (size_t)((npol) * (npwx)) * sizeof(double), "__cb7");
          /* numpy: np.asarray(h_diag) */
          for (int64_t __r0 = 0; __r0 < npol; ++__r0) {
            for (int64_t __r1 = 0; __r1 < npwx; ++__r1) {
              __cb7[(__r0)*(npwx) + (__r1)] = h_diag[(__r0)*(npwx) + (__r1)];
            }
          }
          for (int64_t si0 = npwx; si0 < (npwx + npw_k); ++si0) {
            hd[si0] = __cb7[(1)*(npwx) + ((si0 + (0 - npwx)))];
          }
          double *__cb8 = (double *)malloc((size_t)((npol) * (npwx)) * sizeof(double));
          __npb_alloc_check(__cb8, (size_t)((npol) * (npwx)) * sizeof(double), "__cb8");
          /* numpy: np.asarray(s_diag) */
          for (int64_t __r0 = 0; __r0 < npol; ++__r0) {
            for (int64_t __r1 = 0; __r1 < npwx; ++__r1) {
              __cb8[(__r0)*(npwx) + (__r1)] = s_diag[(__r0)*(npwx) + (__r1)];
            }
          }
          for (int64_t si0 = npwx; si0 < (npwx + npw_k); ++si0) {
            sd[si0] = __cb8[(1)*(npwx) + ((si0 + (0 - npwx)))];
          }
          free(__cb5);
          free(__cb6);
          free(__cb7);
          free(__cb8);
        }
        empty_ethr = max((ethr * 5.0), 1e-05);
        memset(psi, 0, (size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex));
        memset(hpsi, 0, (size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex));
        memset(spsi, 0, (size_t)((nvecx) * ((npwx * npol))) * sizeof(double _Complex));
        memset(hc, 0, (size_t)((nvecx) * (nvecx)) * sizeof(double _Complex));
        memset(sc, 0, (size_t)((nvecx) * (nvecx)) * sizeof(double _Complex));
        memset(vc, 0, (size_t)((nvecx) * (nvecx)) * sizeof(double _Complex));
        memset(ew, 0, (size_t)((nvecx)) * sizeof(double));
        memset(conv, 0, (size_t)((nvec)) * sizeof(bool));
        nhpsi = 0;
        notcnv = (((int64_t)(nvec)) + 0);
        nbase = (((int64_t)(nvec)) + 0);
        dav_iter = 0;
        for (int64_t si0 = 0; si0 < nvec; ++si0) {
          for (int64_t si1 = 0; si1 < (npwx * npol); ++si1) {
            psi[(si0)*((npwx * npol)) + (si1)] = evc[(si0)*((npwx * npol)) + (si1)];
          }
        }
        for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
          for (int64_t __w1 = 0; __w1 < (npwx * npol); ++__w1) {
            psi0[(__w0)*((npwx * npol)) + (__w1)] = psi[(__w0)*((npwx * npol)) + (__w1)];
          }
        }
        memset(__inl3_H, 0, (size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex));
        /* numpy: np.asarray(g2kin) */
        for (int64_t __r0 = 0; __r0 < nks; ++__r0) {
          for (int64_t __r1 = 0; __r1 < npwx; ++__r1) {
            __cb9[(__r0)*(npwx) + (__r1)] = g2kin[(__r0)*(npwx) + (__r1)];
          }
        }
        free(__inl3_g2);
        __inl3_g2 = (double *)malloc((size_t)((npw_k)) * sizeof(double));
        __npb_alloc_check(__inl3_g2, (size_t)((npw_k)) * sizeof(double), "__inl3_g2");
        for (int64_t si0 = 0; si0 < npw_k; ++si0) {
          __inl3_g2[si0] = __cb9[(ck0)*(npwx) + (si0)];
        }
        /* numpy: np.asarray(nlk) */
        for (int64_t __r0 = 0; __r0 < nks; ++__r0) {
          for (int64_t __r1 = 0; __r1 < npwx; ++__r1) {
            __cb10[(__r0)*(npwx) + (__r1)] = nlk[(__r0)*(npwx) + (__r1)];
          }
        }
        free(__inl3_gmap);
        __inl3_gmap = (int64_t *)malloc((size_t)((npw_k)) * sizeof(int64_t));
        __npb_alloc_check(__inl3_gmap, (size_t)((npw_k)) * sizeof(int64_t), "__inl3_gmap");
        for (int64_t __w0 = 0; __w0 < npw_k; ++__w0) {
          __inl3_gmap[__w0] = ((int64_t)(__cb10[(ck0)*(npwx) + (__w0)]));
        }
        for (int64_t __w0 = 0; __w0 < npol; ++__w0) {
          for (int64_t __w1 = 0; __w1 < ((n1 * n2) * n3); ++__w1) {
            __inl3_vrs2[(__w0)*(((n1 * n2) * n3)) + (__w1)] = vrs[(__w0)*(((n1 * n2) * n3)) + (__w1)];
          }
        }
        /* numpy: np.asarray(vkb) */
        for (int64_t __r0 = 0; __r0 < nks; ++__r0) {
          for (int64_t __r1 = 0; __r1 < nkb; ++__r1) {
            for (int64_t __r2 = 0; __r2 < npwx; ++__r2) {
              __cb11[((__r0)*(nkb) + (__r1))*(npwx) + (__r2)] = vkb[((__r0)*(nkb) + (__r1))*(npwx) + (__r2)];
            }
          }
        }
        for (int64_t __inl3_ip = 0; __inl3_ip < npol; ++__inl3_ip) {
          free(__inl3_X_b);
          __inl3_X_b = (double _Complex *)malloc((size_t)((nvec) * (npw_k)) * sizeof(double _Complex));
          __npb_alloc_check(__inl3_X_b, (size_t)((nvec) * (npw_k)) * sizeof(double _Complex), "__inl3_X_b");
          for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
            for (int64_t __w1 = 0; __w1 < npw_k; ++__w1) {
              __inl3_X_b[(__w0)*(npw_k) + (__w1)] = psi0[(__w0)*((npwx * npol)) + ((__w1 + ((__inl3_ip * npwx) - 0)))];
            }
          }
          for (int64_t si0 = 0; si0 < nvec; ++si0) {
            for (int64_t si1 = (__inl3_ip * npwx); si1 < ((__inl3_ip * npwx) + npw_k); ++si1) {
              __inl3_H[(si0)*((npwx * npol)) + (si1)] = (__inl3_g2[(si1 + (0 - (__inl3_ip * npwx)))] * __inl3_X_b[(si0)*(npw_k) + ((si1 - (__inl3_ip * npwx)))]);
            }
          }
          free(__inl26_psic);
          __inl26_psic = (double _Complex *)malloc((size_t)((nvec) * (nnr)) * sizeof(double _Complex));
          __npb_alloc_check(__inl26_psic, (size_t)((nvec) * (nnr)) * sizeof(double _Complex), "__inl26_psic");
          memset(__inl26_psic, 0, (size_t)((nvec) * (nnr)) * sizeof(double _Complex));
          for (int64_t __scs0 = 0; __scs0 < nvec; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < npw_k; ++__sc0) {
              __inl26_psic[(__scs0)*(nnr) + (__inl3_gmap[__sc0])] = __inl3_X_b[(__scs0)*(npw_k) + (__sc0)];
            }
          }
          /* numpy: np.reshape(__inl26_psic, (nvec, n3, n2, n1)) */
          for (int64_t __rs0 = 0; __rs0 < nvec; ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < n3; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < n2; ++__rs2) {
                for (int64_t __rs3 = 0; __rs3 < n1; ++__rs3) {
                  __cb12[(((__rs0)*(n3) + (__rs1))*(n2) + (__rs2))*(n1) + (__rs3)] = __inl26_psic[(__rs0)*(nnr) + ((((__rs1 * (n2 * n1)) + (__rs2 * n1)) + __rs3))];
                }
              }
            }
          }
          /* numpy: np.fft.ifftn(__cb12, axes=(1, 2, 3)) */
          {
            int64_t __fft_n = (int64_t)(n3) * (int64_t)(n2) * (int64_t)(n1);
            int64_t __fft_batch = (int64_t)(nvec);
            if (__fft_n > 0 && __fft_batch > 0) {
              int __fft_dims[3] = {(int)(n3), (int)(n2), (int)(n1)};
              fftw_plan __fft_plan = fftw_plan_many_dft(3, __fft_dims, (int)__fft_batch, (fftw_complex *)(__cb12), NULL, 1, (int)__fft_n, (fftw_complex *)(__cb13), NULL, 1, (int)__fft_n, FFTW_BACKWARD, FFTW_ESTIMATE);
              fftw_execute(__fft_plan);
              fftw_destroy_plan(__fft_plan);
              for (int64_t __fft_i = 0; __fft_i < __fft_n * __fft_batch; ++__fft_i) {
                __cb13[__fft_i] /= ((double)__fft_n);
              }
            }
          }
          free(__cb14);
          __cb14 = (double _Complex *)malloc((size_t)((nvec) * (nnr)) * sizeof(double _Complex));
          __npb_alloc_check(__cb14, (size_t)((nvec) * (nnr)) * sizeof(double _Complex), "__cb14");
          /* numpy: np.reshape(__cb13, (nvec, nnr)) */
          for (int64_t __rs0 = 0; __rs0 < nvec; ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < n3; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < n2; ++__rs2) {
                for (int64_t __rs3 = 0; __rs3 < n1; ++__rs3) {
                  __cb14[(__rs0)*(nnr) + ((((__rs1 * (n2 * n1)) + (__rs2 * n1)) + __rs3))] = __cb13[(((__rs0)*(n3) + (__rs1))*(n2) + (__rs2))*(n1) + (__rs3)];
                }
              }
            }
          }
          free(__inl3_r);
          __inl3_r = (double _Complex *)malloc((size_t)((nvec) * (nnr)) * sizeof(double _Complex));
          __npb_alloc_check(__inl3_r, (size_t)((nvec) * (nnr)) * sizeof(double _Complex), "__inl3_r");
          for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nnr; ++__w1) {
              __inl3_r[(__w0)*(nnr) + (__w1)] = __cb14[(__w0)*(nnr) + (__w1)];
            }
          }
          for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nnr; ++__w1) {
              __inl3_r[(__w0)*(nnr) + (__w1)] = (__inl3_r[(__w0)*(nnr) + (__w1)] * __inl3_vrs2[(__inl3_ip)*(((n1 * n2) * n3)) + (__w1)]);
            }
          }
          /* numpy: np.reshape(__inl3_r, (nvec, n3, n2, n1)) */
          for (int64_t __rs0 = 0; __rs0 < nvec; ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < n3; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < n2; ++__rs2) {
                for (int64_t __rs3 = 0; __rs3 < n1; ++__rs3) {
                  __cb15[(((__rs0)*(n3) + (__rs1))*(n2) + (__rs2))*(n1) + (__rs3)] = __inl3_r[(__rs0)*(nnr) + ((((__rs1 * (n2 * n1)) + (__rs2 * n1)) + __rs3))];
                }
              }
            }
          }
          /* numpy: np.fft.fftn(__cb15, axes=(1, 2, 3)) */
          {
            int64_t __fft_n = (int64_t)(n3) * (int64_t)(n2) * (int64_t)(n1);
            int64_t __fft_batch = (int64_t)(nvec);
            if (__fft_n > 0 && __fft_batch > 0) {
              int __fft_dims[3] = {(int)(n3), (int)(n2), (int)(n1)};
              fftw_plan __fft_plan = fftw_plan_many_dft(3, __fft_dims, (int)__fft_batch, (fftw_complex *)(__cb15), NULL, 1, (int)__fft_n, (fftw_complex *)(__cb16), NULL, 1, (int)__fft_n, FFTW_FORWARD, FFTW_ESTIMATE);
              fftw_execute(__fft_plan);
              fftw_destroy_plan(__fft_plan);
            }
          }
          free(__cb17);
          __cb17 = (double _Complex *)malloc((size_t)((nvec) * (nnr)) * sizeof(double _Complex));
          __npb_alloc_check(__cb17, (size_t)((nvec) * (nnr)) * sizeof(double _Complex), "__cb17");
          /* numpy: np.reshape(__cb16, (nvec, nnr)) */
          for (int64_t __rs0 = 0; __rs0 < nvec; ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < n3; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < n2; ++__rs2) {
                for (int64_t __rs3 = 0; __rs3 < n1; ++__rs3) {
                  __cb17[(__rs0)*(nnr) + ((((__rs1 * (n2 * n1)) + (__rs2 * n1)) + __rs3))] = __cb16[(((__rs0)*(n3) + (__rs1))*(n2) + (__rs2))*(n1) + (__rs3)];
                }
              }
            }
          }
          free(__inl27_g);
          __inl27_g = (double _Complex *)malloc((size_t)((nvec) * (nnr)) * sizeof(double _Complex));
          __npb_alloc_check(__inl27_g, (size_t)((nvec) * (nnr)) * sizeof(double _Complex), "__inl27_g");
          for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nnr; ++__w1) {
              __inl27_g[(__w0)*(nnr) + (__w1)] = __cb17[(__w0)*(nnr) + (__w1)];
            }
          }
          free(__inl3___h_tmp);
          __inl3___h_tmp = (double _Complex *)malloc((size_t)((nvec) * (npw_k)) * sizeof(double _Complex));
          __npb_alloc_check(__inl3___h_tmp, (size_t)((nvec) * (npw_k)) * sizeof(double _Complex), "__inl3___h_tmp");
          for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
            for (int64_t __w1 = 0; __w1 < npw_k; ++__w1) {
              __inl3___h_tmp[(__w0)*(npw_k) + (__w1)] = __inl27_g[(__w0)*(nnr) + (__inl3_gmap[__w1])];
            }
          }
          for (int64_t __inl3_jj = 0; __inl3_jj < nvec; ++__inl3_jj) {
            for (int64_t __inl3_i = 0; __inl3_i < npw_k; ++__inl3_i) {
              __inl3_H[(__inl3_jj)*((npwx * npol)) + (((__inl3_ip * npwx) + __inl3_i))] += __inl3___h_tmp[(__inl3_jj)*(npw_k) + (__inl3_i)];
            }
          }
          if ((nkb > 0)) {
            memset(__inl28_C, 0, (size_t)((nvec) * (nkb)) * sizeof(double _Complex));
            for (int64_t __inl28_i = 0; __inl28_i < nvec; ++__inl28_i) {
              for (int64_t __inl28_j = 0; __inl28_j < nkb; ++__inl28_j) {
                __inl28_acc = (0.0 + (0.0 + 0.0 * _Complex_I));
                for (int64_t __inl28_l = 0; __inl28_l < npw_k; ++__inl28_l) {
                  __inl28_acc += (__inl3_X_b[(__inl28_i)*(npw_k) + (__inl28_l)] * __npb_conj(__cb11[((ck0)*(nkb) + (__inl28_j))*(npwx) + (__inl28_l)]));
                }
                __inl28_C[(__inl28_i)*(nkb) + (__inl28_j)] = __inl28_acc;
              }
            }
            for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nkb; ++__w1) {
                __inl3_ps[(__w0)*(nkb) + (__w1)] = __inl28_C[(__w0)*(nkb) + (__w1)];
              }
            }
            for (int64_t __i = 0; __i < nvec; ++__i) {
              for (int64_t __j = 0; __j < nkb; ++__j) {
                __mm18[(__i)*(nkb) + (__j)] = 0.0;
                for (int64_t __l = 0; __l < nkb; ++__l) {
                  __mm18[(__i)*(nkb) + (__j)] += (__inl3_ps[(__i)*(nkb) + (__l)] * deeq[(__l)*(nkb) + (__j)]);
                }
              }
            }
            free(__mm19);
            __mm19 = (double _Complex *)malloc((size_t)((nvec) * (npw_k)) * sizeof(double _Complex));
            __npb_alloc_check(__mm19, (size_t)((nvec) * (npw_k)) * sizeof(double _Complex), "__mm19");
            for (int64_t __i = 0; __i < nvec; ++__i) {
              for (int64_t __j = 0; __j < npw_k; ++__j) {
                __mm19[(__i)*(npw_k) + (__j)] = 0.0;
                for (int64_t __l = 0; __l < nkb; ++__l) {
                  __mm19[(__i)*(npw_k) + (__j)] += (__mm18[(__i)*(nkb) + (__l)] * __cb11[((ck0)*(nkb) + (__l))*(npwx) + (__j)]);
                }
              }
            }
            free(__inl3___h_tmp2);
            __inl3___h_tmp2 = (double _Complex *)malloc((size_t)((nvec) * (npw_k)) * sizeof(double _Complex));
            __npb_alloc_check(__inl3___h_tmp2, (size_t)((nvec) * (npw_k)) * sizeof(double _Complex), "__inl3___h_tmp2");
            for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
              for (int64_t __w1 = 0; __w1 < npw_k; ++__w1) {
                __inl3___h_tmp2[(__w0)*(npw_k) + (__w1)] = __mm19[(__w0)*(npw_k) + (__w1)];
              }
            }
            for (int64_t __inl3_jj = 0; __inl3_jj < nvec; ++__inl3_jj) {
              for (int64_t __inl3_i = 0; __inl3_i < npw_k; ++__inl3_i) {
                __inl3_H[(__inl3_jj)*((npwx * npol)) + (((__inl3_ip * npwx) + __inl3_i))] += __inl3___h_tmp2[(__inl3_jj)*(npw_k) + (__inl3_i)];
              }
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
          for (int64_t __w1 = 0; __w1 < (npwx * npol); ++__w1) {
            __hpsi0[(__w0)*((npwx * npol)) + (__w1)] = __inl3_H[(__w0)*((npwx * npol)) + (__w1)];
          }
        }
        for (int64_t si0 = 0; si0 < nvec; ++si0) {
          for (int64_t si1 = 0; si1 < (npwx * npol); ++si1) {
            hpsi[(si0)*((npwx * npol)) + (si1)] = __hpsi0[(si0)*((npwx * npol)) + (si1)];
          }
        }
        if (uspp) {
          double _Complex *__inl4_S = (double _Complex *)malloc((size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex));
          __npb_alloc_check(__inl4_S, (size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex), "__inl4_S");
          memset(__inl4_S, 0, (size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex));
          if ((uspp && (nkb > 0))) {
            double _Complex *__cb20 = (double _Complex *)malloc((size_t)((nks) * (nkb) * (npwx)) * sizeof(double _Complex));
            __npb_alloc_check(__cb20, (size_t)((nks) * (nkb) * (npwx)) * sizeof(double _Complex), "__cb20");
            /* numpy: np.asarray(vkb) */
            for (int64_t __r0 = 0; __r0 < nks; ++__r0) {
              for (int64_t __r1 = 0; __r1 < nkb; ++__r1) {
                for (int64_t __r2 = 0; __r2 < npwx; ++__r2) {
                  __cb20[((__r0)*(nkb) + (__r1))*(npwx) + (__r2)] = vkb[((__r0)*(nkb) + (__r1))*(npwx) + (__r2)];
                }
              }
            }
            for (int64_t __inl4_ip = 0; __inl4_ip < npol; ++__inl4_ip) {
              free(__inl4_X_b);
              __inl4_X_b = (double _Complex *)malloc((size_t)((nvec) * (npw_k)) * sizeof(double _Complex));
              __npb_alloc_check(__inl4_X_b, (size_t)((nvec) * (npw_k)) * sizeof(double _Complex), "__inl4_X_b");
              for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
                for (int64_t __w1 = 0; __w1 < npw_k; ++__w1) {
                  __inl4_X_b[(__w0)*(npw_k) + (__w1)] = psi0[(__w0)*((npwx * npol)) + ((__w1 + ((__inl4_ip * npwx) - 0)))];
                }
              }
              for (int64_t si0 = 0; si0 < nvec; ++si0) {
                for (int64_t si1 = (__inl4_ip * npwx); si1 < ((__inl4_ip * npwx) + npw_k); ++si1) {
                  __inl4_S[(si0)*((npwx * npol)) + (si1)] = __inl4_X_b[(si0)*(npw_k) + ((si1 - (__inl4_ip * npwx)))];
                }
              }
              memset(__inl32_C, 0, (size_t)((nvec) * (nkb)) * sizeof(double _Complex));
              for (int64_t __inl32_i = 0; __inl32_i < nvec; ++__inl32_i) {
                for (int64_t __inl32_j = 0; __inl32_j < nkb; ++__inl32_j) {
                  __inl32_acc = (0.0 + (0.0 + 0.0 * _Complex_I));
                  for (int64_t __inl32_l = 0; __inl32_l < npw_k; ++__inl32_l) {
                    __inl32_acc += (__inl4_X_b[(__inl32_i)*(npw_k) + (__inl32_l)] * __npb_conj(__cb20[((ck0)*(nkb) + (__inl32_j))*(npwx) + (__inl32_l)]));
                  }
                  __inl32_C[(__inl32_i)*(nkb) + (__inl32_j)] = __inl32_acc;
                }
              }
              for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
                for (int64_t __w1 = 0; __w1 < nkb; ++__w1) {
                  __inl4_ps[(__w0)*(nkb) + (__w1)] = __inl32_C[(__w0)*(nkb) + (__w1)];
                }
              }
              for (int64_t __i = 0; __i < nvec; ++__i) {
                for (int64_t __j = 0; __j < nkb; ++__j) {
                  __mm21[(__i)*(nkb) + (__j)] = 0.0;
                  for (int64_t __l = 0; __l < nkb; ++__l) {
                    __mm21[(__i)*(nkb) + (__j)] += (__inl4_ps[(__i)*(nkb) + (__l)] * qq[(__l)*(nkb) + (__j)]);
                  }
                }
              }
              free(__mm22);
              __mm22 = (double _Complex *)malloc((size_t)((nvec) * (npw_k)) * sizeof(double _Complex));
              __npb_alloc_check(__mm22, (size_t)((nvec) * (npw_k)) * sizeof(double _Complex), "__mm22");
              for (int64_t __i = 0; __i < nvec; ++__i) {
                for (int64_t __j = 0; __j < npw_k; ++__j) {
                  __mm22[(__i)*(npw_k) + (__j)] = 0.0;
                  for (int64_t __l = 0; __l < nkb; ++__l) {
                    __mm22[(__i)*(npw_k) + (__j)] += (__mm21[(__i)*(nkb) + (__l)] * __cb20[((ck0)*(nkb) + (__l))*(npwx) + (__j)]);
                  }
                }
              }
              free(__inl4___s_tmp);
              __inl4___s_tmp = (double _Complex *)malloc((size_t)((nvec) * (npw_k)) * sizeof(double _Complex));
              __npb_alloc_check(__inl4___s_tmp, (size_t)((nvec) * (npw_k)) * sizeof(double _Complex), "__inl4___s_tmp");
              for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
                for (int64_t __w1 = 0; __w1 < npw_k; ++__w1) {
                  __inl4___s_tmp[(__w0)*(npw_k) + (__w1)] = __mm22[(__w0)*(npw_k) + (__w1)];
                }
              }
              for (int64_t __inl4_j = 0; __inl4_j < nvec; ++__inl4_j) {
                for (int64_t __inl4_i = 0; __inl4_i < npw_k; ++__inl4_i) {
                  __inl4_S[(__inl4_j)*((npwx * npol)) + (((__inl4_ip * npwx) + __inl4_i))] += __inl4___s_tmp[(__inl4_j)*(npw_k) + (__inl4_i)];
                }
              }
            }
            free(__cb20);
          }
          else {
            for (int64_t __inl4_ip = 0; __inl4_ip < npol; ++__inl4_ip) {
              for (int64_t si0 = 0; si0 < nvec; ++si0) {
                for (int64_t si1 = (__inl4_ip * npwx); si1 < ((__inl4_ip * npwx) + npw_k); ++si1) {
                  __inl4_S[(si0)*((npwx * npol)) + (si1)] = psi0[(si0)*((npwx * npol)) + ((si1 + ((__inl4_ip * npwx) - (__inl4_ip * npwx))))];
                }
              }
            }
          }
          double _Complex *__spsi0 = (double _Complex *)malloc((size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex));
          __npb_alloc_check(__spsi0, (size_t)((nvec) * ((npwx * npol))) * sizeof(double _Complex), "__spsi0");
          for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (npwx * npol); ++__w1) {
              __spsi0[(__w0)*((npwx * npol)) + (__w1)] = __inl4_S[(__w0)*((npwx * npol)) + (__w1)];
            }
          }
          for (int64_t si0 = 0; si0 < nvec; ++si0) {
            for (int64_t si1 = 0; si1 < (npwx * npol); ++si1) {
              spsi[(si0)*((npwx * npol)) + (si1)] = __spsi0[(si0)*((npwx * npol)) + (si1)];
            }
          }
          free(__inl4_S);
          free(__spsi0);
        }
        nhpsi += nvec;
        free(psi_k);
        psi_k = (double _Complex *)malloc((size_t)((nbase) * (kdim)) * sizeof(double _Complex));
        __npb_alloc_check(psi_k, (size_t)((nbase) * (kdim)) * sizeof(double _Complex), "psi_k");
        for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
          for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
            psi_k[(__w0)*(kdim) + (__w1)] = psi[(__w0)*((npwx * npol)) + (__w1)];
          }
        }
        free(hpsi_k);
        hpsi_k = (double _Complex *)malloc((size_t)((nbase) * (kdim)) * sizeof(double _Complex));
        __npb_alloc_check(hpsi_k, (size_t)((nbase) * (kdim)) * sizeof(double _Complex), "hpsi_k");
        for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
          for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
            hpsi_k[(__w0)*(kdim) + (__w1)] = hpsi[(__w0)*((npwx * npol)) + (__w1)];
          }
        }
        free(__inl5_C);
        __inl5_C = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
        __npb_alloc_check(__inl5_C, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl5_C");
        memset(__inl5_C, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
        for (int64_t __inl5_i = 0; __inl5_i < nbase; ++__inl5_i) {
          for (int64_t __inl5_j = 0; __inl5_j < nbase; ++__inl5_j) {
            __inl5_acc = (0.0 + (0.0 + 0.0 * _Complex_I));
            for (int64_t __inl5_l = 0; __inl5_l < kdim; ++__inl5_l) {
              __inl5_acc += (__npb_conj(psi_k[(__inl5_i)*(kdim) + (__inl5_l)]) * hpsi_k[(__inl5_j)*(kdim) + (__inl5_l)]);
            }
            __inl5_C[(__inl5_i)*(nbase) + (__inl5_j)] = __inl5_acc;
          }
        }
        for (int64_t si0 = 0; si0 < nbase; ++si0) {
          for (int64_t si1 = 0; si1 < nbase; ++si1) {
            hc[(si0)*(nvecx) + (si1)] = __inl5_C[(si0)*(nbase) + (si1)];
          }
        }
        if (uspp) {
          free(spsi_k);
          spsi_k = (double _Complex *)malloc((size_t)((nbase) * (kdim)) * sizeof(double _Complex));
          __npb_alloc_check(spsi_k, (size_t)((nbase) * (kdim)) * sizeof(double _Complex), "spsi_k");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
              spsi_k[(__w0)*(kdim) + (__w1)] = spsi[(__w0)*((npwx * npol)) + (__w1)];
            }
          }
          free(__inl6_C);
          __inl6_C = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl6_C, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl6_C");
          memset(__inl6_C, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          for (int64_t __inl6_i = 0; __inl6_i < nbase; ++__inl6_i) {
            for (int64_t __inl6_j = 0; __inl6_j < nbase; ++__inl6_j) {
              __inl6_acc = (0.0 + (0.0 + 0.0 * _Complex_I));
              for (int64_t __inl6_l = 0; __inl6_l < kdim; ++__inl6_l) {
                __inl6_acc += (__npb_conj(psi_k[(__inl6_i)*(kdim) + (__inl6_l)]) * spsi_k[(__inl6_j)*(kdim) + (__inl6_l)]);
              }
              __inl6_C[(__inl6_i)*(nbase) + (__inl6_j)] = __inl6_acc;
            }
          }
          for (int64_t si0 = 0; si0 < nbase; ++si0) {
            for (int64_t si1 = 0; si1 < nbase; ++si1) {
              sc[(si0)*(nvecx) + (si1)] = __inl6_C[(si0)*(nbase) + (si1)];
            }
          }
        }
        else {
          free(__inl7_C);
          __inl7_C = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl7_C, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl7_C");
          memset(__inl7_C, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          for (int64_t __inl7_i = 0; __inl7_i < nbase; ++__inl7_i) {
            for (int64_t __inl7_j = 0; __inl7_j < nbase; ++__inl7_j) {
              __inl7_acc = (0.0 + (0.0 + 0.0 * _Complex_I));
              for (int64_t __inl7_l = 0; __inl7_l < kdim; ++__inl7_l) {
                __inl7_acc += (__npb_conj(psi_k[(__inl7_i)*(kdim) + (__inl7_l)]) * psi_k[(__inl7_j)*(kdim) + (__inl7_l)]);
              }
              __inl7_C[(__inl7_i)*(nbase) + (__inl7_j)] = __inl7_acc;
            }
          }
          for (int64_t si0 = 0; si0 < nbase; ++si0) {
            for (int64_t si1 = 0; si1 < nbase; ++si1) {
              sc[(si0)*(nvecx) + (si1)] = __inl7_C[(si0)*(nbase) + (si1)];
            }
          }
        }
        __inl8_nb1_0 = 0;
        for (int64_t __inl8_i = __inl8_nb1_0; __inl8_i < nbase; ++__inl8_i) {
          hc[(__inl8_i)*(nvecx) + (__inl8_i)] = creal(hc[(__inl8_i)*(nvecx) + (__inl8_i)]);
          sc[(__inl8_i)*(nvecx) + (__inl8_i)] = creal(sc[(__inl8_i)*(nvecx) + (__inl8_i)]);
        }
        for (int64_t __inl8_i = 0; __inl8_i < nbase; ++__inl8_i) {
          for (int64_t __inl8_j = max((__inl8_i + 1), __inl8_nb1_0); __inl8_j < nbase; ++__inl8_j) {
            hc[(__inl8_i)*(nvecx) + (__inl8_j)] = __npb_conj(hc[(__inl8_j)*(nvecx) + (__inl8_i)]);
            sc[(__inl8_i)*(nvecx) + (__inl8_j)] = __npb_conj(sc[(__inl8_j)*(nvecx) + (__inl8_i)]);
          }
        }
        if (lrot) {
          for (int64_t i = 0; i < nbase; ++i) {
            e[i] = creal(hc[(i)*(nvecx) + (i)]);
            vc[(i)*(nvecx) + (i)] = 1.0;
          }
        }
        else {
          free(__cb23);
          __cb23 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb23, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb23");
          for (int64_t si0 = 0; si0 < nbase; ++si0) {
            for (int64_t si1 = 0; si1 < nbase; ++si1) {
              __cb23[(si0)*(nbase) + (si1)] = hc[(si0)*(nvecx) + (si1)];
            }
          }
          free(__cb24);
          __cb24 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb24, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb24");
          /* numpy: np.copy(__cb23) */
          for (int64_t __r0 = 0; __r0 < nbase; ++__r0) {
            for (int64_t __r1 = 0; __r1 < nbase; ++__r1) {
              __cb24[(__r0)*(nbase) + (__r1)] = __cb23[(__r0)*(nbase) + (__r1)];
            }
          }
          free(__inl9_a);
          __inl9_a = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9_a, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9_a");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9_a[(__w0)*(nbase) + (__w1)] = __cb24[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__cb25);
          __cb25 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb25, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb25");
          for (int64_t si0 = 0; si0 < nbase; ++si0) {
            for (int64_t si1 = 0; si1 < nbase; ++si1) {
              __cb25[(si0)*(nbase) + (si1)] = sc[(si0)*(nvecx) + (si1)];
            }
          }
          free(__cb26);
          __cb26 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb26, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb26");
          /* numpy: np.copy(__cb25) */
          for (int64_t __r0 = 0; __r0 < nbase; ++__r0) {
            for (int64_t __r1 = 0; __r1 < nbase; ++__r1) {
              __cb26[(__r0)*(nbase) + (__r1)] = __cb25[(__r0)*(nbase) + (__r1)];
            }
          }
          free(__inl9_b);
          __inl9_b = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9_b, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9_b");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9_b[(__w0)*(nbase) + (__w1)] = __cb26[(__w0)*(nbase) + (__w1)];
            }
          }
          for (int64_t __inl9_i = 0; __inl9_i < nbase; ++__inl9_i) {
            __inl9_a[(__inl9_i)*(nbase) + (__inl9_i)] = creal(__inl9_a[(__inl9_i)*(nbase) + (__inl9_i)]);
            __inl9_b[(__inl9_i)*(nbase) + (__inl9_i)] = creal(__inl9_b[(__inl9_i)*(nbase) + (__inl9_i)]);
            for (int64_t __inl9_j = (__inl9_i + 1); __inl9_j < nbase; ++__inl9_j) {
              __inl9_val_a = (0.5 * (__inl9_a[(__inl9_i)*(nbase) + (__inl9_j)] + __npb_conj(__inl9_a[(__inl9_j)*(nbase) + (__inl9_i)])));
              __inl9_val_b = (0.5 * (__inl9_b[(__inl9_i)*(nbase) + (__inl9_j)] + __npb_conj(__inl9_b[(__inl9_j)*(nbase) + (__inl9_i)])));
              __inl9_a[(__inl9_i)*(nbase) + (__inl9_j)] = __inl9_val_a;
              __inl9_a[(__inl9_j)*(nbase) + (__inl9_i)] = __npb_conj(__inl9_val_a);
              __inl9_b[(__inl9_i)*(nbase) + (__inl9_j)] = __inl9_val_b;
              __inl9_b[(__inl9_j)*(nbase) + (__inl9_i)] = __npb_conj(__inl9_val_b);
            }
          }
          free(__inl9_w);
          __inl9_w = (double *)malloc((size_t)((nbase)) * sizeof(double));
          __npb_alloc_check(__inl9_w, (size_t)((nbase)) * sizeof(double), "__inl9_w");
          memset(__inl9_w, 0, (size_t)((nbase)) * sizeof(double));
          free(__inl9_v);
          __inl9_v = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9_v, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9_v");
          memset(__inl9_v, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          free(__cb27);
          __cb27 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb27, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb27");
          /* numpy: np.linalg.cholesky(__inl9_b) */
          for (int64_t __zi = 0; __zi < nbase; ++__zi) {
            for (int64_t __zj = (__zi + 1); __zj < nbase; ++__zj) {
              __cb27[(__zi)*(nbase) + (__zj)] = 0.0;
            }
          }
          for (int64_t __j = 0; __j < nbase; ++__j) {
            __s = __inl9_b[(__j)*(nbase) + (__j)];
            for (int64_t __k = 0; __k < __j; ++__k) {
              __s -= (__cb27[(__j)*(nbase) + (__k)] * __npb_conj(__cb27[(__j)*(nbase) + (__k)]));
            }
            __cb27[(__j)*(nbase) + (__j)] = csqrt(__s);
            for (int64_t __i = (__j + 1); __i < nbase; ++__i) {
              __s = __inl9_b[(__i)*(nbase) + (__j)];
              for (int64_t __k = 0; __k < __j; ++__k) {
                __s -= (__cb27[(__i)*(nbase) + (__k)] * __npb_conj(__cb27[(__j)*(nbase) + (__k)]));
              }
              __cb27[(__i)*(nbase) + (__j)] = (__s / __cb27[(__j)*(nbase) + (__j)]);
            }
          }
          free(__inl9_chol);
          __inl9_chol = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9_chol, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9_chol");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9_chol[(__w0)*(nbase) + (__w1)] = __cb27[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__cb28);
          __cb28 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb28, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb28");
          free(__inv_aw0);
          __inv_aw0 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inv_aw0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inv_aw0");
          /* numpy: np.linalg.inv(__inl9_chol) */
          for (int64_t __inv_i = 0; __inv_i < nbase; ++__inv_i) {
            for (int64_t __inv_j = 0; __inv_j < nbase; ++__inv_j) {
              __inv_aw0[(__inv_i)*(nbase) + (__inv_j)] = __inl9_chol[(__inv_i)*(nbase) + (__inv_j)];
              __cb28[(__inv_i)*(nbase) + (__inv_j)] = ((__inv_i == __inv_j) ? 1.0 : 0.0);
            }
          }
          for (int64_t __inv_k = 0; __inv_k < nbase; ++__inv_k) {
            __inv_p = __inv_k;
            for (int64_t __inv_r = (__inv_k + 1); __inv_r < nbase; ++__inv_r) {
              if ((cabs(__inv_aw0[(__inv_r)*(nbase) + (__inv_k)]) > cabs(__inv_aw0[(__inv_p)*(nbase) + (__inv_k)]))) {
                __inv_p = __inv_r;
              }
            }
            for (int64_t __inv_c = 0; __inv_c < nbase; ++__inv_c) {
              __inv_tmp = __inv_aw0[(__inv_k)*(nbase) + (__inv_c)];
              __inv_aw0[(__inv_k)*(nbase) + (__inv_c)] = __inv_aw0[(__inv_p)*(nbase) + (__inv_c)];
              __inv_aw0[(__inv_p)*(nbase) + (__inv_c)] = __inv_tmp;
              __inv_tmp = __cb28[(__inv_k)*(nbase) + (__inv_c)];
              __cb28[(__inv_k)*(nbase) + (__inv_c)] = __cb28[(__inv_p)*(nbase) + (__inv_c)];
              __cb28[(__inv_p)*(nbase) + (__inv_c)] = __inv_tmp;
            }
            __inv_factor = __inv_aw0[(__inv_k)*(nbase) + (__inv_k)];
            for (int64_t __inv_c = 0; __inv_c < nbase; ++__inv_c) {
              __cb28[(__inv_k)*(nbase) + (__inv_c)] = (__cb28[(__inv_k)*(nbase) + (__inv_c)] / __inv_factor);
              __inv_aw0[(__inv_k)*(nbase) + (__inv_c)] = (__inv_aw0[(__inv_k)*(nbase) + (__inv_c)] / __inv_factor);
            }
            for (int64_t __inv_r = 0; __inv_r < nbase; ++__inv_r) {
              if ((__inv_r != __inv_k)) {
                __inv_factor = __inv_aw0[(__inv_r)*(nbase) + (__inv_k)];
                for (int64_t __inv_c = 0; __inv_c < nbase; ++__inv_c) {
                  __cb28[(__inv_r)*(nbase) + (__inv_c)] = (__cb28[(__inv_r)*(nbase) + (__inv_c)] - (__inv_factor * __cb28[(__inv_k)*(nbase) + (__inv_c)]));
                  __inv_aw0[(__inv_r)*(nbase) + (__inv_c)] = (__inv_aw0[(__inv_r)*(nbase) + (__inv_c)] - (__inv_factor * __inv_aw0[(__inv_k)*(nbase) + (__inv_c)]));
                }
              }
            }
          }
          free(__inl9_chol_inv);
          __inl9_chol_inv = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9_chol_inv, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9_chol_inv");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9_chol_inv[(__w0)*(nbase) + (__w1)] = __cb28[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__inl33_C);
          __inl33_C = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl33_C, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl33_C");
          memset(__inl33_C, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          for (int64_t __inl33_i = 0; __inl33_i < nbase; ++__inl33_i) {
            for (int64_t __inl33_j = 0; __inl33_j < nbase; ++__inl33_j) {
              __inl33_C[(__inl33_i)*(nbase) + (__inl33_j)] = __npb_conj(__inl9_chol[(__inl33_j)*(nbase) + (__inl33_i)]);
            }
          }
          free(__inl9_chol_h);
          __inl9_chol_h = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9_chol_h, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9_chol_h");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9_chol_h[(__w0)*(nbase) + (__w1)] = __inl33_C[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__inl34_C);
          __inl34_C = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl34_C, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl34_C");
          memset(__inl34_C, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          for (int64_t __inl34_i = 0; __inl34_i < nbase; ++__inl34_i) {
            for (int64_t __inl34_j = 0; __inl34_j < nbase; ++__inl34_j) {
              __inl34_C[(__inl34_i)*(nbase) + (__inl34_j)] = __npb_conj(__inl9_chol_inv[(__inl34_j)*(nbase) + (__inl34_i)]);
            }
          }
          free(__inl9_chol_inv_h);
          __inl9_chol_inv_h = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9_chol_inv_h, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9_chol_inv_h");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9_chol_inv_h[(__w0)*(nbase) + (__w1)] = __inl34_C[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__mm29);
          __mm29 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__mm29, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__mm29");
          for (int64_t __i = 0; __i < nbase; ++__i) {
            for (int64_t __j = 0; __j < nbase; ++__j) {
              __mm29[(__i)*(nbase) + (__j)] = 0.0;
              for (int64_t __l = 0; __l < nbase; ++__l) {
                __mm29[(__i)*(nbase) + (__j)] += (__inl9_chol_inv[(__i)*(nbase) + (__l)] * __inl9_a[(__l)*(nbase) + (__j)]);
              }
            }
          }
          free(__inl9___t);
          __inl9___t = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9___t, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9___t");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9___t[(__w0)*(nbase) + (__w1)] = __mm29[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__mm30);
          __mm30 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__mm30, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__mm30");
          for (int64_t __i = 0; __i < nbase; ++__i) {
            for (int64_t __j = 0; __j < nbase; ++__j) {
              __mm30[(__i)*(nbase) + (__j)] = 0.0;
              for (int64_t __l = 0; __l < nbase; ++__l) {
                __mm30[(__i)*(nbase) + (__j)] += (__inl9___t[(__i)*(nbase) + (__l)] * __inl9_chol_inv_h[(__l)*(nbase) + (__j)]);
              }
            }
          }
          free(__inl9_reduced);
          __inl9_reduced = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9_reduced, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9_reduced");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9_reduced[(__w0)*(nbase) + (__w1)] = __mm30[(__w0)*(nbase) + (__w1)];
            }
          }
          for (int64_t __inl9_i = 0; __inl9_i < nbase; ++__inl9_i) {
            for (int64_t __inl9_j = (__inl9_i + 1); __inl9_j < nbase; ++__inl9_j) {
              __inl9_val = (0.5 * (__inl9_reduced[(__inl9_i)*(nbase) + (__inl9_j)] + __npb_conj(__inl9_reduced[(__inl9_j)*(nbase) + (__inl9_i)])));
              __inl9_reduced[(__inl9_i)*(nbase) + (__inl9_j)] = __inl9_val;
              __inl9_reduced[(__inl9_j)*(nbase) + (__inl9_i)] = __npb_conj(__inl9_val);
            }
          }
          free(__inl9___eigh0_Cm);
          __inl9___eigh0_Cm = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9___eigh0_Cm, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9___eigh0_Cm");
          memset(__inl9___eigh0_Cm, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          for (int64_t __inl9___eigh0_ci = 0; __inl9___eigh0_ci < nbase; ++__inl9___eigh0_ci) {
            for (int64_t __inl9___eigh0_cj = 0; __inl9___eigh0_cj < nbase; ++__inl9___eigh0_cj) {
              __inl9___eigh0_Cm[(__inl9___eigh0_ci)*(nbase) + (__inl9___eigh0_cj)] = __inl9_reduced[(__inl9___eigh0_ci)*(nbase) + (__inl9___eigh0_cj)];
            }
          }
          free(__inl9___eigh0_jv);
          __inl9___eigh0_jv = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9___eigh0_jv, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9___eigh0_jv");
          memset(__inl9___eigh0_jv, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          for (int64_t __inl9___eigh0_di = 0; __inl9___eigh0_di < nbase; ++__inl9___eigh0_di) {
            __inl9___eigh0_jv[(__inl9___eigh0_di)*(nbase) + (__inl9___eigh0_di)] = 1;
          }
          for (int64_t __inl9___eigh0_sw = 0; __inl9___eigh0_sw < 80; ++__inl9___eigh0_sw) {
            __inl9___eigh0_off = 0.0;
            for (int64_t __inl9___eigh0_pp = 0; __inl9___eigh0_pp < nbase; ++__inl9___eigh0_pp) {
              for (int64_t __inl9___eigh0_qq = (__inl9___eigh0_pp + 1); __inl9___eigh0_qq < nbase; ++__inl9___eigh0_qq) {
                __inl9___eigh0_off += ((creal(__inl9___eigh0_Cm[(__inl9___eigh0_pp)*(nbase) + (__inl9___eigh0_qq)]) * creal(__inl9___eigh0_Cm[(__inl9___eigh0_pp)*(nbase) + (__inl9___eigh0_qq)])) + (cimag(__inl9___eigh0_Cm[(__inl9___eigh0_pp)*(nbase) + (__inl9___eigh0_qq)]) * cimag(__inl9___eigh0_Cm[(__inl9___eigh0_pp)*(nbase) + (__inl9___eigh0_qq)])));
              }
            }
            if ((__inl9___eigh0_off <= 1e-30)) {
              break;
            }
            for (int64_t __inl9___eigh0_pp = 0; __inl9___eigh0_pp < nbase; ++__inl9___eigh0_pp) {
              for (int64_t __inl9___eigh0_qq = (__inl9___eigh0_pp + 1); __inl9___eigh0_qq < nbase; ++__inl9___eigh0_qq) {
                __inl9___eigh0_apq = __inl9___eigh0_Cm[(__inl9___eigh0_pp)*(nbase) + (__inl9___eigh0_qq)];
                __inl9___eigh0_m = hypot(creal(__inl9___eigh0_apq), cimag(__inl9___eigh0_apq));
                if ((__inl9___eigh0_m == 0.0)) {
                  continue;
                }
                __inl9___eigh0_app = creal(__inl9___eigh0_Cm[(__inl9___eigh0_pp)*(nbase) + (__inl9___eigh0_pp)]);
                __inl9___eigh0_aqq = creal(__inl9___eigh0_Cm[(__inl9___eigh0_qq)*(nbase) + (__inl9___eigh0_qq)]);
                __inl9___eigh0_s = ((((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0)))) * (1.0 / sqrt((((((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0)))) * (((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0))))) + 1.0))));
                for (int64_t __inl9___eigh0_k = 0; __inl9___eigh0_k < nbase; ++__inl9___eigh0_k) {
                  __inl9___eigh0_akp = __inl9___eigh0_Cm[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_pp)];
                  __inl9___eigh0_akq = __inl9___eigh0_Cm[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_qq)];
                  __inl9___eigh0_Cm[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_pp)] = (((1.0 / sqrt((((((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0)))) * (((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0))))) + 1.0))) * __inl9___eigh0_akp) - ((__inl9___eigh0_s * __npb_conj((__inl9___eigh0_apq / __inl9___eigh0_m))) * __inl9___eigh0_akq));
                  __inl9___eigh0_Cm[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_qq)] = (((__inl9___eigh0_s * (__inl9___eigh0_apq / __inl9___eigh0_m)) * __inl9___eigh0_akp) + ((1.0 / sqrt((((((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0)))) * (((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0))))) + 1.0))) * __inl9___eigh0_akq));
                }
                for (int64_t __inl9___eigh0_k = 0; __inl9___eigh0_k < nbase; ++__inl9___eigh0_k) {
                  __inl9___eigh0_apk = __inl9___eigh0_Cm[(__inl9___eigh0_pp)*(nbase) + (__inl9___eigh0_k)];
                  __inl9___eigh0_aqk = __inl9___eigh0_Cm[(__inl9___eigh0_qq)*(nbase) + (__inl9___eigh0_k)];
                  __inl9___eigh0_Cm[(__inl9___eigh0_pp)*(nbase) + (__inl9___eigh0_k)] = (((1.0 / sqrt((((((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0)))) * (((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0))))) + 1.0))) * __inl9___eigh0_apk) - ((__inl9___eigh0_s * (__inl9___eigh0_apq / __inl9___eigh0_m)) * __inl9___eigh0_aqk));
                  __inl9___eigh0_Cm[(__inl9___eigh0_qq)*(nbase) + (__inl9___eigh0_k)] = (((__inl9___eigh0_s * __npb_conj((__inl9___eigh0_apq / __inl9___eigh0_m))) * __inl9___eigh0_apk) + ((1.0 / sqrt((((((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0)))) * (((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0))))) + 1.0))) * __inl9___eigh0_aqk));
                }
                for (int64_t __inl9___eigh0_k = 0; __inl9___eigh0_k < nbase; ++__inl9___eigh0_k) {
                  __inl9___eigh0_vkp = __inl9___eigh0_jv[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_pp)];
                  __inl9___eigh0_vkq = __inl9___eigh0_jv[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_qq)];
                  __inl9___eigh0_jv[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_pp)] = (((1.0 / sqrt((((((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0)))) * (((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0))))) + 1.0))) * __inl9___eigh0_vkp) - ((__inl9___eigh0_s * __npb_conj((__inl9___eigh0_apq / __inl9___eigh0_m))) * __inl9___eigh0_vkq));
                  __inl9___eigh0_jv[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_qq)] = (((__inl9___eigh0_s * (__inl9___eigh0_apq / __inl9___eigh0_m)) * __inl9___eigh0_vkp) + ((1.0 / sqrt((((((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0)))) * (((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + sqrt(((((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m)) * ((__inl9___eigh0_aqq - __inl9___eigh0_app) / (2.0 * __inl9___eigh0_m))) + 1.0))))) + 1.0))) * __inl9___eigh0_vkq));
                }
              }
            }
          }
          free(__inl9___eigh0_wa);
          __inl9___eigh0_wa = (double *)malloc((size_t)((nbase)) * sizeof(double));
          __npb_alloc_check(__inl9___eigh0_wa, (size_t)((nbase)) * sizeof(double), "__inl9___eigh0_wa");
          memset(__inl9___eigh0_wa, 0, (size_t)((nbase)) * sizeof(double));
          for (int64_t __inl9___eigh0_i = 0; __inl9___eigh0_i < nbase; ++__inl9___eigh0_i) {
            __inl9___eigh0_wa[__inl9___eigh0_i] = creal(__inl9___eigh0_Cm[(__inl9___eigh0_i)*(nbase) + (__inl9___eigh0_i)]);
          }
          for (int64_t __inl9___eigh0_i = 0; __inl9___eigh0_i < nbase; ++__inl9___eigh0_i) {
            __inl9___eigh0_mn = __inl9___eigh0_i;
            for (int64_t __inl9___eigh0_j = (__inl9___eigh0_i + 1); __inl9___eigh0_j < nbase; ++__inl9___eigh0_j) {
              if ((__inl9___eigh0_wa[__inl9___eigh0_j] < __inl9___eigh0_wa[__inl9___eigh0_mn])) {
                __inl9___eigh0_mn = __inl9___eigh0_j;
              }
            }
            if ((__inl9___eigh0_mn != __inl9___eigh0_i)) {
              __inl9___eigh0_tw = __inl9___eigh0_wa[__inl9___eigh0_i];
              __inl9___eigh0_wa[__inl9___eigh0_i] = __inl9___eigh0_wa[__inl9___eigh0_mn];
              __inl9___eigh0_wa[__inl9___eigh0_mn] = __inl9___eigh0_tw;
              for (int64_t __inl9___eigh0_k = 0; __inl9___eigh0_k < nbase; ++__inl9___eigh0_k) {
                __inl9___eigh0_tv = __inl9___eigh0_jv[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_i)];
                __inl9___eigh0_jv[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_i)] = __inl9___eigh0_jv[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_mn)];
                __inl9___eigh0_jv[(__inl9___eigh0_k)*(nbase) + (__inl9___eigh0_mn)] = __inl9___eigh0_tv;
              }
            }
          }
          free(__inl9___eigh0_ya);
          __inl9___eigh0_ya = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9___eigh0_ya, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9___eigh0_ya");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9___eigh0_ya[(__w0)*(nbase) + (__w1)] = __inl9___eigh0_jv[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__inl9_ws);
          __inl9_ws = (double *)malloc((size_t)((nbase)) * sizeof(double));
          __npb_alloc_check(__inl9_ws, (size_t)((nbase)) * sizeof(double), "__inl9_ws");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            __inl9_ws[__w0] = __inl9___eigh0_wa[__w0];
          }
          free(__inl9_ys);
          __inl9_ys = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9_ys, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9_ys");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9_ys[(__w0)*(nbase) + (__w1)] = __inl9___eigh0_ya[(__w0)*(nbase) + (__w1)];
            }
          }
          for (int64_t __inl9_j = 0; __inl9_j < nbase; ++__inl9_j) {
            __inl9_max_i = 0;
            __inl9_max_val = (-1.0);
            for (int64_t __inl9_i = 0; __inl9_i < nbase; ++__inl9_i) {
              __inl9_av = cabs(__inl9_ys[(__inl9_i)*(nbase) + (__inl9_j)]);
              if ((__inl9_av > __inl9_max_val)) {
                __inl9_max_val = __inl9_av;
                __inl9_max_i = __inl9_i;
              }
            }
            __inl9_phase = __inl9_ys[(__inl9_max_i)*(nbase) + (__inl9_j)];
            for (int64_t __inl9_i = 0; __inl9_i < nbase; ++__inl9_i) {
              __inl9_ys[(__inl9_i)*(nbase) + (__inl9_j)] = (__inl9_ys[(__inl9_i)*(nbase) + (__inl9_j)] * (cabs(__inl9_phase) / __inl9_phase));
            }
          }
          free(__cb31);
          __cb31 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb31, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb31");
          free(__sol_aw1);
          __sol_aw1 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__sol_aw1, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__sol_aw1");
          /* numpy: np.linalg.solve(__inl9_chol_h, __inl9_ys) */
          for (int64_t __sol_i = 0; __sol_i < nbase; ++__sol_i) {
            for (int64_t __sol_j = 0; __sol_j < nbase; ++__sol_j) {
              __sol_aw1[(__sol_i)*(nbase) + (__sol_j)] = __inl9_chol_h[(__sol_i)*(nbase) + (__sol_j)];
            }
            for (int64_t __sol_j = 0; __sol_j < nbase; ++__sol_j) {
              __cb31[(__sol_i)*(nbase) + (__sol_j)] = __inl9_ys[(__sol_i)*(nbase) + (__sol_j)];
            }
          }
          for (int64_t __sol_k = 0; __sol_k < nbase; ++__sol_k) {
            __sol_p = __sol_k;
            for (int64_t __sol_r = (__sol_k + 1); __sol_r < nbase; ++__sol_r) {
              if ((cabs(__sol_aw1[(__sol_r)*(nbase) + (__sol_k)]) > cabs(__sol_aw1[(__sol_p)*(nbase) + (__sol_k)]))) {
                __sol_p = __sol_r;
              }
            }
            for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
              __sol_tmp = __sol_aw1[(__sol_k)*(nbase) + (__sol_c)];
              __sol_aw1[(__sol_k)*(nbase) + (__sol_c)] = __sol_aw1[(__sol_p)*(nbase) + (__sol_c)];
              __sol_aw1[(__sol_p)*(nbase) + (__sol_c)] = __sol_tmp;
            }
            for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
              __sol_tmp = __cb31[(__sol_k)*(nbase) + (__sol_c)];
              __cb31[(__sol_k)*(nbase) + (__sol_c)] = __cb31[(__sol_p)*(nbase) + (__sol_c)];
              __cb31[(__sol_p)*(nbase) + (__sol_c)] = __sol_tmp;
            }
            __sol_factor = __sol_aw1[(__sol_k)*(nbase) + (__sol_k)];
            for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
              __sol_aw1[(__sol_k)*(nbase) + (__sol_c)] = (__sol_aw1[(__sol_k)*(nbase) + (__sol_c)] / __sol_factor);
            }
            for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
              __cb31[(__sol_k)*(nbase) + (__sol_c)] = (__cb31[(__sol_k)*(nbase) + (__sol_c)] / __sol_factor);
            }
            for (int64_t __sol_r = 0; __sol_r < nbase; ++__sol_r) {
              if ((__sol_r != __sol_k)) {
                __sol_factor = __sol_aw1[(__sol_r)*(nbase) + (__sol_k)];
                for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
                  __sol_aw1[(__sol_r)*(nbase) + (__sol_c)] = (__sol_aw1[(__sol_r)*(nbase) + (__sol_c)] - (__sol_factor * __sol_aw1[(__sol_k)*(nbase) + (__sol_c)]));
                }
                for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
                  __cb31[(__sol_r)*(nbase) + (__sol_c)] = (__cb31[(__sol_r)*(nbase) + (__sol_c)] - (__sol_factor * __cb31[(__sol_k)*(nbase) + (__sol_c)]));
                }
              }
            }
          }
          free(__inl9_vs);
          __inl9_vs = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl9_vs, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl9_vs");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl9_vs[(__w0)*(nbase) + (__w1)] = __cb31[(__w0)*(nbase) + (__w1)];
            }
          }
          if ((nvec < nbase)) {
            for (int64_t si0 = 0; si0 < nvec; ++si0) {
              __inl9_w[si0] = __inl9_ws[si0];
            }
            for (int64_t si0 = 0; si0 < nbase; ++si0) {
              for (int64_t si1 = 0; si1 < nvec; ++si1) {
                __inl9_v[(si0)*(nbase) + (si1)] = __inl9_vs[(si0)*(nbase) + (si1)];
              }
            }
          }
          else {
            for (int64_t si0 = 0; si0 < nbase; ++si0) {
              __inl9_w[si0] = __inl9_ws[si0];
            }
            for (int64_t si0 = 0; si0 < nbase; ++si0) {
              for (int64_t si1 = 0; si1 < nbase; ++si1) {
                __inl9_v[(si0)*(nbase) + (si1)] = __inl9_vs[(si0)*(nbase) + (si1)];
              }
            }
          }
          for (int64_t si0 = 0; si0 < nvec; ++si0) {
            ew[si0] = __inl9_w[si0];
          }
          for (int64_t __inl9_j = 0; __inl9_j < nvec; ++__inl9_j) {
            for (int64_t __inl9_i = 0; __inl9_i < nbase; ++__inl9_i) {
              vc[(__inl9_j)*(nvecx) + (__inl9_i)] = __inl9_v[(__inl9_i)*(nbase) + (__inl9_j)];
            }
          }
          for (int64_t si0 = 0; si0 < nvec; ++si0) {
            e[si0] = ew[si0];
          }
        }
        for (int64_t kter = 1; kter < 21; ++kter) {
          dav_iter = kter;
          memset(unconv, 0, (size_t)((nvec)) * sizeof(int64_t));
          np_ = 0;
          for (int64_t i = 0; i < nvec; ++i) {
            if ((!conv[i])) {
              unconv[np_] = i;
              np_ += 1;
            }
          }
          for (int64_t j = 0; j < np_; ++j) {
            idx = ((int64_t)(unconv[j]));
            ew[(nbase + j)] = e[idx];
            for (int64_t ii = 0; ii < nvecx; ++ii) {
              vc[(j)*(nvecx) + (ii)] = vc[(idx)*(nvecx) + (ii)];
            }
          }
          nb1 = nbase;
          free(ritz_s);
          ritz_s = (double _Complex *)malloc((size_t)((nvecx) * (kdim)) * sizeof(double _Complex));
          __npb_alloc_check(ritz_s, (size_t)((nvecx) * (kdim)) * sizeof(double _Complex), "ritz_s");
          memset(ritz_s, 0, (size_t)((nvecx) * (kdim)) * sizeof(double _Complex));
          free(vc_u);
          vc_u = (double _Complex *)malloc((size_t)((notcnv) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(vc_u, (size_t)((notcnv) * (nbase)) * sizeof(double _Complex), "vc_u");
          for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              vc_u[(__w0)*(nbase) + (__w1)] = vc[(__w0)*(nvecx) + (__w1)];
            }
          }
          if (uspp) {
            free(spsi_k);
            spsi_k = (double _Complex *)malloc((size_t)((nbase) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(spsi_k, (size_t)((nbase) * (kdim)) * sizeof(double _Complex), "spsi_k");
            for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
              for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
                spsi_k[(__w0)*(kdim) + (__w1)] = spsi[(__w0)*((npwx * npol)) + (__w1)];
              }
            }
            free(__mm32);
            __mm32 = (double _Complex *)malloc((size_t)((notcnv) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(__mm32, (size_t)((notcnv) * (kdim)) * sizeof(double _Complex), "__mm32");
            for (int64_t __i = 0; __i < notcnv; ++__i) {
              for (int64_t __j = 0; __j < kdim; ++__j) {
                __mm32[(__i)*(kdim) + (__j)] = 0.0;
                for (int64_t __l = 0; __l < nbase; ++__l) {
                  __mm32[(__i)*(kdim) + (__j)] += (vc_u[(__i)*(nbase) + (__l)] * spsi_k[(__l)*(kdim) + (__j)]);
                }
              }
            }
            for (int64_t si0 = 0; si0 < notcnv; ++si0) {
              for (int64_t si1 = 0; si1 < kdim; ++si1) {
                ritz_s[(si0)*(kdim) + (si1)] = __mm32[(si0)*(kdim) + (si1)];
              }
            }
          }
          else {
            free(psi_k);
            psi_k = (double _Complex *)malloc((size_t)((nbase) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(psi_k, (size_t)((nbase) * (kdim)) * sizeof(double _Complex), "psi_k");
            for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
              for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
                psi_k[(__w0)*(kdim) + (__w1)] = psi[(__w0)*((npwx * npol)) + (__w1)];
              }
            }
            free(__mm33);
            __mm33 = (double _Complex *)malloc((size_t)((notcnv) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(__mm33, (size_t)((notcnv) * (kdim)) * sizeof(double _Complex), "__mm33");
            for (int64_t __i = 0; __i < notcnv; ++__i) {
              for (int64_t __j = 0; __j < kdim; ++__j) {
                __mm33[(__i)*(kdim) + (__j)] = 0.0;
                for (int64_t __l = 0; __l < nbase; ++__l) {
                  __mm33[(__i)*(kdim) + (__j)] += (vc_u[(__i)*(nbase) + (__l)] * psi_k[(__l)*(kdim) + (__j)]);
                }
              }
            }
            for (int64_t si0 = 0; si0 < notcnv; ++si0) {
              for (int64_t si1 = 0; si1 < kdim; ++si1) {
                ritz_s[(si0)*(kdim) + (si1)] = __mm33[(si0)*(kdim) + (si1)];
              }
            }
          }
          free(hpsi_k);
          hpsi_k = (double _Complex *)malloc((size_t)((nbase) * (kdim)) * sizeof(double _Complex));
          __npb_alloc_check(hpsi_k, (size_t)((nbase) * (kdim)) * sizeof(double _Complex), "hpsi_k");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
              hpsi_k[(__w0)*(kdim) + (__w1)] = hpsi[(__w0)*((npwx * npol)) + (__w1)];
            }
          }
          free(__mm34);
          __mm34 = (double _Complex *)malloc((size_t)((notcnv) * (kdim)) * sizeof(double _Complex));
          __npb_alloc_check(__mm34, (size_t)((notcnv) * (kdim)) * sizeof(double _Complex), "__mm34");
          for (int64_t __i = 0; __i < notcnv; ++__i) {
            for (int64_t __j = 0; __j < kdim; ++__j) {
              __mm34[(__i)*(kdim) + (__j)] = 0.0;
              for (int64_t __l = 0; __l < nbase; ++__l) {
                __mm34[(__i)*(kdim) + (__j)] += (vc_u[(__i)*(nbase) + (__l)] * hpsi_k[(__l)*(kdim) + (__j)]);
              }
            }
          }
          free(resid);
          resid = (double _Complex *)malloc((size_t)((notcnv) * (kdim)) * sizeof(double _Complex));
          __npb_alloc_check(resid, (size_t)((notcnv) * (kdim)) * sizeof(double _Complex), "resid");
          for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
            for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
              resid[(__w0)*(kdim) + (__w1)] = __mm34[(__w0)*(kdim) + (__w1)];
            }
          }
          for (int64_t j = 0; j < notcnv; ++j) {
            for (int64_t si1 = 0; si1 < kdim; ++si1) {
              resid[(j)*(kdim) + (si1)] = (resid[(j)*(kdim) + (si1)] - (ew[(nb1 + j)] * ritz_s[(j)*(kdim) + (si1)]));
            }
          }
          for (int64_t si0 = nb1; si0 < (nb1 + notcnv); ++si0) {
            for (int64_t si1 = 0; si1 < kdim; ++si1) {
              psi[(si0)*((npwx * npol)) + (si1)] = resid[((si0 - nb1))*(kdim) + (si1)];
            }
          }
          for (int64_t j = 0; j < notcnv; ++j) {
            for (int64_t i = 0; i < kdim; ++i) {
              x = (hd[i] - (ew[(nb1 + j)] * sd[i]));
              pow_base2 = (x - 1.0);
              denm = (0.5 * ((1.0 + x) + sqrt((1.0 + (pow_base2 * pow_base2)))));
              psi[((nb1 + j))*((npwx * npol)) + (i)] = (psi[((nb1 + j))*((npwx * npol)) + (i)] / denm);
            }
          }
          free(cv);
          cv = (double _Complex *)malloc((size_t)((notcnv) * (kdim)) * sizeof(double _Complex));
          __npb_alloc_check(cv, (size_t)((notcnv) * (kdim)) * sizeof(double _Complex), "cv");
          for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
            for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
              cv[(__w0)*(kdim) + (__w1)] = psi[((__w0 + (nb1 - 0)))*((npwx * npol)) + (__w1)];
            }
          }
          free(__cb35);
          __cb35 = (double *)malloc((size_t)((notcnv) * (kdim)) * sizeof(double));
          __npb_alloc_check(__cb35, (size_t)((notcnv) * (kdim)) * sizeof(double), "__cb35");
          for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
            for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
              __cb35[(__w0)*(kdim) + (__w1)] = (creal(cv[(__w0)*(kdim) + (__w1)]) * creal(cv[(__w0)*(kdim) + (__w1)]));
            }
          }
          free(__cb36);
          __cb36 = (double *)malloc((size_t)((notcnv)) * sizeof(double));
          __npb_alloc_check(__cb36, (size_t)((notcnv)) * sizeof(double), "__cb36");
          /* numpy: np.sum(__cb35, axis=1) */
          for (int64_t __ax0 = 0; __ax0 < notcnv; ++__ax0) {
            __cb36[__ax0] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < kdim; ++__rd0) {
              __cb36[__ax0] = (__cb36[__ax0] + __cb35[(__ax0)*(kdim) + (__rd0)]);
            }
          }
          free(__cb37);
          __cb37 = (double *)malloc((size_t)((notcnv) * (kdim)) * sizeof(double));
          __npb_alloc_check(__cb37, (size_t)((notcnv) * (kdim)) * sizeof(double), "__cb37");
          for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
            for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
              __cb37[(__w0)*(kdim) + (__w1)] = (cimag(cv[(__w0)*(kdim) + (__w1)]) * cimag(cv[(__w0)*(kdim) + (__w1)]));
            }
          }
          free(__cb38);
          __cb38 = (double *)malloc((size_t)((notcnv)) * sizeof(double));
          __npb_alloc_check(__cb38, (size_t)((notcnv)) * sizeof(double), "__cb38");
          /* numpy: np.sum(__cb37, axis=1) */
          for (int64_t __ax0 = 0; __ax0 < notcnv; ++__ax0) {
            __cb38[__ax0] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < kdim; ++__rd0) {
              __cb38[__ax0] = (__cb38[__ax0] + __cb37[(__ax0)*(kdim) + (__rd0)]);
            }
          }
          for (int64_t si0 = 0; si0 < notcnv; ++si0) {
            ew[si0] = (__cb36[si0] + __cb38[si0]);
          }
          for (int64_t j = 0; j < notcnv; ++j) {
            for (int64_t si1 = 0; si1 < kdim; ++si1) {
              psi[((nb1 + j))*((npwx * npol)) + (si1)] = (cv[(j)*(kdim) + (si1)] / sqrt(ew[j]));
            }
          }
          free(psi1);
          psi1 = (double _Complex *)malloc((size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex));
          __npb_alloc_check(psi1, (size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex), "psi1");
          for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (npwx * npol); ++__w1) {
              psi1[(__w0)*((npwx * npol)) + (__w1)] = psi[((__w0 + (nb1 - 0)))*((npwx * npol)) + (__w1)];
            }
          }
          free(__inl12_H);
          __inl12_H = (double _Complex *)malloc((size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex));
          __npb_alloc_check(__inl12_H, (size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex), "__inl12_H");
          memset(__inl12_H, 0, (size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex));
          /* numpy: np.asarray(g2kin) */
          for (int64_t __r0 = 0; __r0 < nks; ++__r0) {
            for (int64_t __r1 = 0; __r1 < npwx; ++__r1) {
              __cb39[(__r0)*(npwx) + (__r1)] = g2kin[(__r0)*(npwx) + (__r1)];
            }
          }
          free(__inl12_g2);
          __inl12_g2 = (double *)malloc((size_t)((npw_k)) * sizeof(double));
          __npb_alloc_check(__inl12_g2, (size_t)((npw_k)) * sizeof(double), "__inl12_g2");
          for (int64_t si0 = 0; si0 < npw_k; ++si0) {
            __inl12_g2[si0] = __cb39[(ck0)*(npwx) + (si0)];
          }
          /* numpy: np.asarray(nlk) */
          for (int64_t __r0 = 0; __r0 < nks; ++__r0) {
            for (int64_t __r1 = 0; __r1 < npwx; ++__r1) {
              __cb40[(__r0)*(npwx) + (__r1)] = nlk[(__r0)*(npwx) + (__r1)];
            }
          }
          free(__inl12_gmap);
          __inl12_gmap = (int64_t *)malloc((size_t)((npw_k)) * sizeof(int64_t));
          __npb_alloc_check(__inl12_gmap, (size_t)((npw_k)) * sizeof(int64_t), "__inl12_gmap");
          for (int64_t __w0 = 0; __w0 < npw_k; ++__w0) {
            __inl12_gmap[__w0] = ((int64_t)(__cb40[(ck0)*(npwx) + (__w0)]));
          }
          for (int64_t __w0 = 0; __w0 < npol; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((n1 * n2) * n3); ++__w1) {
              __inl12_vrs2[(__w0)*(((n1 * n2) * n3)) + (__w1)] = vrs[(__w0)*(((n1 * n2) * n3)) + (__w1)];
            }
          }
          /* numpy: np.asarray(vkb) */
          for (int64_t __r0 = 0; __r0 < nks; ++__r0) {
            for (int64_t __r1 = 0; __r1 < nkb; ++__r1) {
              for (int64_t __r2 = 0; __r2 < npwx; ++__r2) {
                __cb41[((__r0)*(nkb) + (__r1))*(npwx) + (__r2)] = vkb[((__r0)*(nkb) + (__r1))*(npwx) + (__r2)];
              }
            }
          }
          for (int64_t __inl12_ip = 0; __inl12_ip < npol; ++__inl12_ip) {
            free(__inl12_X_b);
            __inl12_X_b = (double _Complex *)malloc((size_t)((notcnv) * (npw_k)) * sizeof(double _Complex));
            __npb_alloc_check(__inl12_X_b, (size_t)((notcnv) * (npw_k)) * sizeof(double _Complex), "__inl12_X_b");
            for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
              for (int64_t __w1 = 0; __w1 < npw_k; ++__w1) {
                __inl12_X_b[(__w0)*(npw_k) + (__w1)] = psi1[(__w0)*((npwx * npol)) + ((__w1 + ((__inl12_ip * npwx) - 0)))];
              }
            }
            for (int64_t si0 = 0; si0 < notcnv; ++si0) {
              for (int64_t si1 = (__inl12_ip * npwx); si1 < ((__inl12_ip * npwx) + npw_k); ++si1) {
                __inl12_H[(si0)*((npwx * npol)) + (si1)] = (__inl12_g2[(si1 + (0 - (__inl12_ip * npwx)))] * __inl12_X_b[(si0)*(npw_k) + ((si1 - (__inl12_ip * npwx)))]);
              }
            }
            free(__inl42_psic);
            __inl42_psic = (double _Complex *)malloc((size_t)((notcnv) * (nnr)) * sizeof(double _Complex));
            __npb_alloc_check(__inl42_psic, (size_t)((notcnv) * (nnr)) * sizeof(double _Complex), "__inl42_psic");
            memset(__inl42_psic, 0, (size_t)((notcnv) * (nnr)) * sizeof(double _Complex));
            for (int64_t __scs0 = 0; __scs0 < notcnv; ++__scs0) {
              for (int64_t __sc0 = 0; __sc0 < npw_k; ++__sc0) {
                __inl42_psic[(__scs0)*(nnr) + (__inl12_gmap[__sc0])] = __inl12_X_b[(__scs0)*(npw_k) + (__sc0)];
              }
            }
            free(__cb42);
            __cb42 = (double _Complex *)malloc((size_t)((notcnv) * (n3) * (n2) * (n1)) * sizeof(double _Complex));
            __npb_alloc_check(__cb42, (size_t)((notcnv) * (n3) * (n2) * (n1)) * sizeof(double _Complex), "__cb42");
            /* numpy: np.reshape(__inl42_psic, (notcnv, n3, n2, n1)) */
            for (int64_t __rs0 = 0; __rs0 < notcnv; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < n3; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < n2; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < n1; ++__rs3) {
                    __cb42[(((__rs0)*(n3) + (__rs1))*(n2) + (__rs2))*(n1) + (__rs3)] = __inl42_psic[(__rs0)*(nnr) + ((((__rs1 * (n2 * n1)) + (__rs2 * n1)) + __rs3))];
                  }
                }
              }
            }
            free(__cb43);
            __cb43 = (double _Complex *)malloc((size_t)((notcnv) * (n3) * (n2) * (n1)) * sizeof(double _Complex));
            __npb_alloc_check(__cb43, (size_t)((notcnv) * (n3) * (n2) * (n1)) * sizeof(double _Complex), "__cb43");
            /* numpy: np.fft.ifftn(__cb42, axes=(1, 2, 3)) */
            {
              int64_t __fft_n = (int64_t)(n3) * (int64_t)(n2) * (int64_t)(n1);
              int64_t __fft_batch = (int64_t)(notcnv);
              if (__fft_n > 0 && __fft_batch > 0) {
                int __fft_dims[3] = {(int)(n3), (int)(n2), (int)(n1)};
                fftw_plan __fft_plan = fftw_plan_many_dft(3, __fft_dims, (int)__fft_batch, (fftw_complex *)(__cb42), NULL, 1, (int)__fft_n, (fftw_complex *)(__cb43), NULL, 1, (int)__fft_n, FFTW_BACKWARD, FFTW_ESTIMATE);
                fftw_execute(__fft_plan);
                fftw_destroy_plan(__fft_plan);
                for (int64_t __fft_i = 0; __fft_i < __fft_n * __fft_batch; ++__fft_i) {
                  __cb43[__fft_i] /= ((double)__fft_n);
                }
              }
            }
            free(__cb44);
            __cb44 = (double _Complex *)malloc((size_t)((notcnv) * (nnr)) * sizeof(double _Complex));
            __npb_alloc_check(__cb44, (size_t)((notcnv) * (nnr)) * sizeof(double _Complex), "__cb44");
            /* numpy: np.reshape(__cb43, (notcnv, nnr)) */
            for (int64_t __rs0 = 0; __rs0 < notcnv; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < n3; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < n2; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < n1; ++__rs3) {
                    __cb44[(__rs0)*(nnr) + ((((__rs1 * (n2 * n1)) + (__rs2 * n1)) + __rs3))] = __cb43[(((__rs0)*(n3) + (__rs1))*(n2) + (__rs2))*(n1) + (__rs3)];
                  }
                }
              }
            }
            free(__inl12_r);
            __inl12_r = (double _Complex *)malloc((size_t)((notcnv) * (nnr)) * sizeof(double _Complex));
            __npb_alloc_check(__inl12_r, (size_t)((notcnv) * (nnr)) * sizeof(double _Complex), "__inl12_r");
            for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nnr; ++__w1) {
                __inl12_r[(__w0)*(nnr) + (__w1)] = __cb44[(__w0)*(nnr) + (__w1)];
              }
            }
            for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nnr; ++__w1) {
                __inl12_r[(__w0)*(nnr) + (__w1)] = (__inl12_r[(__w0)*(nnr) + (__w1)] * __inl12_vrs2[(__inl12_ip)*(((n1 * n2) * n3)) + (__w1)]);
              }
            }
            free(__cb45);
            __cb45 = (double _Complex *)malloc((size_t)((notcnv) * (n3) * (n2) * (n1)) * sizeof(double _Complex));
            __npb_alloc_check(__cb45, (size_t)((notcnv) * (n3) * (n2) * (n1)) * sizeof(double _Complex), "__cb45");
            /* numpy: np.reshape(__inl12_r, (notcnv, n3, n2, n1)) */
            for (int64_t __rs0 = 0; __rs0 < notcnv; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < n3; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < n2; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < n1; ++__rs3) {
                    __cb45[(((__rs0)*(n3) + (__rs1))*(n2) + (__rs2))*(n1) + (__rs3)] = __inl12_r[(__rs0)*(nnr) + ((((__rs1 * (n2 * n1)) + (__rs2 * n1)) + __rs3))];
                  }
                }
              }
            }
            free(__cb46);
            __cb46 = (double _Complex *)malloc((size_t)((notcnv) * (n3) * (n2) * (n1)) * sizeof(double _Complex));
            __npb_alloc_check(__cb46, (size_t)((notcnv) * (n3) * (n2) * (n1)) * sizeof(double _Complex), "__cb46");
            /* numpy: np.fft.fftn(__cb45, axes=(1, 2, 3)) */
            {
              int64_t __fft_n = (int64_t)(n3) * (int64_t)(n2) * (int64_t)(n1);
              int64_t __fft_batch = (int64_t)(notcnv);
              if (__fft_n > 0 && __fft_batch > 0) {
                int __fft_dims[3] = {(int)(n3), (int)(n2), (int)(n1)};
                fftw_plan __fft_plan = fftw_plan_many_dft(3, __fft_dims, (int)__fft_batch, (fftw_complex *)(__cb45), NULL, 1, (int)__fft_n, (fftw_complex *)(__cb46), NULL, 1, (int)__fft_n, FFTW_FORWARD, FFTW_ESTIMATE);
                fftw_execute(__fft_plan);
                fftw_destroy_plan(__fft_plan);
              }
            }
            free(__cb47);
            __cb47 = (double _Complex *)malloc((size_t)((notcnv) * (nnr)) * sizeof(double _Complex));
            __npb_alloc_check(__cb47, (size_t)((notcnv) * (nnr)) * sizeof(double _Complex), "__cb47");
            /* numpy: np.reshape(__cb46, (notcnv, nnr)) */
            for (int64_t __rs0 = 0; __rs0 < notcnv; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < n3; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < n2; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < n1; ++__rs3) {
                    __cb47[(__rs0)*(nnr) + ((((__rs1 * (n2 * n1)) + (__rs2 * n1)) + __rs3))] = __cb46[(((__rs0)*(n3) + (__rs1))*(n2) + (__rs2))*(n1) + (__rs3)];
                  }
                }
              }
            }
            free(__inl43_g);
            __inl43_g = (double _Complex *)malloc((size_t)((notcnv) * (nnr)) * sizeof(double _Complex));
            __npb_alloc_check(__inl43_g, (size_t)((notcnv) * (nnr)) * sizeof(double _Complex), "__inl43_g");
            for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nnr; ++__w1) {
                __inl43_g[(__w0)*(nnr) + (__w1)] = __cb47[(__w0)*(nnr) + (__w1)];
              }
            }
            free(__inl12___h_tmp);
            __inl12___h_tmp = (double _Complex *)malloc((size_t)((notcnv) * (npw_k)) * sizeof(double _Complex));
            __npb_alloc_check(__inl12___h_tmp, (size_t)((notcnv) * (npw_k)) * sizeof(double _Complex), "__inl12___h_tmp");
            for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
              for (int64_t __w1 = 0; __w1 < npw_k; ++__w1) {
                __inl12___h_tmp[(__w0)*(npw_k) + (__w1)] = __inl43_g[(__w0)*(nnr) + (__inl12_gmap[__w1])];
              }
            }
            for (int64_t __inl12_jj = 0; __inl12_jj < notcnv; ++__inl12_jj) {
              for (int64_t __inl12_i = 0; __inl12_i < npw_k; ++__inl12_i) {
                __inl12_H[(__inl12_jj)*((npwx * npol)) + (((__inl12_ip * npwx) + __inl12_i))] += __inl12___h_tmp[(__inl12_jj)*(npw_k) + (__inl12_i)];
              }
            }
            if ((nkb > 0)) {
              free(__inl44_C);
              __inl44_C = (double _Complex *)malloc((size_t)((notcnv) * (nkb)) * sizeof(double _Complex));
              __npb_alloc_check(__inl44_C, (size_t)((notcnv) * (nkb)) * sizeof(double _Complex), "__inl44_C");
              memset(__inl44_C, 0, (size_t)((notcnv) * (nkb)) * sizeof(double _Complex));
              for (int64_t __inl44_i = 0; __inl44_i < notcnv; ++__inl44_i) {
                for (int64_t __inl44_j = 0; __inl44_j < nkb; ++__inl44_j) {
                  __inl44_acc = (0.0 + (0.0 + 0.0 * _Complex_I));
                  for (int64_t __inl44_l = 0; __inl44_l < npw_k; ++__inl44_l) {
                    __inl44_acc += (__inl12_X_b[(__inl44_i)*(npw_k) + (__inl44_l)] * __npb_conj(__cb41[((ck0)*(nkb) + (__inl44_j))*(npwx) + (__inl44_l)]));
                  }
                  __inl44_C[(__inl44_i)*(nkb) + (__inl44_j)] = __inl44_acc;
                }
              }
              free(__inl12_ps);
              __inl12_ps = (double _Complex *)malloc((size_t)((notcnv) * (nkb)) * sizeof(double _Complex));
              __npb_alloc_check(__inl12_ps, (size_t)((notcnv) * (nkb)) * sizeof(double _Complex), "__inl12_ps");
              for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
                for (int64_t __w1 = 0; __w1 < nkb; ++__w1) {
                  __inl12_ps[(__w0)*(nkb) + (__w1)] = __inl44_C[(__w0)*(nkb) + (__w1)];
                }
              }
              free(__mm48);
              __mm48 = (double _Complex *)malloc((size_t)((notcnv) * (nkb)) * sizeof(double _Complex));
              __npb_alloc_check(__mm48, (size_t)((notcnv) * (nkb)) * sizeof(double _Complex), "__mm48");
              for (int64_t __i = 0; __i < notcnv; ++__i) {
                for (int64_t __j = 0; __j < nkb; ++__j) {
                  __mm48[(__i)*(nkb) + (__j)] = 0.0;
                  for (int64_t __l = 0; __l < nkb; ++__l) {
                    __mm48[(__i)*(nkb) + (__j)] += (__inl12_ps[(__i)*(nkb) + (__l)] * deeq[(__l)*(nkb) + (__j)]);
                  }
                }
              }
              free(__mm49);
              __mm49 = (double _Complex *)malloc((size_t)((notcnv) * (npw_k)) * sizeof(double _Complex));
              __npb_alloc_check(__mm49, (size_t)((notcnv) * (npw_k)) * sizeof(double _Complex), "__mm49");
              for (int64_t __i = 0; __i < notcnv; ++__i) {
                for (int64_t __j = 0; __j < npw_k; ++__j) {
                  __mm49[(__i)*(npw_k) + (__j)] = 0.0;
                  for (int64_t __l = 0; __l < nkb; ++__l) {
                    __mm49[(__i)*(npw_k) + (__j)] += (__mm48[(__i)*(nkb) + (__l)] * __cb41[((ck0)*(nkb) + (__l))*(npwx) + (__j)]);
                  }
                }
              }
              free(__inl12___h_tmp2);
              __inl12___h_tmp2 = (double _Complex *)malloc((size_t)((notcnv) * (npw_k)) * sizeof(double _Complex));
              __npb_alloc_check(__inl12___h_tmp2, (size_t)((notcnv) * (npw_k)) * sizeof(double _Complex), "__inl12___h_tmp2");
              for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
                for (int64_t __w1 = 0; __w1 < npw_k; ++__w1) {
                  __inl12___h_tmp2[(__w0)*(npw_k) + (__w1)] = __mm49[(__w0)*(npw_k) + (__w1)];
                }
              }
              for (int64_t __inl12_jj = 0; __inl12_jj < notcnv; ++__inl12_jj) {
                for (int64_t __inl12_i = 0; __inl12_i < npw_k; ++__inl12_i) {
                  __inl12_H[(__inl12_jj)*((npwx * npol)) + (((__inl12_ip * npwx) + __inl12_i))] += __inl12___h_tmp2[(__inl12_jj)*(npw_k) + (__inl12_i)];
                }
              }
            }
          }
          free(__hpsi1);
          __hpsi1 = (double _Complex *)malloc((size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex));
          __npb_alloc_check(__hpsi1, (size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex), "__hpsi1");
          for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (npwx * npol); ++__w1) {
              __hpsi1[(__w0)*((npwx * npol)) + (__w1)] = __inl12_H[(__w0)*((npwx * npol)) + (__w1)];
            }
          }
          for (int64_t si0 = nb1; si0 < (nb1 + notcnv); ++si0) {
            for (int64_t si1 = 0; si1 < (npwx * npol); ++si1) {
              hpsi[(si0)*((npwx * npol)) + (si1)] = __hpsi1[((si0 - nb1))*((npwx * npol)) + (si1)];
            }
          }
          if (uspp) {
            free(__inl13_S);
            __inl13_S = (double _Complex *)malloc((size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex));
            __npb_alloc_check(__inl13_S, (size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex), "__inl13_S");
            memset(__inl13_S, 0, (size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex));
            if ((uspp && (nkb > 0))) {
              /* numpy: np.asarray(vkb) */
              for (int64_t __r0 = 0; __r0 < nks; ++__r0) {
                for (int64_t __r1 = 0; __r1 < nkb; ++__r1) {
                  for (int64_t __r2 = 0; __r2 < npwx; ++__r2) {
                    __cb50[((__r0)*(nkb) + (__r1))*(npwx) + (__r2)] = vkb[((__r0)*(nkb) + (__r1))*(npwx) + (__r2)];
                  }
                }
              }
              for (int64_t __inl13_ip = 0; __inl13_ip < npol; ++__inl13_ip) {
                free(__inl13_X_b);
                __inl13_X_b = (double _Complex *)malloc((size_t)((notcnv) * (npw_k)) * sizeof(double _Complex));
                __npb_alloc_check(__inl13_X_b, (size_t)((notcnv) * (npw_k)) * sizeof(double _Complex), "__inl13_X_b");
                for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < npw_k; ++__w1) {
                    __inl13_X_b[(__w0)*(npw_k) + (__w1)] = psi1[(__w0)*((npwx * npol)) + ((__w1 + ((__inl13_ip * npwx) - 0)))];
                  }
                }
                for (int64_t si0 = 0; si0 < notcnv; ++si0) {
                  for (int64_t si1 = (__inl13_ip * npwx); si1 < ((__inl13_ip * npwx) + npw_k); ++si1) {
                    __inl13_S[(si0)*((npwx * npol)) + (si1)] = __inl13_X_b[(si0)*(npw_k) + ((si1 - (__inl13_ip * npwx)))];
                  }
                }
                free(__inl48_C);
                __inl48_C = (double _Complex *)malloc((size_t)((notcnv) * (nkb)) * sizeof(double _Complex));
                __npb_alloc_check(__inl48_C, (size_t)((notcnv) * (nkb)) * sizeof(double _Complex), "__inl48_C");
                memset(__inl48_C, 0, (size_t)((notcnv) * (nkb)) * sizeof(double _Complex));
                for (int64_t __inl48_i = 0; __inl48_i < notcnv; ++__inl48_i) {
                  for (int64_t __inl48_j = 0; __inl48_j < nkb; ++__inl48_j) {
                    __inl48_acc = (0.0 + (0.0 + 0.0 * _Complex_I));
                    for (int64_t __inl48_l = 0; __inl48_l < npw_k; ++__inl48_l) {
                      __inl48_acc += (__inl13_X_b[(__inl48_i)*(npw_k) + (__inl48_l)] * __npb_conj(__cb50[((ck0)*(nkb) + (__inl48_j))*(npwx) + (__inl48_l)]));
                    }
                    __inl48_C[(__inl48_i)*(nkb) + (__inl48_j)] = __inl48_acc;
                  }
                }
                free(__inl13_ps);
                __inl13_ps = (double _Complex *)malloc((size_t)((notcnv) * (nkb)) * sizeof(double _Complex));
                __npb_alloc_check(__inl13_ps, (size_t)((notcnv) * (nkb)) * sizeof(double _Complex), "__inl13_ps");
                for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < nkb; ++__w1) {
                    __inl13_ps[(__w0)*(nkb) + (__w1)] = __inl48_C[(__w0)*(nkb) + (__w1)];
                  }
                }
                free(__mm51);
                __mm51 = (double _Complex *)malloc((size_t)((notcnv) * (nkb)) * sizeof(double _Complex));
                __npb_alloc_check(__mm51, (size_t)((notcnv) * (nkb)) * sizeof(double _Complex), "__mm51");
                for (int64_t __i = 0; __i < notcnv; ++__i) {
                  for (int64_t __j = 0; __j < nkb; ++__j) {
                    __mm51[(__i)*(nkb) + (__j)] = 0.0;
                    for (int64_t __l = 0; __l < nkb; ++__l) {
                      __mm51[(__i)*(nkb) + (__j)] += (__inl13_ps[(__i)*(nkb) + (__l)] * qq[(__l)*(nkb) + (__j)]);
                    }
                  }
                }
                free(__mm52);
                __mm52 = (double _Complex *)malloc((size_t)((notcnv) * (npw_k)) * sizeof(double _Complex));
                __npb_alloc_check(__mm52, (size_t)((notcnv) * (npw_k)) * sizeof(double _Complex), "__mm52");
                for (int64_t __i = 0; __i < notcnv; ++__i) {
                  for (int64_t __j = 0; __j < npw_k; ++__j) {
                    __mm52[(__i)*(npw_k) + (__j)] = 0.0;
                    for (int64_t __l = 0; __l < nkb; ++__l) {
                      __mm52[(__i)*(npw_k) + (__j)] += (__mm51[(__i)*(nkb) + (__l)] * __cb50[((ck0)*(nkb) + (__l))*(npwx) + (__j)]);
                    }
                  }
                }
                free(__inl13___s_tmp);
                __inl13___s_tmp = (double _Complex *)malloc((size_t)((notcnv) * (npw_k)) * sizeof(double _Complex));
                __npb_alloc_check(__inl13___s_tmp, (size_t)((notcnv) * (npw_k)) * sizeof(double _Complex), "__inl13___s_tmp");
                for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < npw_k; ++__w1) {
                    __inl13___s_tmp[(__w0)*(npw_k) + (__w1)] = __mm52[(__w0)*(npw_k) + (__w1)];
                  }
                }
                for (int64_t __inl13_j = 0; __inl13_j < notcnv; ++__inl13_j) {
                  for (int64_t __inl13_i = 0; __inl13_i < npw_k; ++__inl13_i) {
                    __inl13_S[(__inl13_j)*((npwx * npol)) + (((__inl13_ip * npwx) + __inl13_i))] += __inl13___s_tmp[(__inl13_j)*(npw_k) + (__inl13_i)];
                  }
                }
              }
            }
            else {
              for (int64_t __inl13_ip = 0; __inl13_ip < npol; ++__inl13_ip) {
                for (int64_t si0 = 0; si0 < notcnv; ++si0) {
                  for (int64_t si1 = (__inl13_ip * npwx); si1 < ((__inl13_ip * npwx) + npw_k); ++si1) {
                    __inl13_S[(si0)*((npwx * npol)) + (si1)] = psi1[(si0)*((npwx * npol)) + ((si1 + ((__inl13_ip * npwx) - (__inl13_ip * npwx))))];
                  }
                }
              }
            }
            free(__spsi1);
            __spsi1 = (double _Complex *)malloc((size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex));
            __npb_alloc_check(__spsi1, (size_t)((notcnv) * ((npwx * npol))) * sizeof(double _Complex), "__spsi1");
            for (int64_t __w0 = 0; __w0 < notcnv; ++__w0) {
              for (int64_t __w1 = 0; __w1 < (npwx * npol); ++__w1) {
                __spsi1[(__w0)*((npwx * npol)) + (__w1)] = __inl13_S[(__w0)*((npwx * npol)) + (__w1)];
              }
            }
            for (int64_t si0 = nb1; si0 < (nb1 + notcnv); ++si0) {
              for (int64_t si1 = 0; si1 < (npwx * npol); ++si1) {
                spsi[(si0)*((npwx * npol)) + (si1)] = __spsi1[((si0 - nb1))*((npwx * npol)) + (si1)];
              }
            }
          }
          nhpsi += notcnv;
          nend = (nbase + notcnv);
          free(hpsi_b);
          hpsi_b = (double _Complex *)malloc((size_t)(((nend - nb1)) * (kdim)) * sizeof(double _Complex));
          __npb_alloc_check(hpsi_b, (size_t)(((nend - nb1)) * (kdim)) * sizeof(double _Complex), "hpsi_b");
          for (int64_t __w0 = 0; __w0 < (nend - nb1); ++__w0) {
            for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
              hpsi_b[(__w0)*(kdim) + (__w1)] = hpsi[((__w0 + (nb1 - 0)))*((npwx * npol)) + (__w1)];
            }
          }
          free(psi_b);
          psi_b = (double _Complex *)malloc((size_t)((nend) * (kdim)) * sizeof(double _Complex));
          __npb_alloc_check(psi_b, (size_t)((nend) * (kdim)) * sizeof(double _Complex), "psi_b");
          for (int64_t __w0 = 0; __w0 < nend; ++__w0) {
            for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
              psi_b[(__w0)*(kdim) + (__w1)] = psi[(__w0)*((npwx * npol)) + (__w1)];
            }
          }
          free(__inl14_C);
          __inl14_C = (double _Complex *)malloc((size_t)((notcnv) * (nend)) * sizeof(double _Complex));
          __npb_alloc_check(__inl14_C, (size_t)((notcnv) * (nend)) * sizeof(double _Complex), "__inl14_C");
          memset(__inl14_C, 0, (size_t)((notcnv) * (nend)) * sizeof(double _Complex));
          for (int64_t __inl14_i = 0; __inl14_i < notcnv; ++__inl14_i) {
            for (int64_t __inl14_j = 0; __inl14_j < nend; ++__inl14_j) {
              __inl14_acc = (0.0 + (0.0 + 0.0 * _Complex_I));
              for (int64_t __inl14_l = 0; __inl14_l < kdim; ++__inl14_l) {
                __inl14_acc += (__npb_conj(hpsi_b[(__inl14_i)*(kdim) + (__inl14_l)]) * psi_b[(__inl14_j)*(kdim) + (__inl14_l)]);
              }
              __inl14_C[(__inl14_i)*(nend) + (__inl14_j)] = __inl14_acc;
            }
          }
          for (int64_t si0 = nb1; si0 < nend; ++si0) {
            for (int64_t si1 = 0; si1 < nend; ++si1) {
              hc[(si0)*(nvecx) + (si1)] = __inl14_C[((si0 - nb1))*(nend) + (si1)];
            }
          }
          if (uspp) {
            free(spsi_b);
            spsi_b = (double _Complex *)malloc((size_t)(((nend - nb1)) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(spsi_b, (size_t)(((nend - nb1)) * (kdim)) * sizeof(double _Complex), "spsi_b");
            for (int64_t __w0 = 0; __w0 < (nend - nb1); ++__w0) {
              for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
                spsi_b[(__w0)*(kdim) + (__w1)] = spsi[((__w0 + (nb1 - 0)))*((npwx * npol)) + (__w1)];
              }
            }
            free(__inl15_C);
            __inl15_C = (double _Complex *)malloc((size_t)((notcnv) * (nend)) * sizeof(double _Complex));
            __npb_alloc_check(__inl15_C, (size_t)((notcnv) * (nend)) * sizeof(double _Complex), "__inl15_C");
            memset(__inl15_C, 0, (size_t)((notcnv) * (nend)) * sizeof(double _Complex));
            for (int64_t __inl15_i = 0; __inl15_i < notcnv; ++__inl15_i) {
              for (int64_t __inl15_j = 0; __inl15_j < nend; ++__inl15_j) {
                __inl15_acc = (0.0 + (0.0 + 0.0 * _Complex_I));
                for (int64_t __inl15_l = 0; __inl15_l < kdim; ++__inl15_l) {
                  __inl15_acc += (__npb_conj(spsi_b[(__inl15_i)*(kdim) + (__inl15_l)]) * psi_b[(__inl15_j)*(kdim) + (__inl15_l)]);
                }
                __inl15_C[(__inl15_i)*(nend) + (__inl15_j)] = __inl15_acc;
              }
            }
            for (int64_t si0 = nb1; si0 < nend; ++si0) {
              for (int64_t si1 = 0; si1 < nend; ++si1) {
                sc[(si0)*(nvecx) + (si1)] = __inl15_C[((si0 - nb1))*(nend) + (si1)];
              }
            }
          }
          else {
            free(psi_b2);
            psi_b2 = (double _Complex *)malloc((size_t)(((nend - nb1)) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(psi_b2, (size_t)(((nend - nb1)) * (kdim)) * sizeof(double _Complex), "psi_b2");
            for (int64_t __w0 = 0; __w0 < (nend - nb1); ++__w0) {
              for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
                psi_b2[(__w0)*(kdim) + (__w1)] = psi[((__w0 + (nb1 - 0)))*((npwx * npol)) + (__w1)];
              }
            }
            free(__inl16_C);
            __inl16_C = (double _Complex *)malloc((size_t)((notcnv) * (nend)) * sizeof(double _Complex));
            __npb_alloc_check(__inl16_C, (size_t)((notcnv) * (nend)) * sizeof(double _Complex), "__inl16_C");
            memset(__inl16_C, 0, (size_t)((notcnv) * (nend)) * sizeof(double _Complex));
            for (int64_t __inl16_i = 0; __inl16_i < notcnv; ++__inl16_i) {
              for (int64_t __inl16_j = 0; __inl16_j < nend; ++__inl16_j) {
                __inl16_acc = (0.0 + (0.0 + 0.0 * _Complex_I));
                for (int64_t __inl16_l = 0; __inl16_l < kdim; ++__inl16_l) {
                  __inl16_acc += (__npb_conj(psi_b2[(__inl16_i)*(kdim) + (__inl16_l)]) * psi_b[(__inl16_j)*(kdim) + (__inl16_l)]);
                }
                __inl16_C[(__inl16_i)*(nend) + (__inl16_j)] = __inl16_acc;
              }
            }
            for (int64_t si0 = nb1; si0 < nend; ++si0) {
              for (int64_t si1 = 0; si1 < nend; ++si1) {
                sc[(si0)*(nvecx) + (si1)] = __inl16_C[((si0 - nb1))*(nend) + (si1)];
              }
            }
          }
          nbase = nend;
          for (int64_t __inl17_i = ((nb1 + 1) - 1); __inl17_i < nbase; ++__inl17_i) {
            hc[(__inl17_i)*(nvecx) + (__inl17_i)] = creal(hc[(__inl17_i)*(nvecx) + (__inl17_i)]);
            sc[(__inl17_i)*(nvecx) + (__inl17_i)] = creal(sc[(__inl17_i)*(nvecx) + (__inl17_i)]);
          }
          for (int64_t __inl17_i = 0; __inl17_i < nbase; ++__inl17_i) {
            for (int64_t __inl17_j = max((__inl17_i + 1), ((nb1 + 1) - 1)); __inl17_j < nbase; ++__inl17_j) {
              hc[(__inl17_i)*(nvecx) + (__inl17_j)] = __npb_conj(hc[(__inl17_j)*(nvecx) + (__inl17_i)]);
              sc[(__inl17_i)*(nvecx) + (__inl17_j)] = __npb_conj(sc[(__inl17_j)*(nvecx) + (__inl17_i)]);
            }
          }
          free(__cb53);
          __cb53 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb53, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb53");
          for (int64_t si0 = 0; si0 < nbase; ++si0) {
            for (int64_t si1 = 0; si1 < nbase; ++si1) {
              __cb53[(si0)*(nbase) + (si1)] = hc[(si0)*(nvecx) + (si1)];
            }
          }
          free(__cb54);
          __cb54 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb54, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb54");
          /* numpy: np.copy(__cb53) */
          for (int64_t __r0 = 0; __r0 < nbase; ++__r0) {
            for (int64_t __r1 = 0; __r1 < nbase; ++__r1) {
              __cb54[(__r0)*(nbase) + (__r1)] = __cb53[(__r0)*(nbase) + (__r1)];
            }
          }
          free(__inl18_a);
          __inl18_a = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18_a, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18_a");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18_a[(__w0)*(nbase) + (__w1)] = __cb54[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__cb55);
          __cb55 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb55, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb55");
          for (int64_t si0 = 0; si0 < nbase; ++si0) {
            for (int64_t si1 = 0; si1 < nbase; ++si1) {
              __cb55[(si0)*(nbase) + (si1)] = sc[(si0)*(nvecx) + (si1)];
            }
          }
          free(__cb56);
          __cb56 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb56, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb56");
          /* numpy: np.copy(__cb55) */
          for (int64_t __r0 = 0; __r0 < nbase; ++__r0) {
            for (int64_t __r1 = 0; __r1 < nbase; ++__r1) {
              __cb56[(__r0)*(nbase) + (__r1)] = __cb55[(__r0)*(nbase) + (__r1)];
            }
          }
          free(__inl18_b);
          __inl18_b = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18_b, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18_b");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18_b[(__w0)*(nbase) + (__w1)] = __cb56[(__w0)*(nbase) + (__w1)];
            }
          }
          for (int64_t __inl18_i = 0; __inl18_i < nbase; ++__inl18_i) {
            __inl18_a[(__inl18_i)*(nbase) + (__inl18_i)] = creal(__inl18_a[(__inl18_i)*(nbase) + (__inl18_i)]);
            __inl18_b[(__inl18_i)*(nbase) + (__inl18_i)] = creal(__inl18_b[(__inl18_i)*(nbase) + (__inl18_i)]);
            for (int64_t __inl18_j = (__inl18_i + 1); __inl18_j < nbase; ++__inl18_j) {
              __inl18_val_a = (0.5 * (__inl18_a[(__inl18_i)*(nbase) + (__inl18_j)] + __npb_conj(__inl18_a[(__inl18_j)*(nbase) + (__inl18_i)])));
              __inl18_val_b = (0.5 * (__inl18_b[(__inl18_i)*(nbase) + (__inl18_j)] + __npb_conj(__inl18_b[(__inl18_j)*(nbase) + (__inl18_i)])));
              __inl18_a[(__inl18_i)*(nbase) + (__inl18_j)] = __inl18_val_a;
              __inl18_a[(__inl18_j)*(nbase) + (__inl18_i)] = __npb_conj(__inl18_val_a);
              __inl18_b[(__inl18_i)*(nbase) + (__inl18_j)] = __inl18_val_b;
              __inl18_b[(__inl18_j)*(nbase) + (__inl18_i)] = __npb_conj(__inl18_val_b);
            }
          }
          free(__inl18_w);
          __inl18_w = (double *)malloc((size_t)((nbase)) * sizeof(double));
          __npb_alloc_check(__inl18_w, (size_t)((nbase)) * sizeof(double), "__inl18_w");
          memset(__inl18_w, 0, (size_t)((nbase)) * sizeof(double));
          free(__inl18_v);
          __inl18_v = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18_v, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18_v");
          memset(__inl18_v, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          free(__cb57);
          __cb57 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb57, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb57");
          /* numpy: np.linalg.cholesky(__inl18_b) */
          for (int64_t __zi = 0; __zi < nbase; ++__zi) {
            for (int64_t __zj = (__zi + 1); __zj < nbase; ++__zj) {
              __cb57[(__zi)*(nbase) + (__zj)] = 0.0;
            }
          }
          for (int64_t __j = 0; __j < nbase; ++__j) {
            __s = __inl18_b[(__j)*(nbase) + (__j)];
            for (int64_t __k = 0; __k < __j; ++__k) {
              __s -= (__cb57[(__j)*(nbase) + (__k)] * __npb_conj(__cb57[(__j)*(nbase) + (__k)]));
            }
            __cb57[(__j)*(nbase) + (__j)] = csqrt(__s);
            for (int64_t __i = (__j + 1); __i < nbase; ++__i) {
              __s = __inl18_b[(__i)*(nbase) + (__j)];
              for (int64_t __k = 0; __k < __j; ++__k) {
                __s -= (__cb57[(__i)*(nbase) + (__k)] * __npb_conj(__cb57[(__j)*(nbase) + (__k)]));
              }
              __cb57[(__i)*(nbase) + (__j)] = (__s / __cb57[(__j)*(nbase) + (__j)]);
            }
          }
          free(__inl18_chol);
          __inl18_chol = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18_chol, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18_chol");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18_chol[(__w0)*(nbase) + (__w1)] = __cb57[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__cb58);
          __cb58 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb58, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb58");
          free(__inv_aw2);
          __inv_aw2 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inv_aw2, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inv_aw2");
          /* numpy: np.linalg.inv(__inl18_chol) */
          for (int64_t __inv_i = 0; __inv_i < nbase; ++__inv_i) {
            for (int64_t __inv_j = 0; __inv_j < nbase; ++__inv_j) {
              __inv_aw2[(__inv_i)*(nbase) + (__inv_j)] = __inl18_chol[(__inv_i)*(nbase) + (__inv_j)];
              __cb58[(__inv_i)*(nbase) + (__inv_j)] = ((__inv_i == __inv_j) ? 1.0 : 0.0);
            }
          }
          for (int64_t __inv_k = 0; __inv_k < nbase; ++__inv_k) {
            __inv_p = __inv_k;
            for (int64_t __inv_r = (__inv_k + 1); __inv_r < nbase; ++__inv_r) {
              if ((cabs(__inv_aw2[(__inv_r)*(nbase) + (__inv_k)]) > cabs(__inv_aw2[(__inv_p)*(nbase) + (__inv_k)]))) {
                __inv_p = __inv_r;
              }
            }
            for (int64_t __inv_c = 0; __inv_c < nbase; ++__inv_c) {
              __inv_tmp = __inv_aw2[(__inv_k)*(nbase) + (__inv_c)];
              __inv_aw2[(__inv_k)*(nbase) + (__inv_c)] = __inv_aw2[(__inv_p)*(nbase) + (__inv_c)];
              __inv_aw2[(__inv_p)*(nbase) + (__inv_c)] = __inv_tmp;
              __inv_tmp = __cb58[(__inv_k)*(nbase) + (__inv_c)];
              __cb58[(__inv_k)*(nbase) + (__inv_c)] = __cb58[(__inv_p)*(nbase) + (__inv_c)];
              __cb58[(__inv_p)*(nbase) + (__inv_c)] = __inv_tmp;
            }
            __inv_factor = __inv_aw2[(__inv_k)*(nbase) + (__inv_k)];
            for (int64_t __inv_c = 0; __inv_c < nbase; ++__inv_c) {
              __cb58[(__inv_k)*(nbase) + (__inv_c)] = (__cb58[(__inv_k)*(nbase) + (__inv_c)] / __inv_factor);
              __inv_aw2[(__inv_k)*(nbase) + (__inv_c)] = (__inv_aw2[(__inv_k)*(nbase) + (__inv_c)] / __inv_factor);
            }
            for (int64_t __inv_r = 0; __inv_r < nbase; ++__inv_r) {
              if ((__inv_r != __inv_k)) {
                __inv_factor = __inv_aw2[(__inv_r)*(nbase) + (__inv_k)];
                for (int64_t __inv_c = 0; __inv_c < nbase; ++__inv_c) {
                  __cb58[(__inv_r)*(nbase) + (__inv_c)] = (__cb58[(__inv_r)*(nbase) + (__inv_c)] - (__inv_factor * __cb58[(__inv_k)*(nbase) + (__inv_c)]));
                  __inv_aw2[(__inv_r)*(nbase) + (__inv_c)] = (__inv_aw2[(__inv_r)*(nbase) + (__inv_c)] - (__inv_factor * __inv_aw2[(__inv_k)*(nbase) + (__inv_c)]));
                }
              }
            }
          }
          free(__inl18_chol_inv);
          __inl18_chol_inv = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18_chol_inv, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18_chol_inv");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18_chol_inv[(__w0)*(nbase) + (__w1)] = __cb58[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__inl49_C);
          __inl49_C = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl49_C, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl49_C");
          memset(__inl49_C, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          for (int64_t __inl49_i = 0; __inl49_i < nbase; ++__inl49_i) {
            for (int64_t __inl49_j = 0; __inl49_j < nbase; ++__inl49_j) {
              __inl49_C[(__inl49_i)*(nbase) + (__inl49_j)] = __npb_conj(__inl18_chol[(__inl49_j)*(nbase) + (__inl49_i)]);
            }
          }
          free(__inl18_chol_h);
          __inl18_chol_h = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18_chol_h, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18_chol_h");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18_chol_h[(__w0)*(nbase) + (__w1)] = __inl49_C[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__inl50_C);
          __inl50_C = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl50_C, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl50_C");
          memset(__inl50_C, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          for (int64_t __inl50_i = 0; __inl50_i < nbase; ++__inl50_i) {
            for (int64_t __inl50_j = 0; __inl50_j < nbase; ++__inl50_j) {
              __inl50_C[(__inl50_i)*(nbase) + (__inl50_j)] = __npb_conj(__inl18_chol_inv[(__inl50_j)*(nbase) + (__inl50_i)]);
            }
          }
          free(__inl18_chol_inv_h);
          __inl18_chol_inv_h = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18_chol_inv_h, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18_chol_inv_h");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18_chol_inv_h[(__w0)*(nbase) + (__w1)] = __inl50_C[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__mm59);
          __mm59 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__mm59, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__mm59");
          for (int64_t __i = 0; __i < nbase; ++__i) {
            for (int64_t __j = 0; __j < nbase; ++__j) {
              __mm59[(__i)*(nbase) + (__j)] = 0.0;
              for (int64_t __l = 0; __l < nbase; ++__l) {
                __mm59[(__i)*(nbase) + (__j)] += (__inl18_chol_inv[(__i)*(nbase) + (__l)] * __inl18_a[(__l)*(nbase) + (__j)]);
              }
            }
          }
          free(__inl18___t);
          __inl18___t = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18___t, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18___t");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18___t[(__w0)*(nbase) + (__w1)] = __mm59[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__mm60);
          __mm60 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__mm60, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__mm60");
          for (int64_t __i = 0; __i < nbase; ++__i) {
            for (int64_t __j = 0; __j < nbase; ++__j) {
              __mm60[(__i)*(nbase) + (__j)] = 0.0;
              for (int64_t __l = 0; __l < nbase; ++__l) {
                __mm60[(__i)*(nbase) + (__j)] += (__inl18___t[(__i)*(nbase) + (__l)] * __inl18_chol_inv_h[(__l)*(nbase) + (__j)]);
              }
            }
          }
          free(__inl18_reduced);
          __inl18_reduced = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18_reduced, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18_reduced");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18_reduced[(__w0)*(nbase) + (__w1)] = __mm60[(__w0)*(nbase) + (__w1)];
            }
          }
          for (int64_t __inl18_i = 0; __inl18_i < nbase; ++__inl18_i) {
            for (int64_t __inl18_j = (__inl18_i + 1); __inl18_j < nbase; ++__inl18_j) {
              __inl18_val = (0.5 * (__inl18_reduced[(__inl18_i)*(nbase) + (__inl18_j)] + __npb_conj(__inl18_reduced[(__inl18_j)*(nbase) + (__inl18_i)])));
              __inl18_reduced[(__inl18_i)*(nbase) + (__inl18_j)] = __inl18_val;
              __inl18_reduced[(__inl18_j)*(nbase) + (__inl18_i)] = __npb_conj(__inl18_val);
            }
          }
          free(__inl18___eigh0_Cm);
          __inl18___eigh0_Cm = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18___eigh0_Cm, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18___eigh0_Cm");
          memset(__inl18___eigh0_Cm, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          for (int64_t __inl18___eigh0_ci = 0; __inl18___eigh0_ci < nbase; ++__inl18___eigh0_ci) {
            for (int64_t __inl18___eigh0_cj = 0; __inl18___eigh0_cj < nbase; ++__inl18___eigh0_cj) {
              __inl18___eigh0_Cm[(__inl18___eigh0_ci)*(nbase) + (__inl18___eigh0_cj)] = __inl18_reduced[(__inl18___eigh0_ci)*(nbase) + (__inl18___eigh0_cj)];
            }
          }
          free(__inl18___eigh0_jv);
          __inl18___eigh0_jv = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18___eigh0_jv, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18___eigh0_jv");
          memset(__inl18___eigh0_jv, 0, (size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          for (int64_t __inl18___eigh0_di = 0; __inl18___eigh0_di < nbase; ++__inl18___eigh0_di) {
            __inl18___eigh0_jv[(__inl18___eigh0_di)*(nbase) + (__inl18___eigh0_di)] = 1;
          }
          for (int64_t __inl18___eigh0_sw = 0; __inl18___eigh0_sw < 80; ++__inl18___eigh0_sw) {
            __inl18___eigh0_off = 0.0;
            for (int64_t __inl18___eigh0_pp = 0; __inl18___eigh0_pp < nbase; ++__inl18___eigh0_pp) {
              for (int64_t __inl18___eigh0_qq = (__inl18___eigh0_pp + 1); __inl18___eigh0_qq < nbase; ++__inl18___eigh0_qq) {
                __inl18___eigh0_off += ((creal(__inl18___eigh0_Cm[(__inl18___eigh0_pp)*(nbase) + (__inl18___eigh0_qq)]) * creal(__inl18___eigh0_Cm[(__inl18___eigh0_pp)*(nbase) + (__inl18___eigh0_qq)])) + (cimag(__inl18___eigh0_Cm[(__inl18___eigh0_pp)*(nbase) + (__inl18___eigh0_qq)]) * cimag(__inl18___eigh0_Cm[(__inl18___eigh0_pp)*(nbase) + (__inl18___eigh0_qq)])));
              }
            }
            if ((__inl18___eigh0_off <= 1e-30)) {
              break;
            }
            for (int64_t __inl18___eigh0_pp = 0; __inl18___eigh0_pp < nbase; ++__inl18___eigh0_pp) {
              for (int64_t __inl18___eigh0_qq = (__inl18___eigh0_pp + 1); __inl18___eigh0_qq < nbase; ++__inl18___eigh0_qq) {
                __inl18___eigh0_apq = __inl18___eigh0_Cm[(__inl18___eigh0_pp)*(nbase) + (__inl18___eigh0_qq)];
                __inl18___eigh0_m = hypot(creal(__inl18___eigh0_apq), cimag(__inl18___eigh0_apq));
                if ((__inl18___eigh0_m == 0.0)) {
                  continue;
                }
                __inl18___eigh0_app = creal(__inl18___eigh0_Cm[(__inl18___eigh0_pp)*(nbase) + (__inl18___eigh0_pp)]);
                __inl18___eigh0_aqq = creal(__inl18___eigh0_Cm[(__inl18___eigh0_qq)*(nbase) + (__inl18___eigh0_qq)]);
                __inl18___eigh0_s = ((((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0)))) * (1.0 / sqrt((((((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0)))) * (((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0))))) + 1.0))));
                for (int64_t __inl18___eigh0_k = 0; __inl18___eigh0_k < nbase; ++__inl18___eigh0_k) {
                  __inl18___eigh0_akp = __inl18___eigh0_Cm[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_pp)];
                  __inl18___eigh0_akq = __inl18___eigh0_Cm[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_qq)];
                  __inl18___eigh0_Cm[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_pp)] = (((1.0 / sqrt((((((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0)))) * (((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0))))) + 1.0))) * __inl18___eigh0_akp) - ((__inl18___eigh0_s * __npb_conj((__inl18___eigh0_apq / __inl18___eigh0_m))) * __inl18___eigh0_akq));
                  __inl18___eigh0_Cm[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_qq)] = (((__inl18___eigh0_s * (__inl18___eigh0_apq / __inl18___eigh0_m)) * __inl18___eigh0_akp) + ((1.0 / sqrt((((((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0)))) * (((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0))))) + 1.0))) * __inl18___eigh0_akq));
                }
                for (int64_t __inl18___eigh0_k = 0; __inl18___eigh0_k < nbase; ++__inl18___eigh0_k) {
                  __inl18___eigh0_apk = __inl18___eigh0_Cm[(__inl18___eigh0_pp)*(nbase) + (__inl18___eigh0_k)];
                  __inl18___eigh0_aqk = __inl18___eigh0_Cm[(__inl18___eigh0_qq)*(nbase) + (__inl18___eigh0_k)];
                  __inl18___eigh0_Cm[(__inl18___eigh0_pp)*(nbase) + (__inl18___eigh0_k)] = (((1.0 / sqrt((((((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0)))) * (((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0))))) + 1.0))) * __inl18___eigh0_apk) - ((__inl18___eigh0_s * (__inl18___eigh0_apq / __inl18___eigh0_m)) * __inl18___eigh0_aqk));
                  __inl18___eigh0_Cm[(__inl18___eigh0_qq)*(nbase) + (__inl18___eigh0_k)] = (((__inl18___eigh0_s * __npb_conj((__inl18___eigh0_apq / __inl18___eigh0_m))) * __inl18___eigh0_apk) + ((1.0 / sqrt((((((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0)))) * (((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0))))) + 1.0))) * __inl18___eigh0_aqk));
                }
                for (int64_t __inl18___eigh0_k = 0; __inl18___eigh0_k < nbase; ++__inl18___eigh0_k) {
                  __inl18___eigh0_vkp = __inl18___eigh0_jv[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_pp)];
                  __inl18___eigh0_vkq = __inl18___eigh0_jv[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_qq)];
                  __inl18___eigh0_jv[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_pp)] = (((1.0 / sqrt((((((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0)))) * (((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0))))) + 1.0))) * __inl18___eigh0_vkp) - ((__inl18___eigh0_s * __npb_conj((__inl18___eigh0_apq / __inl18___eigh0_m))) * __inl18___eigh0_vkq));
                  __inl18___eigh0_jv[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_qq)] = (((__inl18___eigh0_s * (__inl18___eigh0_apq / __inl18___eigh0_m)) * __inl18___eigh0_vkp) + ((1.0 / sqrt((((((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0)))) * (((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + sqrt(((((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m)) * ((__inl18___eigh0_aqq - __inl18___eigh0_app) / (2.0 * __inl18___eigh0_m))) + 1.0))))) + 1.0))) * __inl18___eigh0_vkq));
                }
              }
            }
          }
          free(__inl18___eigh0_wa);
          __inl18___eigh0_wa = (double *)malloc((size_t)((nbase)) * sizeof(double));
          __npb_alloc_check(__inl18___eigh0_wa, (size_t)((nbase)) * sizeof(double), "__inl18___eigh0_wa");
          memset(__inl18___eigh0_wa, 0, (size_t)((nbase)) * sizeof(double));
          for (int64_t __inl18___eigh0_i = 0; __inl18___eigh0_i < nbase; ++__inl18___eigh0_i) {
            __inl18___eigh0_wa[__inl18___eigh0_i] = creal(__inl18___eigh0_Cm[(__inl18___eigh0_i)*(nbase) + (__inl18___eigh0_i)]);
          }
          for (int64_t __inl18___eigh0_i = 0; __inl18___eigh0_i < nbase; ++__inl18___eigh0_i) {
            __inl18___eigh0_mn = __inl18___eigh0_i;
            for (int64_t __inl18___eigh0_j = (__inl18___eigh0_i + 1); __inl18___eigh0_j < nbase; ++__inl18___eigh0_j) {
              if ((__inl18___eigh0_wa[__inl18___eigh0_j] < __inl18___eigh0_wa[__inl18___eigh0_mn])) {
                __inl18___eigh0_mn = __inl18___eigh0_j;
              }
            }
            if ((__inl18___eigh0_mn != __inl18___eigh0_i)) {
              __inl18___eigh0_tw = __inl18___eigh0_wa[__inl18___eigh0_i];
              __inl18___eigh0_wa[__inl18___eigh0_i] = __inl18___eigh0_wa[__inl18___eigh0_mn];
              __inl18___eigh0_wa[__inl18___eigh0_mn] = __inl18___eigh0_tw;
              for (int64_t __inl18___eigh0_k = 0; __inl18___eigh0_k < nbase; ++__inl18___eigh0_k) {
                __inl18___eigh0_tv = __inl18___eigh0_jv[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_i)];
                __inl18___eigh0_jv[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_i)] = __inl18___eigh0_jv[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_mn)];
                __inl18___eigh0_jv[(__inl18___eigh0_k)*(nbase) + (__inl18___eigh0_mn)] = __inl18___eigh0_tv;
              }
            }
          }
          free(__inl18___eigh0_ya);
          __inl18___eigh0_ya = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18___eigh0_ya, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18___eigh0_ya");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18___eigh0_ya[(__w0)*(nbase) + (__w1)] = __inl18___eigh0_jv[(__w0)*(nbase) + (__w1)];
            }
          }
          free(__inl18_ws);
          __inl18_ws = (double *)malloc((size_t)((nbase)) * sizeof(double));
          __npb_alloc_check(__inl18_ws, (size_t)((nbase)) * sizeof(double), "__inl18_ws");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            __inl18_ws[__w0] = __inl18___eigh0_wa[__w0];
          }
          free(__inl18_ys);
          __inl18_ys = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18_ys, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18_ys");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18_ys[(__w0)*(nbase) + (__w1)] = __inl18___eigh0_ya[(__w0)*(nbase) + (__w1)];
            }
          }
          for (int64_t __inl18_j = 0; __inl18_j < nbase; ++__inl18_j) {
            __inl18_max_i = 0;
            __inl18_max_val = (-1.0);
            for (int64_t __inl18_i = 0; __inl18_i < nbase; ++__inl18_i) {
              __inl18_av = cabs(__inl18_ys[(__inl18_i)*(nbase) + (__inl18_j)]);
              if ((__inl18_av > __inl18_max_val)) {
                __inl18_max_val = __inl18_av;
                __inl18_max_i = __inl18_i;
              }
            }
            __inl18_phase = __inl18_ys[(__inl18_max_i)*(nbase) + (__inl18_j)];
            for (int64_t __inl18_i = 0; __inl18_i < nbase; ++__inl18_i) {
              __inl18_ys[(__inl18_i)*(nbase) + (__inl18_j)] = (__inl18_ys[(__inl18_i)*(nbase) + (__inl18_j)] * (cabs(__inl18_phase) / __inl18_phase));
            }
          }
          free(__cb61);
          __cb61 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__cb61, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__cb61");
          free(__sol_aw3);
          __sol_aw3 = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__sol_aw3, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__sol_aw3");
          /* numpy: np.linalg.solve(__inl18_chol_h, __inl18_ys) */
          for (int64_t __sol_i = 0; __sol_i < nbase; ++__sol_i) {
            for (int64_t __sol_j = 0; __sol_j < nbase; ++__sol_j) {
              __sol_aw3[(__sol_i)*(nbase) + (__sol_j)] = __inl18_chol_h[(__sol_i)*(nbase) + (__sol_j)];
            }
            for (int64_t __sol_j = 0; __sol_j < nbase; ++__sol_j) {
              __cb61[(__sol_i)*(nbase) + (__sol_j)] = __inl18_ys[(__sol_i)*(nbase) + (__sol_j)];
            }
          }
          for (int64_t __sol_k = 0; __sol_k < nbase; ++__sol_k) {
            __sol_p = __sol_k;
            for (int64_t __sol_r = (__sol_k + 1); __sol_r < nbase; ++__sol_r) {
              if ((cabs(__sol_aw3[(__sol_r)*(nbase) + (__sol_k)]) > cabs(__sol_aw3[(__sol_p)*(nbase) + (__sol_k)]))) {
                __sol_p = __sol_r;
              }
            }
            for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
              __sol_tmp = __sol_aw3[(__sol_k)*(nbase) + (__sol_c)];
              __sol_aw3[(__sol_k)*(nbase) + (__sol_c)] = __sol_aw3[(__sol_p)*(nbase) + (__sol_c)];
              __sol_aw3[(__sol_p)*(nbase) + (__sol_c)] = __sol_tmp;
            }
            for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
              __sol_tmp = __cb61[(__sol_k)*(nbase) + (__sol_c)];
              __cb61[(__sol_k)*(nbase) + (__sol_c)] = __cb61[(__sol_p)*(nbase) + (__sol_c)];
              __cb61[(__sol_p)*(nbase) + (__sol_c)] = __sol_tmp;
            }
            __sol_factor = __sol_aw3[(__sol_k)*(nbase) + (__sol_k)];
            for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
              __sol_aw3[(__sol_k)*(nbase) + (__sol_c)] = (__sol_aw3[(__sol_k)*(nbase) + (__sol_c)] / __sol_factor);
            }
            for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
              __cb61[(__sol_k)*(nbase) + (__sol_c)] = (__cb61[(__sol_k)*(nbase) + (__sol_c)] / __sol_factor);
            }
            for (int64_t __sol_r = 0; __sol_r < nbase; ++__sol_r) {
              if ((__sol_r != __sol_k)) {
                __sol_factor = __sol_aw3[(__sol_r)*(nbase) + (__sol_k)];
                for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
                  __sol_aw3[(__sol_r)*(nbase) + (__sol_c)] = (__sol_aw3[(__sol_r)*(nbase) + (__sol_c)] - (__sol_factor * __sol_aw3[(__sol_k)*(nbase) + (__sol_c)]));
                }
                for (int64_t __sol_c = 0; __sol_c < nbase; ++__sol_c) {
                  __cb61[(__sol_r)*(nbase) + (__sol_c)] = (__cb61[(__sol_r)*(nbase) + (__sol_c)] - (__sol_factor * __cb61[(__sol_k)*(nbase) + (__sol_c)]));
                }
              }
            }
          }
          free(__inl18_vs);
          __inl18_vs = (double _Complex *)malloc((size_t)((nbase) * (nbase)) * sizeof(double _Complex));
          __npb_alloc_check(__inl18_vs, (size_t)((nbase) * (nbase)) * sizeof(double _Complex), "__inl18_vs");
          for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
              __inl18_vs[(__w0)*(nbase) + (__w1)] = __cb61[(__w0)*(nbase) + (__w1)];
            }
          }
          if ((nvec < nbase)) {
            for (int64_t si0 = 0; si0 < nvec; ++si0) {
              __inl18_w[si0] = __inl18_ws[si0];
            }
            for (int64_t si0 = 0; si0 < nbase; ++si0) {
              for (int64_t si1 = 0; si1 < nvec; ++si1) {
                __inl18_v[(si0)*(nbase) + (si1)] = __inl18_vs[(si0)*(nbase) + (si1)];
              }
            }
          }
          else {
            for (int64_t si0 = 0; si0 < nbase; ++si0) {
              __inl18_w[si0] = __inl18_ws[si0];
            }
            for (int64_t si0 = 0; si0 < nbase; ++si0) {
              for (int64_t si1 = 0; si1 < nbase; ++si1) {
                __inl18_v[(si0)*(nbase) + (si1)] = __inl18_vs[(si0)*(nbase) + (si1)];
              }
            }
          }
          for (int64_t si0 = 0; si0 < nvec; ++si0) {
            ew[si0] = __inl18_w[si0];
          }
          for (int64_t __inl18_j = 0; __inl18_j < nvec; ++__inl18_j) {
            for (int64_t __inl18_i = 0; __inl18_i < nbase; ++__inl18_i) {
              vc[(__inl18_j)*(nvecx) + (__inl18_i)] = __inl18_v[(__inl18_i)*(nbase) + (__inl18_j)];
            }
          }
          /* numpy: np.where(btype[:nvec] == 1, ethr, empty_ethr) */
          for (int64_t __r0 = 0; __r0 < nvec; ++__r0) {
            __cb62[__r0] = ((((int64_t)(btype[__r0])) == 1) ? ethr : empty_ethr);
          }
          for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
            thr[__w0] = __cb62[__w0];
          }
          for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
            conv[__w0] = (fabs((ew[__w0] - e[__w0])) < thr[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
            __cb63[__w0] = (!conv[__w0]);
          }
          /* numpy: np.count_nonzero(__cb63) */
          __cb64 = 0;
          for (int64_t __r0 = 0; __r0 < nvec; ++__r0) {
            if ((__cb63[__r0] != 0)) {
              __cb64 = (__cb64 + 1);
            }
          }
          notcnv = ((int64_t)(__cb64));
          for (int64_t si0 = 0; si0 < nvec; ++si0) {
            e[si0] = ew[si0];
          }
          if (((notcnv == 0) || ((nbase + notcnv) > nvecx) || (dav_iter == 20))) {
            free(psi_k);
            psi_k = (double _Complex *)malloc((size_t)((nbase) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(psi_k, (size_t)((nbase) * (kdim)) * sizeof(double _Complex), "psi_k");
            for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
              for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
                psi_k[(__w0)*(kdim) + (__w1)] = psi[(__w0)*((npwx * npol)) + (__w1)];
              }
            }
            free(vc_v);
            vc_v = (double _Complex *)malloc((size_t)((nvec) * (nbase)) * sizeof(double _Complex));
            __npb_alloc_check(vc_v, (size_t)((nvec) * (nbase)) * sizeof(double _Complex), "vc_v");
            for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nbase; ++__w1) {
                vc_v[(__w0)*(nbase) + (__w1)] = vc[(__w0)*(nvecx) + (__w1)];
              }
            }
            free(__mm65);
            __mm65 = (double _Complex *)malloc((size_t)((nvec) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(__mm65, (size_t)((nvec) * (kdim)) * sizeof(double _Complex), "__mm65");
            for (int64_t __i = 0; __i < nvec; ++__i) {
              for (int64_t __j = 0; __j < kdim; ++__j) {
                __mm65[(__i)*(kdim) + (__j)] = 0.0;
                for (int64_t __l = 0; __l < nbase; ++__l) {
                  __mm65[(__i)*(kdim) + (__j)] += (vc_v[(__i)*(nbase) + (__l)] * psi_k[(__l)*(kdim) + (__j)]);
                }
              }
            }
            free(__evc);
            __evc = (double _Complex *)malloc((size_t)((nvec) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(__evc, (size_t)((nvec) * (kdim)) * sizeof(double _Complex), "__evc");
            for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
              for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
                __evc[(__w0)*(kdim) + (__w1)] = __mm65[(__w0)*(kdim) + (__w1)];
              }
            }
            for (int64_t si0 = 0; si0 < nvec; ++si0) {
              for (int64_t si1 = 0; si1 < kdim; ++si1) {
                evc[(si0)*((npwx * npol)) + (si1)] = __evc[(si0)*(kdim) + (si1)];
              }
            }
            if (((notcnv == 0) || (dav_iter == 20))) {
              break;
            }
            for (int64_t si0 = 0; si0 < nvec; ++si0) {
              for (int64_t si1 = 0; si1 < (npwx * npol); ++si1) {
                psi[(si0)*((npwx * npol)) + (si1)] = evc[(si0)*((npwx * npol)) + (si1)];
              }
            }
            if (uspp) {
              free(spsi_k);
              spsi_k = (double _Complex *)malloc((size_t)((nbase) * (kdim)) * sizeof(double _Complex));
              __npb_alloc_check(spsi_k, (size_t)((nbase) * (kdim)) * sizeof(double _Complex), "spsi_k");
              for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
                for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
                  spsi_k[(__w0)*(kdim) + (__w1)] = spsi[(__w0)*((npwx * npol)) + (__w1)];
                }
              }
              free(__mm66);
              __mm66 = (double _Complex *)malloc((size_t)((nvec) * (kdim)) * sizeof(double _Complex));
              __npb_alloc_check(__mm66, (size_t)((nvec) * (kdim)) * sizeof(double _Complex), "__mm66");
              for (int64_t __i = 0; __i < nvec; ++__i) {
                for (int64_t __j = 0; __j < kdim; ++__j) {
                  __mm66[(__i)*(kdim) + (__j)] = 0.0;
                  for (int64_t __l = 0; __l < nbase; ++__l) {
                    __mm66[(__i)*(kdim) + (__j)] += (vc_v[(__i)*(nbase) + (__l)] * spsi_k[(__l)*(kdim) + (__j)]);
                  }
                }
              }
              free(__spsi_block);
              __spsi_block = (double _Complex *)malloc((size_t)((nvec) * (kdim)) * sizeof(double _Complex));
              __npb_alloc_check(__spsi_block, (size_t)((nvec) * (kdim)) * sizeof(double _Complex), "__spsi_block");
              for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
                for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
                  __spsi_block[(__w0)*(kdim) + (__w1)] = __mm66[(__w0)*(kdim) + (__w1)];
                }
              }
              for (int64_t si0 = nvec; si0 < (2 * nvec); ++si0) {
                for (int64_t si1 = 0; si1 < kdim; ++si1) {
                  psi[(si0)*((npwx * npol)) + (si1)] = __spsi_block[((si0 - nvec))*(kdim) + (si1)];
                }
              }
              for (int64_t si0 = 0; si0 < nvec; ++si0) {
                for (int64_t si1 = 0; si1 < kdim; ++si1) {
                  spsi[(si0)*((npwx * npol)) + (si1)] = psi[((si0 + (nvec - 0)))*((npwx * npol)) + (si1)];
                }
              }
            }
            free(hpsi_k);
            hpsi_k = (double _Complex *)malloc((size_t)((nbase) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(hpsi_k, (size_t)((nbase) * (kdim)) * sizeof(double _Complex), "hpsi_k");
            for (int64_t __w0 = 0; __w0 < nbase; ++__w0) {
              for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
                hpsi_k[(__w0)*(kdim) + (__w1)] = hpsi[(__w0)*((npwx * npol)) + (__w1)];
              }
            }
            free(__mm67);
            __mm67 = (double _Complex *)malloc((size_t)((nvec) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(__mm67, (size_t)((nvec) * (kdim)) * sizeof(double _Complex), "__mm67");
            for (int64_t __i = 0; __i < nvec; ++__i) {
              for (int64_t __j = 0; __j < kdim; ++__j) {
                __mm67[(__i)*(kdim) + (__j)] = 0.0;
                for (int64_t __l = 0; __l < nbase; ++__l) {
                  __mm67[(__i)*(kdim) + (__j)] += (vc_v[(__i)*(nbase) + (__l)] * hpsi_k[(__l)*(kdim) + (__j)]);
                }
              }
            }
            free(__hpsi_block);
            __hpsi_block = (double _Complex *)malloc((size_t)((nvec) * (kdim)) * sizeof(double _Complex));
            __npb_alloc_check(__hpsi_block, (size_t)((nvec) * (kdim)) * sizeof(double _Complex), "__hpsi_block");
            for (int64_t __w0 = 0; __w0 < nvec; ++__w0) {
              for (int64_t __w1 = 0; __w1 < kdim; ++__w1) {
                __hpsi_block[(__w0)*(kdim) + (__w1)] = __mm67[(__w0)*(kdim) + (__w1)];
              }
            }
            for (int64_t si0 = nvec; si0 < (2 * nvec); ++si0) {
              for (int64_t si1 = 0; si1 < kdim; ++si1) {
                psi[(si0)*((npwx * npol)) + (si1)] = __hpsi_block[((si0 - nvec))*(kdim) + (si1)];
              }
            }
            for (int64_t si0 = 0; si0 < nvec; ++si0) {
              for (int64_t si1 = 0; si1 < kdim; ++si1) {
                hpsi[(si0)*((npwx * npol)) + (si1)] = psi[((si0 + (nvec - 0)))*((npwx * npol)) + (si1)];
              }
            }
            nbase = (((int64_t)(nvec)) + 0);
            for (int64_t si0 = 0; si0 < nbase; ++si0) {
              for (int64_t si1 = 0; si1 < nbase; ++si1) {
                hc[(si0)*(nvecx) + (si1)] = 0.0;
              }
            }
            for (int64_t si0 = 0; si0 < nbase; ++si0) {
              for (int64_t si1 = 0; si1 < nbase; ++si1) {
                sc[(si0)*(nvecx) + (si1)] = 0.0;
              }
            }
            for (int64_t si0 = 0; si0 < nbase; ++si0) {
              for (int64_t si1 = 0; si1 < nbase; ++si1) {
                vc[(si0)*(nvecx) + (si1)] = 0.0;
              }
            }
            for (int64_t i = 0; i < nbase; ++i) {
              hc[(i)*(nvecx) + (i)] = e[i];
              sc[(i)*(nvecx) + (i)] = 1.0;
              vc[(i)*(nvecx) + (i)] = 1.0;
            }
          }
        }
        free(psi);
        free(hpsi);
        free(spsi);
        free(hc);
        free(sc);
        free(vc);
        free(ew);
        free(conv);
        free(__inl3_H);
        free(__inl28_C);
        free(__inl32_C);
        free(unconv);
        free(__cb1);
        free(__cb2);
        free(__cb9);
        free(__cb10);
        free(__cb11);
        free(__cb12);
        free(__cb13);
        free(__cb15);
        free(__cb16);
        free(__mm18);
        free(__mm21);
        free(__cb39);
        free(__cb40);
        free(__cb41);
        free(__cb50);
        free(__cb62);
        free(__cb63);
        free(__inl3_vrs2);
        free(__inl3_ps);
        free(__hpsi0);
        free(__inl4_ps);
        free(__inl12_vrs2);
        free(thr);
        free(psi0);
        free(hd);
        free(sd);
        free(__inl26_psic);
        free(__inl5_C);
        free(__inl6_C);
        free(__inl7_C);
        free(__inl9_w);
        free(__inl9_v);
        free(__inl33_C);
        free(__inl34_C);
        free(__inl9___eigh0_Cm);
        free(__inl9___eigh0_jv);
        free(__inl9___eigh0_wa);
        free(ritz_s);
        free(__inl12_H);
        free(__inl42_psic);
        free(__inl44_C);
        free(__inl13_S);
        free(__inl48_C);
        free(__inl14_C);
        free(__inl15_C);
        free(__inl16_C);
        free(__inl18_w);
        free(__inl18_v);
        free(__inl49_C);
        free(__inl50_C);
        free(__inl18___eigh0_Cm);
        free(__inl18___eigh0_jv);
        free(__inl18___eigh0_wa);
        free(__cb14);
        free(__cb17);
        free(__mm19);
        free(__mm22);
        free(__cb23);
        free(__cb24);
        free(__cb25);
        free(__cb26);
        free(__cb27);
        free(__cb28);
        free(__mm29);
        free(__mm30);
        free(__cb31);
        free(__mm32);
        free(__mm33);
        free(__mm34);
        free(__cb35);
        free(__cb36);
        free(__cb37);
        free(__cb38);
        free(__cb42);
        free(__cb43);
        free(__cb44);
        free(__cb45);
        free(__cb46);
        free(__cb47);
        free(__mm48);
        free(__mm49);
        free(__mm51);
        free(__mm52);
        free(__cb53);
        free(__cb54);
        free(__cb55);
        free(__cb56);
        free(__cb57);
        free(__cb58);
        free(__mm59);
        free(__mm60);
        free(__cb61);
        free(__mm65);
        free(__mm66);
        free(__mm67);
        free(__inv_aw0);
        free(__sol_aw1);
        free(__inv_aw2);
        free(__sol_aw3);
        free(__inl3_r);
        free(__inl27_g);
        free(__inl3___h_tmp2);
        free(__inl4___s_tmp);
        free(__inl9_a);
        free(__inl9_b);
        free(__inl9_chol);
        free(__inl9_chol_inv);
        free(__inl9_chol_h);
        free(__inl9_chol_inv_h);
        free(__inl9___t);
        free(__inl9_reduced);
        free(__inl9___eigh0_ya);
        free(__inl9_ws);
        free(__inl9_ys);
        free(__inl9_vs);
        free(resid);
        free(__inl12_r);
        free(__inl43_g);
        free(__inl12_ps);
        free(__inl12___h_tmp2);
        free(__hpsi1);
        free(__inl13_ps);
        free(__inl13___s_tmp);
        free(__spsi1);
        free(__inl18_a);
        free(__inl18_b);
        free(__inl18_chol);
        free(__inl18_chol_inv);
        free(__inl18_chol_h);
        free(__inl18_chol_inv_h);
        free(__inl18___t);
        free(__inl18_reduced);
        free(__inl18___eigh0_ya);
        free(__inl18_ws);
        free(__inl18_ys);
        free(__inl18_vs);
        free(__evc);
        free(__spsi_block);
        free(__hpsi_block);
        free(__inl3_g2);
        free(__inl3_gmap);
        free(psi_k);
        free(hpsi_k);
        free(__inl3_X_b);
        free(__inl3___h_tmp);
        free(spsi_k);
        free(vc_u);
        free(cv);
        free(psi1);
        free(__inl12_g2);
        free(__inl12_gmap);
        free(hpsi_b);
        free(psi_b);
        free(__inl12_X_b);
        free(__inl12___h_tmp);
        free(spsi_b);
        free(psi_b2);
        free(vc_v);
        free(__inl4_X_b);
        free(__inl13_X_b);
}
