// Optimized bicgstab implementation with OpenMP parallelization.
// The function signature follows the specification in signature.json.

#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <omp.h>

void bicgstab_csr_fp64(const double *restrict A_data,
                        const int64_t *restrict A_indices,
                        const int64_t *restrict A_indptr,
                        const double *restrict b,
                        double *restrict x,
                        const int64_t N,
                        const int64_t nnz,
                        uint8_t *restrict workspace,
                        const int64_t workspace_size) {
    // Compute norm(b) to set stopping tolerance.
    double normb = 0.0;
    #pragma omp parallel for reduction(+:normb) schedule(static)
    for (int64_t i = 0; i < N; ++i) {
        normb += b[i] * b[i];
    }
    normb = sqrt(normb);
    const double stop = 1e-12 + 1e-6 * normb;

    // Allocate working vectors.
    double *p       = (double *)calloc((size_t)N, sizeof(double)); // zero
    double *r_tilde = (double *)malloc((size_t)N * sizeof(double));
    double *r       = (double *)malloc((size_t)N * sizeof(double));
    double *v       = (double *)malloc((size_t)N * sizeof(double));
    double *s       = (double *)malloc((size_t)N * sizeof(double));
    double *t       = (double *)malloc((size_t)N * sizeof(double));
    double *tmp     = (double *)malloc((size_t)N * sizeof(double)); // for SpMV

    if (!p || !r_tilde || !r || !v || !s || !t || !tmp) {
        abort();
    }

    // Compute initial residual r = b - A*x.
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < N; ++i) {
        double sum = 0.0;
        for (int64_t k = A_indptr[i]; k < A_indptr[i+1]; ++k) {
            sum += A_data[k] * x[A_indices[k]];
        }
        tmp[i] = sum;
    }
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < N; ++i) {
        r[i] = b[i] - tmp[i];
    }

    // r_tilde = r, p already zero.
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < N; ++i) {
        r_tilde[i] = r[i];
    }

    double rho_prev = 1.0;
    double alpha = 1.0;
    double omega = 1.0;
    const int64_t max_iter = 250;

    for (int64_t iter = 0; iter < max_iter; ++iter) {
        // rho = (r_tilde, r)
        double rho = 0.0;
        #pragma omp parallel for reduction(+:rho) schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            rho += r_tilde[i] * r[i];
        }

        double beta = (rho / rho_prev) * (alpha / omega);

        // p = r + beta * (p - omega * v)
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            p[i] = r[i] + beta * (p[i] - omega * v[i]);
        }

        // v = A * p
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            double sum = 0.0;
            for (int64_t k = A_indptr[i]; k < A_indptr[i+1]; ++k) {
                sum += A_data[k] * p[A_indices[k]];
            }
            tmp[i] = sum;
        }
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            v[i] = tmp[i];
        }

        // alpha = rho / (r_tilde, v)
        double rtv = 0.0;
        #pragma omp parallel for reduction(+:rtv) schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            rtv += r_tilde[i] * v[i];
        }
        alpha = rho / rtv;

        // s = r - alpha * v
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            s[i] = r[i] - alpha * v[i];
        }

        // t = A * s
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            double sum = 0.0;
            for (int64_t k = A_indptr[i]; k < A_indptr[i+1]; ++k) {
                sum += A_data[k] * s[A_indices[k]];
            }
            tmp[i] = sum;
        }
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            t[i] = tmp[i];
        }

        // omega = (t, s) / (t, t)
        double t_s = 0.0;
        double t_t = 0.0;
        #pragma omp parallel for reduction(+:t_s,t_t) schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            t_s += t[i] * s[i];
            t_t += t[i] * t[i];
        }
        omega = t_s / t_t;

        // x = x + alpha * p + omega * s
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            x[i] += alpha * p[i] + omega * s[i];
        }

        // r = s - omega * t
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            r[i] = s[i] - omega * t[i];
        }

        // Check convergence: norm(r) < stop
        double norm_r = 0.0;
        #pragma omp parallel for reduction(+:norm_r) schedule(static)
        for (int64_t i = 0; i < N; ++i) {
            norm_r += r[i] * r[i];
        }
        norm_r = sqrt(norm_r);
        if (norm_r < stop) {
            break;
        }

        rho_prev = rho;
    }

    free(p);
    free(r_tilde);
    free(r);
    free(v);
    free(s);
    free(t);
    free(tmp);
}
