// Optimized channel_flow C implementation
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <omp.h>

#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif

static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}

static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}

#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }

// Helper macros for generic math
#define __NPB_F16_ASSOC(fn) 
#define __NPB_UNSIGNED_ASSOC(fn) unsigned int: fn, unsigned long: fn, unsigned long long: fn,
#define __npb_fmin(a, b) _Generic((a) + (b), \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#define int_floor(a, b) _Generic((a) + (b), \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#define int_ceil(a, b) _Generic((a) + (b), \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#define python_mod(a, b) _Generic((a) + (b), \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))

static void build_up_b(double *restrict b, const double *restrict u, const double *restrict v, double dt, double dx, double dy, int64_t nx, int64_t ny, double rho) {
    // Compute interior points
    #pragma omp parallel for collapse(2)
    for (int64_t i = 1; i < ny-1; ++i) {
        for (int64_t j = 1; j < nx-1; ++j) {
            double du_dx = (u[i*nx + (j+1)] - u[i*nx + (j-1)]) / (2.0*dx);
            double dv_dy = (v[(i+1)*nx + j] - v[(i-1)*nx + j]) / (2.0*dy);
            double du_dy = (u[(i+1)*nx + j] - u[(i-1)*nx + j]) / (2.0*dy);
            double dv_dx = (v[i*nx + (j+1)] - v[i*nx + (j-1)]) / (2.0*dx);
            b[i*nx + j] = rho * ((1.0/dt)*(du_dx + dv_dy) - du_dx*du_dx - 2.0*du_dy*dv_dx - dv_dx*dv_dx);
        }
    }
    // Periodic BC at right boundary (j=nx-1)
    #pragma omp parallel for
    for (int64_t i = 1; i < ny-1; ++i) {
        double du_dx = (u[i*nx + 0] - u[i*nx + (nx-2)]) / (2.0*dx);
        double dv_dy = (v[(i+1)*nx + (nx-1)] - v[(i-1)*nx + (nx-1)]) / (2.0*dy);
        double du_dy = (u[(i+1)*nx + (nx-1)] - u[(i-1)*nx + (nx-1)]) / (2.0*dy);
        double dv_dx = (v[i*nx + 0] - v[i*nx + (nx-2)]) / (2.0*dx);
        b[i*nx + (nx-1)] = rho * ((1.0/dt)*(du_dx + dv_dy) - du_dx*du_dx - 2.0*du_dy*dv_dx - dv_dx*dv_dx);
    }
    // Periodic BC at left boundary (j=0)
    #pragma omp parallel for
    for (int64_t i = 1; i < ny-1; ++i) {
        double du_dx = (u[i*nx + 1] - u[i*nx + (nx-1)]) / (2.0*dx);
        double dv_dy = (v[(i+1)*nx + 0] - v[(i-1)*nx + 0]) / (2.0*dy);
        double du_dy = (u[(i+1)*nx + 0] - u[(i-1)*nx + 0]) / (2.0*dy);
        double dv_dx = (v[i*nx + 1] - v[i*nx + (nx-1)]) / (2.0*dx);
        b[i*nx + 0] = rho * ((1.0/dt)*(du_dx + dv_dy) - du_dx*du_dx - 2.0*du_dy*dv_dx - dv_dx*dv_dx);
    }
}

static void pressure_poisson_periodic(const double *restrict b, double *restrict p, double dx, double dy, int64_t nit, int64_t nx, int64_t ny, double *restrict pn) {
    double denom = 2.0 * (dx*dx + dy*dy);
    double dxy2 = (dx*dx * dy*dy) / denom;
    for (int64_t it = 0; it < nit; ++it) {
        // copy p into pn
        #pragma omp parallel for collapse(2)
        for (int64_t i = 0; i < ny; ++i) {
            for (int64_t j = 0; j < nx; ++j) {
                pn[i*nx + j] = p[i*nx + j];
            }
        }
        // interior update
        #pragma omp parallel for collapse(2)
        for (int64_t i = 1; i < ny-1; ++i) {
            for (int64_t j = 1; j < nx-1; ++j) {
                p[i*nx + j] = ((pn[i*nx + (j+1)] + pn[i*nx + (j-1)]) * (dy*dy) + (pn[(i+1)*nx + j] + pn[(i-1)*nx + j]) * (dx*dx)) / denom - dxy2 * b[i*nx + j];
            }
        }
        // right boundary j=nx-1
        #pragma omp parallel for
        for (int64_t i = 1; i < ny-1; ++i) {
            p[i*nx + (nx-1)] = ((pn[i*nx + 0] + pn[i*nx + (nx-2)]) * (dy*dy) + (pn[(i+1)*nx + (nx-1)] + pn[(i-1)*nx + (nx-1)]) * (dx*dx)) / denom - dxy2 * b[i*nx + (nx-1)];
        }
        // left boundary j=0
        #pragma omp parallel for
        for (int64_t i = 1; i < ny-1; ++i) {
            p[i*nx + 0] = ((pn[i*nx + 1] + pn[i*nx + (nx-1)]) * (dy*dy) + (pn[(i+1)*nx + 0] + pn[(i-1)*nx + 0]) * (dx*dx)) / denom - dxy2 * b[i*nx + 0];
        }
        // top and bottom walls
        #pragma omp parallel for
        for (int64_t j = 0; j < nx; ++j) {
            p[(ny-1)*nx + j] = p[(ny-2)*nx + j]; // dp/dy = 0 at y = max
            p[0*nx + j] = p[1*nx + j];           // dp/dy = 0 at y = 0
        }
    }
}

void channel_flow_fp64(double *restrict p, double *restrict u, double *restrict v, const double F, const double dt, const double dx, const double dy, const int64_t nit, const double nu, const int64_t nx, const int64_t ny, const double rho, uint8_t *restrict workspace, const int64_t workspace_size) {
    size_t N = (size_t)nx * (size_t)ny;
    double *un, *vn, *b, *pn;
    // Determine if workspace is large enough (needs 4*N doubles)
    size_t needed_bytes = 4 * N * sizeof(double);
    if ((size_t)workspace_size >= needed_bytes) {
        double *buf = (double *)workspace;
        un = buf;
        vn = buf + N;
        b = buf + 2*N;
        pn = buf + 3*N;
    } else {
        // fallback to malloc
        un = (double*)malloc(N * sizeof(double)); __npb_alloc_check(un, N*sizeof(double), "un");
        vn = (double*)malloc(N * sizeof(double)); __npb_alloc_check(vn, N*sizeof(double), "vn");
        b = (double*)malloc(N * sizeof(double)); __npb_alloc_check(b, N*sizeof(double), "b");
        pn = (double*)malloc(N * sizeof(double)); __npb_alloc_check(pn, N*sizeof(double), "pn");
    }

    double udiff = 1.0;
    while (udiff > 0.001) {
        // copy u and v to un, vn
        #pragma omp parallel for collapse(2)
        for (int64_t i = 0; i < ny; ++i) {
            for (int64_t j = 0; j < nx; ++j) {
                size_t idx = i*nx + j;
                un[idx] = u[idx];
                vn[idx] = v[idx];
            }
        }
        // compute source term b (initialize to zero first)
        memset(b, 0, N * sizeof(double));
        build_up_b(b, u, v, dt, dx, dy, nx, ny, rho);
        // pressure Poisson
        pressure_poisson_periodic(b, p, dx, dy, nit, nx, ny, pn);
        // update u interior
        #pragma omp parallel for collapse(2)
        for (int64_t i = 1; i < ny-1; ++i) {
            for (int64_t j = 1; j < nx-1; ++j) {
                size_t idx = i*nx + j;
                double term1 = un[idx] - (un[idx] * dt / dx) * (un[idx] - un[i*nx + (j-1)]);
                double term2 = - (vn[idx] * dt / dy) * (un[idx] - un[(i-1)*nx + j]);
                double term3 = - (dt / (2.0 * rho * dx)) * (p[i*nx + (j+1)] - p[i*nx + (j-1)]);
                double term4 = nu * ((dt / (dx*dx)) * (un[i*nx + (j+1)] - 2.0*un[idx] + un[i*nx + (j-1)]) + (dt / (dy*dy)) * (un[(i+1)*nx + j] - 2.0*un[idx] + un[(i-1)*nx + j]));
                u[idx] = term1 + term2 + term3 + term4 + F * dt;
            }
        }
        // update v interior
        #pragma omp parallel for collapse(2)
        for (int64_t i = 1; i < ny-1; ++i) {
            for (int64_t j = 1; j < nx-1; ++j) {
                size_t idx = i*nx + j;
                double term1 = vn[idx] - (un[idx] * dt / dx) * (vn[idx] - vn[i*nx + (j-1)]);
                double term2 = - (vn[idx] * dt / dy) * (vn[idx] - vn[(i-1)*nx + j]);
                double term3 = - (dt / (2.0 * rho * dy)) * (p[(i+1)*nx + j] - p[(i-1)*nx + j]);
                double term4 = nu * ((dt / (dx*dx)) * (vn[i*nx + (j+1)] - 2.0*vn[idx] + vn[i*nx + (j-1)]) + (dt / (dy*dy)) * (vn[(i+1)*nx + j] - 2.0*vn[idx] + vn[(i-1)*nx + j]));
                v[idx] = term1 + term2 + term3 + term4;
            }
        }
        // right boundary (j=nx-1) for u
        #pragma omp parallel for
        for (int64_t i = 1; i < ny-1; ++i) {
            size_t idx = i*nx + (nx-1);
            double term1 = un[idx] - (un[idx] * dt / dx) * (un[idx] - un[i*nx + (nx-2)]);
            double term2 = - (vn[idx] * dt / dy) * (un[idx] - un[(i-1)*nx + (nx-1)]);
            double term3 = - (dt / (2.0 * rho * dx)) * (p[i*nx + 0] - p[i*nx + (nx-2)]);
            double term4 = nu * ((dt / (dx*dx)) * (un[i*nx + 0] - 2.0*un[idx] + un[i*nx + (nx-2)]) + (dt / (dy*dy)) * (un[(i+1)*nx + (nx-1)] - 2.0*un[idx] + un[(i-1)*nx + (nx-1)]));
            u[idx] = term1 + term2 + term3 + term4 + F * dt;
        }
        // left boundary (j=0) for u
        #pragma omp parallel for
        for (int64_t i = 1; i < ny-1; ++i) {
            size_t idx = i*nx + 0;
            double term1 = un[idx] - (un[idx] * dt / dx) * (un[idx] - un[i*nx + (nx-1)]);
            double term2 = - (vn[idx] * dt / dy) * (un[idx] - un[(i-1)*nx + 0]);
            double term3 = - (dt / (2.0 * rho * dx)) * (p[i*nx + 1] - p[i*nx + (nx-1)]);
            double term4 = nu * ((dt / (dx*dx)) * (un[i*nx + 1] - 2.0*un[idx] + un[i*nx + (nx-1)]) + (dt / (dy*dy)) * (un[(i+1)*nx + 0] - 2.0*un[idx] + un[(i-1)*nx + 0]));
            u[idx] = term1 + term2 + term3 + term4 + F * dt;
        }
        // right boundary (j=nx-1) for v
        #pragma omp parallel for
        for (int64_t i = 1; i < ny-1; ++i) {
            size_t idx = i*nx + (nx-1);
            double term1 = vn[idx] - (un[idx] * dt / dx) * (vn[idx] - vn[i*nx + (nx-2)]);
            double term2 = - (vn[idx] * dt / dy) * (vn[idx] - vn[(i-1)*nx + (nx-1)]);
            double term3 = - (dt / (2.0 * rho * dy)) * (p[(i+1)*nx + (nx-1)] - p[(i-1)*nx + (nx-1)]);
            double term4 = nu * ((dt / (dx*dx)) * (vn[i*nx + 0] - 2.0*vn[idx] + vn[i*nx + (nx-2)]) + (dt / (dy*dy)) * (vn[(i+1)*nx + (nx-1)] - 2.0*vn[idx] + vn[(i-1)*nx + (nx-1)]));
            v[idx] = term1 + term2 + term3 + term4;
        }
        // left boundary (j=0) for v
        #pragma omp parallel for
        for (int64_t i = 1; i < ny-1; ++i) {
            size_t idx = i*nx + 0;
            double term1 = vn[idx] - (un[idx] * dt / dx) * (vn[idx] - vn[i*nx + (nx-1)]);
            double term2 = - (vn[idx] * dt / dy) * (vn[idx] - vn[(i-1)*nx + 0]);
            double term3 = - (dt / (2.0 * rho * dy)) * (p[(i+1)*nx + 0] - p[(i-1)*nx + 0]);
            double term4 = nu * ((dt / (dx*dx)) * (vn[i*nx + 1] - 2.0*vn[idx] + vn[i*nx + (nx-1)]) + (dt / (dy*dy)) * (vn[(i+1)*nx + 0] - 2.0*vn[idx] + vn[(i-1)*nx + 0]));
            v[idx] = term1 + term2 + term3 + term4;
        }
        // enforce wall BCs for u and v (y=0 and y=ny-1)
        #pragma omp parallel for
        for (int64_t j = 0; j < nx; ++j) {
            u[0*nx + j] = 0.0;
            u[(ny-1)*nx + j] = 0.0;
            v[0*nx + j] = 0.0;
            v[(ny-1)*nx + j] = 0.0;
        }
        // compute sum_u and udiff
        double sum_u = 0.0;
        double sum_un = 0.0;
        #pragma omp parallel for reduction(+:sum_u,sum_un)
        for (size_t idx = 0; idx < N; ++idx) {
            sum_u += u[idx];
            sum_un += un[idx];
        }
        udiff = (sum_u - sum_un) / sum_u;
    }
    // free allocated buffers if we used malloc
    if ((size_t)workspace_size < needed_bytes) {
        free(un);
        free(vn);
        free(b);
        free(pn);
    }
}

