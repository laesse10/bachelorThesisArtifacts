// hpcagent_bench-autogen -- generated from velocity_tendencies_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

void velocity_tendencies_fp64(double *restrict p_diag_ddt_vn_apc_pc, double *restrict p_diag_ddt_vn_cor_pc, double *restrict p_diag_ddt_w_adv_pc, double *restrict p_diag_max_vcfl_dyn, double *restrict p_diag_vn_ie, const double *restrict p_diag_vn_ie_ubc, double *restrict p_diag_vt, double *restrict p_diag_w_concorr_c, const double *restrict p_int_c_lin_e, const double *restrict p_int_cells_aw_verts, const double *restrict p_int_e_bln_c_s, const double *restrict p_int_geofac_grdiv, const double *restrict p_int_geofac_n2s, const double *restrict p_int_geofac_rot, const double *restrict p_int_rbf_vec_coeff_e, const double *restrict p_metrics_coeff1_dwdz, const double *restrict p_metrics_coeff2_dwdz, const double *restrict p_metrics_coeff_gradekin, const double *restrict p_metrics_ddqz_z_full_e, const double *restrict p_metrics_ddqz_z_half, const double *restrict p_metrics_ddxn_z_full, const double *restrict p_metrics_ddxt_z_full, const double *restrict p_metrics_deepatmo_gradh_ifc, const double *restrict p_metrics_deepatmo_gradh_mc, const double *restrict p_metrics_deepatmo_invr_ifc, const double *restrict p_metrics_deepatmo_invr_mc, const double *restrict p_metrics_wgtfac_c, const double *restrict p_metrics_wgtfac_e, const double *restrict p_metrics_wgtfacq_e, const double *restrict p_patch_cells_area, const int8_t *restrict p_patch_cells_decomp_info_owner_mask, const int32_t *restrict p_patch_cells_edge_blk, const int32_t *restrict p_patch_cells_edge_idx, const int32_t *restrict p_patch_cells_end_block, const int32_t *restrict p_patch_cells_end_index, const int32_t *restrict p_patch_cells_neighbor_blk, const int32_t *restrict p_patch_cells_neighbor_idx, const int32_t *restrict p_patch_cells_start_block, const int32_t *restrict p_patch_cells_start_index, const double *restrict p_patch_edges_area_edge, const int32_t *restrict p_patch_edges_cell_blk, const int32_t *restrict p_patch_edges_cell_idx, const int32_t *restrict p_patch_edges_end_block, const int32_t *restrict p_patch_edges_end_index, const double *restrict p_patch_edges_f_e, const double *restrict p_patch_edges_fn_e, const double *restrict p_patch_edges_ft_e, const double *restrict p_patch_edges_inv_dual_edge_length, const double *restrict p_patch_edges_inv_primal_edge_length, const int32_t *restrict p_patch_edges_quad_blk, const int32_t *restrict p_patch_edges_quad_idx, const int32_t *restrict p_patch_edges_start_block, const int32_t *restrict p_patch_edges_start_index, const double *restrict p_patch_edges_tangent_orientation, const int32_t *restrict p_patch_edges_vertex_blk, const int32_t *restrict p_patch_edges_vertex_idx, const int32_t *restrict p_patch_verts_cell_blk, const int32_t *restrict p_patch_verts_cell_idx, const int32_t *restrict p_patch_verts_edge_blk, const int32_t *restrict p_patch_verts_edge_idx, const int32_t *restrict p_patch_verts_end_block, const int32_t *restrict p_patch_verts_end_index, const int32_t *restrict p_patch_verts_start_block, const int32_t *restrict p_patch_verts_start_index, const double *restrict p_prog_vn, const double *restrict p_prog_w, double *restrict z_kin_hor_e, double *restrict z_vt_ie, double *restrict z_w_concorr_me, const int64_t ddt_vn_cor_associated, const double dt_linintp_ubc, const double dtime, const int64_t istep, const int64_t l_vert_nested, const int64_t ldeepatmo, const int64_t lextra_diffu, const int64_t lvn_only, const int64_t nblks_c, const int64_t nblks_e, const int64_t nblks_v, const int64_t nflatlev_jg, const int64_t nlev, const int64_t nlevp1, const int64_t nproma, const int64_t nrdmax_jg, const int64_t ntnd, uint8_t *restrict workspace, const int64_t workspace_size) {
        int64_t t;
        int64_t jk0_lo;
        int64_t jk0_hi;
        double __cb6;
        double cfl_w_limit;
        double scalfac_exdiff;
        int64_t jk0;
        double *z_w_v = (double *)malloc((size_t)((nblks_v) * (nlevp1) * (nproma)) * sizeof(double));
        __npb_alloc_check(z_w_v, (size_t)((nblks_v) * (nlevp1) * (nproma)) * sizeof(double), "z_w_v");
        memset(z_w_v, 0, (size_t)((nblks_v) * (nlevp1) * (nproma)) * sizeof(double));
        double *acc_zwv = (double *)malloc((size_t)((nblks_v) * (nproma)) * sizeof(double));
        __npb_alloc_check(acc_zwv, (size_t)((nblks_v) * (nproma)) * sizeof(double), "acc_zwv");
        memset(acc_zwv, 0, (size_t)((nblks_v) * (nproma)) * sizeof(double));
        double *zeta = (double *)malloc((size_t)((nblks_v) * (nlev) * (nproma)) * sizeof(double));
        __npb_alloc_check(zeta, (size_t)((nblks_v) * (nlev) * (nproma)) * sizeof(double), "zeta");
        memset(zeta, 0, (size_t)((nblks_v) * (nlev) * (nproma)) * sizeof(double));
        double *acc_zeta = (double *)malloc((size_t)((nblks_v) * (nproma)) * sizeof(double));
        __npb_alloc_check(acc_zeta, (size_t)((nblks_v) * (nproma)) * sizeof(double), "acc_zeta");
        memset(acc_zeta, 0, (size_t)((nblks_v) * (nproma)) * sizeof(double));
        double *acc_vt = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(acc_vt, (size_t)((nblks_e) * (nproma)) * sizeof(double), "acc_vt");
        memset(acc_vt, 0, (size_t)((nblks_e) * (nproma)) * sizeof(double));
        double *z_v_grad_w = (double *)malloc((size_t)((nblks_e) * (nlev) * (nproma)) * sizeof(double));
        __npb_alloc_check(z_v_grad_w, (size_t)((nblks_e) * (nlev) * (nproma)) * sizeof(double), "z_v_grad_w");
        memset(z_v_grad_w, 0, (size_t)((nblks_e) * (nlev) * (nproma)) * sizeof(double));
        double *z_ekinh = (double *)malloc((size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double));
        __npb_alloc_check(z_ekinh, (size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double), "z_ekinh");
        memset(z_ekinh, 0, (size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double));
        double *acc_ek = (double *)malloc((size_t)((nblks_c) * (nproma)) * sizeof(double));
        __npb_alloc_check(acc_ek, (size_t)((nblks_c) * (nproma)) * sizeof(double), "acc_ek");
        memset(acc_ek, 0, (size_t)((nblks_c) * (nproma)) * sizeof(double));
        double *acc_wcm = (double *)malloc((size_t)((nblks_c) * (nproma)) * sizeof(double));
        __npb_alloc_check(acc_wcm, (size_t)((nblks_c) * (nproma)) * sizeof(double), "acc_wcm");
        memset(acc_wcm, 0, (size_t)((nblks_c) * (nproma)) * sizeof(double));
        double *z_w_con_c = (double *)malloc((size_t)((nblks_c) * (nlevp1) * (nproma)) * sizeof(double));
        __npb_alloc_check(z_w_con_c, (size_t)((nblks_c) * (nlevp1) * (nproma)) * sizeof(double), "z_w_con_c");
        memset(z_w_con_c, 0, (size_t)((nblks_c) * (nlevp1) * (nproma)) * sizeof(double));
        double *vcflmax = (double *)malloc((size_t)((nblks_c)) * sizeof(double));
        __npb_alloc_check(vcflmax, (size_t)((nblks_c)) * sizeof(double), "vcflmax");
        memset(vcflmax, 0, (size_t)((nblks_c)) * sizeof(double));
        bool *cfl_clip = (bool *)malloc((size_t)((nblks_c) * (nlevp1) * (nproma)) * sizeof(bool));
        __npb_alloc_check(cfl_clip, (size_t)((nblks_c) * (nlevp1) * (nproma)) * sizeof(bool), "cfl_clip");
        memset(cfl_clip, 0, (size_t)((nblks_c) * (nlevp1) * (nproma)) * sizeof(bool));
        double *z_w_con_c_full = (double *)malloc((size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double));
        __npb_alloc_check(z_w_con_c_full, (size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double), "z_w_con_c_full");
        memset(z_w_con_c_full, 0, (size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double));
        double *acc_dwa = (double *)malloc((size_t)((nblks_c) * (nproma)) * sizeof(double));
        __npb_alloc_check(acc_dwa, (size_t)((nblks_c) * (nproma)) * sizeof(double), "acc_dwa");
        memset(acc_dwa, 0, (size_t)((nblks_c) * (nproma)) * sizeof(double));
        double *__cb7 = (double *)malloc((size_t)((nblks_c) * (nproma)) * sizeof(double));
        __npb_alloc_check(__cb7, (size_t)((nblks_c) * (nproma)) * sizeof(double), "__cb7");
        double *__cb8 = (double *)malloc((size_t)((nblks_c) * (nproma)) * sizeof(double));
        __npb_alloc_check(__cb8, (size_t)((nblks_c) * (nproma)) * sizeof(double), "__cb8");
        double *__cb9 = (double *)malloc((size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double));
        __npb_alloc_check(__cb9, (size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double), "__cb9");
        double *__cb11 = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(__cb11, (size_t)((nblks_e) * (nproma)) * sizeof(double), "__cb11");
        double *__cb12 = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(__cb12, (size_t)((nblks_e) * (nproma)) * sizeof(double), "__cb12");
        bool *levelmask = (bool *)malloc((size_t)((nlev)) * sizeof(bool));
        __npb_alloc_check(levelmask, (size_t)((nlev)) * sizeof(bool), "levelmask");
        bool *owner = (bool *)malloc((size_t)((nblks_c) * (nproma)) * sizeof(bool));
        __npb_alloc_check(owner, (size_t)((nblks_c) * (nproma)) * sizeof(bool), "owner");
        bool *mask = (bool *)malloc((size_t)((nblks_c) * (nproma)) * sizeof(bool));
        __npb_alloc_check(mask, (size_t)((nblks_c) * (nproma)) * sizeof(bool), "mask");
        double *difcoef_c = (double *)malloc((size_t)((nblks_c) * (nproma)) * sizeof(double));
        __npb_alloc_check(difcoef_c, (size_t)((nblks_c) * (nproma)) * sizeof(double), "difcoef_c");
        double *lap = (double *)malloc((size_t)((nblks_c) * (nproma)) * sizeof(double));
        __npb_alloc_check(lap, (size_t)((nblks_c) * (nproma)) * sizeof(double), "lap");
        double *clin = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(clin, (size_t)((nblks_e) * (nproma)) * sizeof(double), "clin");
        double *grad_ekin = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(grad_ekin, (size_t)((nblks_e) * (nproma)) * sizeof(double), "grad_ekin");
        double *w_con_e = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(w_con_e, (size_t)((nblks_e) * (nproma)) * sizeof(double), "w_con_e");
        bool *clip_e = (bool *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(bool));
        __npb_alloc_check(clip_e, (size_t)((nblks_e) * (nproma)) * sizeof(bool), "clip_e");
        double *difcoef_e = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(difcoef_e, (size_t)((nblks_e) * (nproma)) * sizeof(double), "difcoef_e");
        double *grad = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(grad, (size_t)((nblks_e) * (nproma)) * sizeof(double), "grad");
        double *ekc1 = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(ekc1, (size_t)((nblks_e) * (nproma)) * sizeof(double), "ekc1");
        double *ekc2 = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(ekc2, (size_t)((nblks_e) * (nproma)) * sizeof(double), "ekc2");
        double *zv1 = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(zv1, (size_t)((nblks_e) * (nproma)) * sizeof(double), "zv1");
        double *zv2 = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(zv2, (size_t)((nblks_e) * (nproma)) * sizeof(double), "zv2");
        double *wcf1 = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(wcf1, (size_t)((nblks_e) * (nproma)) * sizeof(double), "wcf1");
        double *wcf2 = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(wcf2, (size_t)((nblks_e) * (nproma)) * sizeof(double), "wcf2");
        double *we = (double *)malloc((size_t)((nblks_e) * (nproma)) * sizeof(double));
        __npb_alloc_check(we, (size_t)((nblks_e) * (nproma)) * sizeof(double), "we");
        double *wc = (double *)malloc((size_t)((nblks_c) * (nproma)) * sizeof(double));
        __npb_alloc_check(wc, (size_t)((nblks_c) * (nproma)) * sizeof(double), "wc");
        double *__cb1 = NULL;
        double *__cb4 = NULL;
        double *__cb5 = NULL;
        bool *clip = NULL;
        double *vcfl = NULL;
        double *abs_vcfl_masked = NULL;
        bool *lo_clip = NULL;
        bool *hi_clip = NULL;
        double *h = NULL;
        double *zc = NULL;
        t = (ntnd - 1);
        if (lextra_diffu) {
          cfl_w_limit = (0.65 / dtime);
          scalfac_exdiff = (0.05 / (dtime * (0.85 - (cfl_w_limit * dtime))));
        }
        else {
          cfl_w_limit = (0.85 / dtime);
          scalfac_exdiff = 0.0;
        }
        memset(z_w_v, 0, (size_t)((nblks_v) * (nlevp1) * (nproma)) * sizeof(double));
        if ((!lvn_only)) {
          for (int64_t jk = 0; jk < nlevp1; ++jk) {
            memset(acc_zwv, 0, (size_t)((nblks_v) * (nproma)) * sizeof(double));
            for (int64_t n = 0; n < 6; ++n) {
              for (int64_t __w0 = 0; __w0 < nblks_v; ++__w0) {
                for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                  acc_zwv[(__w0)*(nproma) + (__w1)] += (p_int_cells_aw_verts[((__w0)*(6) + (n))*(nproma) + (__w1)] * p_prog_w[((((int64_t)(p_patch_verts_cell_blk[((n)*(nblks_v) + (__w0))*(nproma) + (__w1)])))*((nlev + 1)) + (jk))*(nproma) + (((int64_t)(p_patch_verts_cell_idx[((n)*(nblks_v) + (__w0))*(nproma) + (__w1)])))]);
                }
              }
            }
            for (int64_t si0 = 0; si0 < nblks_v; ++si0) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                z_w_v[((si0)*(nlevp1) + (jk))*(nproma) + (si2)] = acc_zwv[(si0)*(nproma) + (si2)];
              }
            }
          }
        }
        memset(zeta, 0, (size_t)((nblks_v) * (nlev) * (nproma)) * sizeof(double));
        for (int64_t jk = 0; jk < nlev; ++jk) {
          memset(acc_zeta, 0, (size_t)((nblks_v) * (nproma)) * sizeof(double));
          for (int64_t n = 0; n < 6; ++n) {
            for (int64_t __w0 = 0; __w0 < nblks_v; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                acc_zeta[(__w0)*(nproma) + (__w1)] += (p_prog_vn[((((int64_t)(p_patch_verts_edge_blk[((n)*(nblks_v) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_verts_edge_idx[((n)*(nblks_v) + (__w0))*(nproma) + (__w1)])))] * p_int_geofac_rot[((__w0)*(6) + (n))*(nproma) + (__w1)]);
              }
            }
          }
          for (int64_t si0 = 0; si0 < nblks_v; ++si0) {
            for (int64_t si2 = 0; si2 < nproma; ++si2) {
              zeta[((si0)*(nlev) + (jk))*(nproma) + (si2)] = acc_zeta[(si0)*(nproma) + (si2)];
            }
          }
        }
        if ((istep == 1)) {
          for (int64_t jk = 0; jk < nlev; ++jk) {
            memset(acc_vt, 0, (size_t)((nblks_e) * (nproma)) * sizeof(double));
            for (int64_t n = 0; n < 4; ++n) {
              for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
                for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                  acc_vt[(__w0)*(nproma) + (__w1)] += (p_int_rbf_vec_coeff_e[((__w0)*(nproma) + (__w1))*(4) + (n)] * p_prog_vn[((((int64_t)(p_patch_edges_quad_blk[((n)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_edges_quad_idx[((n)*(nblks_e) + (__w0))*(nproma) + (__w1)])))]);
                }
              }
            }
            for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                p_diag_vt[((si0)*(nlev) + (jk))*(nproma) + (si2)] = acc_vt[(si0)*(nproma) + (si2)];
              }
            }
          }
          for (int64_t jk = 1; jk < nlev; ++jk) {
            for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
              for (int64_t si1 = 0; si1 < nproma; ++si1) {
                we[(si0)*(nproma) + (si1)] = p_metrics_wgtfac_e[((si0)*((nlev + 1)) + (jk))*(nproma) + (si1)];
              }
            }
            for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                p_diag_vn_ie[((si0)*((nlev + 1)) + (jk))*(nproma) + (si2)] = ((we[(si0)*(nproma) + (si2)] * p_prog_vn[((si0)*(nlev) + (jk))*(nproma) + (si2)]) + ((1.0 - we[(si0)*(nproma) + (si2)]) * p_prog_vn[((si0)*(nlev) + ((jk - 1)))*(nproma) + (si2)]));
              }
            }
            for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                z_kin_hor_e[((si0)*(nlev) + (jk))*(nproma) + (si2)] = (0.5 * ((p_prog_vn[((si0)*(nlev) + (jk))*(nproma) + (si2)] * p_prog_vn[((si0)*(nlev) + (jk))*(nproma) + (si2)]) + (p_diag_vt[((si0)*(nlev) + (jk))*(nproma) + (si2)] * p_diag_vt[((si0)*(nlev) + (jk))*(nproma) + (si2)])));
              }
            }
          }
          if ((!lvn_only)) {
            for (int64_t jk = 1; jk < nlev; ++jk) {
              for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
                for (int64_t si1 = 0; si1 < nproma; ++si1) {
                  we[(si0)*(nproma) + (si1)] = p_metrics_wgtfac_e[((si0)*((nlev + 1)) + (jk))*(nproma) + (si1)];
                }
              }
              for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
                for (int64_t si2 = 0; si2 < nproma; ++si2) {
                  z_vt_ie[((si0)*((nlev + 1)) + (jk))*(nproma) + (si2)] = ((we[(si0)*(nproma) + (si2)] * p_diag_vt[((si0)*(nlev) + (jk))*(nproma) + (si2)]) + ((1.0 - we[(si0)*(nproma) + (si2)]) * p_diag_vt[((si0)*(nlev) + ((jk - 1)))*(nproma) + (si2)]));
                }
              }
            }
          }
          for (int64_t jk = (nflatlev_jg - 1); jk < nlev; ++jk) {
            for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                z_w_concorr_me[((si0)*(nlev) + (jk))*(nproma) + (si2)] = ((p_prog_vn[((si0)*(nlev) + (jk))*(nproma) + (si2)] * p_metrics_ddxn_z_full[((si0)*(nlev) + (jk))*(nproma) + (si2)]) + (p_diag_vt[((si0)*(nlev) + (jk))*(nproma) + (si2)] * p_metrics_ddxt_z_full[((si0)*(nlev) + (jk))*(nproma) + (si2)]));
              }
            }
          }
          if ((!l_vert_nested)) {
            for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                p_diag_vn_ie[((si0)*((nlev + 1)) + (0))*(nproma) + (si2)] = p_prog_vn[((si0)*(nlev) + (0))*(nproma) + (si2)];
              }
            }
          }
          else {
            for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                p_diag_vn_ie[((si0)*((nlev + 1)) + (0))*(nproma) + (si2)] = (p_diag_vn_ie_ubc[((si0)*(2) + (0))*(nproma) + (si2)] + (dt_linintp_ubc * p_diag_vn_ie_ubc[((si0)*(2) + (1))*(nproma) + (si2)]));
              }
            }
          }
          for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
            for (int64_t si2 = 0; si2 < nproma; ++si2) {
              z_vt_ie[((si0)*((nlev + 1)) + (0))*(nproma) + (si2)] = p_diag_vt[((si0)*(nlev) + (0))*(nproma) + (si2)];
            }
          }
          for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
            for (int64_t si2 = 0; si2 < nproma; ++si2) {
              z_kin_hor_e[((si0)*(nlev) + (0))*(nproma) + (si2)] = (0.5 * ((p_prog_vn[((si0)*(nlev) + (0))*(nproma) + (si2)] * p_prog_vn[((si0)*(nlev) + (0))*(nproma) + (si2)]) + (p_diag_vt[((si0)*(nlev) + (0))*(nproma) + (si2)] * p_diag_vt[((si0)*(nlev) + (0))*(nproma) + (si2)])));
            }
          }
          for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
            for (int64_t si2 = 0; si2 < nproma; ++si2) {
              p_diag_vn_ie[((si0)*((nlev + 1)) + ((nlevp1 - 1)))*(nproma) + (si2)] = (((p_metrics_wgtfacq_e[((si0)*(3) + (0))*(nproma) + (si2)] * p_prog_vn[((si0)*(nlev) + ((nlev - 1)))*(nproma) + (si2)]) + (p_metrics_wgtfacq_e[((si0)*(3) + (1))*(nproma) + (si2)] * p_prog_vn[((si0)*(nlev) + ((nlev - 2)))*(nproma) + (si2)])) + (p_metrics_wgtfacq_e[((si0)*(3) + (2))*(nproma) + (si2)] * p_prog_vn[((si0)*(nlev) + ((nlev - 3)))*(nproma) + (si2)]));
            }
          }
        }
        memset(z_v_grad_w, 0, (size_t)((nblks_e) * (nlev) * (nproma)) * sizeof(double));
        if ((!lvn_only)) {
          for (int64_t jk = 0; jk < nlev; ++jk) {
            for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                z_v_grad_w[((si0)*(nlev) + (jk))*(nproma) + (si2)] = (((p_diag_vn_ie[((si0)*((nlev + 1)) + (jk))*(nproma) + (si2)] * p_patch_edges_inv_dual_edge_length[(si0)*(nproma) + (si2)]) * (p_prog_w[((((int64_t)(p_patch_edges_cell_blk[((0)*(nblks_e) + (si0))*(nproma) + (si2)])))*((nlev + 1)) + (jk))*(nproma) + (((int64_t)(p_patch_edges_cell_idx[((0)*(nblks_e) + (si0))*(nproma) + (si2)])))] - p_prog_w[((((int64_t)(p_patch_edges_cell_blk[((1)*(nblks_e) + (si0))*(nproma) + (si2)])))*((nlev + 1)) + (jk))*(nproma) + (((int64_t)(p_patch_edges_cell_idx[((1)*(nblks_e) + (si0))*(nproma) + (si2)])))])) + (((z_vt_ie[((si0)*((nlev + 1)) + (jk))*(nproma) + (si2)] * p_patch_edges_inv_primal_edge_length[(si0)*(nproma) + (si2)]) * p_patch_edges_tangent_orientation[(si0)*(nproma) + (si2)]) * (z_w_v[((((int64_t)(p_patch_edges_vertex_blk[((0)*(nblks_e) + (si0))*(nproma) + (si2)])))*(nlevp1) + (jk))*(nproma) + (((int64_t)(p_patch_edges_vertex_idx[((0)*(nblks_e) + (si0))*(nproma) + (si2)])))] - z_w_v[((((int64_t)(p_patch_edges_vertex_blk[((1)*(nblks_e) + (si0))*(nproma) + (si2)])))*(nlevp1) + (jk))*(nproma) + (((int64_t)(p_patch_edges_vertex_idx[((1)*(nblks_e) + (si0))*(nproma) + (si2)])))])));
              }
            }
          }
          if (ldeepatmo) {
            for (int64_t jk = 0; jk < nlev; ++jk) {
              for (int64_t si0 = 0; si0 < nblks_e; ++si0) {
                for (int64_t si2 = 0; si2 < nproma; ++si2) {
                  z_v_grad_w[((si0)*(nlev) + (jk))*(nproma) + (si2)] = (((z_v_grad_w[((si0)*(nlev) + (jk))*(nproma) + (si2)] * p_metrics_deepatmo_gradh_ifc[jk]) + (p_diag_vn_ie[((si0)*((nlev + 1)) + (jk))*(nproma) + (si2)] * ((p_diag_vn_ie[((si0)*((nlev + 1)) + (jk))*(nproma) + (si2)] * p_metrics_deepatmo_invr_ifc[jk]) - p_patch_edges_ft_e[(si0)*(nproma) + (si2)]))) + (z_vt_ie[((si0)*((nlev + 1)) + (jk))*(nproma) + (si2)] * ((z_vt_ie[((si0)*((nlev + 1)) + (jk))*(nproma) + (si2)] * p_metrics_deepatmo_invr_ifc[jk]) + p_patch_edges_fn_e[(si0)*(nproma) + (si2)])));
                }
              }
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
          for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
            owner[(__w0)*(nproma) + (__w1)] = (((int64_t)(p_patch_cells_decomp_info_owner_mask[(__w0)*(nproma) + (__w1)])) != 0);
          }
        }
        memset(z_ekinh, 0, (size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double));
        for (int64_t jk = 0; jk < nlev; ++jk) {
          memset(acc_ek, 0, (size_t)((nblks_c) * (nproma)) * sizeof(double));
          for (int64_t n = 0; n < 3; ++n) {
            for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                acc_ek[(__w0)*(nproma) + (__w1)] += (p_int_e_bln_c_s[((__w0)*(3) + (n))*(nproma) + (__w1)] * z_kin_hor_e[((((int64_t)(p_patch_cells_edge_blk[((n)*(nblks_c) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_cells_edge_idx[((n)*(nblks_c) + (__w0))*(nproma) + (__w1)])))]);
              }
            }
          }
          for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
            for (int64_t si2 = 0; si2 < nproma; ++si2) {
              z_ekinh[((si0)*(nlev) + (jk))*(nproma) + (si2)] = acc_ek[(si0)*(nproma) + (si2)];
            }
          }
        }
        if ((istep == 1)) {
          double *z_w_concorr_mc = (double *)malloc((size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double));
          __npb_alloc_check(z_w_concorr_mc, (size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double), "z_w_concorr_mc");
          memset(z_w_concorr_mc, 0, (size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double));
          for (int64_t jk = (nflatlev_jg - 1); jk < nlev; ++jk) {
            memset(acc_wcm, 0, (size_t)((nblks_c) * (nproma)) * sizeof(double));
            for (int64_t n = 0; n < 3; ++n) {
              for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
                for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                  acc_wcm[(__w0)*(nproma) + (__w1)] += (p_int_e_bln_c_s[((__w0)*(3) + (n))*(nproma) + (__w1)] * z_w_concorr_me[((((int64_t)(p_patch_cells_edge_blk[((n)*(nblks_c) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_cells_edge_idx[((n)*(nblks_c) + (__w0))*(nproma) + (__w1)])))]);
                }
              }
            }
            for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                z_w_concorr_mc[((si0)*(nlev) + (jk))*(nproma) + (si2)] = acc_wcm[(si0)*(nproma) + (si2)];
              }
            }
          }
          for (int64_t jk = nflatlev_jg; jk < nlev; ++jk) {
            for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
              for (int64_t si1 = 0; si1 < nproma; ++si1) {
                wc[(si0)*(nproma) + (si1)] = p_metrics_wgtfac_c[((si0)*((nlev + 1)) + (jk))*(nproma) + (si1)];
              }
            }
            for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                p_diag_w_concorr_c[((si0)*(nlev) + (jk))*(nproma) + (si2)] = ((wc[(si0)*(nproma) + (si2)] * z_w_concorr_mc[((si0)*(nlev) + (jk))*(nproma) + (si2)]) + ((1.0 - wc[(si0)*(nproma) + (si2)]) * z_w_concorr_mc[((si0)*(nlev) + ((jk - 1)))*(nproma) + (si2)]));
              }
            }
          }
          free(z_w_concorr_mc);
        }
        memset(z_w_con_c, 0, (size_t)((nblks_c) * (nlevp1) * (nproma)) * sizeof(double));
        for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
          for (int64_t si1 = 0; si1 < nlev; ++si1) {
            for (int64_t si2 = 0; si2 < nproma; ++si2) {
              z_w_con_c[((si0)*(nlevp1) + (si1))*(nproma) + (si2)] = p_prog_w[((si0)*((nlev + 1)) + (si1))*(nproma) + (si2)];
            }
          }
        }
        for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
          for (int64_t si2 = 0; si2 < nproma; ++si2) {
            z_w_con_c[((si0)*(nlevp1) + ((nlevp1 - 1)))*(nproma) + (si2)] = 0.0;
          }
        }
        for (int64_t jk = nflatlev_jg; jk < nlev; ++jk) {
          for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
            for (int64_t si2 = 0; si2 < nproma; ++si2) {
              z_w_con_c[((si0)*(nlevp1) + (jk))*(nproma) + (si2)] -= p_diag_w_concorr_c[((si0)*(nlev) + (jk))*(nproma) + (si2)];
            }
          }
        }
        memset(vcflmax, 0, (size_t)((nblks_c)) * sizeof(double));
        memset(cfl_clip, 0, (size_t)((nblks_c) * (nlevp1) * (nproma)) * sizeof(bool));
        jk0_lo = (max(3, (nrdmax_jg - 2)) - 1);
        jk0_hi = (nlev - 4);
        if ((jk0_hi >= jk0_lo)) {
          free(h);
          h = (double *)malloc((size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double));
          __npb_alloc_check(h, (size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double), "h");
          for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((jk0_hi + 1) - jk0_lo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nproma; ++__w2) {
                h[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] = p_metrics_ddqz_z_half[((__w0)*((nlev + 1)) + ((__w1 + (jk0_lo - 0))))*(nproma) + (__w2)];
              }
            }
          }
          free(zc);
          zc = (double *)malloc((size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double));
          __npb_alloc_check(zc, (size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double), "zc");
          for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((jk0_hi + 1) - jk0_lo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nproma; ++__w2) {
                zc[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] = z_w_con_c[((__w0)*(nlevp1) + ((__w1 + (jk0_lo - 0))))*(nproma) + (__w2)];
              }
            }
          }
          free(clip);
          clip = (bool *)malloc((size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(bool));
          __npb_alloc_check(clip, (size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(bool), "clip");
          for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((jk0_hi + 1) - jk0_lo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nproma; ++__w2) {
                clip[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] = (fabs(zc[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)]) > (cfl_w_limit * h[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)]));
              }
            }
          }
          free(vcfl);
          vcfl = (double *)malloc((size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double));
          __npb_alloc_check(vcfl, (size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double), "vcfl");
          for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((jk0_hi + 1) - jk0_lo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nproma; ++__w2) {
                vcfl[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] = ((zc[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] * dtime) / h[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)]);
              }
            }
          }
          for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
            for (int64_t si1 = jk0_lo; si1 < (jk0_hi + 1); ++si1) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                cfl_clip[((si0)*(nlevp1) + (si1))*(nproma) + (si2)] = clip[((si0)*(((jk0_hi + 1) - jk0_lo)) + ((si1 - jk0_lo)))*(nproma) + (si2)];
              }
            }
          }
          free(__cb1);
          __cb1 = (double *)malloc((size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double));
          __npb_alloc_check(__cb1, (size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double), "__cb1");
          /* numpy: np.where(clip, fabs(vcfl), -INFINITY) */
          for (int64_t __r0 = 0; __r0 < nblks_c; ++__r0) {
            for (int64_t __r1 = 0; __r1 < ((jk0_hi + 1) - jk0_lo); ++__r1) {
              for (int64_t __r2 = 0; __r2 < nproma; ++__r2) {
                __cb1[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)] = (clip[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)] ? fabs(vcfl[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)]) : (-INFINITY));
              }
            }
          }
          free(abs_vcfl_masked);
          abs_vcfl_masked = (double *)malloc((size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double));
          __npb_alloc_check(abs_vcfl_masked, (size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double), "abs_vcfl_masked");
          for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((jk0_hi + 1) - jk0_lo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nproma; ++__w2) {
                abs_vcfl_masked[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] = __cb1[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)];
              }
            }
          }
          double *__cb2 = (double *)malloc((size_t)((nblks_c)) * sizeof(double));
          __npb_alloc_check(__cb2, (size_t)((nblks_c)) * sizeof(double), "__cb2");
          /* numpy: np.max(abs_vcfl_masked, axis=(1, 2)) */
          for (int64_t __ax0 = 0; __ax0 < nblks_c; ++__ax0) {
            __cb2[__ax0] = abs_vcfl_masked[((__ax0)*(((jk0_hi + 1) - jk0_lo)) + (0))*(nproma) + (0)];
            for (int64_t __rd0 = 0; __rd0 < ((jk0_hi + 1) - jk0_lo); ++__rd0) {
              for (int64_t __rd1 = 0; __rd1 < nproma; ++__rd1) {
                __cb2[__ax0] = (((abs_vcfl_masked[((__ax0)*(((jk0_hi + 1) - jk0_lo)) + (__rd0))*(nproma) + (__rd1)] > __cb2[__ax0]) || (abs_vcfl_masked[((__ax0)*(((jk0_hi + 1) - jk0_lo)) + (__rd0))*(nproma) + (__rd1)] != abs_vcfl_masked[((__ax0)*(((jk0_hi + 1) - jk0_lo)) + (__rd0))*(nproma) + (__rd1)])) ? abs_vcfl_masked[((__ax0)*(((jk0_hi + 1) - jk0_lo)) + (__rd0))*(nproma) + (__rd1)] : __cb2[__ax0]);
              }
            }
          }
          double *__cb3 = (double *)malloc((size_t)((nblks_c)) * sizeof(double));
          __npb_alloc_check(__cb3, (size_t)((nblks_c)) * sizeof(double), "__cb3");
          /* numpy: np.maximum(vcflmax, __cb2) */
          for (int64_t __r0 = 0; __r0 < nblks_c; ++__r0) {
            __cb3[__r0] = max(vcflmax[__r0], __cb2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
            vcflmax[__w0] = __cb3[__w0];
          }
          free(lo_clip);
          lo_clip = (bool *)malloc((size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(bool));
          __npb_alloc_check(lo_clip, (size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(bool), "lo_clip");
          for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((jk0_hi + 1) - jk0_lo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nproma; ++__w2) {
                lo_clip[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] = (clip[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] & (vcfl[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] < (-0.85)));
              }
            }
          }
          free(hi_clip);
          hi_clip = (bool *)malloc((size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(bool));
          __npb_alloc_check(hi_clip, (size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(bool), "hi_clip");
          for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((jk0_hi + 1) - jk0_lo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nproma; ++__w2) {
                hi_clip[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] = (clip[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] & (vcfl[((__w0)*(((jk0_hi + 1) - jk0_lo)) + (__w1))*(nproma) + (__w2)] > 0.85));
              }
            }
          }
          free(__cb4);
          __cb4 = (double *)malloc((size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double));
          __npb_alloc_check(__cb4, (size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double), "__cb4");
          /* numpy: np.where(hi_clip, 0.85 * h / dtime, zc) */
          for (int64_t __r0 = 0; __r0 < nblks_c; ++__r0) {
            for (int64_t __r1 = 0; __r1 < ((jk0_hi + 1) - jk0_lo); ++__r1) {
              for (int64_t __r2 = 0; __r2 < nproma; ++__r2) {
                __cb4[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)] = (hi_clip[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)] ? ((0.85 * h[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)]) / dtime) : zc[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)]);
              }
            }
          }
          free(__cb5);
          __cb5 = (double *)malloc((size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double));
          __npb_alloc_check(__cb5, (size_t)((nblks_c) * (((jk0_hi + 1) - jk0_lo)) * (nproma)) * sizeof(double), "__cb5");
          /* numpy: np.where(lo_clip, -0.85 * h / dtime, __cb4) */
          for (int64_t __r0 = 0; __r0 < nblks_c; ++__r0) {
            for (int64_t __r1 = 0; __r1 < ((jk0_hi + 1) - jk0_lo); ++__r1) {
              for (int64_t __r2 = 0; __r2 < nproma; ++__r2) {
                __cb5[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)] = (lo_clip[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)] ? (((-0.85) * h[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)]) / dtime) : __cb4[((__r0)*(((jk0_hi + 1) - jk0_lo)) + (__r1))*(nproma) + (__r2)]);
              }
            }
          }
          for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
            for (int64_t si1 = jk0_lo; si1 < (jk0_hi + 1); ++si1) {
              for (int64_t si2 = 0; si2 < nproma; ++si2) {
                z_w_con_c[((si0)*(nlevp1) + (si1))*(nproma) + (si2)] = __cb5[((si0)*(((jk0_hi + 1) - jk0_lo)) + ((si1 - jk0_lo)))*(nproma) + (si2)];
              }
            }
          }
          free(__cb2);
          free(__cb3);
        }
        memset(z_w_con_c_full, 0, (size_t)((nblks_c) * (nlev) * (nproma)) * sizeof(double));
        for (int64_t jk = 0; jk < nlev; ++jk) {
          for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
            for (int64_t si2 = 0; si2 < nproma; ++si2) {
              z_w_con_c_full[((si0)*(nlev) + (jk))*(nproma) + (si2)] = (0.5 * (z_w_con_c[((si0)*(nlevp1) + (jk))*(nproma) + (si2)] + z_w_con_c[((si0)*(nlevp1) + ((jk + 1)))*(nproma) + (si2)]));
            }
          }
        }
        /* numpy: np.max(vcflmax) */
        __cb6 = vcflmax[0];
        for (int64_t __r0 = 0; __r0 < nblks_c; ++__r0) {
          __cb6 = (((vcflmax[__r0] > __cb6) || (vcflmax[__r0] != vcflmax[__r0])) ? vcflmax[__r0] : __cb6);
        }
        p_diag_max_vcfl_dyn[0] = max(p_diag_max_vcfl_dyn[0], __cb6);
        if ((!lvn_only)) {
          for (int64_t jk = 1; jk < nlev; ++jk) {
            for (int64_t si1 = 0; si1 < nblks_c; ++si1) {
              for (int64_t si3 = 0; si3 < nproma; ++si3) {
                p_diag_ddt_w_adv_pc[(((t)*(nblks_c) + (si1))*((nlev + 1)) + (jk))*(nproma) + (si3)] = ((-z_w_con_c[((si1)*(nlevp1) + (jk))*(nproma) + (si3)]) * (((p_prog_w[((si1)*((nlev + 1)) + ((jk - 1)))*(nproma) + (si3)] * p_metrics_coeff1_dwdz[((si1)*(nlev) + (jk))*(nproma) + (si3)]) - (p_prog_w[((si1)*((nlev + 1)) + ((jk + 1)))*(nproma) + (si3)] * p_metrics_coeff2_dwdz[((si1)*(nlev) + (jk))*(nproma) + (si3)])) + (p_prog_w[((si1)*((nlev + 1)) + (jk))*(nproma) + (si3)] * (p_metrics_coeff2_dwdz[((si1)*(nlev) + (jk))*(nproma) + (si3)] - p_metrics_coeff1_dwdz[((si1)*(nlev) + (jk))*(nproma) + (si3)]))));
              }
            }
          }
          for (int64_t jk = 1; jk < nlev; ++jk) {
            memset(acc_dwa, 0, (size_t)((nblks_c) * (nproma)) * sizeof(double));
            for (int64_t n = 0; n < 3; ++n) {
              for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
                for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                  acc_dwa[(__w0)*(nproma) + (__w1)] += (p_int_e_bln_c_s[((__w0)*(3) + (n))*(nproma) + (__w1)] * z_v_grad_w[((((int64_t)(p_patch_cells_edge_blk[((n)*(nblks_c) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_cells_edge_idx[((n)*(nblks_c) + (__w0))*(nproma) + (__w1)])))]);
                }
              }
            }
            for (int64_t si1 = 0; si1 < nblks_c; ++si1) {
              for (int64_t si3 = 0; si3 < nproma; ++si3) {
                p_diag_ddt_w_adv_pc[(((t)*(nblks_c) + (si1))*((nlev + 1)) + (jk))*(nproma) + (si3)] += acc_dwa[(si1)*(nproma) + (si3)];
              }
            }
          }
          if (lextra_diffu) {
            for (int64_t jk1 = max(3, (nrdmax_jg - 2)); jk1 < ((nlev - 3) + 1); ++jk1) {
              jk0 = (jk1 - 1);
              for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
                for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                  mask[(__w0)*(nproma) + (__w1)] = (cfl_clip[((__w0)*(nlevp1) + (jk0))*(nproma) + (__w1)] & owner[(__w0)*(nproma) + (__w1)]);
                }
              }
              /* numpy: np.minimum(0.85 - cfl_w_limit * dtime, np.abs(z_w_con_c[:, jk0, :]) * dtime / p_metrics_ddqz_... */
              for (int64_t __r0 = 0; __r0 < nblks_c; ++__r0) {
                for (int64_t __r1 = 0; __r1 < nproma; ++__r1) {
                  __cb7[(__r0)*(nproma) + (__r1)] = min((0.85 - (cfl_w_limit * dtime)), (((fabs(z_w_con_c[((__r0)*(nlevp1) + (jk0))*(nproma) + (__r1)]) * dtime) / p_metrics_ddqz_z_half[((__r0)*((nlev + 1)) + (jk0))*(nproma) + (__r1)]) - (cfl_w_limit * dtime)));
                }
              }
              for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
                for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                  difcoef_c[(__w0)*(nproma) + (__w1)] = (scalfac_exdiff * __cb7[(__w0)*(nproma) + (__w1)]);
                }
              }
              for (int64_t __w0 = 0; __w0 < nblks_c; ++__w0) {
                for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                  lap[(__w0)*(nproma) + (__w1)] = ((((p_prog_w[((__w0)*((nlev + 1)) + (jk0))*(nproma) + (__w1)] * p_int_geofac_n2s[((__w0)*(4) + (0))*(nproma) + (__w1)]) + (p_prog_w[((((int64_t)(p_patch_cells_neighbor_blk[((0)*(nblks_c) + (__w0))*(nproma) + (__w1)])))*((nlev + 1)) + (jk0))*(nproma) + (((int64_t)(p_patch_cells_neighbor_idx[((0)*(nblks_c) + (__w0))*(nproma) + (__w1)])))] * p_int_geofac_n2s[((__w0)*(4) + (1))*(nproma) + (__w1)])) + (p_prog_w[((((int64_t)(p_patch_cells_neighbor_blk[((1)*(nblks_c) + (__w0))*(nproma) + (__w1)])))*((nlev + 1)) + (jk0))*(nproma) + (((int64_t)(p_patch_cells_neighbor_idx[((1)*(nblks_c) + (__w0))*(nproma) + (__w1)])))] * p_int_geofac_n2s[((__w0)*(4) + (2))*(nproma) + (__w1)])) + (p_prog_w[((((int64_t)(p_patch_cells_neighbor_blk[((2)*(nblks_c) + (__w0))*(nproma) + (__w1)])))*((nlev + 1)) + (jk0))*(nproma) + (((int64_t)(p_patch_cells_neighbor_idx[((2)*(nblks_c) + (__w0))*(nproma) + (__w1)])))] * p_int_geofac_n2s[((__w0)*(4) + (3))*(nproma) + (__w1)]));
                }
              }
              /* numpy: np.where(mask, difcoef_c * p_patch_cells_area * lap, 0.0) */
              for (int64_t __r0 = 0; __r0 < nblks_c; ++__r0) {
                for (int64_t __r1 = 0; __r1 < nproma; ++__r1) {
                  __cb8[(__r0)*(nproma) + (__r1)] = (mask[(__r0)*(nproma) + (__r1)] ? ((difcoef_c[(__r0)*(nproma) + (__r1)] * p_patch_cells_area[(__r0)*(nproma) + (__r1)]) * lap[(__r0)*(nproma) + (__r1)]) : 0.0);
                }
              }
              for (int64_t si1 = 0; si1 < nblks_c; ++si1) {
                for (int64_t si3 = 0; si3 < nproma; ++si3) {
                  p_diag_ddt_w_adv_pc[(((t)*(nblks_c) + (si1))*((nlev + 1)) + (jk0))*(nproma) + (si3)] += __cb8[(si1)*(nproma) + (si3)];
                }
              }
            }
          }
        }
        for (int64_t si0 = 0; si0 < nblks_c; ++si0) {
          for (int64_t si1 = 0; si1 < nlev; ++si1) {
            for (int64_t si2 = 0; si2 < nproma; ++si2) {
              __cb9[((si0)*(nlev) + (si1))*(nproma) + (si2)] = cfl_clip[((si0)*(nlevp1) + (si1))*(nproma) + (si2)];
            }
          }
        }
        /* numpy: np.any(cfl_clip[:, :nlev, :], axis=(0, 2)) */
        for (int64_t __ax0 = 0; __ax0 < nlev; ++__ax0) {
          levelmask[__ax0] = 0;
          for (int64_t __rd0 = 0; __rd0 < nblks_c; ++__rd0) {
            for (int64_t __rd1 = 0; __rd1 < nproma; ++__rd1) {
              if ((__cb9[((__rd0)*(nlev) + (__ax0))*(nproma) + (__rd1)] != 0)) {
                levelmask[__ax0] = 1;
              }
            }
          }
        }
        for (int64_t jk = 0; jk < nlev; ++jk) {
          for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
              ekc1[(__w0)*(nproma) + (__w1)] = z_ekinh[((((int64_t)(p_patch_edges_cell_blk[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_edges_cell_idx[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))];
            }
          }
          for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
              ekc2[(__w0)*(nproma) + (__w1)] = z_ekinh[((((int64_t)(p_patch_edges_cell_blk[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_edges_cell_idx[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))];
            }
          }
          for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
              zv1[(__w0)*(nproma) + (__w1)] = zeta[((((int64_t)(p_patch_edges_vertex_blk[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_edges_vertex_idx[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))];
            }
          }
          for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
              zv2[(__w0)*(nproma) + (__w1)] = zeta[((((int64_t)(p_patch_edges_vertex_blk[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_edges_vertex_idx[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))];
            }
          }
          for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
              wcf1[(__w0)*(nproma) + (__w1)] = z_w_con_c_full[((((int64_t)(p_patch_edges_cell_blk[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_edges_cell_idx[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))];
            }
          }
          for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
              wcf2[(__w0)*(nproma) + (__w1)] = z_w_con_c_full[((((int64_t)(p_patch_edges_cell_blk[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk))*(nproma) + (((int64_t)(p_patch_edges_cell_idx[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))];
            }
          }
          for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
              clin[(__w0)*(nproma) + (__w1)] = ((p_int_c_lin_e[((__w0)*(2) + (0))*(nproma) + (__w1)] * wcf1[(__w0)*(nproma) + (__w1)]) + (p_int_c_lin_e[((__w0)*(2) + (1))*(nproma) + (__w1)] * wcf2[(__w0)*(nproma) + (__w1)]));
            }
          }
          for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
              grad_ekin[(__w0)*(nproma) + (__w1)] = (((z_kin_hor_e[((__w0)*(nlev) + (jk))*(nproma) + (__w1)] * (p_metrics_coeff_gradekin[((__w0)*(2) + (0))*(nproma) + (__w1)] - p_metrics_coeff_gradekin[((__w0)*(2) + (1))*(nproma) + (__w1)])) + (p_metrics_coeff_gradekin[((__w0)*(2) + (1))*(nproma) + (__w1)] * ekc2[(__w0)*(nproma) + (__w1)])) - (p_metrics_coeff_gradekin[((__w0)*(2) + (0))*(nproma) + (__w1)] * ekc1[(__w0)*(nproma) + (__w1)]));
            }
          }
          if ((!ldeepatmo)) {
            for (int64_t si1 = 0; si1 < nblks_e; ++si1) {
              for (int64_t si3 = 0; si3 < nproma; ++si3) {
                p_diag_ddt_vn_apc_pc[(((t)*(nblks_e) + (si1))*(nlev) + (jk))*(nproma) + (si3)] = (-((grad_ekin[(si1)*(nproma) + (si3)] + (p_diag_vt[((si1)*(nlev) + (jk))*(nproma) + (si3)] * (p_patch_edges_f_e[(si1)*(nproma) + (si3)] + (0.5 * (zv1[(si1)*(nproma) + (si3)] + zv2[(si1)*(nproma) + (si3)]))))) + ((clin[(si1)*(nproma) + (si3)] * (p_diag_vn_ie[((si1)*((nlev + 1)) + (jk))*(nproma) + (si3)] - p_diag_vn_ie[((si1)*((nlev + 1)) + ((jk + 1)))*(nproma) + (si3)])) / p_metrics_ddqz_z_full_e[((si1)*(nlev) + (jk))*(nproma) + (si3)])));
              }
            }
            if (ddt_vn_cor_associated) {
              for (int64_t si1 = 0; si1 < nblks_e; ++si1) {
                for (int64_t si3 = 0; si3 < nproma; ++si3) {
                  p_diag_ddt_vn_cor_pc[(((t)*(nblks_e) + (si1))*(nlev) + (jk))*(nproma) + (si3)] = ((-p_diag_vt[((si1)*(nlev) + (jk))*(nproma) + (si3)]) * p_patch_edges_f_e[(si1)*(nproma) + (si3)]);
                }
              }
            }
          }
          else {
            for (int64_t si1 = 0; si1 < nblks_e; ++si1) {
              for (int64_t si3 = 0; si3 < nproma; ++si3) {
                p_diag_ddt_vn_apc_pc[(((t)*(nblks_e) + (si1))*(nlev) + (jk))*(nproma) + (si3)] = (-(((grad_ekin[(si1)*(nproma) + (si3)] * p_metrics_deepatmo_gradh_mc[jk]) + (p_diag_vt[((si1)*(nlev) + (jk))*(nproma) + (si3)] * (p_patch_edges_f_e[(si1)*(nproma) + (si3)] + ((0.5 * (zv1[(si1)*(nproma) + (si3)] + zv2[(si1)*(nproma) + (si3)])) * p_metrics_deepatmo_gradh_mc[jk])))) + (clin[(si1)*(nproma) + (si3)] * ((((p_diag_vn_ie[((si1)*((nlev + 1)) + (jk))*(nproma) + (si3)] - p_diag_vn_ie[((si1)*((nlev + 1)) + ((jk + 1)))*(nproma) + (si3)]) / p_metrics_ddqz_z_full_e[((si1)*(nlev) + (jk))*(nproma) + (si3)]) + (p_prog_vn[((si1)*(nlev) + (jk))*(nproma) + (si3)] * p_metrics_deepatmo_invr_mc[jk])) - p_patch_edges_ft_e[(si1)*(nproma) + (si3)]))));
              }
            }
            if (ddt_vn_cor_associated) {
              for (int64_t si1 = 0; si1 < nblks_e; ++si1) {
                for (int64_t si3 = 0; si3 < nproma; ++si3) {
                  p_diag_ddt_vn_cor_pc[(((t)*(nblks_e) + (si1))*(nlev) + (jk))*(nproma) + (si3)] = (-((p_diag_vt[((si1)*(nlev) + (jk))*(nproma) + (si3)] * p_patch_edges_f_e[(si1)*(nproma) + (si3)]) + (clin[(si1)*(nproma) + (si3)] * (-p_patch_edges_ft_e[(si1)*(nproma) + (si3)]))));
                }
              }
            }
          }
        }
        if (lextra_diffu) {
          for (int64_t jk1 = max(3, (nrdmax_jg - 2)); jk1 < ((nlev - 4) + 1); ++jk1) {
            jk0 = (jk1 - 1);
            if ((!(levelmask[jk0] || levelmask[(jk0 + 1)]))) {
              continue;
            }
            for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                w_con_e[(__w0)*(nproma) + (__w1)] = ((p_int_c_lin_e[((__w0)*(2) + (0))*(nproma) + (__w1)] * z_w_con_c_full[((((int64_t)(p_patch_edges_cell_blk[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk0))*(nproma) + (((int64_t)(p_patch_edges_cell_idx[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))]) + (p_int_c_lin_e[((__w0)*(2) + (1))*(nproma) + (__w1)] * z_w_con_c_full[((((int64_t)(p_patch_edges_cell_blk[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk0))*(nproma) + (((int64_t)(p_patch_edges_cell_idx[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))]));
              }
            }
            for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                clip_e[(__w0)*(nproma) + (__w1)] = (fabs(w_con_e[(__w0)*(nproma) + (__w1)]) > (cfl_w_limit * p_metrics_ddqz_z_full_e[((__w0)*(nlev) + (jk0))*(nproma) + (__w1)]));
              }
            }
            /* numpy: np.minimum(0.85 - cfl_w_limit * dtime, fabs(w_con_e) * dtime / p_metrics_ddqz_z_full_e[:, jk0... */
            for (int64_t __r0 = 0; __r0 < nblks_e; ++__r0) {
              for (int64_t __r1 = 0; __r1 < nproma; ++__r1) {
                __cb11[(__r0)*(nproma) + (__r1)] = min((0.85 - (cfl_w_limit * dtime)), (((fabs(w_con_e[(__r0)*(nproma) + (__r1)]) * dtime) / p_metrics_ddqz_z_full_e[((__r0)*(nlev) + (jk0))*(nproma) + (__r1)]) - (cfl_w_limit * dtime)));
              }
            }
            for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                difcoef_e[(__w0)*(nproma) + (__w1)] = (scalfac_exdiff * __cb11[(__w0)*(nproma) + (__w1)]);
              }
            }
            for (int64_t __w0 = 0; __w0 < nblks_e; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nproma; ++__w1) {
                grad[(__w0)*(nproma) + (__w1)] = ((((((p_int_geofac_grdiv[((__w0)*(5) + (0))*(nproma) + (__w1)] * p_prog_vn[((__w0)*(nlev) + (jk0))*(nproma) + (__w1)]) + (p_int_geofac_grdiv[((__w0)*(5) + (1))*(nproma) + (__w1)] * p_prog_vn[((((int64_t)(p_patch_edges_quad_blk[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk0))*(nproma) + (((int64_t)(p_patch_edges_quad_idx[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))])) + (p_int_geofac_grdiv[((__w0)*(5) + (2))*(nproma) + (__w1)] * p_prog_vn[((((int64_t)(p_patch_edges_quad_blk[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk0))*(nproma) + (((int64_t)(p_patch_edges_quad_idx[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))])) + (p_int_geofac_grdiv[((__w0)*(5) + (3))*(nproma) + (__w1)] * p_prog_vn[((((int64_t)(p_patch_edges_quad_blk[((2)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk0))*(nproma) + (((int64_t)(p_patch_edges_quad_idx[((2)*(nblks_e) + (__w0))*(nproma) + (__w1)])))])) + (p_int_geofac_grdiv[((__w0)*(5) + (4))*(nproma) + (__w1)] * p_prog_vn[((((int64_t)(p_patch_edges_quad_blk[((3)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk0))*(nproma) + (((int64_t)(p_patch_edges_quad_idx[((3)*(nblks_e) + (__w0))*(nproma) + (__w1)])))])) + ((p_patch_edges_tangent_orientation[(__w0)*(nproma) + (__w1)] * p_patch_edges_inv_primal_edge_length[(__w0)*(nproma) + (__w1)]) * (zeta[((((int64_t)(p_patch_edges_vertex_blk[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk0))*(nproma) + (((int64_t)(p_patch_edges_vertex_idx[((1)*(nblks_e) + (__w0))*(nproma) + (__w1)])))] - zeta[((((int64_t)(p_patch_edges_vertex_blk[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))*(nlev) + (jk0))*(nproma) + (((int64_t)(p_patch_edges_vertex_idx[((0)*(nblks_e) + (__w0))*(nproma) + (__w1)])))])));
              }
            }
            /* numpy: np.where(clip_e, difcoef_e * p_patch_edges_area_edge * grad, 0.0) */
            for (int64_t __r0 = 0; __r0 < nblks_e; ++__r0) {
              for (int64_t __r1 = 0; __r1 < nproma; ++__r1) {
                __cb12[(__r0)*(nproma) + (__r1)] = (clip_e[(__r0)*(nproma) + (__r1)] ? ((difcoef_e[(__r0)*(nproma) + (__r1)] * p_patch_edges_area_edge[(__r0)*(nproma) + (__r1)]) * grad[(__r0)*(nproma) + (__r1)]) : 0.0);
              }
            }
            for (int64_t si1 = 0; si1 < nblks_e; ++si1) {
              for (int64_t si3 = 0; si3 < nproma; ++si3) {
                p_diag_ddt_vn_apc_pc[(((t)*(nblks_e) + (si1))*(nlev) + (jk0))*(nproma) + (si3)] += __cb12[(si1)*(nproma) + (si3)];
              }
            }
          }
        }
        free(z_w_v);
        free(acc_zwv);
        free(zeta);
        free(acc_zeta);
        free(acc_vt);
        free(z_v_grad_w);
        free(z_ekinh);
        free(acc_ek);
        free(acc_wcm);
        free(z_w_con_c);
        free(vcflmax);
        free(cfl_clip);
        free(z_w_con_c_full);
        free(acc_dwa);
        free(__cb7);
        free(__cb8);
        free(__cb9);
        free(__cb11);
        free(__cb12);
        free(levelmask);
        free(owner);
        free(mask);
        free(difcoef_c);
        free(lap);
        free(clin);
        free(grad_ekin);
        free(w_con_e);
        free(clip_e);
        free(difcoef_e);
        free(grad);
        free(ekc1);
        free(ekc2);
        free(zv1);
        free(zv2);
        free(wcf1);
        free(wcf2);
        free(we);
        free(wc);
        free(__cb1);
        free(__cb4);
        free(__cb5);
        free(clip);
        free(vcfl);
        free(abs_vcfl_masked);
        free(lo_clip);
        free(hi_clip);
        free(h);
        free(zc);
}
