// Optimized implementation of warpx_boris_push_fp64
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <omp.h>

static const double dt = 1e-13;               // time step
static const double inv_c2 = 1.1126500560536185e-17; // 1/c^2 constant

void warpx_boris_push_fp64(
    const double *restrict Bx,
    const double *restrict By,
    const double *restrict Bz,
    const double *restrict Ex,
    const double *restrict Ey,
    const double *restrict Ez,
    double *restrict ux,
    double *restrict uy,
    double *restrict uz,
    const double m,
    const int64_t momentum_push_type,
    const int64_t np_particles,
    const int64_t nsteps,
    const double q,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    const double halfE = (0.5 * q) * dt / m; // common factor for electric push and magnetic term
    const int64_t mpt = momentum_push_type; // copy to local variable

    for (int64_t step = 0; step < nsteps; ++step) {
        /* First half electric push (if requested) */
        if (mpt == 0 || mpt == 1) {
            #pragma omp parallel for schedule(static)
            for (int64_t i = 0; i < np_particles; ++i) {
                ux[i] += halfE * Ex[i];
                uy[i] += halfE * Ey[i];
                uz[i] += halfE * Ez[i];
            }
        }

        /* Magnetic rotation (B push) and final electric push */
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < np_particles; ++i) {
            // Compute gamma and its inverse based on current momentum
            double v2 = ux[i] * ux[i] + uy[i] * uy[i] + uz[i] * uz[i];
            double gamma = sqrt(1.0 + v2 * inv_c2);
            double inv_gamma = 1.0 / gamma;

            // If magnetic push is required, perform the Boris rotation
            if (mpt == 1 || mpt == 2) {
                // t = (q*dt/(2*m)) * inv_gamma * B
                double tx = halfE * inv_gamma * Bx[i];
                double ty = halfE * inv_gamma * By[i];
                double tz = halfE * inv_gamma * Bz[i];

                // Compute factor = (sqrt(1 + t^2) - 1) / t^2   (or 0.5 when t^2 == 0)
                double tsq = tx * tx + ty * ty + tz * tz;
                double factor = (tsq > 0.0) ? ((sqrt(1.0 + tsq) - 1.0) / tsq) : 0.5;
                tx *= factor;
                ty *= factor;
                tz *= factor;

                // s = 2 * t / (1 + t^2)
                double tsqi = 2.0 / (1.0 + tx * tx + ty * ty + tz * tz);
                double sx = tx * tsqi;
                double sy = ty * tsqi;
                double sz = tz * tsqi;

                // u' = u + (u x t)
                double ux_p = ux[i] + (uy[i] * tz) - (uz[i] * ty);
                double uy_p = uy[i] + (uz[i] * tx) - (ux[i] * tz);
                double uz_p = uz[i] + (ux[i] * ty) - (uy[i] * tx);

                // u = u' + (u' x s)
                ux[i] += (uy_p * sz) - (uz_p * sy);
                uy[i] += (uz_p * sx) - (ux_p * sz);
                uz[i] += (ux_p * sy) - (uy_p * sx);
            }
        }

        /* Second half electric push (if requested) */
        if (mpt == 0 || mpt == 2) {
            #pragma omp parallel for schedule(static)
            for (int64_t i = 0; i < np_particles; ++i) {
                ux[i] += halfE * Ex[i];
                uy[i] += halfE * Ey[i];
                uz[i] += halfE * Ez[i];
            }
        }
    }
    // workspace unused; kept to match signature
    (void)workspace; (void)workspace_size;
}

