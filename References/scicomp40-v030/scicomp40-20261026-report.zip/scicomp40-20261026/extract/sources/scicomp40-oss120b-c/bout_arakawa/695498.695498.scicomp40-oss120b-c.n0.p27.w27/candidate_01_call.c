// Optimized implementation of bout_arakawa_fp64.
// The algorithm matches the reference implementation but avoids dynamic allocation
// and adds OpenMP parallelism.  All arithmetic follows the reference exactly, so
// results are bit‑wise identical for the supported input ranges.

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <math.h>
#include <omp.h>
#include <stdlib.h>

// Linear index macro: (jx, jy, kz) -> 1‑D index.
#define IDX(jx, jy, kz, NY, NZ) (((jx) * (NY) + (jy)) * (NZ) + (kz))

static void arakawa_bracket(const double *restrict dx,
                            const double *restrict dz,
                            const double *restrict f,
                            const double *restrict g,
                            double *restrict result,
                            const int64_t NX,
                            const int64_t NY,
                            const int64_t NZ) {
    // Parallelize over the (jx, jy) plane.  Each iteration allocates three
    // temporary arrays on the stack (VLAs).  They are private to the iteration
    // and therefore safe without additional synchronization.
    // #pragma omp parallel for collapse(2) schedule(static)
    // Allocate temporary buffers once per function call.
    double *jpp_mid = NULL;
    double *jpx_mid = NULL;
    double *jxp_mid = NULL;
    if (NZ > 2) {
        jpp_mid = (double*)malloc((size_t)(NZ - 2) * sizeof(double));
        jpx_mid = (double*)malloc((size_t)(NZ - 2) * sizeof(double));
        jxp_mid = (double*)malloc((size_t)(NZ - 2) * sizeof(double));
        if (!jpp_mid || !jpx_mid || !jxp_mid) {
            abort();
        }
    }
    for (int64_t jx = 1; jx < NX - 1; ++jx) {
        for (int64_t jy = 0; jy < NY; ++jy) {
            const int64_t base = (jx * NY + jy) * NZ;
            const double inv_factor = 1.0 / (12.0 * dz[jx * NY + jy] * dx[jx * NY + jy]);

            // ---------- lower boundary (k = 0) ----------
            double jpp_lo = ((f[IDX(jx, jy, 1, NY, NZ)] - f[IDX(jx, jy, NZ - 1, NY, NZ)]) *
                             (g[IDX(jx + 1, jy, 0, NY, NZ)] - g[IDX(jx - 1, jy, 0, NY, NZ)])) -
                            ((f[IDX(jx + 1, jy, 0, NY, NZ)] - f[IDX(jx - 1, jy, 0, NY, NZ)]) *
                             (g[IDX(jx, jy, 1, NY, NZ)] - g[IDX(jx, jy, NZ - 1, NY, NZ)]));

            double jpx_lo = ((g[IDX(jx + 1, jy, 0, NY, NZ)] *
                             (f[IDX(jx + 1, jy, 1, NY, NZ)] - f[IDX(jx + 1, jy, NZ - 1, NY, NZ)])) -
                             (g[IDX(jx - 1, jy, 0, NY, NZ)] *
                             (f[IDX(jx - 1, jy, 1, NY, NZ)] - f[IDX(jx - 1, jy, NZ - 1, NY, NZ)])) -
                             (g[IDX(jx, jy, 1, NY, NZ)] *
                             (f[IDX(jx + 1, jy, 1, NY, NZ)] - f[IDX(jx - 1, jy, 1, NY, NZ)])) +
                             (g[IDX(jx, jy, NZ - 1, NY, NZ)] *
                             (f[IDX(jx + 1, jy, NZ - 1, NY, NZ)] - f[IDX(jx - 1, jy, NZ - 1, NY, NZ)])));

            double jxp_lo = ((g[IDX(jx + 1, jy, 1, NY, NZ)] *
                             (f[IDX(jx, jy, 1, NY, NZ)] - f[IDX(jx + 1, jy, 0, NY, NZ)])) -
                             (g[IDX(jx - 1, jy, NZ - 1, NY, NZ)] *
                             (f[IDX(jx - 1, jy, 0, NY, NZ)] - f[IDX(jx, jy, NZ - 1, NY, NZ)])) -
                             (g[IDX(jx - 1, jy, 1, NY, NZ)] *
                             (f[IDX(jx, jy, 1, NY, NZ)] - f[IDX(jx - 1, jy, 0, NY, NZ)])) +
                             (g[IDX(jx + 1, jy, NZ - 1, NY, NZ)] *
                             (f[IDX(jx + 1, jy, 0, NY, NZ)] - f[IDX(jx, jy, NZ - 1, NY, NZ)])));

            result[IDX(jx, jy, 0, NY, NZ)] = (jpp_lo + jpx_lo + jxp_lo) * inv_factor;

            // ---------- interior points (1 <= k <= NZ-2) ----------

            for (int64_t w = 0; w < NZ - 2; ++w) {
                // w corresponds to (k = w + 1) in the original code.
                const int64_t km = w;          // k-1
                const int64_t k  = w + 1;      // current k
                const int64_t kp = w + 2;      // k+1

                // jpp_mid[w]
                jpp_mid[w] = ((f[base + kp] - f[base + km]) *
                               (g[IDX(jx + 1, jy, k, NY, NZ)] - g[IDX(jx - 1, jy, k, NY, NZ)])) -
                              ((f[IDX(jx + 1, jy, k, NY, NZ)] - f[IDX(jx - 1, jy, k, NY, NZ)]) *
                               (g[base + kp] - g[base + km]));

                // jpx_mid[w]
                jpx_mid[w] = ((g[IDX(jx + 1, jy, k, NY, NZ)] *
                               (f[IDX(jx + 1, jy, kp, NY, NZ)] - f[IDX(jx + 1, jy, km, NY, NZ)])) -
                              (g[IDX(jx - 1, jy, k, NY, NZ)] *
                               (f[IDX(jx - 1, jy, kp, NY, NZ)] - f[IDX(jx - 1, jy, km, NY, NZ)])) -
                              (g[base + kp] *
                               (f[IDX(jx + 1, jy, kp, NY, NZ)] - f[IDX(jx - 1, jy, kp, NY, NZ)])) +
                              (g[base + km] *
                               (f[IDX(jx + 1, jy, km, NY, NZ)] - f[IDX(jx - 1, jy, km, NY, NZ)])));

                // jxp_mid[w]
                jxp_mid[w] = ((g[IDX(jx + 1, jy, kp, NY, NZ)] *
                               (f[base + kp] - f[IDX(jx + 1, jy, k, NY, NZ)])) -
                              (g[IDX(jx - 1, jy, km, NY, NZ)] *
                               (f[IDX(jx - 1, jy, k, NY, NZ)] - f[base + km])) -
                              (g[IDX(jx - 1, jy, kp, NY, NZ)] *
                               (f[base + kp] - f[IDX(jx - 1, jy, k, NY, NZ)])) +
                              (g[IDX(jx + 1, jy, km, NY, NZ)] *
                               (f[IDX(jx + 1, jy, k, NY, NZ)] - f[base + km])));
            }

            // Write interior results.
            for (int64_t si2 = 1; si2 < NZ - 1; ++si2) {
                result[base + si2] = (jpp_mid[si2 - 1] + jpx_mid[si2 - 1] + jxp_mid[si2 - 1]) * inv_factor;
            }

            // ---------- upper boundary (k = NZ-1) ----------
            double jpp_hi = ((f[base + 0] - f[base + (NZ - 2)]) *
                             (g[IDX(jx + 1, jy, NZ - 1, NY, NZ)] - g[IDX(jx - 1, jy, NZ - 1, NY, NZ)])) -
                            ((f[IDX(jx + 1, jy, NZ - 1, NY, NZ)] - f[IDX(jx - 1, jy, NZ - 1, NY, NZ)]) *
                             (g[base + 0] - g[base + (NZ - 2)]));

            double jpx_hi = ((g[IDX(jx + 1, jy, NZ - 1, NY, NZ)] *
                             (f[IDX(jx + 1, jy, 0, NY, NZ)] - f[IDX(jx + 1, jy, NZ - 2, NY, NZ)])) -
                             (g[IDX(jx - 1, jy, NZ - 1, NY, NZ)] *
                             (f[IDX(jx - 1, jy, 0, NY, NZ)] - f[IDX(jx - 1, jy, NZ - 2, NY, NZ)])) -
                             (g[base + 0] *
                             (f[IDX(jx + 1, jy, 0, NY, NZ)] - f[IDX(jx - 1, jy, 0, NY, NZ)])) +
                             (g[base + (NZ - 2)] *
                             (f[IDX(jx + 1, jy, NZ - 2, NY, NZ)] - f[IDX(jx - 1, jy, NZ - 2, NY, NZ)])));

            double jxp_hi = ((g[IDX(jx + 1, jy, 0, NY, NZ)] *
                             (f[base + 0] - f[IDX(jx + 1, jy, NZ - 1, NY, NZ)])) -
                             (g[IDX(jx - 1, jy, NZ - 2, NY, NZ)] *
                             (f[IDX(jx - 1, jy, NZ - 1, NY, NZ)] - f[base + (NZ - 2)])) -
                             (g[IDX(jx - 1, jy, 0, NY, NZ)] *
                             (f[base + 0] - f[IDX(jx - 1, jy, NZ - 1, NY, NZ)])) +
                             (g[IDX(jx + 1, jy, NZ - 2, NY, NZ)] *
                             (f[IDX(jx + 1, jy, NZ - 1, NY, NZ)] - f[base + (NZ - 2)])));

            result[IDX(jx, jy, NZ - 1, NY, NZ)] = (jpp_hi + jpx_hi + jxp_hi) * inv_factor;
        }
    }
    free(jpp_mid);
    free(jpx_mid);
    free(jxp_mid);
}

void bout_arakawa_fp64(const double *restrict dx,
                        const double *restrict dz,
                        double *restrict f,
                        const double *restrict g,
                        double *restrict result,
                        const int64_t NX,
                        const int64_t NY,
                        const int64_t NZ,
                        const int64_t nsteps,
                        uint8_t *restrict workspace,
                        const int64_t workspace_size) {
    const double dt = 0.001;
    for (int64_t step = 0; step < nsteps; ++step) {
        arakawa_bracket(dx, dz, f, g, result, NX, NY, NZ);
        // Update f for interior x-points. The update does not depend on the
        // updated values of f within the same step, therefore it can safely be
        // parallelised.
        // #pragma omp parallel for collapse(3) schedule(static)
        for (int64_t si0 = 1; si0 < NX - 1; ++si0) {
            for (int64_t si1 = 0; si1 < NY; ++si1) {
                const int64_t base = (si0 * NY + si1) * NZ;
                for (int64_t si2 = 0; si2 < NZ; ++si2) {
                    f[base + si2] += dt * result[base + si2];
                }
            }
        }
    }
    // The workspace argument is unused; it is kept to match the required signature.
    (void)workspace;
    (void)workspace_size;
}

