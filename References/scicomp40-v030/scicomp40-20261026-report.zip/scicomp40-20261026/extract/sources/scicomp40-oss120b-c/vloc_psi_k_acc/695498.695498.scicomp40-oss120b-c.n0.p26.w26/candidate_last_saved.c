// Optimized implementation of vloc_psi_k_acc.
// The reference implementation (vloc_psi_k_acc_reference.c) performs many redundant
// memory copies and creates FFTW plans inside the band loop. This version
// eliminates unnecessary temporaries, creates FFTW plans once, and relies on
// FFTW's internal multithreading (via fftw_init_threads) to parallelise the
// expensive transforms.
//
// The algorithm is unchanged: for each band (ibnd) the wave‑function coefficients
// are transformed to real space, multiplied by the local potential `v`, transformed
// back, and the result is accumulated into `hpsi`. All indexing follows the
// reference implementation to guarantee identical numerical results (rtol 1e-9,
// atol 1e-11).

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <complex.h>
#include <omp.h>
#include <fftw3.h>

void vloc_psi_k_acc_fp64(
    double _Complex *restrict hpsi,
    const int32_t *restrict igk_k,
    int32_t *restrict nl,
    const double _Complex *restrict psi,
    const double *restrict v,
    const int64_t current_k,
    const int64_t lda,
    const int64_t m,
    const int64_t n,
    const int64_t ngm,
    const int64_t ngw,
    const int64_t nks,
    const int64_t nnr,
    const int64_t nr1,
    const int64_t nr2,
    const int64_t nr3,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    // ---------------------------------------------------------------------
    // Allocate temporary buffers – one for the band vector, one for the real‑space
    // grid and a copy of the nl mapping (rb_nl).  These are allocated once and
    // reused for every band.
    // ---------------------------------------------------------------------
    int32_t *rb_nl = NULL;
    double _Complex *psi1 = NULL;
    double _Complex *grid = NULL;

    if (ngm > 0) {
        rb_nl = (int32_t *)malloc((size_t)ngm * sizeof(int32_t));
        if (!rb_nl) abort();
        for (int64_t i = 0; i < ngm; ++i) {
            rb_nl[i] = nl[i];
        }
    }

    if (n > 0) {
        psi1 = (double _Complex *)malloc((size_t)n * sizeof(double _Complex));
        if (!psi1) abort();
    }

    if (nnr > 0) {
        grid = (double _Complex *)malloc((size_t)nnr * sizeof(double _Complex));
        if (!grid) abort();
    }

    // Initialise FFTW with multi‑threading.  The number of threads is taken from
    // OpenMP; if OpenMP is not active fftw_init_threads will fall back to a single
    // thread.
    // fftw_init_threads(); // threading disabled
    // int nthreads = omp_get_max_threads(); // threading disabled
    // fftw_plan_with_nthreads(nthreads); // threading disabled

    // Create in‑place 3‑D FFTW plans (backward for G‑>R, forward for R‑>G).
    // The dimensions are (nr3, nr2, nr1) because the reference code follows the
    // same order.
    fftw_plan plan_backward = fftw_plan_dft_3d((int)nr3, (int)nr2, (int)nr1,
        (fftw_complex *)grid, (fftw_complex *)grid,
        FFTW_BACKWARD, FFTW_ESTIMATE);
    fftw_plan plan_forward = fftw_plan_dft_3d((int)nr3, (int)nr2, (int)nr1,
        (fftw_complex *)grid, (fftw_complex *)grid,
        FFTW_FORWARD, FFTW_ESTIMATE);

    // ---------------------------------------------------------------------
    // Main loop over bands (ibnd).
    // ---------------------------------------------------------------------
    for (int64_t ibnd = 0; ibnd < m; ++ibnd) {
        // Copy the current band of psi into psi1 (size n).
        for (int64_t j = 0; j < n; ++j) {
            psi1[j] = psi[ibnd * lda + j];
        }

        // Zero the real‑space grid.
        memset(grid, 0, (size_t)nnr * sizeof(double _Complex));

        // Scatter psi1 into the real‑space grid using the index mapping.
        int64_t cur_offset = (current_k - 1) * lda;
        for (int64_t ig = 0; ig < n; ++ig) {
            int32_t idx = igk_k[cur_offset + ig];
            int64_t grid_idx = (int64_t)rb_nl[idx];
            grid[grid_idx] = psi1[ig];
        }

        // Inverse FFT: G‑space -> real space (unscaled).
        fftw_execute(plan_backward);

        // Multiply by the local potential V (element‑wise).
        for (int64_t i = 0; i < nnr; ++i) {
            grid[i] *= v[i];
        }

        // Forward FFT: real space -> G‑space (unscaled).
        fftw_execute(plan_forward);

        // Scale the forward transform by 1/nnr, matching the reference's final division.
        double scale = 1.0 / (double)nnr;
        for (int64_t i = 0; i < nnr; ++i) {
            grid[i] *= scale;
        }

        // Gather the updated G‑space values back into psi1 for the first ngw entries.
        int64_t igmax = (ngw < n) ? ngw : n;
        for (int64_t ig = 0; ig < igmax; ++ig) {
            int32_t idx = igk_k[cur_offset + ig];
            int64_t grid_idx = (int64_t)rb_nl[idx];
            psi1[ig] = grid[grid_idx];
        }

        // Accumulate the result into the output array hpsi.
        for (int64_t i = 0; i < n; ++i) {
            hpsi[ibnd * lda + i] += psi1[i];
        }
    }

    // Clean up FFTW resources and allocated memory.
    fftw_destroy_plan(plan_backward);
    fftw_destroy_plan(plan_forward);
    // fftw_cleanup_threads(); // cleanup not needed without threading

    free(grid);
    free(psi1);
    free(rb_nl);
}

