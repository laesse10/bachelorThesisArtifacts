// hpcagent_bench-autogen -- generated from vloc_psi_k_acc_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}
#include <fftw3.h>

void vloc_psi_k_acc_fp64(double _Complex *restrict hpsi, const int32_t *restrict igk_k, const int32_t *restrict nl, const double _Complex *restrict psi, const double *restrict v, const int64_t current_k, const int64_t lda, const int64_t m, const int64_t n, const int64_t ngm, const int64_t ngw, const int64_t nks, const int64_t nnr, const int64_t nr1, const int64_t nr2, const int64_t nr3, uint8_t *restrict workspace, const int64_t workspace_size) {
        int64_t __inl1_npw;
        int64_t __inl6_igmax;
        double _Complex *psi1 = (double _Complex *)malloc((size_t)((n) * (1)) * sizeof(double _Complex));
        __npb_alloc_check(psi1, (size_t)((n) * (1)) * sizeof(double _Complex), "psi1");
        memset(psi1, 0, (size_t)((n) * (1)) * sizeof(double _Complex));
        double _Complex *psic = (double _Complex *)malloc((size_t)((nnr)) * sizeof(double _Complex));
        __npb_alloc_check(psic, (size_t)((nnr)) * sizeof(double _Complex), "psic");
        memset(psic, 0, (size_t)((nnr)) * sizeof(double _Complex));
        double _Complex *__cb1 = (double _Complex *)malloc((size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex));
        __npb_alloc_check(__cb1, (size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex), "__cb1");
        double _Complex *__cb2 = (double _Complex *)malloc((size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex));
        __npb_alloc_check(__cb2, (size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex), "__cb2");
        double _Complex *__cb3 = (double _Complex *)malloc((size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex));
        __npb_alloc_check(__cb3, (size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex), "__cb3");
        double _Complex *__cb4 = (double _Complex *)malloc((size_t)((nnr)) * sizeof(double _Complex));
        __npb_alloc_check(__cb4, (size_t)((nnr)) * sizeof(double _Complex), "__cb4");
        double _Complex *__cb5 = (double _Complex *)malloc((size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex));
        __npb_alloc_check(__cb5, (size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex), "__cb5");
        double _Complex *__cb6 = (double _Complex *)malloc((size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex));
        __npb_alloc_check(__cb6, (size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex), "__cb6");
        double _Complex *__cb7 = (double _Complex *)malloc((size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex));
        __npb_alloc_check(__cb7, (size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex), "__cb7");
        double _Complex *__cb8 = (double _Complex *)malloc((size_t)((nnr)) * sizeof(double _Complex));
        __npb_alloc_check(__cb8, (size_t)((nnr)) * sizeof(double _Complex), "__cb8");
        double _Complex *__inl4_grid = (double _Complex *)malloc((size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex));
        __npb_alloc_check(__inl4_grid, (size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex), "__inl4_grid");
        double _Complex *__inl5_grid = (double _Complex *)malloc((size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex));
        __npb_alloc_check(__inl5_grid, (size_t)((nr3) * (nr2) * (nr1)) * sizeof(double _Complex), "__inl5_grid");
        int32_t *__rb_nl = (int32_t *)malloc((size_t)((ngm)) * sizeof(int32_t));
        __npb_alloc_check(__rb_nl, (size_t)((ngm)) * sizeof(int32_t), "__rb_nl");
        int32_t *igk = (int32_t *)malloc((size_t)((lda)) * sizeof(int32_t));
        __npb_alloc_check(igk, (size_t)((lda)) * sizeof(int32_t), "igk");
        for (int64_t __w0 = 0; __w0 < ngm; ++__w0) {
          __rb_nl[__w0] = ((int64_t)(nl[__w0]));
        }
        memset(psi1, 0, (size_t)((n) * (1)) * sizeof(double _Complex));
        memset(psic, 0, (size_t)((nnr)) * sizeof(double _Complex));
        for (int64_t ibnd = 0; ibnd < m; ++ibnd) {
          for (int64_t j = 0; j < n; ++j) {
            psi1[(j)*(1) + (0)] = psi[((ibnd + 0))*(lda) + (j)];
          }
          __inl1_npw = n;
          for (int64_t __w0 = 0; __w0 < nnr; ++__w0) {
            psic[__w0] = 0.0;
          }
          for (int64_t __inl3_ig = 0; __inl3_ig < __inl1_npw; ++__inl3_ig) {
            psic[((int64_t)(__rb_nl[((int64_t)(igk_k[((current_k - 1))*(lda) + (__inl3_ig)]))]))] = psi1[(__inl3_ig)*(1) + ((0 + 0))];
          }
          /* numpy: np.reshape(psic, (nr3, nr2, nr1)) */
          for (int64_t __rs0 = 0; __rs0 < nr3; ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < nr2; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < nr1; ++__rs2) {
                __cb1[((__rs0)*(nr2) + (__rs1))*(nr1) + (__rs2)] = psic[(((__rs0 * (nr2 * nr1)) + (__rs1 * nr1)) + __rs2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < nr3; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nr2; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nr1; ++__w2) {
                __inl4_grid[((__w0)*(nr2) + (__w1))*(nr1) + (__w2)] = __cb1[((__w0)*(nr2) + (__w1))*(nr1) + (__w2)];
              }
            }
          }
          /* numpy: np.fft.ifftn(__inl4_grid) */
          {
            int64_t __fft_n = (int64_t)(nr3) * (int64_t)(nr2) * (int64_t)(nr1);
            int64_t __fft_batch = (int64_t)1;
            if (__fft_n > 0 && __fft_batch > 0) {
              int __fft_dims[3] = {(int)(nr3), (int)(nr2), (int)(nr1)};
              fftw_plan __fft_plan = fftw_plan_many_dft(3, __fft_dims, (int)__fft_batch, (fftw_complex *)(__inl4_grid), NULL, (int)__fft_batch, 1, (fftw_complex *)(__cb2), NULL, (int)__fft_batch, 1, FFTW_BACKWARD, FFTW_ESTIMATE);
              fftw_execute(__fft_plan);
              fftw_destroy_plan(__fft_plan);
              for (int64_t __fft_i = 0; __fft_i < __fft_n * __fft_batch; ++__fft_i) {
                __cb2[__fft_i] /= ((double)__fft_n);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < nr3; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nr2; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nr1; ++__w2) {
                __cb3[((__w0)*(nr2) + (__w1))*(nr1) + (__w2)] = (__cb2[((__w0)*(nr2) + (__w1))*(nr1) + (__w2)] * nnr);
              }
            }
          }
          /* numpy: np.reshape(__cb3, (nnr,)) */
          for (int64_t __rs0 = 0; __rs0 < nr3; ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < nr2; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < nr1; ++__rs2) {
                __cb4[(((__rs0 * (nr2 * nr1)) + (__rs1 * nr1)) + __rs2)] = __cb3[((__rs0)*(nr2) + (__rs1))*(nr1) + (__rs2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < nnr; ++__w0) {
            psic[__w0] = __cb4[__w0];
          }
          for (int64_t j = 0; j < nnr; ++j) {
            psic[j] = (psic[j] * v[j]);
          }
          /* numpy: np.reshape(psic, (nr3, nr2, nr1)) */
          for (int64_t __rs0 = 0; __rs0 < nr3; ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < nr2; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < nr1; ++__rs2) {
                __cb5[((__rs0)*(nr2) + (__rs1))*(nr1) + (__rs2)] = psic[(((__rs0 * (nr2 * nr1)) + (__rs1 * nr1)) + __rs2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < nr3; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nr2; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nr1; ++__w2) {
                __inl5_grid[((__w0)*(nr2) + (__w1))*(nr1) + (__w2)] = __cb5[((__w0)*(nr2) + (__w1))*(nr1) + (__w2)];
              }
            }
          }
          /* numpy: np.fft.fftn(__inl5_grid) */
          {
            int64_t __fft_n = (int64_t)(nr3) * (int64_t)(nr2) * (int64_t)(nr1);
            int64_t __fft_batch = (int64_t)1;
            if (__fft_n > 0 && __fft_batch > 0) {
              int __fft_dims[3] = {(int)(nr3), (int)(nr2), (int)(nr1)};
              fftw_plan __fft_plan = fftw_plan_many_dft(3, __fft_dims, (int)__fft_batch, (fftw_complex *)(__inl5_grid), NULL, (int)__fft_batch, 1, (fftw_complex *)(__cb6), NULL, (int)__fft_batch, 1, FFTW_FORWARD, FFTW_ESTIMATE);
              fftw_execute(__fft_plan);
              fftw_destroy_plan(__fft_plan);
            }
          }
          for (int64_t __w0 = 0; __w0 < nr3; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nr2; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nr1; ++__w2) {
                __cb7[((__w0)*(nr2) + (__w1))*(nr1) + (__w2)] = (__cb6[((__w0)*(nr2) + (__w1))*(nr1) + (__w2)] / nnr);
              }
            }
          }
          /* numpy: np.reshape(__cb7, (nnr,)) */
          for (int64_t __rs0 = 0; __rs0 < nr3; ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < nr2; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < nr1; ++__rs2) {
                __cb8[(((__rs0 * (nr2 * nr1)) + (__rs1 * nr1)) + __rs2)] = __cb7[((__rs0)*(nr2) + (__rs1))*(nr1) + (__rs2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < nnr; ++__w0) {
            psic[__w0] = __cb8[__w0];
          }
          __inl6_igmax = min(ngw, n);
          for (int64_t __inl6_ig = 0; __inl6_ig < __inl6_igmax; ++__inl6_ig) {
            psi1[(__inl6_ig)*(1) + (0)] = psic[((int64_t)(__rb_nl[((int64_t)(igk_k[((current_k - 1))*(lda) + (__inl6_ig)]))]))];
          }
          for (int64_t i = 0; i < n; ++i) {
            hpsi[(ibnd)*(lda) + (i)] = (hpsi[(ibnd)*(lda) + (i)] + psi1[(i)*(1) + (0)]);
          }
        }
        free(psi1);
        free(psic);
        free(__cb1);
        free(__cb2);
        free(__cb3);
        free(__cb4);
        free(__cb5);
        free(__cb6);
        free(__cb7);
        free(__cb8);
        free(__inl4_grid);
        free(__inl5_grid);
        free(__rb_nl);
        free(igk);
}
