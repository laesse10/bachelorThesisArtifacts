// hpcagent_bench-autogen -- generated from examinimd_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

void examinimd_fp64(const int32_t *restrict atom_type, const double *restrict cutsq, double *restrict f, const double *restrict lj1, const double *restrict lj2, const int32_t *restrict neigh_counts, const int32_t *restrict neigh_list, const double *restrict x, const int64_t cells_per_dim, const int64_t max_neighs, uint8_t *restrict workspace, const int64_t workspace_size) {
        int64_t __inl1_n_owned;
        int64_t __inl1_max_neighs;
        int64_t __inl1_ntypes;
        int64_t __inl1_n_pairs;
        int64_t *__cb1 = (int64_t *)malloc((size_t)((max_neighs)) * sizeof(int64_t));
        __npb_alloc_check(__cb1, (size_t)((max_neighs)) * sizeof(int64_t), "__cb1");
        double __cb4[(1)];
        double __cb5[(1)];
        double __cb6[(1)];
        int64_t *__inl1_slot = (int64_t *)malloc((size_t)((max_neighs)) * sizeof(int64_t));
        __npb_alloc_check(__inl1_slot, (size_t)((max_neighs)) * sizeof(int64_t), "__inl1_slot");
        int64_t *__cb2 = NULL;
        double *__cb3 = NULL;
        double *__cb7 = NULL;
        double *__cb8 = NULL;
        double *__cb9 = NULL;
        bool *__inl1_valid = NULL;
        int64_t *__inl1_j = NULL;
        double *__inl1_d = NULL;
        double *__inl1_d2 = NULL;
        double *__inl1_rsq = NULL;
        int64_t *__inl1_pair = NULL;
        bool *__inl1_within = NULL;
        double *__inl1_rsq_safe = NULL;
        double *__inl1_r2inv = NULL;
        double *__inl1_r6inv = NULL;
        double *__inl1_fpair = NULL;
        double *__inl1_fd = NULL;
        double *forces = NULL;
        double *__inl1_cutsq_ij = NULL;
        double *__inl1_lj1_ij = NULL;
        double *__inl1_lj2_ij = NULL;
        __inl1_n_owned = ((int64_t)((((4 * cells_per_dim) * cells_per_dim) * cells_per_dim)));
        __inl1_max_neighs = max_neighs;
        /* numpy: np.arange(max_neighs) */
        for (int64_t __i = 0; __i < max_neighs; ++__i) {
          __cb1[__i] = __i;
        }
        for (int64_t __w0 = 0; __w0 < max_neighs; ++__w0) {
          __inl1_slot[__w0] = __cb1[__w0];
        }
        free(__inl1_valid);
        __inl1_valid = (bool *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(bool));
        __npb_alloc_check(__inl1_valid, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(bool), "__inl1_valid");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_valid[(__w0)*(max_neighs) + (__w1)] = (__inl1_slot[__w1] < ((int64_t)(neigh_counts[__w0])));
          }
        }
        free(__cb2);
        __cb2 = (int64_t *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(int64_t));
        __npb_alloc_check(__cb2, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(int64_t), "__cb2");
        /* numpy: np.where(__inl1_valid, neigh_list[:__inl1_n_owned, :], 0) */
        for (int64_t __r0 = 0; __r0 < __inl1_n_owned; ++__r0) {
          for (int64_t __r1 = 0; __r1 < max_neighs; ++__r1) {
            __cb2[(__r0)*(max_neighs) + (__r1)] = (__inl1_valid[(__r0)*(max_neighs) + (__r1)] ? ((int64_t)(neigh_list[(__r0)*(max_neighs) + (__r1)])) : 0);
          }
        }
        free(__inl1_j);
        __inl1_j = (int64_t *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(int64_t));
        __npb_alloc_check(__inl1_j, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(int64_t), "__inl1_j");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_j[(__w0)*(max_neighs) + (__w1)] = __cb2[(__w0)*(max_neighs) + (__w1)];
          }
        }
        free(__inl1_d);
        __inl1_d = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs) * (3)) * sizeof(double));
        __npb_alloc_check(__inl1_d, (size_t)((__inl1_n_owned) * (max_neighs) * (3)) * sizeof(double), "__inl1_d");
        for (int64_t si0 = 0; si0 < __inl1_n_owned; ++si0) {
          for (int64_t si1 = 0; si1 < max_neighs; ++si1) {
            for (int64_t si2 = 0; si2 < 3; ++si2) {
              __inl1_d[((si0)*(max_neighs) + (si1))*(3) + (si2)] = (x[(si0)*(3) + (si2)] - x[(__inl1_j[(si0)*(max_neighs) + (si1)])*(3) + (si2)]);
            }
          }
        }
        free(__inl1_d2);
        __inl1_d2 = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs) * (3)) * sizeof(double));
        __npb_alloc_check(__inl1_d2, (size_t)((__inl1_n_owned) * (max_neighs) * (3)) * sizeof(double), "__inl1_d2");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
              __inl1_d2[((__w0)*(max_neighs) + (__w1))*(3) + (__w2)] = (__inl1_d[((__w0)*(max_neighs) + (__w1))*(3) + (__w2)] * __inl1_d[((__w0)*(max_neighs) + (__w1))*(3) + (__w2)]);
            }
          }
        }
        free(__cb3);
        __cb3 = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__cb3, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__cb3");
        /* numpy: np.sum(__inl1_d2, axis=2) */
        for (int64_t __ax0 = 0; __ax0 < __inl1_n_owned; ++__ax0) {
          for (int64_t __ax1 = 0; __ax1 < max_neighs; ++__ax1) {
            __cb3[(__ax0)*(max_neighs) + (__ax1)] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < 3; ++__rd0) {
              __cb3[(__ax0)*(max_neighs) + (__ax1)] = (__cb3[(__ax0)*(max_neighs) + (__ax1)] + __inl1_d2[((__ax0)*(max_neighs) + (__ax1))*(3) + (__rd0)]);
            }
          }
        }
        free(__inl1_rsq);
        __inl1_rsq = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__inl1_rsq, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__inl1_rsq");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_rsq[(__w0)*(max_neighs) + (__w1)] = __cb3[(__w0)*(max_neighs) + (__w1)];
          }
        }
        __inl1_ntypes = 1;
        __inl1_n_pairs = (__inl1_ntypes * __inl1_ntypes);
        free(__inl1_pair);
        __inl1_pair = (int64_t *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(int64_t));
        __npb_alloc_check(__inl1_pair, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(int64_t), "__inl1_pair");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_pair[(__w0)*(max_neighs) + (__w1)] = ((((int64_t)(atom_type[__w0])) * __inl1_ntypes) + ((int64_t)(atom_type[__inl1_j[(__w0)*(max_neighs) + (__w1)]])));
          }
        }
        /* numpy: np.reshape(cutsq, (__inl1_n_pairs,)) */
        for (int64_t __rs0 = 0; __rs0 < 1; ++__rs0) {
          __cb4[__rs0] = cutsq[(__rs0)*(1) + (0)];
        }
        free(__inl1_cutsq_ij);
        __inl1_cutsq_ij = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__inl1_cutsq_ij, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__inl1_cutsq_ij");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_cutsq_ij[(__w0)*(max_neighs) + (__w1)] = __cb4[__inl1_pair[(__w0)*(max_neighs) + (__w1)]];
          }
        }
        /* numpy: np.reshape(lj1, (__inl1_n_pairs,)) */
        for (int64_t __rs0 = 0; __rs0 < 1; ++__rs0) {
          __cb5[__rs0] = lj1[(__rs0)*(1) + (0)];
        }
        free(__inl1_lj1_ij);
        __inl1_lj1_ij = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__inl1_lj1_ij, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__inl1_lj1_ij");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_lj1_ij[(__w0)*(max_neighs) + (__w1)] = __cb5[__inl1_pair[(__w0)*(max_neighs) + (__w1)]];
          }
        }
        /* numpy: np.reshape(lj2, (__inl1_n_pairs,)) */
        for (int64_t __rs0 = 0; __rs0 < 1; ++__rs0) {
          __cb6[__rs0] = lj2[(__rs0)*(1) + (0)];
        }
        free(__inl1_lj2_ij);
        __inl1_lj2_ij = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__inl1_lj2_ij, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__inl1_lj2_ij");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_lj2_ij[(__w0)*(max_neighs) + (__w1)] = __cb6[__inl1_pair[(__w0)*(max_neighs) + (__w1)]];
          }
        }
        free(__inl1_within);
        __inl1_within = (bool *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(bool));
        __npb_alloc_check(__inl1_within, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(bool), "__inl1_within");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_within[(__w0)*(max_neighs) + (__w1)] = (__inl1_valid[(__w0)*(max_neighs) + (__w1)] & (__inl1_rsq[(__w0)*(max_neighs) + (__w1)] < __inl1_cutsq_ij[(__w0)*(max_neighs) + (__w1)]));
          }
        }
        free(__cb7);
        __cb7 = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__cb7, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__cb7");
        /* numpy: np.where(__inl1_within, __inl1_rsq, 1.0) */
        for (int64_t __r0 = 0; __r0 < __inl1_n_owned; ++__r0) {
          for (int64_t __r1 = 0; __r1 < max_neighs; ++__r1) {
            __cb7[(__r0)*(max_neighs) + (__r1)] = (__inl1_within[(__r0)*(max_neighs) + (__r1)] ? __inl1_rsq[(__r0)*(max_neighs) + (__r1)] : 1.0);
          }
        }
        free(__inl1_rsq_safe);
        __inl1_rsq_safe = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__inl1_rsq_safe, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__inl1_rsq_safe");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_rsq_safe[(__w0)*(max_neighs) + (__w1)] = __cb7[(__w0)*(max_neighs) + (__w1)];
          }
        }
        free(__inl1_r2inv);
        __inl1_r2inv = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__inl1_r2inv, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__inl1_r2inv");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_r2inv[(__w0)*(max_neighs) + (__w1)] = (1.0 / __inl1_rsq_safe[(__w0)*(max_neighs) + (__w1)]);
          }
        }
        free(__inl1_r6inv);
        __inl1_r6inv = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__inl1_r6inv, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__inl1_r6inv");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_r6inv[(__w0)*(max_neighs) + (__w1)] = ((__inl1_r2inv[(__w0)*(max_neighs) + (__w1)] * __inl1_r2inv[(__w0)*(max_neighs) + (__w1)]) * __inl1_r2inv[(__w0)*(max_neighs) + (__w1)]);
          }
        }
        free(__cb8);
        __cb8 = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__cb8, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__cb8");
        /* numpy: np.where(__inl1_within, __inl1_r6inv * (__inl1_lj1_ij * __inl1_r6inv - __inl1_lj2_ij) * __inl... */
        for (int64_t __r0 = 0; __r0 < __inl1_n_owned; ++__r0) {
          for (int64_t __r1 = 0; __r1 < max_neighs; ++__r1) {
            __cb8[(__r0)*(max_neighs) + (__r1)] = (__inl1_within[(__r0)*(max_neighs) + (__r1)] ? ((__inl1_r6inv[(__r0)*(max_neighs) + (__r1)] * ((__inl1_lj1_ij[(__r0)*(max_neighs) + (__r1)] * __inl1_r6inv[(__r0)*(max_neighs) + (__r1)]) - __inl1_lj2_ij[(__r0)*(max_neighs) + (__r1)])) * __inl1_r2inv[(__r0)*(max_neighs) + (__r1)]) : 0.0);
          }
        }
        free(__inl1_fpair);
        __inl1_fpair = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double));
        __npb_alloc_check(__inl1_fpair, (size_t)((__inl1_n_owned) * (max_neighs)) * sizeof(double), "__inl1_fpair");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            __inl1_fpair[(__w0)*(max_neighs) + (__w1)] = __cb8[(__w0)*(max_neighs) + (__w1)];
          }
        }
        free(__inl1_fd);
        __inl1_fd = (double *)malloc((size_t)((__inl1_n_owned) * (max_neighs) * (3)) * sizeof(double));
        __npb_alloc_check(__inl1_fd, (size_t)((__inl1_n_owned) * (max_neighs) * (3)) * sizeof(double), "__inl1_fd");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < max_neighs; ++__w1) {
            for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
              __inl1_fd[((__w0)*(max_neighs) + (__w1))*(3) + (__w2)] = (__inl1_fpair[(__w0)*(max_neighs) + (__w1)] * __inl1_d[((__w0)*(max_neighs) + (__w1))*(3) + (__w2)]);
            }
          }
        }
        free(__cb9);
        __cb9 = (double *)malloc((size_t)((__inl1_n_owned) * (3)) * sizeof(double));
        __npb_alloc_check(__cb9, (size_t)((__inl1_n_owned) * (3)) * sizeof(double), "__cb9");
        /* numpy: np.sum(__inl1_fd, axis=1) */
        for (int64_t __ax0 = 0; __ax0 < __inl1_n_owned; ++__ax0) {
          for (int64_t __ax1 = 0; __ax1 < 3; ++__ax1) {
            __cb9[(__ax0)*(3) + (__ax1)] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < max_neighs; ++__rd0) {
              __cb9[(__ax0)*(3) + (__ax1)] = (__cb9[(__ax0)*(3) + (__ax1)] + __inl1_fd[((__ax0)*(max_neighs) + (__rd0))*(3) + (__ax1)]);
            }
          }
        }
        free(forces);
        forces = (double *)malloc((size_t)((__inl1_n_owned) * (3)) * sizeof(double));
        __npb_alloc_check(forces, (size_t)((__inl1_n_owned) * (3)) * sizeof(double), "forces");
        for (int64_t __w0 = 0; __w0 < __inl1_n_owned; ++__w0) {
          for (int64_t __w1 = 0; __w1 < 3; ++__w1) {
            forces[(__w0)*(3) + (__w1)] = __cb9[(__w0)*(3) + (__w1)];
          }
        }
        for (int64_t si0 = 0; si0 < (((4 * cells_per_dim) * cells_per_dim) * cells_per_dim); ++si0) {
          for (int64_t si1 = 0; si1 < 3; ++si1) {
            f[(si0)*(3) + (si1)] = forces[(si0)*(3) + (si1)];
          }
        }
        free(__cb1);
        free(__inl1_slot);
        free(__cb2);
        free(__cb3);
        free(__cb7);
        free(__cb8);
        free(__cb9);
        free(__inl1_valid);
        free(__inl1_j);
        free(__inl1_d);
        free(__inl1_d2);
        free(__inl1_rsq);
        free(__inl1_pair);
        free(__inl1_within);
        free(__inl1_rsq_safe);
        free(__inl1_r2inv);
        free(__inl1_r6inv);
        free(__inl1_fpair);
        free(__inl1_fd);
        free(forces);
        free(__inl1_cutsq_ij);
        free(__inl1_lj1_ij);
        free(__inl1_lj2_ij);
}
