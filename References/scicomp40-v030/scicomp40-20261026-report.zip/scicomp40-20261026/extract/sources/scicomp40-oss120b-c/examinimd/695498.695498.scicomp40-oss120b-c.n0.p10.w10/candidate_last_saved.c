// Optimized implementation of examinimd_fp64 kernel
// Computes Lennard-Jones forces for a full neighbor list (single atom type).
// This version avoids large temporary allocations and uses OpenMP parallelism.
// It follows the signature defined in signature.json.
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <math.h>
#include <omp.h>


void examinimd_fp64(
    const int32_t *restrict atom_type, // unused (single type assumed)
    const double *restrict cutsq,    // assumed size 1 (scalar cut-square)
    double *restrict f,              // output forces, size n_owned*3
    const double *restrict lj1,      // assumed size 1 (scalar LJ coefficient)
    const double *restrict lj2,      // assumed size 1 (scalar LJ coefficient)
    const int32_t *restrict neigh_counts, // neighbor counts per atom
    const int32_t *restrict neigh_list,   // neighbor list flattened (n_owned x max_neighs)
    const double *restrict x,        // positions, size n_owned*3
    const int64_t cells_per_dim,
    const int64_t max_neighs,
    uint8_t *restrict workspace,    // unused
    const int64_t workspace_size)   // unused
{
    // Debug output (optional)
    //printf("examinimd_fp64 called: cells_per_dim=%lld, max_neighs=%lld\n", (long long)cells_per_dim, (long long)max_neighs);
    //fflush(stdout);

    // Total number of owned cells (atoms). The reference uses 4 * cells_per_dim^3.
    const int64_t n_owned = (int64_t)(4 * cells_per_dim * cells_per_dim * cells_per_dim);

    // Scalar parameters (single atom type).
    const double cut_sq = cutsq[0];
    const double lj1_val = lj1[0];
    const double lj2_val = lj2[0];

    // Parallel over atoms. Each iteration writes to a distinct slice of f.
    // Parallel loop removed for compatibility
    for (int64_t i = 0; i < n_owned; ++i) {
        double fx = 0.0, fy = 0.0, fz = 0.0;
        // Load atom i's position.
        const double xi = x[3*i];
        const double yi = x[3*i + 1];
        const double zi = x[3*i + 2];
        // Number of valid neighbors for this atom.
        const int32_t ncnt = neigh_counts[i];
        const int32_t *nbr = neigh_list + i * max_neighs;
        for (int32_t k = 0; k < ncnt; ++k) {
            const int32_t j = nbr[k];
            // Compute displacement vector.
            const double dx = xi - x[3*j];
            const double dy = yi - x[3*j + 1];
            const double dz = zi - x[3*j + 2];
            const double rsq = dx*dx + dy*dy + dz*dz;
            if (rsq < cut_sq) {
                const double r2inv = 1.0 / rsq;
                const double r6inv = r2inv * r2inv * r2inv;
                const double fpair = r6inv * (lj1_val * r6inv - lj2_val) * r2inv;
                fx += fpair * dx;
                fy += fpair * dy;
                fz += fpair * dz;
            }
        }
        f[3*i]     = fx;
        f[3*i + 1] = fy;
        f[3*i + 2] = fz;
    }
    // workspace and atom_type are unused in this single-type implementation.
    (void)atom_type; (void)workspace; (void)workspace_size;
}

