// hpcagent_bench-autogen -- generated from fv3_xppm_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

constexpr int64_t nhalo = 3;

static void xppm_flux(const double *restrict courant, const double *restrict dxa, const double *restrict q, double *restrict xflux, const int64_t grid_type, const int64_t iord, const int64_t nhalo, const int64_t ni, const int64_t nj, const int64_t nk);

static void xppm_flux(const double *restrict courant, const double *restrict dxa, const double *restrict q, double *restrict xflux, const int64_t grid_type, const int64_t iord, const int64_t nhalo, const int64_t ni, const int64_t nj, const int64_t nk) {
    double mord;
    int64_t i_start;
    int64_t i_end;
    int64_t lo;
    int64_t hi;
    double *al = (double *)malloc((size_t)((((nhalo + ni) + nhalo)) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(al, (size_t)((((nhalo + ni) + nhalo)) * (nj) * (nk)) * sizeof(double), "al");
    memset(al, 0, (size_t)((((nhalo + ni) + nhalo)) * (nj) * (nk)) * sizeof(double));
    double *__cb1 = NULL;
    double *bl = NULL;
    double *br = NULL;
    double *b0 = NULL;
    double *bl_m1 = NULL;
    double *br_m1 = NULL;
    double *b0_m1 = NULL;
    bool *smt5 = NULL;
    bool *smt5_m1 = NULL;
    double *c = NULL;
    double *q_i = NULL;
    double *q_im1 = NULL;
    double *mask = NULL;
    mord = llabs(iord);
    i_start = nhalo;
    i_end = ((nhalo + ni) - 1);
    memset(al, 0, (size_t)((((nhalo + ni) + nhalo)) * (nj) * (nk)) * sizeof(double));
    lo = (i_start - 1);
    hi = (i_end + 3);
    for (int64_t si0 = lo; si0 < hi; ++si0) {
      for (int64_t si1 = 0; si1 < nj; ++si1) {
        for (int64_t si2 = 0; si2 < nk; ++si2) {
          al[((si0)*(nj) + (si1))*(nk) + (si2)] = ((0.5833333333333334 * (q[(((si0 + ((lo - 1) - lo)))*(nj) + (si1))*(nk) + (si2)] + q[(((si0 + (lo - lo)))*(nj) + (si1))*(nk) + (si2)])) + (-0.08333333333333333 * (q[(((si0 + ((lo - 2) - lo)))*(nj) + (si1))*(nk) + (si2)] + q[(((si0 + ((lo + 1) - lo)))*(nj) + (si1))*(nk) + (si2)])));
        }
      }
    }
    if ((grid_type < 3)) {
      int64_t *ia = (int64_t *)malloc((size_t)((2)) * sizeof(int64_t));
      __npb_alloc_check(ia, (size_t)((2)) * sizeof(int64_t), "ia");
      ia[0] = (i_start - 1);
      ia[1] = i_end;
      for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
        for (int64_t __scs0 = 0; __scs0 < nj; ++__scs0) {
          for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
            al[((ia[__sc0])*(nj) + (__scs0))*(nk) + (__scs1)] = (((-0.14285714285714285 * q[(((ia[__sc0] - 2))*(nj) + (__scs0))*(nk) + (__scs1)]) + (0.7857142857142857 * q[(((ia[__sc0] - 1))*(nj) + (__scs0))*(nk) + (__scs1)])) + (0.35714285714285715 * q[((ia[__sc0])*(nj) + (__scs0))*(nk) + (__scs1)]));
          }
        }
      }
      int64_t *ib = (int64_t *)malloc((size_t)((2)) * sizeof(int64_t));
      __npb_alloc_check(ib, (size_t)((2)) * sizeof(int64_t), "ib");
      ib[0] = i_start;
      ib[1] = (i_end + 1);
      double *left = (double *)malloc((size_t)((2) * (nj) * (nk)) * sizeof(double));
      __npb_alloc_check(left, (size_t)((2) * (nj) * (nk)) * sizeof(double), "left");
      for (int64_t si0 = 0; si0 < 2; ++si0) {
        for (int64_t si1 = 0; si1 < nj; ++si1) {
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            left[((si0)*(nj) + (si1))*(nk) + (si2)] = (((((2.0 * dxa[(((ib[si0] - 1))*(nj) + (si1))*(nk) + (si2)]) + dxa[(((ib[si0] - 2))*(nj) + (si1))*(nk) + (si2)]) * q[(((ib[si0] - 1))*(nj) + (si1))*(nk) + (si2)]) - (dxa[(((ib[si0] - 1))*(nj) + (si1))*(nk) + (si2)] * q[(((ib[si0] - 2))*(nj) + (si1))*(nk) + (si2)])) / (dxa[(((ib[si0] - 2))*(nj) + (si1))*(nk) + (si2)] + dxa[(((ib[si0] - 1))*(nj) + (si1))*(nk) + (si2)]));
          }
        }
      }
      double *right = (double *)malloc((size_t)((2) * (nj) * (nk)) * sizeof(double));
      __npb_alloc_check(right, (size_t)((2) * (nj) * (nk)) * sizeof(double), "right");
      for (int64_t si0 = 0; si0 < 2; ++si0) {
        for (int64_t si1 = 0; si1 < nj; ++si1) {
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            right[((si0)*(nj) + (si1))*(nk) + (si2)] = (((((2.0 * dxa[((ib[si0])*(nj) + (si1))*(nk) + (si2)]) + dxa[(((ib[si0] + 1))*(nj) + (si1))*(nk) + (si2)]) * q[((ib[si0])*(nj) + (si1))*(nk) + (si2)]) - (dxa[((ib[si0])*(nj) + (si1))*(nk) + (si2)] * q[(((ib[si0] + 1))*(nj) + (si1))*(nk) + (si2)])) / (dxa[((ib[si0])*(nj) + (si1))*(nk) + (si2)] + dxa[(((ib[si0] + 1))*(nj) + (si1))*(nk) + (si2)]));
          }
        }
      }
      for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
        for (int64_t __scs0 = 0; __scs0 < nj; ++__scs0) {
          for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
            al[((ib[__sc0])*(nj) + (__scs0))*(nk) + (__scs1)] = (0.5 * (left[((__sc0)*(nj) + (__scs0))*(nk) + (__scs1)] + right[((__sc0)*(nj) + (__scs0))*(nk) + (__scs1)]));
          }
        }
      }
      int64_t *ic = (int64_t *)malloc((size_t)((2)) * sizeof(int64_t));
      __npb_alloc_check(ic, (size_t)((2)) * sizeof(int64_t), "ic");
      ic[0] = (i_start + 1);
      ic[1] = (i_end + 2);
      for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
        for (int64_t __scs0 = 0; __scs0 < nj; ++__scs0) {
          for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
            al[((ic[__sc0])*(nj) + (__scs0))*(nk) + (__scs1)] = (((0.35714285714285715 * q[(((ic[__sc0] - 1))*(nj) + (__scs0))*(nk) + (__scs1)]) + (0.7857142857142857 * q[((ic[__sc0])*(nj) + (__scs0))*(nk) + (__scs1)])) + (-0.14285714285714285 * q[(((ic[__sc0] + 1))*(nj) + (__scs0))*(nk) + (__scs1)]));
          }
        }
      }
      free(ia);
      free(ib);
      free(left);
      free(right);
      free(ic);
    }
    lo = i_start;
    hi = (i_end + 2);
    free(c);
    c = (double *)malloc((size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(c, (size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double), "c");
    for (int64_t __w0 = 0; __w0 < (hi - lo); ++__w0) {
      for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
        for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
          c[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = courant[(((__w0 + (lo - 0)))*(nj) + (__w1))*(nk) + (__w2)];
        }
      }
    }
    free(q_i);
    q_i = (double *)malloc((size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(q_i, (size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double), "q_i");
    for (int64_t __w0 = 0; __w0 < (hi - lo); ++__w0) {
      for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
        for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
          q_i[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = q[(((__w0 + (lo - 0)))*(nj) + (__w1))*(nk) + (__w2)];
        }
      }
    }
    free(q_im1);
    q_im1 = (double *)malloc((size_t)((((hi - 1) - (lo - 1))) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(q_im1, (size_t)((((hi - 1) - (lo - 1))) * (nj) * (nk)) * sizeof(double), "q_im1");
    for (int64_t __w0 = 0; __w0 < ((hi - 1) - (lo - 1)); ++__w0) {
      for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
        for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
          q_im1[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = q[(((__w0 + ((lo - 1) - 0)))*(nj) + (__w1))*(nk) + (__w2)];
        }
      }
    }
    free(bl);
    bl = (double *)malloc((size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(bl, (size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double), "bl");
    for (int64_t __w0 = 0; __w0 < (hi - lo); ++__w0) {
      for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
        for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
          bl[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = (al[(((__w0 + (lo - 0)))*(nj) + (__w1))*(nk) + (__w2)] - q_i[((__w0)*(nj) + (__w1))*(nk) + (__w2)]);
        }
      }
    }
    free(br);
    br = (double *)malloc((size_t)((((hi + 1) - (lo + 1))) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(br, (size_t)((((hi + 1) - (lo + 1))) * (nj) * (nk)) * sizeof(double), "br");
    for (int64_t __w0 = 0; __w0 < ((hi + 1) - (lo + 1)); ++__w0) {
      for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
        for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
          br[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = (al[(((__w0 + ((lo + 1) - 0)))*(nj) + (__w1))*(nk) + (__w2)] - q_i[((__w0)*(nj) + (__w1))*(nk) + (__w2)]);
        }
      }
    }
    free(b0);
    b0 = (double *)malloc((size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(b0, (size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double), "b0");
    for (int64_t __w0 = 0; __w0 < (hi - lo); ++__w0) {
      for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
        for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
          b0[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = (bl[((__w0)*(nj) + (__w1))*(nk) + (__w2)] + br[((__w0)*(nj) + (__w1))*(nk) + (__w2)]);
        }
      }
    }
    free(bl_m1);
    bl_m1 = (double *)malloc((size_t)((((hi - 1) - (lo - 1))) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(bl_m1, (size_t)((((hi - 1) - (lo - 1))) * (nj) * (nk)) * sizeof(double), "bl_m1");
    for (int64_t __w0 = 0; __w0 < ((hi - 1) - (lo - 1)); ++__w0) {
      for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
        for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
          bl_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = (al[(((__w0 + ((lo - 1) - 0)))*(nj) + (__w1))*(nk) + (__w2)] - q_im1[((__w0)*(nj) + (__w1))*(nk) + (__w2)]);
        }
      }
    }
    free(br_m1);
    br_m1 = (double *)malloc((size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(br_m1, (size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double), "br_m1");
    for (int64_t __w0 = 0; __w0 < (hi - lo); ++__w0) {
      for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
        for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
          br_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = (al[(((__w0 + (lo - 0)))*(nj) + (__w1))*(nk) + (__w2)] - q_im1[((__w0)*(nj) + (__w1))*(nk) + (__w2)]);
        }
      }
    }
    free(b0_m1);
    b0_m1 = (double *)malloc((size_t)((((hi - 1) - (lo - 1))) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(b0_m1, (size_t)((((hi - 1) - (lo - 1))) * (nj) * (nk)) * sizeof(double), "b0_m1");
    for (int64_t __w0 = 0; __w0 < ((hi - 1) - (lo - 1)); ++__w0) {
      for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
        for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
          b0_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = (bl_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)] + br_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)]);
        }
      }
    }
    if ((mord == 5)) {
      free(smt5);
      smt5 = (bool *)malloc((size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(bool));
      __npb_alloc_check(smt5, (size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(bool), "smt5");
      for (int64_t __w0 = 0; __w0 < (hi - lo); ++__w0) {
        for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
          for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
            smt5[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = ((bl[((__w0)*(nj) + (__w1))*(nk) + (__w2)] * br[((__w0)*(nj) + (__w1))*(nk) + (__w2)]) < 0.0);
          }
        }
      }
      free(smt5_m1);
      smt5_m1 = (bool *)malloc((size_t)((((hi - 1) - (lo - 1))) * (nj) * (nk)) * sizeof(bool));
      __npb_alloc_check(smt5_m1, (size_t)((((hi - 1) - (lo - 1))) * (nj) * (nk)) * sizeof(bool), "smt5_m1");
      for (int64_t __w0 = 0; __w0 < ((hi - 1) - (lo - 1)); ++__w0) {
        for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
          for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
            smt5_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = ((bl_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)] * br_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)]) < 0.0);
          }
        }
      }
    }
    else {
      free(smt5);
      smt5 = (bool *)malloc((size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(bool));
      __npb_alloc_check(smt5, (size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(bool), "smt5");
      for (int64_t __w0 = 0; __w0 < (hi - lo); ++__w0) {
        for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
          for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
            smt5[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = ((3.0 * fabs(b0[((__w0)*(nj) + (__w1))*(nk) + (__w2)])) < fabs((bl[((__w0)*(nj) + (__w1))*(nk) + (__w2)] - br[((__w0)*(nj) + (__w1))*(nk) + (__w2)])));
          }
        }
      }
      free(smt5_m1);
      smt5_m1 = (bool *)malloc((size_t)((((hi - 1) - (lo - 1))) * (nj) * (nk)) * sizeof(bool));
      __npb_alloc_check(smt5_m1, (size_t)((((hi - 1) - (lo - 1))) * (nj) * (nk)) * sizeof(bool), "smt5_m1");
      for (int64_t __w0 = 0; __w0 < ((hi - 1) - (lo - 1)); ++__w0) {
        for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
          for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
            smt5_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = ((3.0 * fabs(b0_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)])) < fabs((bl_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)] - br_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)])));
          }
        }
      }
    }
    free(mask);
    mask = (double *)malloc((size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(mask, (size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double), "mask");
    for (int64_t __w0 = 0; __w0 < (hi - lo); ++__w0) {
      for (int64_t __w1 = 0; __w1 < nj; ++__w1) {
        for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
          mask[((__w0)*(nj) + (__w1))*(nk) + (__w2)] = ((double)((smt5[((__w0)*(nj) + (__w1))*(nk) + (__w2)] | smt5_m1[((__w0)*(nj) + (__w1))*(nk) + (__w2)])));
        }
      }
    }
    free(__cb1);
    __cb1 = (double *)malloc((size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double));
    __npb_alloc_check(__cb1, (size_t)(((hi - lo)) * (nj) * (nk)) * sizeof(double), "__cb1");
    /* numpy: np.where(c > 0.0, q_im1 + (1.0 - c) * (br_m1 - c * b0_m1) * mask, q_i + (1.0 + c) * (bl + c *... */
    for (int64_t __r0 = 0; __r0 < (hi - lo); ++__r0) {
      for (int64_t __r1 = 0; __r1 < nj; ++__r1) {
        for (int64_t __r2 = 0; __r2 < nk; ++__r2) {
          __cb1[((__r0)*(nj) + (__r1))*(nk) + (__r2)] = ((c[((__r0)*(nj) + (__r1))*(nk) + (__r2)] > 0.0) ? (q_im1[((__r0)*(nj) + (__r1))*(nk) + (__r2)] + (((1.0 - c[((__r0)*(nj) + (__r1))*(nk) + (__r2)]) * (br_m1[((__r0)*(nj) + (__r1))*(nk) + (__r2)] - (c[((__r0)*(nj) + (__r1))*(nk) + (__r2)] * b0_m1[((__r0)*(nj) + (__r1))*(nk) + (__r2)]))) * mask[((__r0)*(nj) + (__r1))*(nk) + (__r2)])) : (q_i[((__r0)*(nj) + (__r1))*(nk) + (__r2)] + (((1.0 + c[((__r0)*(nj) + (__r1))*(nk) + (__r2)]) * (bl[((__r0)*(nj) + (__r1))*(nk) + (__r2)] + (c[((__r0)*(nj) + (__r1))*(nk) + (__r2)] * b0[((__r0)*(nj) + (__r1))*(nk) + (__r2)]))) * mask[((__r0)*(nj) + (__r1))*(nk) + (__r2)])));
        }
      }
    }
    for (int64_t si0 = lo; si0 < hi; ++si0) {
      for (int64_t si1 = 0; si1 < nj; ++si1) {
        for (int64_t si2 = 0; si2 < nk; ++si2) {
          xflux[((si0)*(nj) + (si1))*(nk) + (si2)] = __cb1[(((si0 - lo))*(nj) + (si1))*(nk) + (si2)];
        }
      }
    }
    free(al);
    free(__cb1);
    free(bl);
    free(br);
    free(b0);
    free(bl_m1);
    free(br_m1);
    free(b0_m1);
    free(smt5);
    free(smt5_m1);
    free(c);
    free(q_i);
    free(q_im1);
    free(mask);
}

void fv3_xppm_fp64(const double *restrict courant, const double *restrict dxa, double *restrict q, double *restrict xflux, const int64_t grid_type, const int64_t iord, const int64_t ni, const int64_t nj, const int64_t nk, const int64_t nsteps, uint8_t *restrict workspace, const int64_t workspace_size) {
        int64_t i_end;
        i_end = ((nhalo + ni) - 1);
        for (int64_t _step = 0; _step < nsteps; ++_step) {
          xppm_flux(courant, dxa, q, xflux, grid_type, iord, nhalo, ni, nj, nk);
          for (int64_t si0 = nhalo; si0 < (i_end + 1); ++si0) {
            for (int64_t si1 = 0; si1 < nj; ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                q[((si0)*(nj) + (si1))*(nk) + (si2)] -= (courant[(((si0 + (nhalo - nhalo)))*(nj) + (si1))*(nk) + (si2)] * (xflux[(((si0 + ((nhalo + 1) - nhalo)))*(nj) + (si1))*(nk) + (si2)] - xflux[(((si0 + (nhalo - nhalo)))*(nj) + (si1))*(nk) + (si2)]));
              }
            }
          }
        }
}
