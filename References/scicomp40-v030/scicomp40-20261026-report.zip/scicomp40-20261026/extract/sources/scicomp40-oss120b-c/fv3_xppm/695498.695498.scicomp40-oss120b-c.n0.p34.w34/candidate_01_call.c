// Optimized fv3_xppm implementation with reduced memory usage and OpenMP parallelism.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <omp.h>

#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif

static inline NPB_HD double _Complex __npb_conj(double _Complex z) { return conj(z); }
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
#ifdef I
#undef I
#endif
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
static inline NPB_HD double __npb_fmax_f(double a, double b) { return (a != a) ? a : (b != b) ? b : (a > b ? a : b); }
static inline NPB_HD double __npb_fmin_f(double a, double b) { return (a != a) ? a : (b != b) ? b : (a < b ? a : b); }
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD double __npb_sign(double x) { return x != x ? x : (double)((x > 0) - (x < 0)); }
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) { return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0))); }
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) { return a / b + ((a % b != 0) && ((a < 0) == (b < 0))); }
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) { return __npb_floordiv_i(a, b); }
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) { return __npb_ceildiv_i(a, b); }
#endif
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

constexpr int64_t nhalo = 3;

// Compute the flux for a single time step without allocating large temporary buffers.
static void xppm_flux(const double *restrict courant, const double *restrict dxa, const double *restrict q,
                      double *restrict xflux, const int64_t grid_type, const int64_t iord,
                      const int64_t ni, const int64_t nj, const int64_t nk) {
    const double mord = (double)llabs(iord);
    const int64_t i_start = nhalo;
    const int64_t i_end = (nhalo + ni) - 1;
    // Allocate or reuse the al buffer (size: (ni+6)*nj*nk).
    static double *al = NULL;
    static int64_t saved_ni = -1, saved_nj = -1, saved_nk = -1;
    if (saved_ni != ni || saved_nj != nj || saved_nk != nk) {
        if (al) free(al);
        size_t al_size = (size_t)((ni + 6) * nj * nk);
        al = (double*)malloc(al_size * sizeof(double));
        __npb_alloc_check(al, al_size * sizeof(double), "al");
        saved_ni = ni; saved_nj = nj; saved_nk = nk;
    }
    // Zero the al buffer.
    size_t al_total = (size_t)((ni + 6) * nj * nk);
    #pragma omp parallel for schedule(static)
    for (size_t idx = 0; idx < al_total; ++idx) al[idx] = 0.0;

    // Fill al for interior indices using a 4‑point stencil.
    const int64_t lo_al = i_start - 1; // 2
    const int64_t hi_al = i_end + 3;   // ni+5 (exclusive)
    #pragma omp parallel for schedule(static)
    for (int64_t i = lo_al; i < hi_al; ++i) {
        for (int64_t j = 0; j < nj; ++j) {
            #pragma omp simd
            for (int64_t k = 0; k < nk; ++k) {
                double q_im1 = q[((i - 1) * nj + j) * nk + k];
                double q_i   = q[(i * nj + j) * nk + k];
                double q_im2 = q[((i - 2) * nj + j) * nk + k];
                double q_ip1 = q[((i + 1) * nj + j) * nk + k];
                al[(i * nj + j) * nk + k] = 0.5833333333333334 * (q_im1 + q_i) - 0.08333333333333333 * (q_im2 + q_ip1);
            }
        }
    }

    // Boundary handling for grid_type < 3.
    if (grid_type < 3) {
        // ia = {i_start-1, i_end}
        int64_t ia[2] = { i_start - 1, i_end };
        for (int s = 0; s < 2; ++s) {
            int64_t ii = ia[s];
            #pragma omp parallel for collapse(2) schedule(static)
            for (int64_t j = 0; j < nj; ++j) {
                for (int64_t k = 0; k < nk; ++k) {
                    al[(ii * nj + j) * nk + k] = -0.14285714285714285 * q[((ii - 2) * nj + j) * nk + k]
                        + 0.7857142857142857 * q[((ii - 1) * nj + j) * nk + k]
                        + 0.35714285714285715 * q[(ii * nj + j) * nk + k];
                }
            }
        }
        // ib = {i_start, i_end+1}
        int64_t ib[2] = { i_start, i_end + 1 };
        // Left and right temporary buffers (size 2*nj*nk).
        double *left = (double*)malloc(2 * nj * nk * sizeof(double));
        double *right = (double*)malloc(2 * nj * nk * sizeof(double));
        __npb_alloc_check(left, 2 * nj * nk * sizeof(double), "left");
        __npb_alloc_check(right, 2 * nj * nk * sizeof(double), "right");
        for (int s = 0; s < 2; ++s) {
            int64_t ii = ib[s];
            #pragma omp parallel for collapse(2) schedule(static)
            for (int64_t j = 0; j < nj; ++j) {
                for (int64_t k = 0; k < nk; ++k) {
                    double d1 = dxa[((ii - 1) * nj + j) * nk + k];
                    double d2 = dxa[((ii - 2) * nj + j) * nk + k];
                    double q1 = q[((ii - 1) * nj + j) * nk + k];
                    double q2 = q[((ii - 2) * nj + j) * nk + k];
                    left[(s * nj + j) * nk + k] = ((2.0 * d1 + d2) * q1 - d1 * q2) / (d2 + d1);
                    double d3 = dxa[(ii * nj + j) * nk + k];
                    double d4 = dxa[((ii + 1) * nj + j) * nk + k];
                    double q3 = q[(ii * nj + j) * nk + k];
                    double q4 = q[((ii + 1) * nj + j) * nk + k];
                    right[(s * nj + j) * nk + k] = ((2.0 * d3 + d4) * q3 - d3 * q4) / (d3 + d4);
                }
            }
        }
        // Apply averaged values to al at ib positions.
        for (int s = 0; s < 2; ++s) {
            int64_t ii = ib[s];
            #pragma omp parallel for collapse(2) schedule(static)
            for (int64_t j = 0; j < nj; ++j) {
                for (int64_t k = 0; k < nk; ++k) {
                    al[(ii * nj + j) * nk + k] = 0.5 * (left[(s * nj + j) * nk + k] + right[(s * nj + j) * nk + k]);
                }
            }
        }
        free(left);
        free(right);
        // ic = {i_start+1, i_end+2}
        int64_t ic[2] = { i_start + 1, i_end + 2 };
        for (int s = 0; s < 2; ++s) {
            int64_t ii = ic[s];
            #pragma omp parallel for collapse(2) schedule(static)
            for (int64_t j = 0; j < nj; ++j) {
                for (int64_t k = 0; k < nk; ++k) {
                    al[(ii * nj + j) * nk + k] = 0.35714285714285715 * q[((ii - 1) * nj + j) * nk + k]
                        + 0.7857142857142857 * q[(ii * nj + j) * nk + k]
                        - 0.14285714285714285 * q[((ii + 1) * nj + j) * nk + k];
                }
            }
        }
    }

    // Compute flux for i = i_start .. i_end+1 (inclusive) and store in xflux.
    const int64_t lo = i_start;
    const int64_t hi = i_end + 2; // exclusive upper bound
    #pragma omp parallel for schedule(static)
    for (int64_t i = lo; i < hi; ++i) {
        for (int64_t j = 0; j < nj; ++j) {
            for (int64_t k = 0; k < nk; ++k) {
                double c = courant[(i * nj + j) * nk + k];
                double qi = q[(i * nj + j) * nk + k];
                double qim1 = q[((i - 1) * nj + j) * nk + k];
                double al_i   = al[(i * nj + j) * nk + k];
                double al_ip1 = al[((i + 1) * nj + j) * nk + k];
                double al_im1 = al[((i - 1) * nj + j) * nk + k];
                // Compute bl, br, b0
                double bl = al_i - qi;
                double br = al_ip1 - qi;
                double b0 = bl + br; // = al_i + al_ip1 - 2*qi
                // Compute bl_m1, br_m1, b0_m1
                double bl_m1 = al_im1 - qim1;
                double br_m1 = al_i - qim1;
                double b0_m1 = bl_m1 + br_m1; // = al_im1 + al_i - 2*qim1
                bool smt5, smt5_m1;
                if (mord == 5.0) {
                    smt5 = (bl * br) < 0.0;
                    smt5_m1 = (bl_m1 * br_m1) < 0.0;
                } else {
                    smt5 = (3.0 * fabs(b0)) < fabs(al_i - al_ip1);
                    smt5_m1 = (3.0 * fabs(b0_m1)) < fabs(al_im1 - al_i);
                }
                double mask = (smt5 || smt5_m1) ? 1.0 : 0.0;
                double result;
                if (c > 0.0) {
                    result = qim1 + ((1.0 - c) * (br_m1 - c * b0_m1)) * mask;
                } else {
                    result = qi + ((1.0 + c) * (bl + c * b0)) * mask;
                }
                xflux[(i * nj + j) * nk + k] = result;
            }
        }
    }
    // al buffer retained across calls.
}

void fv3_xppm_fp64(const double *restrict courant, const double *restrict dxa, double *restrict q,
                    double *restrict xflux, const int64_t grid_type, const int64_t iord,
                    const int64_t ni, const int64_t nj, const int64_t nk, const int64_t nsteps,
                    uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace; (void)workspace_size; // unused currently
    const int64_t i_end = (nhalo + ni) - 1;
    for (int64_t step = 0; step < nsteps; ++step) {
        xppm_flux(courant, dxa, q, xflux, grid_type, iord, ni, nj, nk);
        // Update q using fluxes.
        #pragma omp parallel for schedule(static)
        for (int64_t i = nhalo; i < (i_end + 1); ++i) {
            for (int64_t j = 0; j < nj; ++j) {
                for (int64_t k = 0; k < nk; ++k) {
                    q[(i * nj + j) * nk + k] -= courant[(i * nj + j) * nk + k] *
                        (xflux[((i + 1) * nj + j) * nk + k] - xflux[(i * nj + j) * nk + k]);
                }
            }
        }
    }
}

