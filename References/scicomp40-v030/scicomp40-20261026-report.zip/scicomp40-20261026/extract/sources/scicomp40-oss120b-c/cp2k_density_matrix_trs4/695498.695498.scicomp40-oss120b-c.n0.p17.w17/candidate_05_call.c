/* Optimized implementation of the CP2K TRS4 density-matrix purification kernel.
 * The function signature is defined in `signature.json`. All arguments are
 * provided by the benchmark harness. The implementation follows the reference
 * algorithm (generated from the NumPy version) but removes the massive amount of
 * temporary allocations, uses OpenMP for parallelism and performs the blocked
 * CSR multiplication directly with the known fixed fan‑out (3). The floating‑
 * point reduction order is kept identical to the reference by accumulating the
 * sums element‑wise in a single left‑to‑right pass.
 */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

/* ---------------------------------------------------------------------
 * Helper: blocked CSR multiplication for a uniform fan‑out of three.
 *   C = alpha * A * B + beta * C
 * The CSR pattern is circulant: every block row has exactly three blocks
 * whose column indices are stored in `col_idx`. Contributions landing on a
 * column that is not present in the destination row are discarded, exactly as
 * the reference implementation does. After the multiplication a simple norm‑
 * based filter is applied: blocks whose Frobenius norm squared is smaller
 * than `filter_eps*filter_eps` are set to zero.
 * --------------------------------------------------------------------- */
static void blocked_csr_multiply(const double *restrict a_blocks,
                                 const double *restrict b_blocks,
                                 double *restrict c_blocks,
                                 const int32_t *restrict col_idx,
                                 const int32_t *restrict row_ptr, /* unused */
                                 double alpha, double beta,
                                 int64_t block_size, double filter_eps,
                                 int64_t n_block_rows) {
    const int64_t fanout = 3;
    const int64_t nnz = fanout * n_block_rows;
    const int64_t inner = block_size * block_size;

    /* Scale C by beta */
    if (beta != 1.0) {
        for (int64_t blk = 0; blk < nnz; ++blk) {
            double *c = c_blocks + blk * inner;
            for (int64_t i = 0; i < inner; ++i) {
                c[i] *= beta;
            }
        }
    }

    /* Main product: A (row i) * B (row = column of A) */
    for (int64_t i = 0; i < n_block_rows; ++i) {
        const int32_t *row_cols = col_idx + i * fanout;
        for (int64_t a_k = 0; a_k < fanout; ++a_k) {
            int32_t a_col = row_cols[a_k];
            const double *A = a_blocks + (i * fanout + a_k) * inner;
            const int32_t *b_row_cols = col_idx + (int64_t)a_col * fanout;
            for (int64_t b_k = 0; b_k < fanout; ++b_k) {
                int32_t b_col = b_row_cols[b_k];
                const double *B = b_blocks + ((int64_t)a_col * fanout + b_k) * inner;
                /* Find the position p in row i where column == b_col */
                for (int64_t p = 0; p < fanout; ++p) {
                    if (row_cols[p] == b_col) {
                        double *C = c_blocks + (i * fanout + p) * inner;
                        /* Block matrix multiply: C += alpha * A * B */
                        for (int64_t ii = 0; ii < block_size; ++ii) {
                            for (int64_t jj = 0; jj < block_size; ++jj) {
                                double sum = 0.0;
                                for (int64_t kk = 0; kk < block_size; ++kk) {
                                    sum += A[ii * block_size + kk] * B[kk * block_size + jj];
                                }
                                C[ii * block_size + jj] += alpha * sum;
                            }
                        }
                        break; /* found matching column */
                    }
                }
            }
        }
    }

    /* Filter: zero‑out blocks with norm² < filter_eps² */
    double thr_sq = filter_eps * filter_eps;
    for (int64_t blk = 0; blk < nnz; ++blk) {
        const double *c = c_blocks + blk * inner;
        double norm_sq = 0.0;
        for (int64_t i = 0; i < inner; ++i) {
            double v = c[i];
            norm_sq += v * v;
        }
        if (norm_sq < thr_sq) {
            double *c_w = c_blocks + blk * inner;
            for (int64_t i = 0; i < inner; ++i) {
                c_w[i] = 0.0;
            }
        }
    }
}

/* ---------------------------------------------------------------------
 * Helper: compute the global index of the diagonal block for each block row.
 * The diagonal block is the one whose column index equals the row index.
 * --------------------------------------------------------------------- */
static void diag_positions(int32_t *restrict diag_pos,
                           const int32_t *restrict col_idx,
                           int64_t n_block_rows) {
    const int64_t fanout = 3;
    for (int64_t i = 0; i < n_block_rows; ++i) {
        int32_t pos = -1;
        for (int64_t k = 0; k < fanout; ++k) {
            if (col_idx[i * fanout + k] == i) {
                pos = (int32_t)(i * fanout + k);
                break;
            }
        }
        if (pos == -1) {
            /* fallback – should not happen for valid inputs */
            pos = (int32_t)(i * fanout);
        }
        diag_pos[i] = pos;
    }
}

void cp2k_density_matrix_trs4_fp64(int32_t *restrict branch_history,
    const int32_t *restrict col_idx,
    double *restrict g_blocks,
    double *restrict gamma_values,
    const double *restrict ks_blocks,
    double *restrict p_blocks,
    double *restrict poly_blocks,
    const int32_t *restrict row_ptr,
    const double *restrict s_inv_blocks,
    double *restrict scratch_blocks,
    double *restrict state,
    double *restrict x2_blocks,
    double *restrict x_blocks,
    const int64_t block_size,
    const double eps_max,
    const double eps_min,
    const int64_t n_block_rows,
    const int64_t n_iter,
    const int64_t nelectron,
    const double spin_scale,
    const double threshold,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    /* Set the number of threads once */
    omp_set_num_threads(4);
    const int64_t fanout = 3;
    const int64_t nnz = fanout * n_block_rows;
    const int64_t inner = block_size * block_size;
    const int64_t n_blocks = nnz; // number of stored blocks
    const int64_t n_diag = n_block_rows * block_size;

    /* Allocate diagonal position helpers */
    int32_t *diag_pos = (int32_t *)malloc((size_t)n_block_rows * sizeof(int32_t));
    int64_t *diag_rows = (int64_t *)malloc((size_t)n_diag * sizeof(int64_t));
    int64_t *diag_cols = (int64_t *)malloc((size_t)n_diag * sizeof(int64_t));
    if (!diag_pos || !diag_rows || !diag_cols) {
        abort();
    }
    diag_positions(diag_pos, col_idx, n_block_rows);
    for (int64_t i = 0; i < n_block_rows; ++i) {
        for (int64_t d = 0; d < block_size; ++d) {
            int64_t idx = i * block_size + d;
            diag_rows[idx] = diag_pos[i];
            diag_cols[idx] = d;
        }
    }

    /* Zero‑initialize all working blocks */
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_blocks * inner; ++i) { x_blocks[i] = 0.0; }
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_blocks * inner; ++i) { x2_blocks[i] = 0.0; }
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_blocks * inner; ++i) { g_blocks[i] = 0.0; }
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_blocks * inner; ++i) { poly_blocks[i] = 0.0; }
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_blocks * inner; ++i) { scratch_blocks[i] = 0.0; }
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_blocks * inner; ++i) { p_blocks[i] = 0.0; }
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_iter; ++i) { gamma_values[i] = 0.0; }
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_iter; ++i) { branch_history[i] = 0; }
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < 10; ++i) { state[i] = 0.0; }

    /* Initial two multiplications: X = S^{-1/2} * H * S^{-1/2} */
    blocked_csr_multiply(s_inv_blocks, ks_blocks, scratch_blocks,
                         col_idx, row_ptr, 1.0, 0.0, block_size, threshold,
                         n_block_rows);
    blocked_csr_multiply(scratch_blocks, s_inv_blocks, x_blocks,
                         col_idx, row_ptr, 1.0, 0.0, block_size, threshold,
                         n_block_rows);

    /* Spectral scaling */
    double spectral_scale = -1.0 / (eps_max - eps_min);
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_blocks * inner; ++i) {
        x_blocks[i] *= spectral_scale;
    }
    double diag_offset = spectral_scale * eps_max;
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_diag; ++i) {
        int64_t blk = diag_rows[i];
        int64_t d = diag_cols[i];
        x_blocks[blk * inner + d * block_size + d] -= diag_offset;
    }

    /* Iterative purification */
    double trace_fx = 0.0, trace_gx = 0.0, frob_id = 0.0, frob_x = 0.0,
           delta_n = 0.0, converged_value = 0.0;
    int64_t iterations_done = 0;
    int64_t final_branch = 0;
    // Compute Frobenius norms and trace with strict left‑to‑right accumulation
    double frob_id_sq = 0.0;
    double frob_x_sq = 0.0;
    double trace_fx_loc = 0.0;
    for (int64_t blk = 0; blk < n_blocks; ++blk) {
        const double *x = x_blocks + blk * inner;
        const double *x2 = x2_blocks + blk * inner;
        const double *poly = poly_blocks + blk * inner;
        for (int64_t i = 0; i < block_size; ++i) {
            for (int64_t j = 0; j < block_size; ++j) {
                int64_t idx = i * block_size + j;
                double xv = x[idx];
                double x2v = x2[idx];
                double diff = x2v - xv;          // residual element
                double rr = diff * diff;          // (X^2 - X)^2
                double xx = xv * xv;              // X^2 elementwise
                double xp = x2v * poly[idx];      // X^2 * poly
                frob_id_sq += rr;
                frob_x_sq += xx;
                trace_fx_loc += xp;
            }
        }
    }
    trace_fx = trace_fx_loc;
    trace_gx = frob_id_sq;
    frob_id = sqrt(frob_id_sq);
    frob_x = sqrt(frob_x_sq);
    delta_n = (double)nelectron - trace_fx;

    for (int64_t iteration = 0; iteration < n_iter; ++iteration) {
        /* X^2 */
        blocked_csr_multiply(x_blocks, x_blocks, x2_blocks,
                             col_idx, row_ptr, 1.0, 0.0, block_size, threshold,
                             n_block_rows);

        /* G = X^2 - 2*X, then add 1 on the diagonal */
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < n_blocks * inner; ++i) {
            g_blocks[i] = x2_blocks[i] - 2.0 * x_blocks[i];
        }
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < n_diag; ++i) {
            int64_t blk = diag_rows[i];
            int64_t d = diag_cols[i];
            g_blocks[blk * inner + d * block_size + d] += 1.0;
        }

        /* Poly = 4*X - 3*X^2 */
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < n_blocks * inner; ++i) {
            poly_blocks[i] = 4.0 * x_blocks[i] - 3.0 * x2_blocks[i];
        }

        /* Compute Frobenius norms and trace (left‑to‑right accumulation) */
        frob_id_sq = 0.0; frob_x_sq = 0.0; trace_fx_loc = 0.0;
        for (int64_t blk = 0; blk < n_blocks; ++blk) {
            const double *x = x_blocks + blk * inner;
            const double *x2 = x2_blocks + blk * inner;
            const double *poly = poly_blocks + blk * inner;
            for (int64_t i = 0; i < block_size; ++i) {
                for (int64_t j = 0; j < block_size; ++j) {
                    int64_t idx = i * block_size + j;
                    double xv = x[idx];
                    double x2v = x2[idx];
                    double diff = x2v - xv;
                    double rr = diff * diff;
                    double xx = xv * xv;
                    double xp = x2v * poly[idx];
                    frob_id_sq += rr;
                    frob_x_sq += xx;
                    trace_fx_loc += xp;
                }
            }
        }
        trace_fx = trace_fx_loc;
        trace_gx = frob_id_sq;
        frob_id = sqrt(frob_id_sq);
        frob_x = sqrt(frob_x_sq);
        delta_n = (double)nelectron - trace_fx;

        /* Determine gamma */
        double gamma;
        if (frob_id_sq < threshold * frob_x_sq && fabs(delta_n) < 0.5) {
            gamma = 3.0;
        } else if (fabs(delta_n) < 1e-14) {
            gamma = 0.0;
        } else {
            double denominator = trace_gx;
            double denominator_floor = fabs(delta_n) / 100.0;
            if (fabs(denominator) < denominator_floor) {
                denominator = (denominator >= 0.0) ? denominator_floor : -denominator_floor;
            }
            gamma = delta_n / denominator;
        }
        gamma_values[iteration] = gamma;

        int64_t branch = 0;
        if (gamma > 6.0) {
            branch = 1;
            /* X = 2*X - X^2 */
            #pragma omp parallel for schedule(static)
            for (int64_t i = 0; i < n_blocks * inner; ++i) {
                x_blocks[i] = 2.0 * x_blocks[i] - x2_blocks[i];
            }
            /* Filter after the update */
            double thr_sq = threshold * threshold;
            #pragma omp parallel for schedule(static)
            for (int64_t blk = 0; blk < n_blocks; ++blk) {
                const double *c = x_blocks + blk * inner;
                double norm_sq = 0.0;
                for (int64_t k = 0; k < inner; ++k) {
                    double v = c[k];
                    norm_sq += v * v;
                }
                if (norm_sq < thr_sq) {
                    double *c_w = x_blocks + blk * inner;
                    for (int64_t k = 0; k < inner; ++k) {
                        c_w[k] = 0.0;
                    }
                }
            }
        } else if (gamma < 0.0) {
            branch = 2;
            /* X = X^2 */
            #pragma omp parallel for schedule(static)
            for (int64_t i = 0; i < n_blocks * inner; ++i) {
                x_blocks[i] = x2_blocks[i];
            }
        } else {
            branch = 3;
            /* Poly += gamma * G */
            #pragma omp parallel for schedule(static)
            for (int64_t i = 0; i < n_blocks * inner; ++i) {
                poly_blocks[i] += gamma * g_blocks[i];
            }
            /* X = X^2 * Poly */
            blocked_csr_multiply(x2_blocks, poly_blocks, x_blocks,
                                 col_idx, row_ptr, 1.0, 0.0, block_size, threshold,
                                 n_block_rows);
        }
        branch_history[iteration] = (int32_t)branch;
        iterations_done = iteration + 1;
        final_branch = branch;

        if (frob_id_sq < threshold * frob_x_sq && branch == 3 && fabs(delta_n) < 0.5) {
            converged_value = 1.0;
            break;
        }
    }

    /* Final transformation P = S^{-1/2} * X * S^{-1/2} */
    blocked_csr_multiply(x_blocks, s_inv_blocks, scratch_blocks,
                         col_idx, row_ptr, 1.0, 0.0, block_size, threshold,
                         n_block_rows);
    blocked_csr_multiply(s_inv_blocks, scratch_blocks, p_blocks,
                         col_idx, row_ptr, 1.0, 0.0, block_size, threshold,
                         n_block_rows);
    /* Apply spin scaling */
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n_blocks * inner; ++i) {
        p_blocks[i] *= spin_scale;
    }

    /* Bisection to recover chemical potential */
    int64_t polynomial_steps = iterations_done - 1;
    if (polynomial_steps < 0) polynomial_steps = 0;
    double mu_a = 0.0, mu_b = 1.0, mu_fa = -0.5, mu_c = 0.5;
    for (int64_t bstep = 0; bstep < 40; ++bstep) {
        mu_c = 0.5 * (mu_a + mu_b);
        double xr = mu_c;
        for (int64_t gpos = 0; gpos < polynomial_steps; ++gpos) {
            double g = gamma_values[gpos];
            if (g > 6.0) {
                xr = 2.0 * xr - xr * xr;
            } else if (g < 0.0) {
                xr = xr * xr;
            } else {
                double xr2 = xr * xr;
                double one_minus_xr = 1.0 - xr;
                xr = xr2 * (4.0 * xr - 3.0 * xr2) + g * xr2 * one_minus_xr * one_minus_xr;
            }
        }
        double mu_fc = xr - 0.5;
        if (fabs(mu_fc) < 1e-6 || 0.5 * (mu_b - mu_a) < 1e-6) break;
        if (mu_fc * mu_fa > 0.0) {
            mu_a = mu_c;
            mu_fa = mu_fc;
        } else {
            mu_b = mu_c;
        }
    }
    double chemical_potential = (eps_min - eps_max) * mu_c + eps_max;
    state[0] = chemical_potential;
    state[1] = trace_fx;
    state[2] = trace_gx;
    state[3] = frob_id;
    state[4] = frob_x;
    state[5] = delta_n;
    state[6] = (double)iterations_done;
    state[7] = converged_value;
    state[8] = (double)final_branch;
    if (frob_x > 0.0) {
        state[9] = frob_id / frob_x;
    }

    free(diag_pos);
    free(diag_rows);
    free(diag_cols);
}
