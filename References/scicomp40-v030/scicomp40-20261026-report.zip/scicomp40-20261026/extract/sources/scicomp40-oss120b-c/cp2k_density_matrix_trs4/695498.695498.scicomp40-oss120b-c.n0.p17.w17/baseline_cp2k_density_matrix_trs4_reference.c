// hpcagent_bench-autogen -- generated from cp2k_density_matrix_trs4_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

static void blocked_csr_multiply(const double *restrict a_blocks, const double *restrict b_blocks, double *restrict c_blocks, const int32_t *restrict col_idx, const int32_t *restrict row_ptr, const double alpha, const double beta, const int64_t block_size, const double filter_eps, const int64_t n_block_rows);
static void _diag_positions(int32_t *restrict __hret_1, const int32_t *restrict col_idx, const int64_t n_block_rows);

static void blocked_csr_multiply(const double *restrict a_blocks, const double *restrict b_blocks, double *restrict c_blocks, const int32_t *restrict col_idx, const int32_t *restrict row_ptr, const double alpha, const double beta, const int64_t block_size, const double filter_eps, const int64_t n_block_rows) {
    int64_t nnz;
    int64_t fanout;
    double filter_eps_sq;
    int64_t inner;
    double _cp_acc;
    int64_t __ar_val___cb7;
    int64_t *__cb1 = (int64_t *)malloc((size_t)((n_block_rows)) * sizeof(int64_t));
    __npb_alloc_check(__cb1, (size_t)((n_block_rows)) * sizeof(int64_t), "__cb1");
    int64_t *block_rows = (int64_t *)malloc((size_t)((n_block_rows)) * sizeof(int64_t));
    __npb_alloc_check(block_rows, (size_t)((n_block_rows)) * sizeof(int64_t), "block_rows");
    double *b_base = (double *)malloc((size_t)(((3 * n_block_rows))) * sizeof(double));
    __npb_alloc_check(b_base, (size_t)(((3 * n_block_rows))) * sizeof(double), "b_base");
    double *a_expand = (double *)malloc((size_t)(((3 * n_block_rows)) * (1) * (block_size) * (block_size) * (1)) * sizeof(double));
    __npb_alloc_check(a_expand, (size_t)(((3 * n_block_rows)) * (1) * (block_size) * (block_size) * (1)) * sizeof(double), "a_expand");
    int64_t *row_of = NULL;
    int64_t *block_col = NULL;
    int64_t *row_cols_of_a = NULL;
    int64_t *match_int = NULL;
    double *sink = NULL;
    double *prefix = NULL;
    int32_t *__cb3 = NULL;
    int64_t *__cb4 = NULL;
    int64_t *__cb6 = NULL;
    int64_t *__cb7 = NULL;
    double *__cb8 = NULL;
    double *__cb9 = NULL;
    bool *__cb10 = NULL;
    double *__cb11 = NULL;
    double *__cb12 = NULL;
    double *__cb13 = NULL;
    double *__cb14 = NULL;
    double *__cb15 = NULL;
    bool *valid = NULL;
    int64_t *b_pos = NULL;
    bool *match = NULL;
    int64_t *first_hit = NULL;
    int64_t *c_pos = NULL;
    double *prod = NULL;
    bool *flat_valid = NULL;
    int64_t *flat_c_pos = NULL;
    double *flat_prod = NULL;
    double *flat = NULL;
    bool *keep = NULL;
    int64_t *row_cols = NULL;
    double *b_expand = NULL;
    nnz = (3 * n_block_rows);
    fanout = int_floor(nnz, n_block_rows);
    for (int64_t __w0 = 0; __w0 < nnz; ++__w0) {
      for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
        for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
          c_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] *= 0.0;
        }
      }
    }
    /* numpy: np.arange(n_block_rows, dtype=np.int64) */
    for (int64_t __i = 0; __i < n_block_rows; ++__i) {
      __cb1[__i] = __i;
    }
    for (int64_t __w0 = 0; __w0 < n_block_rows; ++__w0) {
      block_rows[__w0] = __cb1[__w0];
    }
    free(row_of);
    row_of = (int64_t *)malloc((size_t)((nnz)) * sizeof(int64_t));
    __npb_alloc_check(row_of, (size_t)((nnz)) * sizeof(int64_t), "row_of");
    memset(row_of, 0, (size_t)((nnz)) * sizeof(int64_t));
    memset(row_of, 0, (size_t)((nnz)) * sizeof(int64_t));
    /* numpy: np.repeat(block_rows, fanout) */
    for (int64_t __rp0 = 0; __rp0 < n_block_rows; ++__rp0) {
      for (int64_t __rep0 = 0; __rep0 < fanout; ++__rep0) {
        row_of[((__rp0 * fanout) + __rep0)] = block_rows[__rp0];
      }
    }
    free(__cb3);
    __cb3 = (int32_t *)malloc((size_t)((n_block_rows) * (fanout)) * sizeof(int32_t));
    __npb_alloc_check(__cb3, (size_t)((n_block_rows) * (fanout)) * sizeof(int32_t), "__cb3");
    /* numpy: np.reshape(col_idx, (n_block_rows, fanout)) */
    for (int64_t __rs0 = 0; __rs0 < n_block_rows; ++__rs0) {
      for (int64_t __rs1 = 0; __rs1 < fanout; ++__rs1) {
        __cb3[(__rs0)*(fanout) + (__rs1)] = ((int64_t)(col_idx[((__rs0 * fanout) + __rs1)]));
      }
    }
    free(row_cols);
    row_cols = (int64_t *)malloc((size_t)((n_block_rows) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(row_cols, (size_t)((n_block_rows) * (fanout)) * sizeof(int64_t), "row_cols");
    for (int64_t __w0 = 0; __w0 < n_block_rows; ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        row_cols[(__w0)*(fanout) + (__w1)] = ((int64_t)(((int64_t)(__cb3[(__w0)*(fanout) + (__w1)]))));
      }
    }
    for (int64_t __w0 = 0; __w0 < (3 * n_block_rows); ++__w0) {
      b_base[__w0] = (((int64_t)(((int64_t)(col_idx[__w0])))) * fanout);
    }
    free(__cb4);
    __cb4 = (int64_t *)malloc((size_t)((fanout)) * sizeof(int64_t));
    __npb_alloc_check(__cb4, (size_t)((fanout)) * sizeof(int64_t), "__cb4");
    /* numpy: np.arange(fanout, dtype=np.int64) */
    for (int64_t __i = 0; __i < fanout; ++__i) {
      __cb4[__i] = __i;
    }
    free(b_pos);
    b_pos = (int64_t *)malloc((size_t)(((3 * n_block_rows)) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(b_pos, (size_t)(((3 * n_block_rows)) * (fanout)) * sizeof(int64_t), "b_pos");
    for (int64_t __w0 = 0; __w0 < (3 * n_block_rows); ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        b_pos[(__w0)*(fanout) + (__w1)] = (b_base[__w0] + __cb4[__w1]);
      }
    }
    free(block_col);
    block_col = (int64_t *)malloc((size_t)((nnz) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(block_col, (size_t)((nnz) * (fanout)) * sizeof(int64_t), "block_col");
    memset(block_col, 0, (size_t)((nnz) * (fanout)) * sizeof(int64_t));
    for (int64_t si0 = 0; si0 < nnz; ++si0) {
      for (int64_t si1 = 0; si1 < fanout; ++si1) {
        block_col[(si0)*(fanout) + (si1)] = ((int64_t)(col_idx[b_pos[(si0)*(fanout) + (si1)]]));
      }
    }
    free(row_cols_of_a);
    row_cols_of_a = (int64_t *)malloc((size_t)((nnz) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(row_cols_of_a, (size_t)((nnz) * (fanout)) * sizeof(int64_t), "row_cols_of_a");
    memset(row_cols_of_a, 0, (size_t)((nnz) * (fanout)) * sizeof(int64_t));
    for (int64_t si0 = 0; si0 < nnz; ++si0) {
      for (int64_t si1 = 0; si1 < fanout; ++si1) {
        row_cols_of_a[(si0)*(fanout) + (si1)] = row_cols[(row_of[si0])*(fanout) + (si1)];
      }
    }
    free(match);
    match = (bool *)malloc((size_t)((nnz) * (fanout) * (fanout)) * sizeof(bool));
    __npb_alloc_check(match, (size_t)((nnz) * (fanout) * (fanout)) * sizeof(bool), "match");
    for (int64_t __w0 = 0; __w0 < nnz; ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        for (int64_t __w2 = 0; __w2 < fanout; ++__w2) {
          match[((__w0)*(fanout) + (__w1))*(fanout) + (__w2)] = (row_cols_of_a[(__w0)*(fanout) + (__w2)] == block_col[(__w0)*(fanout) + (__w1)]);
        }
      }
    }
    free(valid);
    valid = (bool *)malloc((size_t)((nnz) * (fanout)) * sizeof(bool));
    __npb_alloc_check(valid, (size_t)((nnz) * (fanout)) * sizeof(bool), "valid");
    /* numpy: np.any(match, axis=-1) */
    for (int64_t __ax0 = 0; __ax0 < nnz; ++__ax0) {
      for (int64_t __ax1 = 0; __ax1 < fanout; ++__ax1) {
        valid[(__ax0)*(fanout) + (__ax1)] = 0;
        for (int64_t __rd0 = 0; __rd0 < fanout; ++__rd0) {
          if ((match[((__ax0)*(fanout) + (__ax1))*(fanout) + (__rd0)] != 0)) {
            valid[(__ax0)*(fanout) + (__ax1)] = 1;
          }
        }
      }
    }
    free(match_int);
    match_int = (int64_t *)malloc((size_t)((nnz) * (fanout) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(match_int, (size_t)((nnz) * (fanout) * (fanout)) * sizeof(int64_t), "match_int");
    memset(match_int, 0, (size_t)((nnz) * (fanout) * (fanout)) * sizeof(int64_t));
    free(__cb6);
    __cb6 = (int64_t *)malloc((size_t)((nnz) * (fanout) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(__cb6, (size_t)((nnz) * (fanout) * (fanout)) * sizeof(int64_t), "__cb6");
    /* numpy: np.where(match, 1, 0) */
    for (int64_t __r0 = 0; __r0 < nnz; ++__r0) {
      for (int64_t __r1 = 0; __r1 < fanout; ++__r1) {
        for (int64_t __r2 = 0; __r2 < fanout; ++__r2) {
          __cb6[((__r0)*(fanout) + (__r1))*(fanout) + (__r2)] = (match[((__r0)*(fanout) + (__r1))*(fanout) + (__r2)] ? 1 : 0);
        }
      }
    }
    free(match_int);
    match_int = (int64_t *)malloc((size_t)((nnz) * (fanout) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(match_int, (size_t)((nnz) * (fanout) * (fanout)) * sizeof(int64_t), "match_int");
    memset(match_int, 0, (size_t)((nnz) * (fanout) * (fanout)) * sizeof(int64_t));
    for (int64_t __w0 = 0; __w0 < nnz; ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        for (int64_t __w2 = 0; __w2 < fanout; ++__w2) {
          match_int[((__w0)*(fanout) + (__w1))*(fanout) + (__w2)] = __cb6[((__w0)*(fanout) + (__w1))*(fanout) + (__w2)];
        }
      }
    }
    free(__cb7);
    __cb7 = (int64_t *)malloc((size_t)((nnz) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(__cb7, (size_t)((nnz) * (fanout)) * sizeof(int64_t), "__cb7");
    /* numpy: np.argmax(match_int, axis=-1) */
    for (int64_t __aax0 = 0; __aax0 < nnz; ++__aax0) {
      for (int64_t __aax1 = 0; __aax1 < fanout; ++__aax1) {
        __ar_val___cb7 = match_int[((__aax0)*(fanout) + (__aax1))*(fanout) + (0)];
        __cb7[(__aax0)*(fanout) + (__aax1)] = 0;
        for (int64_t __ard0 = 0; __ard0 < fanout; ++__ard0) {
          if (((__ar_val___cb7 == __ar_val___cb7) && ((match_int[((__aax0)*(fanout) + (__aax1))*(fanout) + (__ard0)] != match_int[((__aax0)*(fanout) + (__aax1))*(fanout) + (__ard0)]) || (match_int[((__aax0)*(fanout) + (__aax1))*(fanout) + (__ard0)] > __ar_val___cb7)))) {
            __ar_val___cb7 = match_int[((__aax0)*(fanout) + (__aax1))*(fanout) + (__ard0)];
            __cb7[(__aax0)*(fanout) + (__aax1)] = __ard0;
          }
        }
      }
    }
    free(first_hit);
    first_hit = (int64_t *)malloc((size_t)((nnz) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(first_hit, (size_t)((nnz) * (fanout)) * sizeof(int64_t), "first_hit");
    for (int64_t __w0 = 0; __w0 < nnz; ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        first_hit[(__w0)*(fanout) + (__w1)] = __cb7[(__w0)*(fanout) + (__w1)];
      }
    }
    free(c_pos);
    c_pos = (int64_t *)malloc((size_t)((nnz) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(c_pos, (size_t)((nnz) * (fanout)) * sizeof(int64_t), "c_pos");
    for (int64_t __w0 = 0; __w0 < nnz; ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        c_pos[(__w0)*(fanout) + (__w1)] = ((row_of[__w0] * fanout) + first_hit[(__w0)*(fanout) + (__w1)]);
      }
    }
    for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
      for (int64_t si1 = 0; si1 < 1; ++si1) {
        for (int64_t si2 = 0; si2 < block_size; ++si2) {
          for (int64_t si3 = 0; si3 < block_size; ++si3) {
            for (int64_t si4 = 0; si4 < 1; ++si4) {
              a_expand[((((si0)*(1) + (si1))*(block_size) + (si2))*(block_size) + (si3))*(1) + (si4)] = a_blocks[((si0)*(block_size) + (si2))*(block_size) + (si3)];
            }
          }
        }
      }
    }
    free(b_expand);
    b_expand = (double *)malloc((size_t)(((3 * n_block_rows)) * (fanout) * (1) * (block_size) * (block_size)) * sizeof(double));
    __npb_alloc_check(b_expand, (size_t)(((3 * n_block_rows)) * (fanout) * (1) * (block_size) * (block_size)) * sizeof(double), "b_expand");
    for (int64_t __w0 = 0; __w0 < (3 * n_block_rows); ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        for (int64_t __w2 = 0; __w2 < 1; ++__w2) {
          for (int64_t __w3 = 0; __w3 < block_size; ++__w3) {
            for (int64_t __w4 = 0; __w4 < block_size; ++__w4) {
              b_expand[((((__w0)*(fanout) + (__w1))*(1) + (__w2))*(block_size) + (__w3))*(block_size) + (__w4)] = b_blocks[((b_pos[(__w0)*(fanout) + (__w1)])*(block_size) + (__w3))*(block_size) + (__w4)];
            }
          }
        }
      }
    }
    free(__cb8);
    __cb8 = (double *)malloc((size_t)(((3 * n_block_rows)) * (fanout) * (block_size) * (block_size) * (block_size)) * sizeof(double));
    __npb_alloc_check(__cb8, (size_t)(((3 * n_block_rows)) * (fanout) * (block_size) * (block_size) * (block_size)) * sizeof(double), "__cb8");
    for (int64_t __w0 = 0; __w0 < (3 * n_block_rows); ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
          for (int64_t __w3 = 0; __w3 < block_size; ++__w3) {
            for (int64_t __w4 = 0; __w4 < block_size; ++__w4) {
              __cb8[((((__w0)*(fanout) + (__w1))*(block_size) + (__w2))*(block_size) + (__w3))*(block_size) + (__w4)] = (a_expand[((((__w0)*(1) + (0))*(block_size) + (__w2))*(block_size) + (__w3))*(1) + (0)] * b_expand[((((__w0)*(fanout) + (__w1))*(1) + (0))*(block_size) + (__w3))*(block_size) + (__w4)]);
            }
          }
        }
      }
    }
    free(__cb9);
    __cb9 = (double *)malloc((size_t)(((3 * n_block_rows)) * (fanout) * (block_size) * (block_size)) * sizeof(double));
    __npb_alloc_check(__cb9, (size_t)(((3 * n_block_rows)) * (fanout) * (block_size) * (block_size)) * sizeof(double), "__cb9");
    /* numpy: np.sum(__cb8, axis=3) */
    for (int64_t __ax0 = 0; __ax0 < (3 * n_block_rows); ++__ax0) {
      for (int64_t __ax1 = 0; __ax1 < fanout; ++__ax1) {
        for (int64_t __ax2 = 0; __ax2 < block_size; ++__ax2) {
          for (int64_t __ax3 = 0; __ax3 < block_size; ++__ax3) {
            __cb9[(((__ax0)*(fanout) + (__ax1))*(block_size) + (__ax2))*(block_size) + (__ax3)] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < block_size; ++__rd0) {
              __cb9[(((__ax0)*(fanout) + (__ax1))*(block_size) + (__ax2))*(block_size) + (__ax3)] = (__cb9[(((__ax0)*(fanout) + (__ax1))*(block_size) + (__ax2))*(block_size) + (__ax3)] + __cb8[((((__ax0)*(fanout) + (__ax1))*(block_size) + (__ax2))*(block_size) + (__rd0))*(block_size) + (__ax3)]);
            }
          }
        }
      }
    }
    free(prod);
    prod = (double *)malloc((size_t)(((3 * n_block_rows)) * (fanout) * (block_size) * (block_size)) * sizeof(double));
    __npb_alloc_check(prod, (size_t)(((3 * n_block_rows)) * (fanout) * (block_size) * (block_size)) * sizeof(double), "prod");
    for (int64_t __w0 = 0; __w0 < (3 * n_block_rows); ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
          for (int64_t __w3 = 0; __w3 < block_size; ++__w3) {
            prod[(((__w0)*(fanout) + (__w1))*(block_size) + (__w2))*(block_size) + (__w3)] = __cb9[(((__w0)*(fanout) + (__w1))*(block_size) + (__w2))*(block_size) + (__w3)];
          }
        }
      }
    }
    free(__cb10);
    __cb10 = (bool *)malloc((size_t)(((nnz * fanout))) * sizeof(bool));
    __npb_alloc_check(__cb10, (size_t)(((nnz * fanout))) * sizeof(bool), "__cb10");
    /* numpy: np.reshape(valid, (-1,)) */
    for (int64_t __rs0 = 0; __rs0 < nnz; ++__rs0) {
      for (int64_t __rs1 = 0; __rs1 < fanout; ++__rs1) {
        __cb10[((__rs0 * fanout) + __rs1)] = valid[(__rs0)*(fanout) + (__rs1)];
      }
    }
    free(flat_valid);
    flat_valid = (bool *)malloc((size_t)(((nnz * fanout))) * sizeof(bool));
    __npb_alloc_check(flat_valid, (size_t)(((nnz * fanout))) * sizeof(bool), "flat_valid");
    for (int64_t __w0 = 0; __w0 < (nnz * fanout); ++__w0) {
      flat_valid[__w0] = __cb10[__w0];
    }
    free(sink);
    sink = (double *)malloc((size_t)(((nnz + 1)) * (block_size) * (block_size)) * sizeof(double));
    __npb_alloc_check(sink, (size_t)(((nnz + 1)) * (block_size) * (block_size)) * sizeof(double), "sink");
    memset(sink, 0, (size_t)(((nnz + 1)) * (block_size) * (block_size)) * sizeof(double));
    for (int64_t si0 = 0; si0 < nnz; ++si0) {
      for (int64_t si1 = 0; si1 < block_size; ++si1) {
        for (int64_t si2 = 0; si2 < block_size; ++si2) {
          sink[((si0)*(block_size) + (si1))*(block_size) + (si2)] = c_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)];
        }
      }
    }
    free(__cb11);
    __cb11 = (double *)malloc((size_t)(((nnz * fanout))) * sizeof(double));
    __npb_alloc_check(__cb11, (size_t)(((nnz * fanout))) * sizeof(double), "__cb11");
    /* numpy: np.reshape(c_pos, (-1,)) */
    for (int64_t __rs0 = 0; __rs0 < nnz; ++__rs0) {
      for (int64_t __rs1 = 0; __rs1 < fanout; ++__rs1) {
        __cb11[((__rs0 * fanout) + __rs1)] = c_pos[(__rs0)*(fanout) + (__rs1)];
      }
    }
    free(__cb12);
    __cb12 = (double *)malloc((size_t)(((nnz * fanout))) * sizeof(double));
    __npb_alloc_check(__cb12, (size_t)(((nnz * fanout))) * sizeof(double), "__cb12");
    /* numpy: np.where(flat_valid, __cb11, nnz) */
    for (int64_t __r0 = 0; __r0 < (nnz * fanout); ++__r0) {
      __cb12[__r0] = (flat_valid[__r0] ? __cb11[__r0] : nnz);
    }
    free(flat_c_pos);
    flat_c_pos = (int64_t *)malloc((size_t)(((nnz * fanout))) * sizeof(int64_t));
    __npb_alloc_check(flat_c_pos, (size_t)(((nnz * fanout))) * sizeof(int64_t), "flat_c_pos");
    for (int64_t __w0 = 0; __w0 < (nnz * fanout); ++__w0) {
      flat_c_pos[__w0] = __cb12[__w0];
    }
    free(__cb13);
    __cb13 = (double *)malloc((size_t)(((nnz * fanout)) * (block_size) * (block_size)) * sizeof(double));
    __npb_alloc_check(__cb13, (size_t)(((nnz * fanout)) * (block_size) * (block_size)) * sizeof(double), "__cb13");
    /* numpy: np.reshape(prod, (nnz * fanout, block_size, block_size)) */
    for (int64_t __rs0 = 0; __rs0 < (3 * n_block_rows); ++__rs0) {
      for (int64_t __rs1 = 0; __rs1 < fanout; ++__rs1) {
        for (int64_t __rs2 = 0; __rs2 < block_size; ++__rs2) {
          for (int64_t __rs3 = 0; __rs3 < block_size; ++__rs3) {
            __cb13[((((__rs0 * fanout) + __rs1))*(block_size) + (__rs2))*(block_size) + (__rs3)] = prod[(((__rs0)*(fanout) + (__rs1))*(block_size) + (__rs2))*(block_size) + (__rs3)];
          }
        }
      }
    }
    free(flat_prod);
    flat_prod = (double *)malloc((size_t)(((nnz * fanout)) * (block_size) * (block_size)) * sizeof(double));
    __npb_alloc_check(flat_prod, (size_t)(((nnz * fanout)) * (block_size) * (block_size)) * sizeof(double), "flat_prod");
    for (int64_t __w0 = 0; __w0 < (nnz * fanout); ++__w0) {
      for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
        for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
          flat_prod[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] = __cb13[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)];
        }
      }
    }
    for (int64_t __sat1 = 0; __sat1 < (nnz * fanout); ++__sat1) {
      for (int64_t __sat1_t0 = 0; __sat1_t0 < block_size; ++__sat1_t0) {
        for (int64_t __sat1_t1 = 0; __sat1_t1 < block_size; ++__sat1_t1) {
          sink[((flat_c_pos[__sat1])*(block_size) + (__sat1_t0))*(block_size) + (__sat1_t1)] += (1.0 * flat_prod[((__sat1)*(block_size) + (__sat1_t0))*(block_size) + (__sat1_t1)]);
        }
      }
    }
    for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
      for (int64_t si1 = 0; si1 < block_size; ++si1) {
        for (int64_t si2 = 0; si2 < block_size; ++si2) {
          c_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = sink[((si0)*(block_size) + (si1))*(block_size) + (si2)];
        }
      }
    }
    filter_eps_sq = (filter_eps * filter_eps);
    inner = (block_size * block_size);
    free(__cb14);
    __cb14 = (double *)malloc((size_t)((nnz) * (inner)) * sizeof(double));
    __npb_alloc_check(__cb14, (size_t)((nnz) * (inner)) * sizeof(double), "__cb14");
    /* numpy: np.reshape(c_blocks, (nnz, inner)) */
    for (int64_t __rs0 = 0; __rs0 < (3 * n_block_rows); ++__rs0) {
      for (int64_t __rs1 = 0; __rs1 < block_size; ++__rs1) {
        for (int64_t __rs2 = 0; __rs2 < block_size; ++__rs2) {
          __cb14[(__rs0)*(inner) + (((__rs1 * block_size) + __rs2))] = c_blocks[((__rs0)*(block_size) + (__rs1))*(block_size) + (__rs2)];
        }
      }
    }
    free(flat);
    flat = (double *)malloc((size_t)((nnz) * (inner)) * sizeof(double));
    __npb_alloc_check(flat, (size_t)((nnz) * (inner)) * sizeof(double), "flat");
    for (int64_t __w0 = 0; __w0 < nnz; ++__w0) {
      for (int64_t __w1 = 0; __w1 < inner; ++__w1) {
        flat[(__w0)*(inner) + (__w1)] = __cb14[(__w0)*(inner) + (__w1)];
      }
    }
    free(prefix);
    prefix = (double *)malloc((size_t)((nnz) * (inner)) * sizeof(double));
    __npb_alloc_check(prefix, (size_t)((nnz) * (inner)) * sizeof(double), "prefix");
    memset(prefix, 0, (size_t)((nnz) * (inner)) * sizeof(double));
    for (int64_t _cp_row = 0; _cp_row < nnz; ++_cp_row) {
      _cp_acc = 0.0;
      for (int64_t _cp_col = 0; _cp_col < inner; ++_cp_col) {
        _cp_acc += (flat[(_cp_row)*(inner) + (_cp_col)] * flat[(_cp_row)*(inner) + (_cp_col)]);
        prefix[(_cp_row)*(inner) + (_cp_col)] = _cp_acc;
      }
    }
    free(keep);
    keep = (bool *)malloc((size_t)((nnz)) * sizeof(bool));
    __npb_alloc_check(keep, (size_t)((nnz)) * sizeof(bool), "keep");
    for (int64_t __w0 = 0; __w0 < nnz; ++__w0) {
      keep[__w0] = (prefix[(__w0)*(inner) + ((inner - 1))] >= filter_eps_sq);
    }
    free(__cb15);
    __cb15 = (double *)malloc((size_t)((nnz) * (block_size) * (block_size)) * sizeof(double));
    __npb_alloc_check(__cb15, (size_t)((nnz) * (block_size) * (block_size)) * sizeof(double), "__cb15");
    /* numpy: np.where(keep[:, None, None], c_blocks, 0.0) */
    for (int64_t __r0 = 0; __r0 < nnz; ++__r0) {
      for (int64_t __r1 = 0; __r1 < block_size; ++__r1) {
        for (int64_t __r2 = 0; __r2 < block_size; ++__r2) {
          __cb15[((__r0)*(block_size) + (__r1))*(block_size) + (__r2)] = (keep[__r0] ? c_blocks[((__r0)*(block_size) + (__r1))*(block_size) + (__r2)] : 0.0);
        }
      }
    }
    for (int64_t __w0 = 0; __w0 < nnz; ++__w0) {
      for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
        for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
          c_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] = __cb15[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)];
        }
      }
    }
    free(__cb1);
    free(block_rows);
    free(b_base);
    free(a_expand);
    free(row_of);
    free(block_col);
    free(row_cols_of_a);
    free(match_int);
    free(sink);
    free(prefix);
    free(__cb3);
    free(__cb4);
    free(__cb6);
    free(__cb7);
    free(__cb8);
    free(__cb9);
    free(__cb10);
    free(__cb11);
    free(__cb12);
    free(__cb13);
    free(__cb14);
    free(__cb15);
    free(valid);
    free(b_pos);
    free(match);
    free(first_hit);
    free(c_pos);
    free(prod);
    free(flat_valid);
    free(flat_c_pos);
    free(flat_prod);
    free(flat);
    free(keep);
    free(row_cols);
    free(b_expand);
}

static void _diag_positions(int32_t *restrict __hret_1, const int32_t *restrict col_idx, const int64_t n_block_rows) {
    int64_t fanout;
    int64_t __ar_val___cb4;
    int64_t *__cb2 = (int64_t *)malloc((size_t)((n_block_rows)) * sizeof(int64_t));
    __npb_alloc_check(__cb2, (size_t)((n_block_rows)) * sizeof(int64_t), "__cb2");
    int64_t *__cb4 = (int64_t *)malloc((size_t)((n_block_rows)) * sizeof(int64_t));
    __npb_alloc_check(__cb4, (size_t)((n_block_rows)) * sizeof(int64_t), "__cb4");
    int64_t *__cb5 = (int64_t *)malloc((size_t)((n_block_rows)) * sizeof(int64_t));
    __npb_alloc_check(__cb5, (size_t)((n_block_rows)) * sizeof(int64_t), "__cb5");
    int64_t *diag_offset = (int64_t *)malloc((size_t)((n_block_rows)) * sizeof(int64_t));
    __npb_alloc_check(diag_offset, (size_t)((n_block_rows)) * sizeof(int64_t), "diag_offset");
    int64_t *is_diag = NULL;
    int32_t *__cb1 = NULL;
    int64_t *__cb3 = NULL;
    int32_t *row_cols = NULL;
    fanout = int_floor((3 * n_block_rows), n_block_rows);
    free(__cb1);
    __cb1 = (int32_t *)malloc((size_t)((n_block_rows) * (fanout)) * sizeof(int32_t));
    __npb_alloc_check(__cb1, (size_t)((n_block_rows) * (fanout)) * sizeof(int32_t), "__cb1");
    /* numpy: np.reshape(col_idx, (n_block_rows, fanout)) */
    for (int64_t __rs0 = 0; __rs0 < n_block_rows; ++__rs0) {
      for (int64_t __rs1 = 0; __rs1 < fanout; ++__rs1) {
        __cb1[(__rs0)*(fanout) + (__rs1)] = ((int64_t)(col_idx[((__rs0 * fanout) + __rs1)]));
      }
    }
    free(row_cols);
    row_cols = (int32_t *)malloc((size_t)((n_block_rows) * (fanout)) * sizeof(int32_t));
    __npb_alloc_check(row_cols, (size_t)((n_block_rows) * (fanout)) * sizeof(int32_t), "row_cols");
    for (int64_t __w0 = 0; __w0 < n_block_rows; ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        row_cols[(__w0)*(fanout) + (__w1)] = ((int64_t)(__cb1[(__w0)*(fanout) + (__w1)]));
      }
    }
    free(is_diag);
    is_diag = (int64_t *)malloc((size_t)((n_block_rows) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(is_diag, (size_t)((n_block_rows) * (fanout)) * sizeof(int64_t), "is_diag");
    memset(is_diag, 0, (size_t)((n_block_rows) * (fanout)) * sizeof(int64_t));
    /* numpy: np.arange(n_block_rows, dtype=col_idx.dtype) */
    for (int64_t __i = 0; __i < n_block_rows; ++__i) {
      __cb2[__i] = __i;
    }
    free(__cb3);
    __cb3 = (int64_t *)malloc((size_t)((n_block_rows) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(__cb3, (size_t)((n_block_rows) * (fanout)) * sizeof(int64_t), "__cb3");
    /* numpy: np.where(row_cols == __cb2[:, None], 1, 0) */
    for (int64_t __r0 = 0; __r0 < n_block_rows; ++__r0) {
      for (int64_t __r1 = 0; __r1 < fanout; ++__r1) {
        __cb3[(__r0)*(fanout) + (__r1)] = ((((int64_t)(row_cols[(__r0)*(fanout) + (__r1)])) == __cb2[__r0]) ? 1 : 0);
      }
    }
    free(is_diag);
    is_diag = (int64_t *)malloc((size_t)((n_block_rows) * (fanout)) * sizeof(int64_t));
    __npb_alloc_check(is_diag, (size_t)((n_block_rows) * (fanout)) * sizeof(int64_t), "is_diag");
    memset(is_diag, 0, (size_t)((n_block_rows) * (fanout)) * sizeof(int64_t));
    for (int64_t __w0 = 0; __w0 < n_block_rows; ++__w0) {
      for (int64_t __w1 = 0; __w1 < fanout; ++__w1) {
        is_diag[(__w0)*(fanout) + (__w1)] = __cb3[(__w0)*(fanout) + (__w1)];
      }
    }
    /* numpy: np.argmax(is_diag, axis=1) */
    for (int64_t __aax0 = 0; __aax0 < n_block_rows; ++__aax0) {
      __ar_val___cb4 = is_diag[(__aax0)*(fanout) + (0)];
      __cb4[__aax0] = 0;
      for (int64_t __ard0 = 0; __ard0 < fanout; ++__ard0) {
        if (((__ar_val___cb4 == __ar_val___cb4) && ((is_diag[(__aax0)*(fanout) + (__ard0)] != is_diag[(__aax0)*(fanout) + (__ard0)]) || (is_diag[(__aax0)*(fanout) + (__ard0)] > __ar_val___cb4)))) {
          __ar_val___cb4 = is_diag[(__aax0)*(fanout) + (__ard0)];
          __cb4[__aax0] = __ard0;
        }
      }
    }
    for (int64_t __w0 = 0; __w0 < n_block_rows; ++__w0) {
      diag_offset[__w0] = __cb4[__w0];
    }
    /* numpy: np.arange(n_block_rows, dtype=np.int64) */
    for (int64_t __i = 0; __i < n_block_rows; ++__i) {
      __cb5[__i] = __i;
    }
    for (int64_t __w0 = 0; __w0 < n_block_rows; ++__w0) {
      __hret_1[__w0] = ((int32_t)(((__cb5[__w0] * fanout) + diag_offset[__w0])));
    }
    free(__cb2);
    free(__cb4);
    free(__cb5);
    free(diag_offset);
    free(is_diag);
    free(__cb1);
    free(__cb3);
    free(row_cols);
    return;
}

void cp2k_density_matrix_trs4_fp64(int32_t *restrict branch_history, const int32_t *restrict col_idx, double *restrict g_blocks, double *restrict gamma_values, const double *restrict ks_blocks, double *restrict p_blocks, double *restrict poly_blocks, const int32_t *restrict row_ptr, const double *restrict s_inv_blocks, double *restrict scratch_blocks, double *restrict state, double *restrict x2_blocks, double *restrict x_blocks, const int64_t block_size, const double eps_max, const double eps_min, const int64_t n_block_rows, const int64_t n_iter, const int64_t nelectron, const double spin_scale, const double threshold, uint8_t *restrict workspace, const int64_t workspace_size) {
        int64_t n_blocks;
        int64_t n_elems;
        double spectral_scale;
        double trace_fx;
        double trace_gx;
        double frob_id;
        double frob_x;
        double delta_n;
        int64_t iterations_done;
        double converged_value;
        int64_t final_branch;
        int64_t polynomial_steps;
        double mu_a;
        double mu_b;
        double mu_fa;
        double mu_c;
        double chemical_potential;
        double _acc_rr;
        double _acc_xx;
        double _acc_xp;
        double frob_id_sq;
        double frob_x_sq;
        double xr;
        double mu_fc;
        double gamma_;
        int64_t branch;
        int64_t inner;
        double denominator;
        double denominator_floor;
        double _cp_acc;
        double xr2;
        double one_minus_xr;
        int32_t *diag_pos = (int32_t *)malloc((size_t)((n_block_rows)) * sizeof(int32_t));
        __npb_alloc_check(diag_pos, (size_t)((n_block_rows)) * sizeof(int32_t), "diag_pos");
        int64_t *diag_rows = (int64_t *)malloc((size_t)(((n_block_rows * block_size))) * sizeof(int64_t));
        __npb_alloc_check(diag_rows, (size_t)(((n_block_rows * block_size))) * sizeof(int64_t), "diag_rows");
        memset(diag_rows, 0, (size_t)(((n_block_rows * block_size))) * sizeof(int64_t));
        int64_t *diag_cols = (int64_t *)malloc((size_t)(((n_block_rows * block_size))) * sizeof(int64_t));
        __npb_alloc_check(diag_cols, (size_t)(((n_block_rows * block_size))) * sizeof(int64_t), "diag_cols");
        memset(diag_cols, 0, (size_t)(((n_block_rows * block_size))) * sizeof(int64_t));
        int64_t *__cb1 = (int64_t *)malloc((size_t)(((n_block_rows * block_size))) * sizeof(int64_t));
        __npb_alloc_check(__cb1, (size_t)(((n_block_rows * block_size))) * sizeof(int64_t), "__cb1");
        int64_t *diag_flat = (int64_t *)malloc((size_t)(((n_block_rows * block_size))) * sizeof(int64_t));
        __npb_alloc_check(diag_flat, (size_t)(((n_block_rows * block_size))) * sizeof(int64_t), "diag_flat");
        double *__scg0 = (double *)malloc((size_t)(((n_block_rows * block_size))) * sizeof(double));
        __npb_alloc_check(__scg0, (size_t)(((n_block_rows * block_size))) * sizeof(double), "__scg0");
        double *__scg1 = (double *)malloc((size_t)(((n_block_rows * block_size))) * sizeof(double));
        __npb_alloc_check(__scg1, (size_t)(((n_block_rows * block_size))) * sizeof(double), "__scg1");
        double *residual = (double *)malloc((size_t)(((3 * n_block_rows)) * (block_size) * (block_size)) * sizeof(double));
        __npb_alloc_check(residual, (size_t)(((3 * n_block_rows)) * (block_size) * (block_size)) * sizeof(double), "residual");
        double *prod_rr = (double *)malloc((size_t)(((3 * n_block_rows)) * (block_size) * (block_size)) * sizeof(double));
        __npb_alloc_check(prod_rr, (size_t)(((3 * n_block_rows)) * (block_size) * (block_size)) * sizeof(double), "prod_rr");
        double *prod_xp = (double *)malloc((size_t)(((3 * n_block_rows)) * (block_size) * (block_size)) * sizeof(double));
        __npb_alloc_check(prod_xp, (size_t)(((3 * n_block_rows)) * (block_size) * (block_size)) * sizeof(double), "prod_xp");
        double *scan_rr = NULL;
        double *scan_xx = NULL;
        double *scan_xp = NULL;
        double *prefix = NULL;
        double *__cb2 = NULL;
        double *__cb3 = NULL;
        double *__cb4 = NULL;
        double *__cb5 = NULL;
        double *__cb6 = NULL;
        double *prod_xx = NULL;
        double *_prod_rr_flat = NULL;
        double *_prod_xx_flat = NULL;
        double *_prod_xp_flat = NULL;
        double *flat = NULL;
        bool *keep = NULL;
        n_blocks = (3 * n_block_rows);
        n_elems = ((n_blocks * block_size) * block_size);
        for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
          for (int64_t si1 = 0; si1 < block_size; ++si1) {
            for (int64_t si2 = 0; si2 < block_size; ++si2) {
              x_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = 0.0;
            }
          }
        }
        for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
          for (int64_t si1 = 0; si1 < block_size; ++si1) {
            for (int64_t si2 = 0; si2 < block_size; ++si2) {
              x2_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = 0.0;
            }
          }
        }
        for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
          for (int64_t si1 = 0; si1 < block_size; ++si1) {
            for (int64_t si2 = 0; si2 < block_size; ++si2) {
              g_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = 0.0;
            }
          }
        }
        for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
          for (int64_t si1 = 0; si1 < block_size; ++si1) {
            for (int64_t si2 = 0; si2 < block_size; ++si2) {
              poly_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = 0.0;
            }
          }
        }
        for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
          for (int64_t si1 = 0; si1 < block_size; ++si1) {
            for (int64_t si2 = 0; si2 < block_size; ++si2) {
              scratch_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = 0.0;
            }
          }
        }
        for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
          for (int64_t si1 = 0; si1 < block_size; ++si1) {
            for (int64_t si2 = 0; si2 < block_size; ++si2) {
              p_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = 0.0;
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < n_iter; ++__w0) {
          gamma_values[__w0] = 0.0;
        }
        for (int64_t __w0 = 0; __w0 < n_iter; ++__w0) {
          branch_history[__w0] = 0;
        }
        for (int64_t __w0 = 0; __w0 < 10; ++__w0) {
          state[__w0] = 0.0;
        }
        blocked_csr_multiply(s_inv_blocks, ks_blocks, scratch_blocks, col_idx, row_ptr, 1.0, 0.0, block_size, threshold, n_block_rows);
        blocked_csr_multiply(scratch_blocks, s_inv_blocks, x_blocks, col_idx, row_ptr, 1.0, 0.0, block_size, threshold, n_block_rows);
        spectral_scale = ((-1.0) / (eps_max - eps_min));
        _diag_positions(diag_pos, col_idx, n_block_rows);
        /* numpy: np.arange(n_block_rows * block_size) */
        for (int64_t __i = 0; __i < (n_block_rows * block_size); ++__i) {
          __cb1[__i] = __i;
        }
        for (int64_t __w0 = 0; __w0 < (n_block_rows * block_size); ++__w0) {
          diag_flat[__w0] = __cb1[__w0];
        }
        memset(diag_rows, 0, (size_t)(((n_block_rows * block_size))) * sizeof(int64_t));
        for (int64_t __w0 = 0; __w0 < (n_block_rows * block_size); ++__w0) {
          diag_rows[__w0] = ((int64_t)(diag_pos[int_floor(diag_flat[__w0], block_size)]));
        }
        memset(diag_cols, 0, (size_t)(((n_block_rows * block_size))) * sizeof(int64_t));
        for (int64_t __w0 = 0; __w0 < (n_block_rows * block_size); ++__w0) {
          diag_cols[__w0] = python_mod(diag_flat[__w0], block_size);
        }
        for (int64_t __w0 = 0; __w0 < n_blocks; ++__w0) {
          for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
            for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
              x_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] *= spectral_scale;
            }
          }
        }
        for (int64_t __sc0 = 0; __sc0 < (n_block_rows * block_size); ++__sc0) {
          __scg0[__sc0] = x_blocks[((diag_rows[__sc0])*(block_size) + (diag_cols[__sc0]))*(block_size) + (diag_cols[__sc0])];
        }
        for (int64_t __sc0 = 0; __sc0 < (n_block_rows * block_size); ++__sc0) {
          x_blocks[((diag_rows[__sc0])*(block_size) + (diag_cols[__sc0]))*(block_size) + (diag_cols[__sc0])] = (__scg0[__sc0] - (spectral_scale * eps_max));
        }
        trace_fx = 0.0;
        trace_gx = 0.0;
        frob_id = 0.0;
        frob_x = 0.0;
        delta_n = 0.0;
        iterations_done = 0;
        converged_value = 0.0;
        final_branch = 0;
        for (int64_t iteration = 0; iteration < n_iter; ++iteration) {
          blocked_csr_multiply(x_blocks, x_blocks, x2_blocks, col_idx, row_ptr, 1.0, 0.0, block_size, threshold, n_block_rows);
          for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
            for (int64_t si1 = 0; si1 < block_size; ++si1) {
              for (int64_t si2 = 0; si2 < block_size; ++si2) {
                g_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = (x2_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] - (2.0 * x_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)]));
              }
            }
          }
          for (int64_t __sc0 = 0; __sc0 < (n_block_rows * block_size); ++__sc0) {
            __scg1[__sc0] = g_blocks[((diag_rows[__sc0])*(block_size) + (diag_cols[__sc0]))*(block_size) + (diag_cols[__sc0])];
          }
          for (int64_t __sc0 = 0; __sc0 < (n_block_rows * block_size); ++__sc0) {
            g_blocks[((diag_rows[__sc0])*(block_size) + (diag_cols[__sc0]))*(block_size) + (diag_cols[__sc0])] = (__scg1[__sc0] + 1.0);
          }
          for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
            for (int64_t si1 = 0; si1 < block_size; ++si1) {
              for (int64_t si2 = 0; si2 < block_size; ++si2) {
                poly_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = ((4.0 * x_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)]) - (3.0 * x2_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)]));
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (3 * n_block_rows); ++__w0) {
            for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
              for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
                residual[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] = (x2_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] - x_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (3 * n_block_rows); ++__w0) {
            for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
              for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
                prod_rr[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] = (residual[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] * residual[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)]);
              }
            }
          }
          free(prod_xx);
          prod_xx = (double *)malloc((size_t)((n_blocks) * (block_size) * (block_size)) * sizeof(double));
          __npb_alloc_check(prod_xx, (size_t)((n_blocks) * (block_size) * (block_size)) * sizeof(double), "prod_xx");
          for (int64_t __w0 = 0; __w0 < n_blocks; ++__w0) {
            for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
              for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
                prod_xx[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] = (x_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] * x_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (3 * n_block_rows); ++__w0) {
            for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
              for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
                prod_xp[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] = (x2_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] * poly_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)]);
              }
            }
          }
          free(scan_rr);
          scan_rr = (double *)malloc((size_t)((n_elems)) * sizeof(double));
          __npb_alloc_check(scan_rr, (size_t)((n_elems)) * sizeof(double), "scan_rr");
          memset(scan_rr, 0, (size_t)((n_elems)) * sizeof(double));
          free(scan_xx);
          scan_xx = (double *)malloc((size_t)((n_elems)) * sizeof(double));
          __npb_alloc_check(scan_xx, (size_t)((n_elems)) * sizeof(double), "scan_xx");
          memset(scan_xx, 0, (size_t)((n_elems)) * sizeof(double));
          free(scan_xp);
          scan_xp = (double *)malloc((size_t)((n_elems)) * sizeof(double));
          __npb_alloc_check(scan_xp, (size_t)((n_elems)) * sizeof(double), "scan_xp");
          memset(scan_xp, 0, (size_t)((n_elems)) * sizeof(double));
          free(__cb2);
          __cb2 = (double *)malloc((size_t)((n_elems)) * sizeof(double));
          __npb_alloc_check(__cb2, (size_t)((n_elems)) * sizeof(double), "__cb2");
          /* numpy: np.reshape(prod_rr, (n_elems,)) */
          for (int64_t __rs0 = 0; __rs0 < (3 * n_block_rows); ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < block_size; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < block_size; ++__rs2) {
                __cb2[(((__rs0 * (block_size * block_size)) + (__rs1 * block_size)) + __rs2)] = prod_rr[((__rs0)*(block_size) + (__rs1))*(block_size) + (__rs2)];
              }
            }
          }
          free(_prod_rr_flat);
          _prod_rr_flat = (double *)malloc((size_t)((n_elems)) * sizeof(double));
          __npb_alloc_check(_prod_rr_flat, (size_t)((n_elems)) * sizeof(double), "_prod_rr_flat");
          for (int64_t __w0 = 0; __w0 < n_elems; ++__w0) {
            _prod_rr_flat[__w0] = __cb2[__w0];
          }
          free(__cb3);
          __cb3 = (double *)malloc((size_t)((n_elems)) * sizeof(double));
          __npb_alloc_check(__cb3, (size_t)((n_elems)) * sizeof(double), "__cb3");
          /* numpy: np.reshape(prod_xx, (n_elems,)) */
          for (int64_t __rs0 = 0; __rs0 < (3 * n_block_rows); ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < block_size; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < block_size; ++__rs2) {
                __cb3[(((__rs0 * (block_size * block_size)) + (__rs1 * block_size)) + __rs2)] = prod_xx[((__rs0)*(block_size) + (__rs1))*(block_size) + (__rs2)];
              }
            }
          }
          free(_prod_xx_flat);
          _prod_xx_flat = (double *)malloc((size_t)((n_elems)) * sizeof(double));
          __npb_alloc_check(_prod_xx_flat, (size_t)((n_elems)) * sizeof(double), "_prod_xx_flat");
          for (int64_t __w0 = 0; __w0 < n_elems; ++__w0) {
            _prod_xx_flat[__w0] = __cb3[__w0];
          }
          free(__cb4);
          __cb4 = (double *)malloc((size_t)((n_elems)) * sizeof(double));
          __npb_alloc_check(__cb4, (size_t)((n_elems)) * sizeof(double), "__cb4");
          /* numpy: np.reshape(prod_xp, (n_elems,)) */
          for (int64_t __rs0 = 0; __rs0 < (3 * n_block_rows); ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < block_size; ++__rs1) {
              for (int64_t __rs2 = 0; __rs2 < block_size; ++__rs2) {
                __cb4[(((__rs0 * (block_size * block_size)) + (__rs1 * block_size)) + __rs2)] = prod_xp[((__rs0)*(block_size) + (__rs1))*(block_size) + (__rs2)];
              }
            }
          }
          free(_prod_xp_flat);
          _prod_xp_flat = (double *)malloc((size_t)((n_elems)) * sizeof(double));
          __npb_alloc_check(_prod_xp_flat, (size_t)((n_elems)) * sizeof(double), "_prod_xp_flat");
          for (int64_t __w0 = 0; __w0 < n_elems; ++__w0) {
            _prod_xp_flat[__w0] = __cb4[__w0];
          }
          _acc_rr = 0.0;
          _acc_xx = 0.0;
          _acc_xp = 0.0;
          for (int64_t _cp_i = 0; _cp_i < n_elems; ++_cp_i) {
            _acc_rr += _prod_rr_flat[_cp_i];
            _acc_xx += _prod_xx_flat[_cp_i];
            _acc_xp += _prod_xp_flat[_cp_i];
            scan_rr[_cp_i] = _acc_rr;
            scan_xx[_cp_i] = _acc_xx;
            scan_xp[_cp_i] = _acc_xp;
          }
          frob_id_sq = scan_rr[(n_elems - 1)];
          frob_x_sq = scan_xx[(n_elems - 1)];
          trace_fx = scan_xp[(n_elems - 1)];
          trace_gx = frob_id_sq;
          frob_id = sqrt(frob_id_sq);
          frob_x = sqrt(frob_x_sq);
          delta_n = (nelectron - trace_fx);
          if (((frob_id_sq < (threshold * frob_x_sq)) && (fabs(delta_n) < 0.5))) {
            gamma_ = 3.0;
          }
          else if ((fabs(delta_n) < 1e-14)) {
            gamma_ = 0.0;
          }
          else {
            denominator = trace_gx;
            denominator_floor = (fabs(delta_n) / 100.0);
            if ((fabs(denominator) < denominator_floor)) {
              denominator = ((denominator >= 0.0) ? denominator_floor : (-denominator_floor));
            }
            gamma_ = (delta_n / denominator);
          }
          gamma_values[iteration] = gamma_;
          if ((gamma_ > 6.0)) {
            branch = 1;
            for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
              for (int64_t si1 = 0; si1 < block_size; ++si1) {
                for (int64_t si2 = 0; si2 < block_size; ++si2) {
                  x_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = ((2.0 * x_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)]) - x2_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)]);
                }
              }
            }
            inner = (block_size * block_size);
            free(__cb5);
            __cb5 = (double *)malloc((size_t)((n_blocks) * (inner)) * sizeof(double));
            __npb_alloc_check(__cb5, (size_t)((n_blocks) * (inner)) * sizeof(double), "__cb5");
            /* numpy: np.reshape(x_blocks, (n_blocks, inner)) */
            for (int64_t __rs0 = 0; __rs0 < (3 * n_block_rows); ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < block_size; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < block_size; ++__rs2) {
                  __cb5[(__rs0)*(inner) + (((__rs1 * block_size) + __rs2))] = x_blocks[((__rs0)*(block_size) + (__rs1))*(block_size) + (__rs2)];
                }
              }
            }
            free(flat);
            flat = (double *)malloc((size_t)((n_blocks) * (inner)) * sizeof(double));
            __npb_alloc_check(flat, (size_t)((n_blocks) * (inner)) * sizeof(double), "flat");
            for (int64_t __w0 = 0; __w0 < n_blocks; ++__w0) {
              for (int64_t __w1 = 0; __w1 < inner; ++__w1) {
                flat[(__w0)*(inner) + (__w1)] = __cb5[(__w0)*(inner) + (__w1)];
              }
            }
            free(prefix);
            prefix = (double *)malloc((size_t)((n_blocks) * (inner)) * sizeof(double));
            __npb_alloc_check(prefix, (size_t)((n_blocks) * (inner)) * sizeof(double), "prefix");
            memset(prefix, 0, (size_t)((n_blocks) * (inner)) * sizeof(double));
            for (int64_t _cp_row = 0; _cp_row < n_blocks; ++_cp_row) {
              _cp_acc = 0.0;
              for (int64_t _cp_col = 0; _cp_col < inner; ++_cp_col) {
                _cp_acc += (flat[(_cp_row)*(inner) + (_cp_col)] * flat[(_cp_row)*(inner) + (_cp_col)]);
                prefix[(_cp_row)*(inner) + (_cp_col)] = _cp_acc;
              }
            }
            free(keep);
            keep = (bool *)malloc((size_t)((n_blocks)) * sizeof(bool));
            __npb_alloc_check(keep, (size_t)((n_blocks)) * sizeof(bool), "keep");
            for (int64_t __w0 = 0; __w0 < n_blocks; ++__w0) {
              keep[__w0] = (prefix[(__w0)*(inner) + ((inner - 1))] >= (threshold * threshold));
            }
            free(__cb6);
            __cb6 = (double *)malloc((size_t)((n_blocks) * (block_size) * (block_size)) * sizeof(double));
            __npb_alloc_check(__cb6, (size_t)((n_blocks) * (block_size) * (block_size)) * sizeof(double), "__cb6");
            /* numpy: np.where(keep[:, None, None], x_blocks, 0.0) */
            for (int64_t __r0 = 0; __r0 < n_blocks; ++__r0) {
              for (int64_t __r1 = 0; __r1 < block_size; ++__r1) {
                for (int64_t __r2 = 0; __r2 < block_size; ++__r2) {
                  __cb6[((__r0)*(block_size) + (__r1))*(block_size) + (__r2)] = (keep[__r0] ? x_blocks[((__r0)*(block_size) + (__r1))*(block_size) + (__r2)] : 0.0);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < n_blocks; ++__w0) {
              for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
                for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
                  x_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] = __cb6[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)];
                }
              }
            }
          }
          else if ((gamma_ < 0.0)) {
            branch = 2;
            for (int64_t si0 = 0; si0 < (3 * n_block_rows); ++si0) {
              for (int64_t si1 = 0; si1 < block_size; ++si1) {
                for (int64_t si2 = 0; si2 < block_size; ++si2) {
                  x_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)] = x2_blocks[((si0)*(block_size) + (si1))*(block_size) + (si2)];
                }
              }
            }
          }
          else {
            branch = 3;
            for (int64_t __w0 = 0; __w0 < (3 * n_block_rows); ++__w0) {
              for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
                for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
                  poly_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] += (gamma_ * g_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)]);
                }
              }
            }
            blocked_csr_multiply(x2_blocks, poly_blocks, x_blocks, col_idx, row_ptr, 1.0, 0.0, block_size, threshold, n_block_rows);
          }
          branch_history[iteration] = branch;
          iterations_done = (iteration + 1);
          final_branch = branch;
          if (((frob_id_sq < (threshold * frob_x_sq)) && (branch == 3) && (fabs(delta_n) < 0.5))) {
            converged_value = 1.0;
            break;
          }
        }
        blocked_csr_multiply(x_blocks, s_inv_blocks, scratch_blocks, col_idx, row_ptr, 1.0, 0.0, block_size, threshold, n_block_rows);
        blocked_csr_multiply(s_inv_blocks, scratch_blocks, p_blocks, col_idx, row_ptr, 1.0, 0.0, block_size, threshold, n_block_rows);
        for (int64_t __w0 = 0; __w0 < (3 * n_block_rows); ++__w0) {
          for (int64_t __w1 = 0; __w1 < block_size; ++__w1) {
            for (int64_t __w2 = 0; __w2 < block_size; ++__w2) {
              p_blocks[((__w0)*(block_size) + (__w1))*(block_size) + (__w2)] *= spin_scale;
            }
          }
        }
        polynomial_steps = (iterations_done - 1);
        if ((polynomial_steps < 0)) {
          polynomial_steps = 0;
        }
        mu_a = 0.0;
        mu_b = 1.0;
        mu_fa = (-0.5);
        mu_c = 0.5;
        for (int64_t bisection_step = 0; bisection_step < 40; ++bisection_step) {
          mu_c = (0.5 * (mu_a + mu_b));
          xr = mu_c;
          for (int64_t gamma_pos = 0; gamma_pos < polynomial_steps; ++gamma_pos) {
            gamma_ = gamma_values[gamma_pos];
            if ((gamma_ > 6.0)) {
              xr = ((2.0 * xr) - (xr * xr));
            }
            else if ((gamma_ < 0.0)) {
              xr = (xr * xr);
            }
            else {
              xr2 = (xr * xr);
              one_minus_xr = (1.0 - xr);
              xr = ((xr2 * ((4.0 * xr) - (3.0 * xr2))) + (((gamma_ * xr2) * one_minus_xr) * one_minus_xr));
            }
          }
          mu_fc = (xr - 0.5);
          if (((fabs(mu_fc) < 1e-06) || ((0.5 * (mu_b - mu_a)) < 1e-06))) {
            break;
          }
          if (((mu_fc * mu_fa) > 0.0)) {
            mu_a = mu_c;
            mu_fa = mu_fc;
          }
          else {
            mu_b = mu_c;
          }
        }
        chemical_potential = (((eps_min - eps_max) * mu_c) + eps_max);
        state[0] = chemical_potential;
        state[1] = trace_fx;
        state[2] = trace_gx;
        state[3] = frob_id;
        state[4] = frob_x;
        state[5] = delta_n;
        state[6] = iterations_done;
        state[7] = converged_value;
        state[8] = final_branch;
        if ((frob_x > 0.0)) {
          state[9] = (frob_id / frob_x);
        }
        free(diag_pos);
        free(diag_rows);
        free(diag_cols);
        free(__cb1);
        free(diag_flat);
        free(__scg0);
        free(__scg1);
        free(residual);
        free(prod_rr);
        free(prod_xp);
        free(scan_rr);
        free(scan_xx);
        free(scan_xp);
        free(prefix);
        free(__cb2);
        free(__cb3);
        free(__cb4);
        free(__cb5);
        free(__cb6);
        free(prod_xx);
        free(_prod_rr_flat);
        free(_prod_xx_flat);
        free(_prod_xp_flat);
        free(flat);
        free(keep);
}
