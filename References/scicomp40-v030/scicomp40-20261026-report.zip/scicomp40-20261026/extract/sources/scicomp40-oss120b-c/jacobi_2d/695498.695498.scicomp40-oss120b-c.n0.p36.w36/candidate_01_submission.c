#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

// Kernel function signature as defined in signature.json
void jacobi_2d_fp64(double *restrict A, double *restrict B, const int64_t N, const int64_t TSTEPS,
                    uint8_t *restrict workspace, const int64_t workspace_size) {
    // We ignore workspace; it's unused in reference implementation.
    // Use pointer swapping to avoid an extra copy pass.
    double *restrict cur = A;
    double *restrict nxt = B;

    // Main time-stepping loop: each timestep consists of two half-steps.
    #pragma omp parallel
    {
        for (int64_t t = 0; t < TSTEPS; ++t) {
            #pragma omp for schedule(static)
            for (int64_t i = 1; i < N - 1; ++i) {
                const int64_t row = i * N;
                double *restrict cur_row = cur + row;
                double *restrict cur_up = cur + row + N;
                double *restrict cur_down = cur + row - N;
                double *restrict nxt_row = nxt + row;
                #pragma omp simd
                for (int64_t j = 1; j < N - 1; ++j) {
                    nxt_row[j] = 0.2 * (cur_row[j] + cur_row[j-1] + cur_row[j+1] + cur_up[j] + cur_down[j]);
                }
            }

            #pragma omp for schedule(static)
            for (int64_t i = 1; i < N - 1; ++i) {
                const int64_t row = i * N;
                double *restrict nxt_row = nxt + row;
                double *restrict nxt_up = nxt + row + N;
                double *restrict nxt_down = nxt + row - N;
                double *restrict cur_row = cur + row;
                #pragma omp simd
                for (int64_t j = 1; j < N - 1; ++j) {
                    cur_row[j] = 0.2 * (nxt_row[j] + nxt_row[j-1] + nxt_row[j+1] + nxt_up[j] + nxt_down[j]);
                }
            }
        }
    }
    // At the end of the loop A (cur) already holds the final result, matching the reference.
}

