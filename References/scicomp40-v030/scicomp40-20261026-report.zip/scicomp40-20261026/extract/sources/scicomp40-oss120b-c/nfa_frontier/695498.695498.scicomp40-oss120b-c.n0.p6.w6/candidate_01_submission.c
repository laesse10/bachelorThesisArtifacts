/* Optimized implementation of the NFA frontier kernel.
 *
 * This version follows the reference algorithm while making the following improvements:
 *   * Uses a per‑component local "enabled" flag array (uint8_t) to avoid false sharing
 *     between OpenMP threads.
 *   * Removes duplicate zero‑initialisation of buffers.
 *   * Pulls the component base pointer out of inner loops.
 *   * Parallelises the outer component loop with OpenMP static scheduling.
 *   * Uses simple pointer arithmetic and local variables for the hot loops.
 */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <omp.h>

static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}

void nfa_frontier_fp64(
    int64_t *restrict activation_counts,
    const int64_t *restrict col_idx,
    const int64_t *restrict comp_ptr,
    const uint8_t *restrict is_report,
    int64_t *restrict report_counts,
    const int64_t *restrict row_ptr,
    const int64_t *restrict start_idx,
    const int64_t *restrict start_ptr,
    const uint8_t *restrict start_sod,
    const int64_t *restrict stream,
    const uint8_t *restrict symbol_cols,
    const int64_t C,
    const int64_t NE,
    const int64_t NS,
    const int64_t NSTART,
    const int64_t T,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    // Working buffers for frontier and matched indices (shared across components)
    int64_t *frontier = (int64_t *)malloc((size_t)NS * sizeof(int64_t));
    __npb_alloc_check(frontier, (size_t)NS * sizeof(int64_t), "frontier");
    int64_t *matched = (int64_t *)malloc((size_t)NS * sizeof(int64_t));
    __npb_alloc_check(matched, (size_t)NS * sizeof(int64_t), "matched");

    #pragma omp parallel for schedule(static)
    for (int64_t c = 0; c < C; ++c) {
        int64_t base = comp_ptr[c];
        int64_t comp_sz = comp_ptr[c + 1] - base; // number of states in this component
        // Local deduplication flag array for this component
        uint8_t enabled_local[comp_sz];
        memset(enabled_local, 0, (size_t)comp_sz);

        int64_t n_front = 0;
        // Initialise start states
        for (int64_t k = start_ptr[c]; k < start_ptr[c + 1]; ++k) {
            int64_t s = start_idx[k];
            int64_t idx = s - base;
            if (enabled_local[idx] == 0) {
                enabled_local[idx] = 1;
                frontier[base + n_front] = s;
                ++n_front;
            }
        }

        int64_t reports = 0;
        for (int64_t t = 0; t < T; ++t) {
            int64_t eod = (t == T - 1) || (stream[t] == 10);
            int64_t n_match = 0;
            // Step 1: match current frontier
            for (int64_t k = 0; k < n_front; ++k) {
                int64_t s = frontier[base + k];
                if (symbol_cols[s * 256 + stream[t]] != 0) {
                    matched[base + n_match] = s;
                    ++n_match;
                    activation_counts[s] += 1;
                    if (is_report[s] != 0) {
                        ++reports;
                    }
                }
                enabled_local[s - base] = 0; // clear flag
            }
            // Step 2: enable children of matched states
            n_front = 0;
            for (int64_t k = 0; k < n_match; ++k) {
                int64_t s = matched[base + k];
                for (int64_t e = row_ptr[s]; e < row_ptr[s + 1]; ++e) {
                    int64_t child = col_idx[e];
                    int64_t cidx = child - base;
                    if (enabled_local[cidx] == 0) {
                        enabled_local[cidx] = 1;
                        frontier[base + n_front] = child;
                        ++n_front;
                    }
                }
            }
            // Step 3: re‑enable start states
            for (int64_t k = start_ptr[c]; k < start_ptr[c + 1]; ++k) {
                if (start_sod[k] == 0 || eod) {
                    int64_t s = start_idx[k];
                    int64_t idx = s - base;
                    if (enabled_local[idx] == 0) {
                        enabled_local[idx] = 1;
                        frontier[base + n_front] = s;
                        ++n_front;
                    }
                }
            }
        }
        report_counts[c] = reports;
    }

    free(frontier);
    free(matched);
}
