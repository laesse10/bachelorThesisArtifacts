#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

/*
 * Optimized implementation of the 3‑D heat diffusion stencil.
 *
 * The reference implementation allocates two temporary interior buffers and copies the
 * inner cube of A and B on each time‑step. That incurs a large amount of memory traffic –
 * O(N³) extra loads and stores – and dominates the runtime for the large problem sizes
 * used by the benchmark (N ≈ 600‑800, i.e. >200 Mi elements). The algorithm itself is a
 * classic Jacobi update:
 *
 *   B[i,j,k] = A[i,j,k] + α * ( A[i+1,j,k] + A[i-1,j,k] +
 *                              A[i,j+1,k] + A[i,j-1,k] +
 *                              A[i,j,k+1] + A[i,j,k-1] - 6*A[i,j,k] );
 *
 * followed by the same update swapping the roles of A and B. The temporary buffers are
 * unnecessary – the expression only needs the current value of the centre point and its
 * six neighbours. By operating directly on the input arrays we eliminate two full‑cube
 * copies per step and reduce the memory footprint from ~12 GiB to ~8 GiB (the two input
 * arrays only).
 *
 * The implementation uses plain pointer arithmetic for speed and OpenMP parallelism to
 * exploit the many‑core CPUs used in the evaluation. The outer two loops are collapsed
 * ("#pragma omp parallel for collapse(2)") so that each thread works on a block of rows,
 * while the innermost k loop is left for the compiler's auto‑vectoriser.
 *
 * The function signature matches the one described in `signature.json`. The optional
 * workspace argument is currently unused – the algorithm does not need auxiliary storage.
 */

void heat_3d_fp64(double *restrict A,
                  double *restrict B,
                  const int64_t N,
                  const int64_t TSTEPS,
                  const double alpha,
                  uint8_t *restrict workspace,
                  const int64_t workspace_size) {
    (void)workspace; // unused
    (void)workspace_size;

    const int64_t inner = N - 2;               // interior dimension size
    const int64_t stride_i = N * N;            // stride for i dimension
    const int64_t stride_j = N;                // stride for j dimension

    for (int64_t t = 1; t <= TSTEPS; ++t) {
        // Sweep 1: compute B from A
        #pragma omp parallel for collapse(2) schedule(static)
        for (int64_t i = 1; i <= inner; ++i) {
            for (int64_t j = 1; j <= inner; ++j) {
                int64_t base = i * stride_i + j * stride_j + 1; // k starts at 1
                for (int64_t k = 1; k <= inner; ++k) {
                    int64_t idx = base + (k - 1);
                    double a_center = A[idx];
                    double neighbor_sum =
                        A[idx + stride_i] + A[idx - stride_i] +   // i +/- 1
                        A[idx + stride_j] + A[idx - stride_j] +   // j +/- 1
                        A[idx + 1]       + A[idx - 1];            // k +/- 1
                    B[idx] = a_center + alpha * (neighbor_sum - 6.0 * a_center);
                }
            }
        }
        // Sweep 2: compute A from B
        #pragma omp parallel for collapse(2) schedule(static)
        for (int64_t i = 1; i <= inner; ++i) {
            for (int64_t j = 1; j <= inner; ++j) {
                int64_t base = i * stride_i + j * stride_j + 1;
                for (int64_t k = 1; k <= inner; ++k) {
                    int64_t idx = base + (k - 1);
                    double b_center = B[idx];
                    double neighbor_sum =
                        B[idx + stride_i] + B[idx - stride_i] +
                        B[idx + stride_j] + B[idx - stride_j] +
                        B[idx + 1]       + B[idx - 1];
                    A[idx] = b_center + alpha * (neighbor_sum - 6.0 * b_center);
                }
            }
        }
    }
}

