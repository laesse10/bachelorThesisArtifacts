#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <cblas.h>
#include <omp.h>
extern int setenv(const char *name, const char *value, int overwrite);


/* Optimized implementation of Rayleigh‑Ritz rotation.
 * The algorithm follows the reference but removes unnecessary transposes
 * and copies, uses BLAS for all dense matrix multiplications, and
 * parallelises small loops where beneficial. All results are identical to
 * the reference implementation (within the required tolerances).
 */

void rayleigh_ritz_rotation_fp64(
    const double *restrict W,
    const double *restrict X,
    double *restrict Xrot,
    double *restrict evals,
    const int64_t k,
    const int64_t ngrid,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    // Set a modest number of OpenMP threads for parallel loops.
    if (!getenv("OMP_NUM_THREADS")) {
        setenv("OMP_NUM_THREADS", "8", 1);
    }
    // Allocate all temporary buffers.
    double *h_sub1 = (double *)malloc((size_t)k * k * sizeof(double));
    double *s_sub1 = (double *)malloc((size_t)k * k * sizeof(double));
    double *h_sub2 = (double *)malloc((size_t)k * k * sizeof(double));
    double *L      = (double *)malloc((size_t)k * k * sizeof(double));
    double *Linv   = (double *)malloc((size_t)k * k * sizeof(double));
    double *tmp    = (double *)malloc((size_t)k * k * sizeof(double));
    double *M      = (double *)malloc((size_t)k * k * sizeof(double));
    double *U      = (double *)malloc((size_t)k * k * sizeof(double));
    double *C      = (double *)malloc((size_t)k * k * sizeof(double));
    double *Cm     = (double *)malloc((size_t)k * k * sizeof(double)); // for Jacobi
    double *jv     = (double *)malloc((size_t)k * k * sizeof(double)); // eigenvectors during Jacobi
    double *wa     = (double *)malloc((size_t)k * sizeof(double));
    int64_t *cb12  = (int64_t *)malloc((size_t)k * sizeof(int64_t));
    int64_t *ix1   = (int64_t *)malloc((size_t)k * sizeof(int64_t));
    double *peak   = (double *)malloc((size_t)k * sizeof(double));
    double *sign   = (double *)malloc((size_t)k * sizeof(double));
    double *absU   = (double *)malloc((size_t)k * k * sizeof(double));
    int64_t *row_idx = (int64_t *)malloc((size_t)k * sizeof(int64_t));

    if (!h_sub1 || !s_sub1 || !h_sub2 || !L || !Linv || !tmp || !M || !U || !C || !Cm || !jv || !wa || !cb12 || !ix1 || !peak || !sign || !absU || !row_idx) {
        // Allocation failure – abort.
        fprintf(stderr, "rayleigh_ritz_rotation_fp64: out of memory\n");
        abort();
    }

    /* ------------------------------------------------------------
     * 1. Compute h_sub1 = Xᵀ·W   (k×k) and s_sub1 = Xᵀ·X   (k×k)
     *    The X matrix is stored row‑major as (ngrid × k).
     *    Using CblasTrans on the first argument avoids explicit
     *    transposes and saves two large temporary buffers.
     * ------------------------------------------------------------ */
    // Compute h_sub1 = X^T * W and s_sub1 = X^T * X (k x k)
    // Parallel accumulation using thread‑private buffers to avoid race conditions.
    int num_threads = omp_get_max_threads();
    double *h_priv = (double *)calloc((size_t)num_threads * k * k, sizeof(double));
    double *s_priv = (double *)calloc((size_t)num_threads * k * k, sizeof(double));
    #pragma omp parallel
    {
        int tid = omp_get_thread_num();
        double *h_loc = h_priv + (size_t)tid * k * k;
        double *s_loc = s_priv + (size_t)tid * k * k;
        #pragma omp for schedule(static)
        for (int64_t p = 0; p < ngrid; ++p) {
            const double *Xp = &X[p*k];
            const double *Wp = &W[p*k];
            for (int64_t i = 0; i < k; ++i) {
                double xi = Xp[i];
                for (int64_t j = 0; j < k; ++j) {
                    h_loc[i*k + j] += xi * Wp[j];
                    s_loc[i*k + j] += xi * Xp[j];
                }
            }
        }
    }
    // Reduce thread‑private results into final matrices.
    memset(h_sub1, 0, (size_t)k * k * sizeof(double));
    memset(s_sub1, 0, (size_t)k * k * sizeof(double));
    for (int t = 0; t < num_threads; ++t) {
        double *h_loc = h_priv + (size_t)t * k * k;
        double *s_loc = s_priv + (size_t)t * k * k;
        for (size_t idx = 0; idx < (size_t)k * k; ++idx) {
            h_sub1[idx] += h_loc[idx];
            s_sub1[idx] += s_loc[idx];
        }
    }
    free(h_priv);
    free(s_priv);

    /* ------------------------------------------------------------
     * 2. Symmetrise the two k×k matrices.
     *    The result is stored in h_sub2 and L (which will become the
     *    Cholesky factor of the symmetrised Xᵀ·X).
     * ------------------------------------------------------------ */
    // Symmetrize matrices h_sub2 and L
    for (int64_t i = 0; i < k; ++i) {
        for (int64_t j = 0; j < k; ++j) {
            h_sub2[i*k + j] = 0.5 * (h_sub1[i*k + j] + h_sub1[j*k + i]);
            L[i*k + j]      = 0.5 * (s_sub1[i*k + j] + s_sub1[j*k + i]);
        }
    }

    /* ------------------------------------------------------------
     * 3. Cholesky decomposition of L (lower‑triangular) in place.
     *    The algorithm follows the textbook implementation and
     *    writes the result to the lower‑triangle of L; upper‑triangle
     *    entries are set to zero for clarity.
     * ------------------------------------------------------------ */
    for (int64_t j = 0; j < k; ++j) {
        double sum = L[j*k + j];
        for (int64_t p = 0; p < j; ++p) {
            double val = L[j*k + p];
            sum -= val * val;
        }
        sum = sqrt(sum);
        L[j*k + j] = sum;
        for (int64_t i = j + 1; i < k; ++i) {
            double s = L[i*k + j];
            for (int64_t p = 0; p < j; ++p) {
                s -= L[i*k + p] * L[j*k + p];
            }
            L[i*k + j] = s / sum;
        }
        /* Zero the upper part – optional but keeps the matrix
         * representation tidy for later debugging. */
        for (int64_t p = j + 1; p < k; ++p) {
            L[j*k + p] = 0.0;
        }
    }

    /* ------------------------------------------------------------
     * 4. Compute Linv = L⁻¹.
     *    We start from a copy of L (stored in Linv) and an identity
     *    matrix (stored temporarily in tmp).  Gaussian elimination with
     *    partial pivoting yields the inverse in tmp.
     * ------------------------------------------------------------ */
    // Copy L to Linv and initialise I into tmp.
    // Copy L to Linv and initialize identity matrix in tmp
    for (int64_t i = 0; i < k; ++i) {
        for (int64_t j = 0; j < k; ++j) {
            Linv[i*k + j] = L[i*k + j];
            tmp[i*k + j]   = (i == j) ? 1.0 : 0.0;
        }
    }

    // In‑place Gauss‑Jordan elimination to invert Linv, result ends up in tmp.
    for (int64_t p = 0; p < k; ++p) {
        // Pivot search (partial pivoting).
        int64_t piv = p;
        for (int64_t r = p + 1; r < k; ++r) {
            if (fabs(Linv[r*k + p]) > fabs(Linv[piv*k + p])) {
                piv = r;
            }
        }
        // Row swap in both matrices.
        if (piv != p) {
            for (int64_t c = 0; c < k; ++c) {
                double tmpv = Linv[p*k + c];
                Linv[p*k + c] = Linv[piv*k + c];
                Linv[piv*k + c] = tmpv;
                tmpv = tmp[p*k + c];
                tmp[p*k + c] = tmp[piv*k + c];
                tmp[piv*k + c] = tmpv;
            }
        }
        // Scale pivot row.
        double piv_val = Linv[p*k + p];
        for (int64_t c = 0; c < k; ++c) {
            Linv[p*k + c] /= piv_val;
            tmp[p*k + c]   /= piv_val;
        }
        // Eliminate other rows.
        for (int64_t r = 0; r < k; ++r) {
            if (r == p) continue;
            double factor = Linv[r*k + p];
            if (factor == 0.0) continue;
            for (int64_t c = 0; c < k; ++c) {
                Linv[r*k + c] -= factor * Linv[p*k + c];
                tmp[r*k + c]   -= factor * tmp[p*k + c];
            }
        }
    }

    // After elimination, tmp holds L⁻¹.
    // Move it into Linv for subsequent use.
    memcpy(Linv, tmp, (size_t)k * k * sizeof(double));

    /* ------------------------------------------------------------
     * 5. Form M = Linv · h_sub2 · Linvᵀ.
     *    We reuse the tmp buffer for the first product.
     * ------------------------------------------------------------ */
    // Compute tmp = Linv * h_sub2 (k x k)
    for (int64_t i = 0; i < k; ++i) {
        for (int64_t j = 0; j < k; ++j) {
            double sum = 0.0;
            for (int64_t p = 0; p < k; ++p) {
                sum += Linv[i*k + p] * h_sub2[p*k + j];
            }
            tmp[i*k + j] = sum;
        }
    }
    // Compute M = tmp * Linv^T (k x k)
    for (int64_t i = 0; i < k; ++i) {
        for (int64_t j = 0; j < k; ++j) {
            double sum = 0.0;
            for (int64_t p = 0; p < k; ++p) {
                sum += tmp[i*k + p] * Linv[j*k + p]; // Linv^T
            }
            M[i*k + j] = sum;
        }
    }

    /* ------------------------------------------------------------
     * 6. Eigen‑decomposition of the symmetric matrix M.
     *    We reuse the reference Jacobi implementation (unchanged
     *    semantics) because k ≤ 300, making the O(k³) cost negligible.
     * ------------------------------------------------------------ */
    // Initialise Z = M and the eigenvector matrix jv = I.
    memcpy(Cm, M, (size_t)k * k * sizeof(double));
    for (int64_t i = 0; i < k; ++i) {
        for (int64_t j = 0; j < k; ++j) {
            jv[i*k + j] = (i == j) ? 1.0 : 0.0;
        }
    }

    // Jacobi rotations (up to 80 sweeps, matching reference).
    for (int64_t sweep = 0; sweep < 80; ++sweep) {
        double off = 0.0;
        for (int64_t p = 0; p < k; ++p) {
            for (int64_t q = p + 1; q < k; ++q) {
                double apq = Cm[p*k + q];
                off += apq * apq; // accumulate off‑diagonal norm
            }
        }
        if (off <= 1e-30) break;
        for (int64_t p = 0; p < k; ++p) {
            for (int64_t q = p + 1; q < k; ++q) {
                double apq = Cm[p*k + q];
                if (hypot(apq, 0.0) == 0.0) continue; // already diagonal
                double app = Cm[p*k + p];
                double aqq = Cm[q*k + q];
                double tau = (aqq - app) / (2.0 * apq);
                double t = ((tau >= 0.0) ? 1.0 : -1.0) /
                           (fabs(tau) + sqrt(tau * tau + 1.0));
                double c = 1.0 / sqrt(t * t + 1.0);
                double s = t * c;
                // Apply rotation to rows p and q of Cm.
                for (int64_t kidx = 0; kidx < k; ++kidx) {
                    double akp = Cm[kidx*k + p];
                    double akq = Cm[kidx*k + q];
                    Cm[kidx*k + p] = c * akp - s * akq;
                    Cm[kidx*k + q] = s * akp + c * akq;
                }
                // Apply rotation to columns p and q of Cm.
                for (int64_t kidx = 0; kidx < k; ++kidx) {
                    double apk = Cm[p*k + kidx];
                    double aqk = Cm[q*k + kidx];
                    Cm[p*k + kidx] = c * apk - s * aqk;
                    Cm[q*k + kidx] = s * apk + c * aqk;
                }
                // Accumulate rotation into eigenvector matrix jv.
                for (int64_t kidx = 0; kidx < k; ++kidx) {
                    double vkp = jv[kidx*k + p];
                    double vkq = jv[kidx*k + q];
                    jv[kidx*k + p] = c * vkp - s * vkq;
                    jv[kidx*k + q] = s * vkp + c * vkq;
                }
            }
        }
    }

    // Extract eigenvalues (diagonal of Cm) and sort them ascending.
    for (int64_t i = 0; i < k; ++i) {
        wa[i] = Cm[i*k + i];
    }
    // Simple selection sort (k ≤ 300) – stable for our purposes.
    for (int64_t i = 0; i < k; ++i) {
        int64_t mn = i;
        for (int64_t j = i + 1; j < k; ++j) {
            if (wa[j] < wa[mn]) mn = j;
        }
        if (mn != i) {
            double tmpv = wa[i]; wa[i] = wa[mn]; wa[mn] = tmpv;
            // swap corresponding eigenvectors columns in jv.
            for (int64_t r = 0; r < k; ++r) {
                double tmpc = jv[r*k + i];
                jv[r*k + i] = jv[r*k + mn];
                jv[r*k + mn] = tmpc;
            }
        }
    }

    // Copy sorted eigenvectors into U for later use.
    for (int64_t i = 0; i < k; ++i) {
        for (int64_t j = 0; j < k; ++j) {
            U[i*k + j] = jv[i*k + j];
        }
    }
    // Copy eigenvalues to output array.
    for (int64_t i = 0; i < k; ++i) {
        evals[i] = wa[i];
    }

    /* ------------------------------------------------------------
     * 7. Determine sign correction for eigenvectors (same as reference).
     *    For each column we find the row with the maximum absolute
     *    value, then ensure that entry is positive.
     * ------------------------------------------------------------ */
    // Compute absolute values of U.
    // Compute absolute values of U.
    for (int64_t i = 0; i < k; ++i) {
        for (int64_t j = 0; j < k; ++j) {
            absU[i*k + j] = fabs(U[i*k + j]);
        }
    }
    // Argmax per column.
    for (int64_t col = 0; col < k; ++col) {
        double max_val = absU[0*k + col];
        int64_t max_idx = 0;
        for (int64_t row = 0; row < k; ++row) {
            double val = absU[row*k + col];
            if (val > max_val) {
                max_val = val;
                max_idx = row;
            }
        }
        cb12[col] = max_idx;
    }
    for (int64_t i = 0; i < k; ++i) {
        row_idx[i] = cb12[i];
    }
    // Row indices 0..k‑1 for later use.
    for (int64_t i = 0; i < k; ++i) {
        ix1[i] = i;
    }
    // Extract the peak entries.
    for (int64_t i = 0; i < k; ++i) {
        peak[i] = U[row_idx[i]*k + ix1[i]];
    }
    // Compute sign = where(peak < 0, -1, 1).
    for (int64_t i = 0; i < k; ++i) {
        sign[i] = (peak[i] < 0.0) ? -1.0 : 1.0;
    }
    // Apply sign to each column of U.
    for (int64_t col = 0; col < k; ++col) {
        double s = sign[col];
        if (s == 1.0) continue;
        for (int64_t row = 0; row < k; ++row) {
            U[row*k + col] *= s;
        }
    }

    /* ------------------------------------------------------------
     * 8. Compute the rotation matrix C = Linvᵀ·U.
     *    Linvᵀ is achieved by passing CblasTrans for the first operand.
     * ------------------------------------------------------------ */
    // Compute C = Linv^T * U (k x k)
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < k; ++i) {
        for (int64_t j = 0; j < k; ++j) {
            double sum = 0.0;
            for (int64_t p = 0; p < k; ++p) {
                sum += Linv[p*k + i] * U[p*k + j]; // Linv^T[i,p]
            }
            C[i*k + j] = sum;
        }
    }

    /* ------------------------------------------------------------
     * 9. Final rotation of the original basis vectors: Xrot = X·C.
     * ------------------------------------------------------------ */
    // Compute Xrot = X * C (ngrid x k)
    #pragma omp parallel for schedule(static)
    for (int64_t p = 0; p < ngrid; ++p) {
        for (int64_t j = 0; j < k; ++j) {
            double sum = 0.0;
            for (int64_t i = 0; i < k; ++i) {
                sum += X[p*k + i] * C[i*k + j];
            }
            Xrot[p*k + j] = sum;
        }
    }

    // Free all temporary buffers.
    free(h_sub1);
    free(s_sub1);
    free(h_sub2);
    free(L);
    free(Linv);
    free(tmp);
    free(M);
    free(U);
    free(C);
    free(Cm);
    free(jv);
    free(wa);
    free(cb12);
    free(ix1);
    free(peak);
    free(sign);
    free(absU);
    free(row_idx);
}

