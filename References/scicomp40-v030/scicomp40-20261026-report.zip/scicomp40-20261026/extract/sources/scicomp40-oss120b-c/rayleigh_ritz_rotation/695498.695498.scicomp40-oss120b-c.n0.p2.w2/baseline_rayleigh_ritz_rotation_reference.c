// hpcagent_bench-autogen -- generated from rayleigh_ritz_rotation_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}
#include <cblas.h>

void rayleigh_ritz_rotation_fp64(const double *restrict W, const double *restrict X, double *restrict Xrot, double *restrict evals, const int64_t k, const int64_t ngrid, uint8_t *restrict workspace, const int64_t workspace_size) {
        double __s;
        int64_t __inv_p;
        double __inv_factor;
        double __eigh0_off;
        int64_t __eigh0_mn;
        double __ar_val___cb12;
        double __inv_tmp;
        double __eigh0_tw;
        double __eigh0_apq;
        double __eigh0_app;
        double __eigh0_aqq;
        double __eigh0_s;
        double __eigh0_tv;
        double __eigh0_akp;
        double __eigh0_akq;
        double __eigh0_apk;
        double __eigh0_aqk;
        double __eigh0_vkp;
        double __eigh0_vkq;
        double *__eigh0_Cm = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__eigh0_Cm, (size_t)((k) * (k)) * sizeof(double), "__eigh0_Cm");
        memset(__eigh0_Cm, 0, (size_t)((k) * (k)) * sizeof(double));
        double *__eigh0_jv = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__eigh0_jv, (size_t)((k) * (k)) * sizeof(double), "__eigh0_jv");
        memset(__eigh0_jv, 0, (size_t)((k) * (k)) * sizeof(double));
        double *__eigh0_wa = (double *)malloc((size_t)((k)) * sizeof(double));
        __npb_alloc_check(__eigh0_wa, (size_t)((k)) * sizeof(double), "__eigh0_wa");
        memset(__eigh0_wa, 0, (size_t)((k)) * sizeof(double));
        double *__cb1 = (double *)malloc((size_t)((k) * (ngrid)) * sizeof(double));
        __npb_alloc_check(__cb1, (size_t)((k) * (ngrid)) * sizeof(double), "__cb1");
        double *__mm2 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__mm2, (size_t)((k) * (k)) * sizeof(double), "__mm2");
        double *__cb3 = (double *)malloc((size_t)((k) * (ngrid)) * sizeof(double));
        __npb_alloc_check(__cb3, (size_t)((k) * (ngrid)) * sizeof(double), "__cb3");
        double *__mm4 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__mm4, (size_t)((k) * (k)) * sizeof(double), "__mm4");
        double *__cb5 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__cb5, (size_t)((k) * (k)) * sizeof(double), "__cb5");
        double *__cb6 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__cb6, (size_t)((k) * (k)) * sizeof(double), "__cb6");
        double *__cb7 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__cb7, (size_t)((k) * (k)) * sizeof(double), "__cb7");
        double *__cb8 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__cb8, (size_t)((k) * (k)) * sizeof(double), "__cb8");
        double *__cb9 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__cb9, (size_t)((k) * (k)) * sizeof(double), "__cb9");
        double *__mm10 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__mm10, (size_t)((k) * (k)) * sizeof(double), "__mm10");
        double *__mm11 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__mm11, (size_t)((k) * (k)) * sizeof(double), "__mm11");
        int64_t *__cb12 = (int64_t *)malloc((size_t)((k)) * sizeof(int64_t));
        __npb_alloc_check(__cb12, (size_t)((k)) * sizeof(int64_t), "__cb12");
        int64_t *__cb13 = (int64_t *)malloc((size_t)((k)) * sizeof(int64_t));
        __npb_alloc_check(__cb13, (size_t)((k)) * sizeof(int64_t), "__cb13");
        double *__cb14 = (double *)malloc((size_t)((k)) * sizeof(double));
        __npb_alloc_check(__cb14, (size_t)((k)) * sizeof(double), "__cb14");
        double *__cb15 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__cb15, (size_t)((k) * (k)) * sizeof(double), "__cb15");
        double *__mm16 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__mm16, (size_t)((k) * (k)) * sizeof(double), "__mm16");
        double *__mm17 = (double *)malloc((size_t)((ngrid) * (k)) * sizeof(double));
        __npb_alloc_check(__mm17, (size_t)((ngrid) * (k)) * sizeof(double), "__mm17");
        double *__inv_aw0 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__inv_aw0, (size_t)((k) * (k)) * sizeof(double), "__inv_aw0");
        double *h_sub1 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(h_sub1, (size_t)((k) * (k)) * sizeof(double), "h_sub1");
        double *s_sub1 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(s_sub1, (size_t)((k) * (k)) * sizeof(double), "s_sub1");
        double *h_sub2 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(h_sub2, (size_t)((k) * (k)) * sizeof(double), "h_sub2");
        double *s_sub2 = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(s_sub2, (size_t)((k) * (k)) * sizeof(double), "s_sub2");
        double *L = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(L, (size_t)((k) * (k)) * sizeof(double), "L");
        double *Linv = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(Linv, (size_t)((k) * (k)) * sizeof(double), "Linv");
        double *M = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(M, (size_t)((k) * (k)) * sizeof(double), "M");
        double *__eigh0_ya = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(__eigh0_ya, (size_t)((k) * (k)) * sizeof(double), "__eigh0_ya");
        double *w = (double *)malloc((size_t)((k)) * sizeof(double));
        __npb_alloc_check(w, (size_t)((k)) * sizeof(double), "w");
        double *U = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(U, (size_t)((k) * (k)) * sizeof(double), "U");
        int64_t *row_idx = (int64_t *)malloc((size_t)((k)) * sizeof(int64_t));
        __npb_alloc_check(row_idx, (size_t)((k)) * sizeof(int64_t), "row_idx");
        int64_t *__ix1 = (int64_t *)malloc((size_t)((k)) * sizeof(int64_t));
        __npb_alloc_check(__ix1, (size_t)((k)) * sizeof(int64_t), "__ix1");
        double *sign = (double *)malloc((size_t)((k)) * sizeof(double));
        __npb_alloc_check(sign, (size_t)((k)) * sizeof(double), "sign");
        double *C = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(C, (size_t)((k) * (k)) * sizeof(double), "C");
        double *peak = (double *)malloc((size_t)((k)) * sizeof(double));
        __npb_alloc_check(peak, (size_t)((k)) * sizeof(double), "peak");
        double *absU = (double *)malloc((size_t)((k) * (k)) * sizeof(double));
        __npb_alloc_check(absU, (size_t)((k) * (k)) * sizeof(double), "absU");
        /* numpy: np.transpose(X) */
        for (int64_t __t0 = 0; __t0 < ngrid; ++__t0) {
          for (int64_t __t1 = 0; __t1 < k; ++__t1) {
            __cb1[(__t1)*(ngrid) + (__t0)] = X[(__t0)*(k) + (__t1)];
          }
        }
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(k), (blasint)(k), (blasint)(ngrid), 1.0, __cb1, (blasint)(ngrid), W, (blasint)(k), 0.0, __mm2, (blasint)(k));
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            h_sub1[(__w0)*(k) + (__w1)] = __mm2[(__w0)*(k) + (__w1)];
          }
        }
        /* numpy: np.transpose(X) */
        for (int64_t __t0 = 0; __t0 < ngrid; ++__t0) {
          for (int64_t __t1 = 0; __t1 < k; ++__t1) {
            __cb3[(__t1)*(ngrid) + (__t0)] = X[(__t0)*(k) + (__t1)];
          }
        }
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(k), (blasint)(k), (blasint)(ngrid), 1.0, __cb3, (blasint)(ngrid), X, (blasint)(k), 0.0, __mm4, (blasint)(k));
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            s_sub1[(__w0)*(k) + (__w1)] = __mm4[(__w0)*(k) + (__w1)];
          }
        }
        /* numpy: np.transpose(h_sub1) */
        for (int64_t __t0 = 0; __t0 < k; ++__t0) {
          for (int64_t __t1 = 0; __t1 < k; ++__t1) {
            __cb5[(__t1)*(k) + (__t0)] = h_sub1[(__t0)*(k) + (__t1)];
          }
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            h_sub2[(__w0)*(k) + (__w1)] = (0.5 * (h_sub1[(__w0)*(k) + (__w1)] + __cb5[(__w0)*(k) + (__w1)]));
          }
        }
        /* numpy: np.transpose(s_sub1) */
        for (int64_t __t0 = 0; __t0 < k; ++__t0) {
          for (int64_t __t1 = 0; __t1 < k; ++__t1) {
            __cb6[(__t1)*(k) + (__t0)] = s_sub1[(__t0)*(k) + (__t1)];
          }
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            s_sub2[(__w0)*(k) + (__w1)] = (0.5 * (s_sub1[(__w0)*(k) + (__w1)] + __cb6[(__w0)*(k) + (__w1)]));
          }
        }
        /* numpy: np.linalg.cholesky(s_sub2) */
        for (int64_t __zi = 0; __zi < k; ++__zi) {
          for (int64_t __zj = (__zi + 1); __zj < k; ++__zj) {
            __cb7[(__zi)*(k) + (__zj)] = 0.0;
          }
        }
        for (int64_t __j = 0; __j < k; ++__j) {
          __s = s_sub2[(__j)*(k) + (__j)];
          for (int64_t __k = 0; __k < __j; ++__k) {
            __s -= (__cb7[(__j)*(k) + (__k)] * __cb7[(__j)*(k) + (__k)]);
          }
          __cb7[(__j)*(k) + (__j)] = sqrt(__s);
          for (int64_t __i = (__j + 1); __i < k; ++__i) {
            __s = s_sub2[(__i)*(k) + (__j)];
            for (int64_t __k = 0; __k < __j; ++__k) {
              __s -= (__cb7[(__i)*(k) + (__k)] * __cb7[(__j)*(k) + (__k)]);
            }
            __cb7[(__i)*(k) + (__j)] = (__s / __cb7[(__j)*(k) + (__j)]);
          }
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            L[(__w0)*(k) + (__w1)] = __cb7[(__w0)*(k) + (__w1)];
          }
        }
        /* numpy: np.linalg.inv(L) */
        for (int64_t __inv_i = 0; __inv_i < k; ++__inv_i) {
          for (int64_t __inv_j = 0; __inv_j < k; ++__inv_j) {
            __inv_aw0[(__inv_i)*(k) + (__inv_j)] = L[(__inv_i)*(k) + (__inv_j)];
            __cb8[(__inv_i)*(k) + (__inv_j)] = ((__inv_i == __inv_j) ? 1.0 : 0.0);
          }
        }
        for (int64_t __inv_k = 0; __inv_k < k; ++__inv_k) {
          __inv_p = __inv_k;
          for (int64_t __inv_r = (__inv_k + 1); __inv_r < k; ++__inv_r) {
            if ((fabs(__inv_aw0[(__inv_r)*(k) + (__inv_k)]) > fabs(__inv_aw0[(__inv_p)*(k) + (__inv_k)]))) {
              __inv_p = __inv_r;
            }
          }
          for (int64_t __inv_c = 0; __inv_c < k; ++__inv_c) {
            __inv_tmp = __inv_aw0[(__inv_k)*(k) + (__inv_c)];
            __inv_aw0[(__inv_k)*(k) + (__inv_c)] = __inv_aw0[(__inv_p)*(k) + (__inv_c)];
            __inv_aw0[(__inv_p)*(k) + (__inv_c)] = __inv_tmp;
            __inv_tmp = __cb8[(__inv_k)*(k) + (__inv_c)];
            __cb8[(__inv_k)*(k) + (__inv_c)] = __cb8[(__inv_p)*(k) + (__inv_c)];
            __cb8[(__inv_p)*(k) + (__inv_c)] = __inv_tmp;
          }
          __inv_factor = __inv_aw0[(__inv_k)*(k) + (__inv_k)];
          for (int64_t __inv_c = 0; __inv_c < k; ++__inv_c) {
            __cb8[(__inv_k)*(k) + (__inv_c)] = (__cb8[(__inv_k)*(k) + (__inv_c)] / __inv_factor);
            __inv_aw0[(__inv_k)*(k) + (__inv_c)] = (__inv_aw0[(__inv_k)*(k) + (__inv_c)] / __inv_factor);
          }
          for (int64_t __inv_r = 0; __inv_r < k; ++__inv_r) {
            if ((__inv_r != __inv_k)) {
              __inv_factor = __inv_aw0[(__inv_r)*(k) + (__inv_k)];
              for (int64_t __inv_c = 0; __inv_c < k; ++__inv_c) {
                __cb8[(__inv_r)*(k) + (__inv_c)] = (__cb8[(__inv_r)*(k) + (__inv_c)] - (__inv_factor * __cb8[(__inv_k)*(k) + (__inv_c)]));
                __inv_aw0[(__inv_r)*(k) + (__inv_c)] = (__inv_aw0[(__inv_r)*(k) + (__inv_c)] - (__inv_factor * __inv_aw0[(__inv_k)*(k) + (__inv_c)]));
              }
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            Linv[(__w0)*(k) + (__w1)] = __cb8[(__w0)*(k) + (__w1)];
          }
        }
        /* numpy: np.transpose(Linv) */
        for (int64_t __t0 = 0; __t0 < k; ++__t0) {
          for (int64_t __t1 = 0; __t1 < k; ++__t1) {
            __cb9[(__t1)*(k) + (__t0)] = Linv[(__t0)*(k) + (__t1)];
          }
        }
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(k), (blasint)(k), (blasint)(k), 1.0, Linv, (blasint)(k), h_sub2, (blasint)(k), 0.0, __mm10, (blasint)(k));
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(k), (blasint)(k), (blasint)(k), 1.0, __mm10, (blasint)(k), __cb9, (blasint)(k), 0.0, __mm11, (blasint)(k));
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            M[(__w0)*(k) + (__w1)] = __mm11[(__w0)*(k) + (__w1)];
          }
        }
        memset(__eigh0_Cm, 0, (size_t)((k) * (k)) * sizeof(double));
        for (int64_t __eigh0_ci = 0; __eigh0_ci < k; ++__eigh0_ci) {
          for (int64_t __eigh0_cj = 0; __eigh0_cj < k; ++__eigh0_cj) {
            __eigh0_Cm[(__eigh0_ci)*(k) + (__eigh0_cj)] = M[(__eigh0_ci)*(k) + (__eigh0_cj)];
          }
        }
        memset(__eigh0_jv, 0, (size_t)((k) * (k)) * sizeof(double));
        for (int64_t __eigh0_di = 0; __eigh0_di < k; ++__eigh0_di) {
          __eigh0_jv[(__eigh0_di)*(k) + (__eigh0_di)] = 1;
        }
        for (int64_t __eigh0_sw = 0; __eigh0_sw < 80; ++__eigh0_sw) {
          __eigh0_off = 0.0;
          for (int64_t __eigh0_pp = 0; __eigh0_pp < k; ++__eigh0_pp) {
            for (int64_t __eigh0_qq = (__eigh0_pp + 1); __eigh0_qq < k; ++__eigh0_qq) {
              __eigh0_off += ((__eigh0_Cm[(__eigh0_pp)*(k) + (__eigh0_qq)] * __eigh0_Cm[(__eigh0_pp)*(k) + (__eigh0_qq)]) + (0.0 * 0.0));
            }
          }
          if ((__eigh0_off <= 1e-30)) {
            break;
          }
          for (int64_t __eigh0_pp = 0; __eigh0_pp < k; ++__eigh0_pp) {
            for (int64_t __eigh0_qq = (__eigh0_pp + 1); __eigh0_qq < k; ++__eigh0_qq) {
              __eigh0_apq = __eigh0_Cm[(__eigh0_pp)*(k) + (__eigh0_qq)];
              if ((hypot(__eigh0_apq, 0.0) == 0.0)) {
                continue;
              }
              __eigh0_app = __eigh0_Cm[(__eigh0_pp)*(k) + (__eigh0_pp)];
              __eigh0_aqq = __eigh0_Cm[(__eigh0_qq)*(k) + (__eigh0_qq)];
              __eigh0_s = ((((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0)))) * (1.0 / sqrt((((((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0)))) * (((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0))))) + 1.0))));
              for (int64_t __eigh0_k = 0; __eigh0_k < k; ++__eigh0_k) {
                __eigh0_akp = __eigh0_Cm[(__eigh0_k)*(k) + (__eigh0_pp)];
                __eigh0_akq = __eigh0_Cm[(__eigh0_k)*(k) + (__eigh0_qq)];
                __eigh0_Cm[(__eigh0_k)*(k) + (__eigh0_pp)] = (((1.0 / sqrt((((((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0)))) * (((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __eigh0_akp) - ((__eigh0_s * (__eigh0_apq / hypot(__eigh0_apq, 0.0))) * __eigh0_akq));
                __eigh0_Cm[(__eigh0_k)*(k) + (__eigh0_qq)] = (((__eigh0_s * (__eigh0_apq / hypot(__eigh0_apq, 0.0))) * __eigh0_akp) + ((1.0 / sqrt((((((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0)))) * (((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __eigh0_akq));
              }
              for (int64_t __eigh0_k = 0; __eigh0_k < k; ++__eigh0_k) {
                __eigh0_apk = __eigh0_Cm[(__eigh0_pp)*(k) + (__eigh0_k)];
                __eigh0_aqk = __eigh0_Cm[(__eigh0_qq)*(k) + (__eigh0_k)];
                __eigh0_Cm[(__eigh0_pp)*(k) + (__eigh0_k)] = (((1.0 / sqrt((((((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0)))) * (((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __eigh0_apk) - ((__eigh0_s * (__eigh0_apq / hypot(__eigh0_apq, 0.0))) * __eigh0_aqk));
                __eigh0_Cm[(__eigh0_qq)*(k) + (__eigh0_k)] = (((__eigh0_s * (__eigh0_apq / hypot(__eigh0_apq, 0.0))) * __eigh0_apk) + ((1.0 / sqrt((((((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0)))) * (((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __eigh0_aqk));
              }
              for (int64_t __eigh0_k = 0; __eigh0_k < k; ++__eigh0_k) {
                __eigh0_vkp = __eigh0_jv[(__eigh0_k)*(k) + (__eigh0_pp)];
                __eigh0_vkq = __eigh0_jv[(__eigh0_k)*(k) + (__eigh0_qq)];
                __eigh0_jv[(__eigh0_k)*(k) + (__eigh0_pp)] = (((1.0 / sqrt((((((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0)))) * (((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __eigh0_vkp) - ((__eigh0_s * (__eigh0_apq / hypot(__eigh0_apq, 0.0))) * __eigh0_vkq));
                __eigh0_jv[(__eigh0_k)*(k) + (__eigh0_qq)] = (((__eigh0_s * (__eigh0_apq / hypot(__eigh0_apq, 0.0))) * __eigh0_vkp) + ((1.0 / sqrt((((((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0)))) * (((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + sqrt(((((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0))) * ((__eigh0_aqq - __eigh0_app) / (2.0 * hypot(__eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __eigh0_vkq));
              }
            }
          }
        }
        memset(__eigh0_wa, 0, (size_t)((k)) * sizeof(double));
        for (int64_t __eigh0_i = 0; __eigh0_i < k; ++__eigh0_i) {
          __eigh0_wa[__eigh0_i] = __eigh0_Cm[(__eigh0_i)*(k) + (__eigh0_i)];
        }
        for (int64_t __eigh0_i = 0; __eigh0_i < k; ++__eigh0_i) {
          __eigh0_mn = __eigh0_i;
          for (int64_t __eigh0_j = (__eigh0_i + 1); __eigh0_j < k; ++__eigh0_j) {
            if ((__eigh0_wa[__eigh0_j] < __eigh0_wa[__eigh0_mn])) {
              __eigh0_mn = __eigh0_j;
            }
          }
          if ((__eigh0_mn != __eigh0_i)) {
            __eigh0_tw = __eigh0_wa[__eigh0_i];
            __eigh0_wa[__eigh0_i] = __eigh0_wa[__eigh0_mn];
            __eigh0_wa[__eigh0_mn] = __eigh0_tw;
            for (int64_t __eigh0_k = 0; __eigh0_k < k; ++__eigh0_k) {
              __eigh0_tv = __eigh0_jv[(__eigh0_k)*(k) + (__eigh0_i)];
              __eigh0_jv[(__eigh0_k)*(k) + (__eigh0_i)] = __eigh0_jv[(__eigh0_k)*(k) + (__eigh0_mn)];
              __eigh0_jv[(__eigh0_k)*(k) + (__eigh0_mn)] = __eigh0_tv;
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            __eigh0_ya[(__w0)*(k) + (__w1)] = __eigh0_jv[(__w0)*(k) + (__w1)];
          }
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          w[__w0] = __eigh0_wa[__w0];
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            U[(__w0)*(k) + (__w1)] = __eigh0_ya[(__w0)*(k) + (__w1)];
          }
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            absU[(__w0)*(k) + (__w1)] = fabs(U[(__w0)*(k) + (__w1)]);
          }
        }
        /* numpy: np.argmax(absU, axis=0) */
        for (int64_t __aax0 = 0; __aax0 < k; ++__aax0) {
          __ar_val___cb12 = absU[(0)*(k) + (__aax0)];
          __cb12[__aax0] = 0;
          for (int64_t __ard0 = 0; __ard0 < k; ++__ard0) {
            if (((__ar_val___cb12 == __ar_val___cb12) && ((absU[(__ard0)*(k) + (__aax0)] != absU[(__ard0)*(k) + (__aax0)]) || (absU[(__ard0)*(k) + (__aax0)] > __ar_val___cb12)))) {
              __ar_val___cb12 = absU[(__ard0)*(k) + (__aax0)];
              __cb12[__aax0] = __ard0;
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          row_idx[__w0] = __cb12[__w0];
        }
        /* numpy: np.arange(k) */
        for (int64_t __i = 0; __i < k; ++__i) {
          __cb13[__i] = __i;
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          __ix1[__w0] = __cb13[__w0];
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          peak[__w0] = U[(row_idx[__w0])*(k) + (__ix1[__w0])];
        }
        /* numpy: np.where(peak < 0.0, -1.0, 1.0) */
        for (int64_t __r0 = 0; __r0 < k; ++__r0) {
          __cb14[__r0] = ((peak[__r0] < 0.0) ? (-1.0) : 1.0);
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          sign[__w0] = __cb14[__w0];
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            U[(__w0)*(k) + (__w1)] = (U[(__w0)*(k) + (__w1)] * sign[__w1]);
          }
        }
        /* numpy: np.transpose(Linv) */
        for (int64_t __t0 = 0; __t0 < k; ++__t0) {
          for (int64_t __t1 = 0; __t1 < k; ++__t1) {
            __cb15[(__t1)*(k) + (__t0)] = Linv[(__t0)*(k) + (__t1)];
          }
        }
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(k), (blasint)(k), (blasint)(k), 1.0, __cb15, (blasint)(k), U, (blasint)(k), 0.0, __mm16, (blasint)(k));
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          for (int64_t __w1 = 0; __w1 < k; ++__w1) {
            C[(__w0)*(k) + (__w1)] = __mm16[(__w0)*(k) + (__w1)];
          }
        }
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(ngrid), (blasint)(k), (blasint)(k), 1.0, X, (blasint)(k), C, (blasint)(k), 0.0, __mm17, (blasint)(k));
        for (int64_t si0 = 0; si0 < ngrid; ++si0) {
          for (int64_t si1 = 0; si1 < k; ++si1) {
            Xrot[(si0)*(k) + (si1)] = __mm17[(si0)*(k) + (si1)];
          }
        }
        for (int64_t __w0 = 0; __w0 < k; ++__w0) {
          evals[__w0] = w[__w0];
        }
        free(__eigh0_Cm);
        free(__eigh0_jv);
        free(__eigh0_wa);
        free(__cb1);
        free(__mm2);
        free(__cb3);
        free(__mm4);
        free(__cb5);
        free(__cb6);
        free(__cb7);
        free(__cb8);
        free(__cb9);
        free(__mm10);
        free(__mm11);
        free(__cb12);
        free(__cb13);
        free(__cb14);
        free(__cb15);
        free(__mm16);
        free(__mm17);
        free(__inv_aw0);
        free(h_sub1);
        free(s_sub1);
        free(h_sub2);
        free(s_sub2);
        free(L);
        free(Linv);
        free(M);
        free(__eigh0_ya);
        free(w);
        free(U);
        free(row_idx);
        free(__ix1);
        free(sign);
        free(C);
        free(peak);
        free(absU);
}
