#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <omp.h>

static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}

static const int64_t MAX_ITER = 100;
static const double TOLERANCE = 1e-10;

// Sparse matrix-vector multiply (CSR): y = A * x
static inline void spmv_csr(const int64_t *restrict row_offsets,
                             const int64_t *restrict cols,
                             const double *restrict values,
                             const double *restrict x,
                             double *restrict y,
                             int64_t nrows) {
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < nrows; ++i) {
        double sum = 0.0;
        for (int64_t j = row_offsets[i]; j < row_offsets[i + 1]; ++j) {
            sum += values[j] * x[cols[j]];
        }
        y[i] = sum;
    }
}

void minife_fp64(double *restrict b,
                 const int64_t *restrict cols,
                 const int64_t *restrict row_offsets,
                 const double *restrict values,
                 double *restrict x,
                 const int64_t nsteps,
                 const int64_t nx,
                 const int64_t ny,
                 const int64_t nz,
                 uint8_t *restrict workspace,
                 const int64_t workspace_size) {
    const int64_t nrows = (nx + 1) * (ny + 1) * (nz + 1);

    // Allocate temporary vectors
    double *p  = (double *)malloc((size_t)nrows * sizeof(double));
    double *ap = (double *)malloc((size_t)nrows * sizeof(double));
    double *r  = (double *)malloc((size_t)nrows * sizeof(double));
    __npb_alloc_check(p,  (size_t)nrows * sizeof(double), "p");
    __npb_alloc_check(ap, (size_t)nrows * sizeof(double), "ap");
    __npb_alloc_check(r,  (size_t)nrows * sizeof(double), "r");

    for (int64_t step = 0; step < nsteps; ++step) {
        // p = x (copy current guess)
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < nrows; ++i) {
            p[i] = x[i];
        }
        // ap = A * p
        spmv_csr(row_offsets, cols, values, p, ap, nrows);
        // r = b - ap
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < nrows; ++i) {
            r[i] = b[i] - ap[i];
        }
        // Compute residual norm squared
        double r_norm_sq = 0.0;
        #pragma omp parallel for reduction(+:r_norm_sq) schedule(static)
        for (int64_t i = 0; i < nrows; ++i) {
            r_norm_sq += r[i] * r[i];
        }
        double r_norm = sqrt(r_norm_sq);
        double r_norm_sq_old = r_norm_sq;

        // Conjugate Gradient iterations
        for (int64_t k = 1; k <= MAX_ITER; ++k) {
            if (r_norm <= TOLERANCE) {
                break;
            }
            if (k == 1) {
                // p = r
                #pragma omp parallel for schedule(static)
                for (int64_t i = 0; i < nrows; ++i) {
                    p[i] = r[i];
                }
            } else {
                double beta = r_norm_sq / r_norm_sq_old;
                #pragma omp parallel for schedule(static)
                for (int64_t i = 0; i < nrows; ++i) {
                    p[i] = r[i] + beta * p[i];
                }
            }
            // ap = A * p
            spmv_csr(row_offsets, cols, values, p, ap, nrows);
            // Compute dot(p, ap)
            double p_ap_dot = 0.0;
            #pragma omp parallel for reduction(+:p_ap_dot) schedule(static)
            for (int64_t i = 0; i < nrows; ++i) {
                p_ap_dot += p[i] * ap[i];
            }
            if (p_ap_dot <= 0.0) {
                break; // non-positive definite matrix (should not happen)
            }
            double alpha = r_norm_sq / p_ap_dot;
            // Update solution x = x + alpha * p
            #pragma omp parallel for schedule(static)
            for (int64_t i = 0; i < nrows; ++i) {
                x[i] += alpha * p[i];
            }
            // Update residual r = r - alpha * ap
            #pragma omp parallel for schedule(static)
            for (int64_t i = 0; i < nrows; ++i) {
                r[i] -= alpha * ap[i];
            }
            // Prepare for next iteration
            r_norm_sq_old = r_norm_sq;
            r_norm_sq = 0.0;
            #pragma omp parallel for reduction(+:r_norm_sq) schedule(static)
            for (int64_t i = 0; i < nrows; ++i) {
                r_norm_sq += r[i] * r[i];
            }
            r_norm = sqrt(r_norm_sq);
        }
        // Update RHS for next step: b = x
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < nrows; ++i) {
            b[i] = x[i];
        }
    }

    // Free temporaries
    free(p);
    free(ap);
    free(r);
    (void)workspace;
    (void)workspace_size;
}

