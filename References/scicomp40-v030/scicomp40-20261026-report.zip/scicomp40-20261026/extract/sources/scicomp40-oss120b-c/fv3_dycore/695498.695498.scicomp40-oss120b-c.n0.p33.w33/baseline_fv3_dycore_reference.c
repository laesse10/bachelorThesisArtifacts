// hpcagent_bench-autogen -- generated from fv3_dycore_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

constexpr int64_t nhalo = 3;

void fv3_dycore_fp64(const double *restrict area, const double *restrict crx, const double *restrict cry, const double *restrict dxa, const double *restrict dya, double *restrict q, double *restrict q_x_flux, double *restrict q_y_flux, const double *restrict x_area_flux, const double *restrict y_area_flux, const int64_t grid_type, const int64_t hord, const int64_t ni, const int64_t nj, const int64_t nk, const int64_t nsteps, uint8_t *restrict workspace, const int64_t workspace_size) {
        int64_t x_lo;
        int64_t x_hi;
        int64_t y_lo;
        int64_t y_hi;
        int64_t __inl2_nx;
        int64_t __inl2_ny;
        int64_t __inl2_ord_inner;
        int64_t __inl15_j_end;
        int64_t __inl15_hi;
        int64_t __inl5_ny;
        int64_t __inl5_j0;
        int64_t __inl5_j1;
        int64_t __inl16_i_end;
        int64_t __inl16_hi;
        int64_t __inl17_i_end;
        int64_t __inl17_hi;
        int64_t __inl18_i_end;
        int64_t __inl18_hi;
        int64_t __inl19_i_end;
        int64_t __inl19_hi;
        int64_t __inl9_nx;
        int64_t __inl9_i0;
        int64_t __inl9_i1;
        int64_t __inl21_j_end;
        int64_t __inl21_hi;
        int64_t __inl11_i_end;
        double *__inl2_q_y_advected_mean = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl2_q_y_advected_mean, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl2_q_y_advected_mean");
        memset(__inl2_q_y_advected_mean, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        double *__inl2_q_x_advected_mean = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl2_q_x_advected_mean, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl2_q_x_advected_mean");
        memset(__inl2_q_x_advected_mean, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        double *__inl2_q_advected_y = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl2_q_advected_y, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl2_q_advected_y");
        memset(__inl2_q_advected_y, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        double *__inl2_q_advected_x = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl2_q_advected_x, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl2_q_advected_x");
        memset(__inl2_q_advected_x, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        double *__inl2_q_ayxa = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl2_q_ayxa, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl2_q_ayxa");
        memset(__inl2_q_ayxa, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        double *__inl2_q_axya = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl2_q_axya, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl2_q_axya");
        memset(__inl2_q_axya, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        double *__inl2_al = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl2_al, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl2_al");
        memset(__inl2_al, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        int64_t __inl14_ja[(2)];
        int64_t __inl14_jb[(2)];
        int64_t __inl14_jc[(2)];
        int64_t __inl16_ia[(2)];
        int64_t __inl16_ib[(2)];
        int64_t __inl16_ic[(2)];
        int64_t __inl18_ia[(2)];
        int64_t __inl18_ib[(2)];
        int64_t __inl18_ic[(2)];
        int64_t __inl20_ja[(2)];
        int64_t __inl20_jb[(2)];
        int64_t __inl20_jc[(2)];
        double *__cb1 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__cb1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__cb1");
        double *__cb2 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__cb2, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__cb2");
        double *__cb3 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__cb3, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__cb3");
        double *__cb4 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__cb4, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__cb4");
        double *__inl14_left = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (2) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl14_left, (size_t)((((2 * nhalo) + ni)) * (2) * (nk)) * sizeof(double), "__inl14_left");
        double *__inl14_right = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (2) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl14_right, (size_t)((((2 * nhalo) + ni)) * (2) * (nk)) * sizeof(double), "__inl14_right");
        double *__inl15_bl = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl15_bl, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl15_bl");
        double *__inl15_br = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl15_br, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl15_br");
        double *__inl15_b0 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl15_b0, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl15_b0");
        double *__inl15_bl_m1 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl15_bl_m1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl15_bl_m1");
        double *__inl15_br_m1 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl15_br_m1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl15_br_m1");
        double *__inl15_b0_m1 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl15_b0_m1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl15_b0_m1");
        bool *__inl15_smt5 = (bool *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(bool));
        __npb_alloc_check(__inl15_smt5, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(bool), "__inl15_smt5");
        bool *__inl15_smt5_m1 = (bool *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(bool));
        __npb_alloc_check(__inl15_smt5_m1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(bool), "__inl15_smt5_m1");
        double *__inl5_fyy_j = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((((2 * nhalo) + nj) - 6)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl5_fyy_j, (size_t)((((2 * nhalo) + ni)) * ((((2 * nhalo) + nj) - 6)) * (nk)) * sizeof(double), "__inl5_fyy_j");
        double *__inl5_fyy_jp1 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((((2 * nhalo) + nj) - 6)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl5_fyy_jp1, (size_t)((((2 * nhalo) + ni)) * ((((2 * nhalo) + nj) - 6)) * (nk)) * sizeof(double), "__inl5_fyy_jp1");
        double *__inl5_denom = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((((2 * nhalo) + nj) - 6)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl5_denom, (size_t)((((2 * nhalo) + ni)) * ((((2 * nhalo) + nj) - 6)) * (nk)) * sizeof(double), "__inl5_denom");
        double *__inl16_left = (double *)malloc((size_t)((2) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl16_left, (size_t)((2) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl16_left");
        double *__inl16_right = (double *)malloc((size_t)((2) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl16_right, (size_t)((2) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl16_right");
        double *__inl17_bl = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl17_bl, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl17_bl");
        double *__inl17_br = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl17_br, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl17_br");
        double *__inl17_b0 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl17_b0, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl17_b0");
        double *__inl17_bl_m1 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl17_bl_m1, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl17_bl_m1");
        double *__inl17_br_m1 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl17_br_m1, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl17_br_m1");
        double *__inl17_b0_m1 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl17_b0_m1, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl17_b0_m1");
        bool *__inl17_smt5 = (bool *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(bool));
        __npb_alloc_check(__inl17_smt5, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(bool), "__inl17_smt5");
        bool *__inl17_smt5_m1 = (bool *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(bool));
        __npb_alloc_check(__inl17_smt5_m1, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(bool), "__inl17_smt5_m1");
        double *__inl18_left = (double *)malloc((size_t)((2) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl18_left, (size_t)((2) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl18_left");
        double *__inl18_right = (double *)malloc((size_t)((2) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl18_right, (size_t)((2) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl18_right");
        double *__inl19_bl = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl19_bl, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl19_bl");
        double *__inl19_br = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl19_br, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl19_br");
        double *__inl19_b0 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl19_b0, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl19_b0");
        double *__inl19_bl_m1 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl19_bl_m1, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl19_bl_m1");
        double *__inl19_br_m1 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl19_br_m1, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl19_br_m1");
        double *__inl19_b0_m1 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl19_b0_m1, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl19_b0_m1");
        bool *__inl19_smt5 = (bool *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(bool));
        __npb_alloc_check(__inl19_smt5, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(bool), "__inl19_smt5");
        bool *__inl19_smt5_m1 = (bool *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(bool));
        __npb_alloc_check(__inl19_smt5_m1, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(bool), "__inl19_smt5_m1");
        double *__inl9_fx1_i = (double *)malloc((size_t)(((((2 * nhalo) + ni) - 6)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl9_fx1_i, (size_t)(((((2 * nhalo) + ni) - 6)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl9_fx1_i");
        double *__inl9_fx1_ip1 = (double *)malloc((size_t)(((((2 * nhalo) + ni) - 6)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl9_fx1_ip1, (size_t)(((((2 * nhalo) + ni) - 6)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl9_fx1_ip1");
        double *__inl9_area_with_x_flux = (double *)malloc((size_t)(((((2 * nhalo) + ni) - 6)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl9_area_with_x_flux, (size_t)(((((2 * nhalo) + ni) - 6)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl9_area_with_x_flux");
        double *__inl20_left = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (2) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl20_left, (size_t)((((2 * nhalo) + ni)) * (2) * (nk)) * sizeof(double), "__inl20_left");
        double *__inl20_right = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (2) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl20_right, (size_t)((((2 * nhalo) + ni)) * (2) * (nk)) * sizeof(double), "__inl20_right");
        double *__inl21_bl = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl21_bl, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl21_bl");
        double *__inl21_br = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl21_br, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl21_br");
        double *__inl21_b0 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl21_b0, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl21_b0");
        double *__inl21_bl_m1 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl21_bl_m1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl21_bl_m1");
        double *__inl21_br_m1 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl21_br_m1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl21_br_m1");
        double *__inl21_b0_m1 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl21_b0_m1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl21_b0_m1");
        bool *__inl21_smt5 = (bool *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(bool));
        __npb_alloc_check(__inl21_smt5, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(bool), "__inl21_smt5");
        bool *__inl21_smt5_m1 = (bool *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(bool));
        __npb_alloc_check(__inl21_smt5_m1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(bool), "__inl21_smt5_m1");
        double *__inl2_xuf = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl2_xuf, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl2_xuf");
        double *__inl2_yuf = (double *)malloc((size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl2_yuf, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl2_yuf");
        double *__inl15_c = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl15_c, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl15_c");
        double *__inl15_q_j = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl15_q_j, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl15_q_j");
        double *__inl15_q_jm1 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl15_q_jm1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl15_q_jm1");
        double *__inl17_c = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl17_c, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl17_c");
        double *__inl17_q_i = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl17_q_i, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl17_q_i");
        double *__inl17_q_im1 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl17_q_im1, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl17_q_im1");
        double *__inl19_c = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl19_c, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl19_c");
        double *__inl19_q_i = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl19_q_i, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl19_q_i");
        double *__inl19_q_im1 = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl19_q_im1, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl19_q_im1");
        double *__inl21_c = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl21_c, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl21_c");
        double *__inl21_q_j = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl21_q_j, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl21_q_j");
        double *__inl21_q_jm1 = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl21_q_jm1, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl21_q_jm1");
        double *__inl15_mask = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl15_mask, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl15_mask");
        double *__inl17_mask = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl17_mask, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl17_mask");
        double *__inl19_mask = (double *)malloc((size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl19_mask, (size_t)(((ni + 1)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double), "__inl19_mask");
        double *__inl21_mask = (double *)malloc((size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double));
        __npb_alloc_check(__inl21_mask, (size_t)((((2 * nhalo) + ni)) * ((nj + 1)) * (nk)) * sizeof(double), "__inl21_mask");
        x_lo = nhalo;
        x_hi = (nhalo + ni);
        y_lo = nhalo;
        y_hi = (nhalo + nj);
        for (int64_t _step = 0; _step < nsteps; ++_step) {
          __inl2_nx = ((nhalo + ni) + nhalo);
          __inl2_ny = ((nhalo + nj) + nhalo);
          __inl2_ord_inner = ((hord == 10) ? 8 : hord);
          memset(__inl2_q_y_advected_mean, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
          memset(__inl2_q_x_advected_mean, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
          memset(__inl2_q_advected_y, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
          memset(__inl2_q_advected_x, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
          memset(__inl2_q_ayxa, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
          memset(__inl2_q_axya, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
          memset(__inl2_al, 0, (size_t)((((2 * nhalo) + ni)) * (((2 * nhalo) + nj)) * (nk)) * sizeof(double));
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[((5)*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[((5)*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[((5)*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[((4)*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[((4)*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[((4)*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[((3)*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[((3)*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[((3)*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 7))*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 7))*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 7))*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 6))*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 6))*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 6))*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 5))*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 5))*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 5))*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[((5)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[((4)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[((3)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[((5)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[((4)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[((3)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[((5)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[((4)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[((3)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 5))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 6))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 7))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 5))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 6))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 7))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 5))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 6))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 7))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)];
          }
          for (int64_t si0 = 0; si0 < ((2 * nhalo) + ni); ++si0) {
            for (int64_t si1 = (nhalo - 1); si1 < (((nhalo + nj) - 1) + 3); ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                __inl2_al[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = ((0.5833333333333334 * (q[((si0)*(((nhalo + nj) + nhalo)) + ((si1 + (((nhalo - 1) - 1) - (nhalo - 1)))))*(nk) + (si2)] + q[((si0)*(((nhalo + nj) + nhalo)) + ((si1 + ((nhalo - 1) - (nhalo - 1)))))*(nk) + (si2)])) + (-0.08333333333333333 * (q[((si0)*(((nhalo + nj) + nhalo)) + ((si1 + (((nhalo - 1) - 2) - (nhalo - 1)))))*(nk) + (si2)] + q[((si0)*(((nhalo + nj) + nhalo)) + ((si1 + (((nhalo - 1) + 1) - (nhalo - 1)))))*(nk) + (si2)])));
              }
            }
          }
          if ((grid_type < 3)) {
            __inl14_ja[0] = (nhalo - 1);
            __inl14_ja[1] = ((nhalo + nj) - 1);
            for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
              for (int64_t __scs0 = 0; __scs0 < __inl2_nx; ++__scs0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__scs0)*(((2 * nhalo) + nj)) + (__inl14_ja[__sc0]))*(nk) + (__scs1)] = (((-0.14285714285714285 * q[((__scs0)*(((nhalo + nj) + nhalo)) + ((__inl14_ja[__sc0] - 2)))*(nk) + (__scs1)]) + (0.7857142857142857 * q[((__scs0)*(((nhalo + nj) + nhalo)) + ((__inl14_ja[__sc0] - 1)))*(nk) + (__scs1)])) + (0.35714285714285715 * q[((__scs0)*(((nhalo + nj) + nhalo)) + (__inl14_ja[__sc0]))*(nk) + (__scs1)]));
                }
              }
            }
            __inl14_jb[0] = nhalo;
            __inl14_jb[1] = (((nhalo + nj) - 1) + 1);
            for (int64_t si0 = 0; si0 < ((2 * nhalo) + ni); ++si0) {
              for (int64_t si1 = 0; si1 < 2; ++si1) {
                for (int64_t si2 = 0; si2 < nk; ++si2) {
                  __inl14_left[((si0)*(2) + (si1))*(nk) + (si2)] = (((((2.0 * dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl14_jb[si1] - 1)))*(nk) + (si2)]) + dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl14_jb[si1] - 2)))*(nk) + (si2)]) * q[((si0)*(((nhalo + nj) + nhalo)) + ((__inl14_jb[si1] - 1)))*(nk) + (si2)]) - (dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl14_jb[si1] - 1)))*(nk) + (si2)] * q[((si0)*(((nhalo + nj) + nhalo)) + ((__inl14_jb[si1] - 2)))*(nk) + (si2)])) / (dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl14_jb[si1] - 2)))*(nk) + (si2)] + dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl14_jb[si1] - 1)))*(nk) + (si2)]));
                }
              }
            }
            for (int64_t si0 = 0; si0 < ((2 * nhalo) + ni); ++si0) {
              for (int64_t si1 = 0; si1 < 2; ++si1) {
                for (int64_t si2 = 0; si2 < nk; ++si2) {
                  __inl14_right[((si0)*(2) + (si1))*(nk) + (si2)] = (((((2.0 * dya[((si0)*(((nhalo + nj) + nhalo)) + (__inl14_jb[si1]))*(nk) + (si2)]) + dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl14_jb[si1] + 1)))*(nk) + (si2)]) * q[((si0)*(((nhalo + nj) + nhalo)) + (__inl14_jb[si1]))*(nk) + (si2)]) - (dya[((si0)*(((nhalo + nj) + nhalo)) + (__inl14_jb[si1]))*(nk) + (si2)] * q[((si0)*(((nhalo + nj) + nhalo)) + ((__inl14_jb[si1] + 1)))*(nk) + (si2)])) / (dya[((si0)*(((nhalo + nj) + nhalo)) + (__inl14_jb[si1]))*(nk) + (si2)] + dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl14_jb[si1] + 1)))*(nk) + (si2)]));
                }
              }
            }
            for (int64_t __scs0 = 0; __scs0 < __inl2_nx; ++__scs0) {
              for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__scs0)*(((2 * nhalo) + nj)) + (__inl14_jb[__sc0]))*(nk) + (__scs1)] = (0.5 * (__inl14_left[((__scs0)*(2) + (__sc0))*(nk) + (__scs1)] + __inl14_right[((__scs0)*(2) + (__sc0))*(nk) + (__scs1)]));
                }
              }
            }
            __inl14_jc[0] = (nhalo + 1);
            __inl14_jc[1] = (((nhalo + nj) - 1) + 2);
            for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
              for (int64_t __scs0 = 0; __scs0 < __inl2_nx; ++__scs0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__scs0)*(((2 * nhalo) + nj)) + (__inl14_jc[__sc0]))*(nk) + (__scs1)] = (((0.35714285714285715 * q[((__scs0)*(((nhalo + nj) + nhalo)) + ((__inl14_jc[__sc0] - 1)))*(nk) + (__scs1)]) + (0.7857142857142857 * q[((__scs0)*(((nhalo + nj) + nhalo)) + (__inl14_jc[__sc0]))*(nk) + (__scs1)])) + (-0.14285714285714285 * q[((__scs0)*(((nhalo + nj) + nhalo)) + ((__inl14_jc[__sc0] + 1)))*(nk) + (__scs1)]));
                }
              }
            }
          }
          __inl15_j_end = ((nhalo + nj) - 1);
          __inl15_hi = (__inl15_j_end + 2);
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl15_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl15_c[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] = cry[((__w0)*(((nhalo + nj) + nhalo)) + ((__w1 + (nhalo - 0))))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl15_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl15_q_j[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] = q[((__w0)*(((nhalo + nj) + nhalo)) + ((__w1 + (nhalo - 0))))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((__inl15_hi - 1) - (nhalo - 1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl15_q_jm1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] = q[((__w0)*(((nhalo + nj) + nhalo)) + ((__w1 + ((nhalo - 1) - 0))))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl15_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl15_bl[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] = (__inl2_al[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + (nhalo - 0))))*(nk) + (__w2)] - __inl15_q_j[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((__inl15_hi + 1) - (nhalo + 1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl15_br[((__w0)*(((__inl15_hi + 1) - (nhalo + 1))) + (__w1))*(nk) + (__w2)] = (__inl2_al[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + ((nhalo + 1) - 0))))*(nk) + (__w2)] - __inl15_q_j[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl15_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl15_b0[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] = (__inl15_bl[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] + __inl15_br[((__w0)*(((__inl15_hi + 1) - (nhalo + 1))) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((__inl15_hi - 1) - (nhalo - 1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl15_bl_m1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] = (__inl2_al[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + ((nhalo - 1) - 0))))*(nk) + (__w2)] - __inl15_q_jm1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl15_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl15_br_m1[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] = (__inl2_al[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + (nhalo - 0))))*(nk) + (__w2)] - __inl15_q_jm1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((__inl15_hi - 1) - (nhalo - 1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl15_b0_m1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] = (__inl15_bl_m1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] + __inl15_br_m1[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          if ((llabs(__inl2_ord_inner) == 5)) {
            for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
              for (int64_t __w1 = 0; __w1 < (__inl15_hi - nhalo); ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl15_smt5[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] = ((__inl15_bl[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] * __inl15_br[((__w0)*(((__inl15_hi + 1) - (nhalo + 1))) + (__w1))*(nk) + (__w2)]) < 0.0);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
              for (int64_t __w1 = 0; __w1 < ((__inl15_hi - 1) - (nhalo - 1)); ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl15_smt5_m1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] = ((__inl15_bl_m1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] * __inl15_br_m1[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)]) < 0.0);
                }
              }
            }
          }
          else {
            for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
              for (int64_t __w1 = 0; __w1 < (__inl15_hi - nhalo); ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl15_smt5[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] = ((3.0 * fabs(__inl15_b0[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)])) < fabs((__inl15_bl[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] - __inl15_br[((__w0)*(((__inl15_hi + 1) - (nhalo + 1))) + (__w1))*(nk) + (__w2)])));
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
              for (int64_t __w1 = 0; __w1 < ((__inl15_hi - 1) - (nhalo - 1)); ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl15_smt5_m1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] = ((3.0 * fabs(__inl15_b0_m1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)])) < fabs((__inl15_bl_m1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] - __inl15_br_m1[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)])));
                }
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl15_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl15_mask[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] = ((double)((__inl15_smt5[((__w0)*((__inl15_hi - nhalo)) + (__w1))*(nk) + (__w2)] | __inl15_smt5_m1[((__w0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)])));
              }
            }
          }
          /* numpy: np.where(__inl15_c > 0.0, __inl15_q_jm1 + (1.0 - __inl15_c) * (__inl15_br_m1 - __inl15_c * __... */
          for (int64_t __r0 = 0; __r0 < ((2 * nhalo) + ni); ++__r0) {
            for (int64_t __r1 = 0; __r1 < (__inl15_hi - nhalo); ++__r1) {
              for (int64_t __r2 = 0; __r2 < nk; ++__r2) {
                __cb1[((__r0)*((nj + 1)) + (__r1))*(nk) + (__r2)] = ((__inl15_c[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)] > 0.0) ? (__inl15_q_jm1[((__r0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__r1))*(nk) + (__r2)] + (((1.0 - __inl15_c[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)]) * (__inl15_br_m1[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)] - (__inl15_c[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)] * __inl15_b0_m1[((__r0)*(((__inl15_hi - 1) - (nhalo - 1))) + (__r1))*(nk) + (__r2)]))) * __inl15_mask[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)])) : (__inl15_q_j[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)] + (((1.0 + __inl15_c[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)]) * (__inl15_bl[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)] + (__inl15_c[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)] * __inl15_b0[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)]))) * __inl15_mask[((__r0)*((__inl15_hi - nhalo)) + (__r1))*(nk) + (__r2)])));
              }
            }
          }
          for (int64_t si0 = 0; si0 < ((2 * nhalo) + ni); ++si0) {
            for (int64_t si1 = nhalo; si1 < __inl15_hi; ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                __inl2_q_y_advected_mean[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = __cb1[((si0)*((nj + 1)) + ((si1 - nhalo)))*(nk) + (si2)];
              }
            }
          }
          __inl5_ny = ((nhalo + nj) + nhalo);
          __inl5_j0 = 3;
          __inl5_j1 = (__inl5_ny - 3);
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl5_j1 - __inl5_j0); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl5_fyy_j[((__w0)*((__inl5_j1 - __inl5_j0)) + (__w1))*(nk) + (__w2)] = (y_area_flux[((__w0)*(((nhalo + nj) + nhalo)) + ((__w1 + (__inl5_j0 - 0))))*(nk) + (__w2)] * __inl2_q_y_advected_mean[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + (__inl5_j0 - 0))))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((__inl5_j1 + 1) - (__inl5_j0 + 1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl5_fyy_jp1[((__w0)*(((__inl5_j1 + 1) - (__inl5_j0 + 1))) + (__w1))*(nk) + (__w2)] = (y_area_flux[((__w0)*(((nhalo + nj) + nhalo)) + ((__w1 + ((__inl5_j0 + 1) - 0))))*(nk) + (__w2)] * __inl2_q_y_advected_mean[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + ((__inl5_j0 + 1) - 0))))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl5_j1 - __inl5_j0); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl5_denom[((__w0)*((__inl5_j1 - __inl5_j0)) + (__w1))*(nk) + (__w2)] = ((area[((__w0)*(((nhalo + nj) + nhalo)) + ((__w1 + (__inl5_j0 - 0))))*(nk) + (__w2)] + y_area_flux[((__w0)*(((nhalo + nj) + nhalo)) + ((__w1 + (__inl5_j0 - 0))))*(nk) + (__w2)]) - y_area_flux[((__w0)*(((nhalo + nj) + nhalo)) + ((__w1 + ((__inl5_j0 + 1) - 0))))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t si0 = 0; si0 < ((2 * nhalo) + ni); ++si0) {
            for (int64_t si1 = __inl5_j0; si1 < __inl5_j1; ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                __inl2_q_advected_y[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = ((((q[((si0)*(((nhalo + nj) + nhalo)) + ((si1 + (__inl5_j0 - __inl5_j0))))*(nk) + (si2)] * area[((si0)*(((nhalo + nj) + nhalo)) + ((si1 + (__inl5_j0 - __inl5_j0))))*(nk) + (si2)]) + __inl5_fyy_j[((si0)*((__inl5_j1 - __inl5_j0)) + ((si1 - __inl5_j0)))*(nk) + (si2)]) - __inl5_fyy_jp1[((si0)*(((__inl5_j1 + 1) - (__inl5_j0 + 1))) + ((si1 - __inl5_j0)))*(nk) + (si2)]) / __inl5_denom[((si0)*((__inl5_j1 - __inl5_j0)) + ((si1 - __inl5_j0)))*(nk) + (si2)]);
              }
            }
          }
          __inl16_i_end = ((nhalo + ni) - 1);
          __inl16_hi = (__inl16_i_end + 3);
          for (int64_t si0 = (nhalo - 1); si0 < __inl16_hi; ++si0) {
            for (int64_t si1 = 0; si1 < ((2 * nhalo) + nj); ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                __inl2_al[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = ((0.5833333333333334 * (__inl2_q_advected_y[(((si0 + (((nhalo - 1) - 1) - (nhalo - 1))))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] + __inl2_q_advected_y[(((si0 + ((nhalo - 1) - (nhalo - 1))))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)])) + (-0.08333333333333333 * (__inl2_q_advected_y[(((si0 + (((nhalo - 1) - 2) - (nhalo - 1))))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] + __inl2_q_advected_y[(((si0 + (((nhalo - 1) + 1) - (nhalo - 1))))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)])));
              }
            }
          }
          if ((grid_type < 3)) {
            __inl16_ia[0] = (nhalo - 1);
            __inl16_ia[1] = __inl16_i_end;
            for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
              for (int64_t __scs0 = 0; __scs0 < __inl2_ny; ++__scs0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__inl16_ia[__sc0])*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)] = (((-0.14285714285714285 * __inl2_q_advected_y[(((__inl16_ia[__sc0] - 2))*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)]) + (0.7857142857142857 * __inl2_q_advected_y[(((__inl16_ia[__sc0] - 1))*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)])) + (0.35714285714285715 * __inl2_q_advected_y[((__inl16_ia[__sc0])*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)]));
                }
              }
            }
            __inl16_ib[0] = nhalo;
            __inl16_ib[1] = (__inl16_i_end + 1);
            for (int64_t si0 = 0; si0 < 2; ++si0) {
              for (int64_t si1 = 0; si1 < ((2 * nhalo) + nj); ++si1) {
                for (int64_t si2 = 0; si2 < nk; ++si2) {
                  __inl16_left[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = (((((2.0 * dxa[(((__inl16_ib[si0] - 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) + dxa[(((__inl16_ib[si0] - 2))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) * __inl2_q_advected_y[(((__inl16_ib[si0] - 1))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)]) - (dxa[(((__inl16_ib[si0] - 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] * __inl2_q_advected_y[(((__inl16_ib[si0] - 2))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)])) / (dxa[(((__inl16_ib[si0] - 2))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] + dxa[(((__inl16_ib[si0] - 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]));
                }
              }
            }
            for (int64_t si0 = 0; si0 < 2; ++si0) {
              for (int64_t si1 = 0; si1 < ((2 * nhalo) + nj); ++si1) {
                for (int64_t si2 = 0; si2 < nk; ++si2) {
                  __inl16_right[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = (((((2.0 * dxa[((__inl16_ib[si0])*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) + dxa[(((__inl16_ib[si0] + 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) * __inl2_q_advected_y[((__inl16_ib[si0])*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)]) - (dxa[((__inl16_ib[si0])*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] * __inl2_q_advected_y[(((__inl16_ib[si0] + 1))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)])) / (dxa[((__inl16_ib[si0])*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] + dxa[(((__inl16_ib[si0] + 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]));
                }
              }
            }
            for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
              for (int64_t __scs0 = 0; __scs0 < __inl2_ny; ++__scs0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__inl16_ib[__sc0])*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)] = (0.5 * (__inl16_left[((__sc0)*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)] + __inl16_right[((__sc0)*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)]));
                }
              }
            }
            __inl16_ic[0] = (nhalo + 1);
            __inl16_ic[1] = (__inl16_i_end + 2);
            for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
              for (int64_t __scs0 = 0; __scs0 < __inl2_ny; ++__scs0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__inl16_ic[__sc0])*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)] = (((0.35714285714285715 * __inl2_q_advected_y[(((__inl16_ic[__sc0] - 1))*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)]) + (0.7857142857142857 * __inl2_q_advected_y[((__inl16_ic[__sc0])*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)])) + (-0.14285714285714285 * __inl2_q_advected_y[(((__inl16_ic[__sc0] + 1))*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)]));
                }
              }
            }
          }
          __inl17_i_end = ((nhalo + ni) - 1);
          __inl17_hi = (__inl17_i_end + 2);
          for (int64_t __w0 = 0; __w0 < (__inl17_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl17_c[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = crx[(((__w0 + (nhalo - 0)))*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl17_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl17_q_i[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = __inl2_q_advected_y[(((__w0 + (nhalo - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((__inl17_hi - 1) - (nhalo - 1)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl17_q_im1[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = __inl2_q_advected_y[(((__w0 + ((nhalo - 1) - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl17_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl17_bl[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl2_al[(((__w0 + (nhalo - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] - __inl17_q_i[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((__inl17_hi + 1) - (nhalo + 1)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl17_br[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl2_al[(((__w0 + ((nhalo + 1) - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] - __inl17_q_i[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl17_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl17_b0[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl17_bl[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] + __inl17_br[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((__inl17_hi - 1) - (nhalo - 1)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl17_bl_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl2_al[(((__w0 + ((nhalo - 1) - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] - __inl17_q_im1[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl17_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl17_br_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl2_al[(((__w0 + (nhalo - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] - __inl17_q_im1[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((__inl17_hi - 1) - (nhalo - 1)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl17_b0_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl17_bl_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] + __inl17_br_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          if ((llabs(hord) == 5)) {
            for (int64_t __w0 = 0; __w0 < (__inl17_hi - nhalo); ++__w0) {
              for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl17_smt5[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = ((__inl17_bl[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] * __inl17_br[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)]) < 0.0);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((__inl17_hi - 1) - (nhalo - 1)); ++__w0) {
              for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl17_smt5_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = ((__inl17_bl_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] * __inl17_br_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)]) < 0.0);
                }
              }
            }
          }
          else {
            for (int64_t __w0 = 0; __w0 < (__inl17_hi - nhalo); ++__w0) {
              for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl17_smt5[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = ((3.0 * fabs(__inl17_b0[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)])) < fabs((__inl17_bl[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] - __inl17_br[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)])));
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((__inl17_hi - 1) - (nhalo - 1)); ++__w0) {
              for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl17_smt5_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = ((3.0 * fabs(__inl17_b0_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)])) < fabs((__inl17_bl_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] - __inl17_br_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)])));
                }
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl17_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl17_mask[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = ((double)((__inl17_smt5[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] | __inl17_smt5_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)])));
              }
            }
          }
          /* numpy: np.where(__inl17_c > 0.0, __inl17_q_im1 + (1.0 - __inl17_c) * (__inl17_br_m1 - __inl17_c * __... */
          for (int64_t __r0 = 0; __r0 < (__inl17_hi - nhalo); ++__r0) {
            for (int64_t __r1 = 0; __r1 < ((2 * nhalo) + nj); ++__r1) {
              for (int64_t __r2 = 0; __r2 < nk; ++__r2) {
                __cb2[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] = ((__inl17_c[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] > 0.0) ? (__inl17_q_im1[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] + (((1.0 - __inl17_c[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)]) * (__inl17_br_m1[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)] - (__inl17_c[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] * __inl17_b0_m1[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)]))) * __inl17_mask[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)])) : (__inl17_q_i[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] + (((1.0 + __inl17_c[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)]) * (__inl17_bl[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)] + (__inl17_c[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] * __inl17_b0[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)]))) * __inl17_mask[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)])));
              }
            }
          }
          for (int64_t si0 = nhalo; si0 < __inl17_hi; ++si0) {
            for (int64_t si1 = 0; si1 < ((2 * nhalo) + nj); ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                __inl2_q_ayxa[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = __cb2[(((si0 - nhalo))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)];
              }
            }
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[((0)*(((nhalo + nj) + nhalo)) + (5))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[((1)*(((nhalo + nj) + nhalo)) + (5))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[((2)*(((nhalo + nj) + nhalo)) + (5))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[((0)*(((nhalo + nj) + nhalo)) + (4))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[((1)*(((nhalo + nj) + nhalo)) + (4))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[((2)*(((nhalo + nj) + nhalo)) + (4))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[((0)*(((nhalo + nj) + nhalo)) + (3))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[((1)*(((nhalo + nj) + nhalo)) + (3))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[((2)*(((nhalo + nj) + nhalo)) + (3))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[((2)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 7)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[((1)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 7)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((0)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[((0)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 7)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[((2)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 6)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[((1)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 6)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((1)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[((0)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 6)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[((2)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 5)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[((1)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 5)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[((2)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[((0)*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 5)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + (3))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + (3))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + (3))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + (4))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + (4))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + (4))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + (0))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + (5))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + (1))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + (5))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + (2))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + (5))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 5)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 5)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 5)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 6)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 6)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 6)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 2)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 7)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 3)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 3))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 7)))*(nk) + (si2)];
          }
          for (int64_t si2 = 0; si2 < nk; ++si2) {
            q[(((((2 * nhalo) + ni) - 2))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 4)))*(nk) + (si2)] = q[(((((2 * nhalo) + ni) - 4))*(((nhalo + nj) + nhalo)) + ((((2 * nhalo) + nj) - 7)))*(nk) + (si2)];
          }
          __inl18_i_end = ((nhalo + ni) - 1);
          __inl18_hi = (__inl18_i_end + 3);
          for (int64_t si0 = (nhalo - 1); si0 < __inl18_hi; ++si0) {
            for (int64_t si1 = 0; si1 < ((2 * nhalo) + nj); ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                __inl2_al[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = ((0.5833333333333334 * (q[(((si0 + (((nhalo - 1) - 1) - (nhalo - 1))))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] + q[(((si0 + ((nhalo - 1) - (nhalo - 1))))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)])) + (-0.08333333333333333 * (q[(((si0 + (((nhalo - 1) - 2) - (nhalo - 1))))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] + q[(((si0 + (((nhalo - 1) + 1) - (nhalo - 1))))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)])));
              }
            }
          }
          if ((grid_type < 3)) {
            __inl18_ia[0] = (nhalo - 1);
            __inl18_ia[1] = __inl18_i_end;
            for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
              for (int64_t __scs0 = 0; __scs0 < __inl2_ny; ++__scs0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__inl18_ia[__sc0])*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)] = (((-0.14285714285714285 * q[(((__inl18_ia[__sc0] - 2))*(((nhalo + nj) + nhalo)) + (__scs0))*(nk) + (__scs1)]) + (0.7857142857142857 * q[(((__inl18_ia[__sc0] - 1))*(((nhalo + nj) + nhalo)) + (__scs0))*(nk) + (__scs1)])) + (0.35714285714285715 * q[((__inl18_ia[__sc0])*(((nhalo + nj) + nhalo)) + (__scs0))*(nk) + (__scs1)]));
                }
              }
            }
            __inl18_ib[0] = nhalo;
            __inl18_ib[1] = (__inl18_i_end + 1);
            for (int64_t si0 = 0; si0 < 2; ++si0) {
              for (int64_t si1 = 0; si1 < ((2 * nhalo) + nj); ++si1) {
                for (int64_t si2 = 0; si2 < nk; ++si2) {
                  __inl18_left[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = (((((2.0 * dxa[(((__inl18_ib[si0] - 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) + dxa[(((__inl18_ib[si0] - 2))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) * q[(((__inl18_ib[si0] - 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) - (dxa[(((__inl18_ib[si0] - 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] * q[(((__inl18_ib[si0] - 2))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)])) / (dxa[(((__inl18_ib[si0] - 2))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] + dxa[(((__inl18_ib[si0] - 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]));
                }
              }
            }
            for (int64_t si0 = 0; si0 < 2; ++si0) {
              for (int64_t si1 = 0; si1 < ((2 * nhalo) + nj); ++si1) {
                for (int64_t si2 = 0; si2 < nk; ++si2) {
                  __inl18_right[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = (((((2.0 * dxa[((__inl18_ib[si0])*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) + dxa[(((__inl18_ib[si0] + 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) * q[((__inl18_ib[si0])*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) - (dxa[((__inl18_ib[si0])*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] * q[(((__inl18_ib[si0] + 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)])) / (dxa[((__inl18_ib[si0])*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] + dxa[(((__inl18_ib[si0] + 1))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]));
                }
              }
            }
            for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
              for (int64_t __scs0 = 0; __scs0 < __inl2_ny; ++__scs0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__inl18_ib[__sc0])*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)] = (0.5 * (__inl18_left[((__sc0)*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)] + __inl18_right[((__sc0)*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)]));
                }
              }
            }
            __inl18_ic[0] = (nhalo + 1);
            __inl18_ic[1] = (__inl18_i_end + 2);
            for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
              for (int64_t __scs0 = 0; __scs0 < __inl2_ny; ++__scs0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__inl18_ic[__sc0])*(((2 * nhalo) + nj)) + (__scs0))*(nk) + (__scs1)] = (((0.35714285714285715 * q[(((__inl18_ic[__sc0] - 1))*(((nhalo + nj) + nhalo)) + (__scs0))*(nk) + (__scs1)]) + (0.7857142857142857 * q[((__inl18_ic[__sc0])*(((nhalo + nj) + nhalo)) + (__scs0))*(nk) + (__scs1)])) + (-0.14285714285714285 * q[(((__inl18_ic[__sc0] + 1))*(((nhalo + nj) + nhalo)) + (__scs0))*(nk) + (__scs1)]));
                }
              }
            }
          }
          __inl19_i_end = ((nhalo + ni) - 1);
          __inl19_hi = (__inl19_i_end + 2);
          for (int64_t __w0 = 0; __w0 < (__inl19_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl19_c[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = crx[(((__w0 + (nhalo - 0)))*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl19_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl19_q_i[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = q[(((__w0 + (nhalo - 0)))*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((__inl19_hi - 1) - (nhalo - 1)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl19_q_im1[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = q[(((__w0 + ((nhalo - 1) - 0)))*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl19_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl19_bl[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl2_al[(((__w0 + (nhalo - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] - __inl19_q_i[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((__inl19_hi + 1) - (nhalo + 1)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl19_br[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl2_al[(((__w0 + ((nhalo + 1) - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] - __inl19_q_i[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl19_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl19_b0[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl19_bl[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] + __inl19_br[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((__inl19_hi - 1) - (nhalo - 1)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl19_bl_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl2_al[(((__w0 + ((nhalo - 1) - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] - __inl19_q_im1[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl19_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl19_br_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl2_al[(((__w0 + (nhalo - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] - __inl19_q_im1[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((__inl19_hi - 1) - (nhalo - 1)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl19_b0_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = (__inl19_bl_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] + __inl19_br_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          if ((llabs(__inl2_ord_inner) == 5)) {
            for (int64_t __w0 = 0; __w0 < (__inl19_hi - nhalo); ++__w0) {
              for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl19_smt5[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = ((__inl19_bl[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] * __inl19_br[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)]) < 0.0);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((__inl19_hi - 1) - (nhalo - 1)); ++__w0) {
              for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl19_smt5_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = ((__inl19_bl_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] * __inl19_br_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)]) < 0.0);
                }
              }
            }
          }
          else {
            for (int64_t __w0 = 0; __w0 < (__inl19_hi - nhalo); ++__w0) {
              for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl19_smt5[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = ((3.0 * fabs(__inl19_b0[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)])) < fabs((__inl19_bl[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] - __inl19_br[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)])));
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((__inl19_hi - 1) - (nhalo - 1)); ++__w0) {
              for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl19_smt5_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = ((3.0 * fabs(__inl19_b0_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)])) < fabs((__inl19_bl_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] - __inl19_br_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)])));
                }
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl19_hi - nhalo); ++__w0) {
            for (int64_t __w1 = 0; __w1 < __inl2_ny; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl19_mask[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] = ((double)((__inl19_smt5[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)] | __inl19_smt5_m1[((__w0)*(__inl2_ny) + (__w1))*(nk) + (__w2)])));
              }
            }
          }
          /* numpy: np.where(__inl19_c > 0.0, __inl19_q_im1 + (1.0 - __inl19_c) * (__inl19_br_m1 - __inl19_c * __... */
          for (int64_t __r0 = 0; __r0 < (__inl19_hi - nhalo); ++__r0) {
            for (int64_t __r1 = 0; __r1 < ((2 * nhalo) + nj); ++__r1) {
              for (int64_t __r2 = 0; __r2 < nk; ++__r2) {
                __cb3[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] = ((__inl19_c[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] > 0.0) ? (__inl19_q_im1[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] + (((1.0 - __inl19_c[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)]) * (__inl19_br_m1[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)] - (__inl19_c[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] * __inl19_b0_m1[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)]))) * __inl19_mask[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)])) : (__inl19_q_i[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] + (((1.0 + __inl19_c[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)]) * (__inl19_bl[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)] + (__inl19_c[((__r0)*(((2 * nhalo) + nj)) + (__r1))*(nk) + (__r2)] * __inl19_b0[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)]))) * __inl19_mask[((__r0)*(__inl2_ny) + (__r1))*(nk) + (__r2)])));
              }
            }
          }
          for (int64_t si0 = nhalo; si0 < __inl19_hi; ++si0) {
            for (int64_t si1 = 0; si1 < ((2 * nhalo) + nj); ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                __inl2_q_x_advected_mean[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = __cb3[(((si0 - nhalo))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)];
              }
            }
          }
          __inl9_nx = ((nhalo + ni) + nhalo);
          __inl9_i0 = 3;
          __inl9_i1 = (__inl9_nx - 3);
          for (int64_t __w0 = 0; __w0 < (__inl9_i1 - __inl9_i0); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl9_fx1_i[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = (x_area_flux[(((__w0 + (__inl9_i0 - 0)))*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)] * __inl2_q_x_advected_mean[(((__w0 + (__inl9_i0 - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((__inl9_i1 + 1) - (__inl9_i0 + 1)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl9_fx1_ip1[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = (x_area_flux[(((__w0 + ((__inl9_i0 + 1) - 0)))*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)] * __inl2_q_x_advected_mean[(((__w0 + ((__inl9_i0 + 1) - 0)))*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (__inl9_i1 - __inl9_i0); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl9_area_with_x_flux[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = ((area[(((__w0 + (__inl9_i0 - 0)))*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)] + x_area_flux[(((__w0 + (__inl9_i0 - 0)))*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)]) - x_area_flux[(((__w0 + ((__inl9_i0 + 1) - 0)))*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t si0 = __inl9_i0; si0 < __inl9_i1; ++si0) {
            for (int64_t si1 = 0; si1 < ((2 * nhalo) + nj); ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                __inl2_q_advected_x[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = ((((q[(((si0 + (__inl9_i0 - __inl9_i0)))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] * area[(((si0 + (__inl9_i0 - __inl9_i0)))*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)]) + __inl9_fx1_i[(((si0 - __inl9_i0))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)]) - __inl9_fx1_ip1[(((si0 - __inl9_i0))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)]) / __inl9_area_with_x_flux[(((si0 - __inl9_i0))*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)]);
              }
            }
          }
          for (int64_t si0 = 0; si0 < ((2 * nhalo) + ni); ++si0) {
            for (int64_t si1 = (nhalo - 1); si1 < (((nhalo + nj) - 1) + 3); ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                __inl2_al[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = ((0.5833333333333334 * (__inl2_q_advected_x[((si0)*(((2 * nhalo) + nj)) + ((si1 + (((nhalo - 1) - 1) - (nhalo - 1)))))*(nk) + (si2)] + __inl2_q_advected_x[((si0)*(((2 * nhalo) + nj)) + ((si1 + ((nhalo - 1) - (nhalo - 1)))))*(nk) + (si2)])) + (-0.08333333333333333 * (__inl2_q_advected_x[((si0)*(((2 * nhalo) + nj)) + ((si1 + (((nhalo - 1) - 2) - (nhalo - 1)))))*(nk) + (si2)] + __inl2_q_advected_x[((si0)*(((2 * nhalo) + nj)) + ((si1 + (((nhalo - 1) + 1) - (nhalo - 1)))))*(nk) + (si2)])));
              }
            }
          }
          if ((grid_type < 3)) {
            __inl20_ja[0] = (nhalo - 1);
            __inl20_ja[1] = ((nhalo + nj) - 1);
            for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
              for (int64_t __scs0 = 0; __scs0 < __inl2_nx; ++__scs0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__scs0)*(((2 * nhalo) + nj)) + (__inl20_ja[__sc0]))*(nk) + (__scs1)] = (((-0.14285714285714285 * __inl2_q_advected_x[((__scs0)*(((2 * nhalo) + nj)) + ((__inl20_ja[__sc0] - 2)))*(nk) + (__scs1)]) + (0.7857142857142857 * __inl2_q_advected_x[((__scs0)*(((2 * nhalo) + nj)) + ((__inl20_ja[__sc0] - 1)))*(nk) + (__scs1)])) + (0.35714285714285715 * __inl2_q_advected_x[((__scs0)*(((2 * nhalo) + nj)) + (__inl20_ja[__sc0]))*(nk) + (__scs1)]));
                }
              }
            }
            __inl20_jb[0] = nhalo;
            __inl20_jb[1] = (((nhalo + nj) - 1) + 1);
            for (int64_t si0 = 0; si0 < ((2 * nhalo) + ni); ++si0) {
              for (int64_t si1 = 0; si1 < 2; ++si1) {
                for (int64_t si2 = 0; si2 < nk; ++si2) {
                  __inl20_left[((si0)*(2) + (si1))*(nk) + (si2)] = (((((2.0 * dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl20_jb[si1] - 1)))*(nk) + (si2)]) + dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl20_jb[si1] - 2)))*(nk) + (si2)]) * __inl2_q_advected_x[((si0)*(((2 * nhalo) + nj)) + ((__inl20_jb[si1] - 1)))*(nk) + (si2)]) - (dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl20_jb[si1] - 1)))*(nk) + (si2)] * __inl2_q_advected_x[((si0)*(((2 * nhalo) + nj)) + ((__inl20_jb[si1] - 2)))*(nk) + (si2)])) / (dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl20_jb[si1] - 2)))*(nk) + (si2)] + dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl20_jb[si1] - 1)))*(nk) + (si2)]));
                }
              }
            }
            for (int64_t si0 = 0; si0 < ((2 * nhalo) + ni); ++si0) {
              for (int64_t si1 = 0; si1 < 2; ++si1) {
                for (int64_t si2 = 0; si2 < nk; ++si2) {
                  __inl20_right[((si0)*(2) + (si1))*(nk) + (si2)] = (((((2.0 * dya[((si0)*(((nhalo + nj) + nhalo)) + (__inl20_jb[si1]))*(nk) + (si2)]) + dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl20_jb[si1] + 1)))*(nk) + (si2)]) * __inl2_q_advected_x[((si0)*(((2 * nhalo) + nj)) + (__inl20_jb[si1]))*(nk) + (si2)]) - (dya[((si0)*(((nhalo + nj) + nhalo)) + (__inl20_jb[si1]))*(nk) + (si2)] * __inl2_q_advected_x[((si0)*(((2 * nhalo) + nj)) + ((__inl20_jb[si1] + 1)))*(nk) + (si2)])) / (dya[((si0)*(((nhalo + nj) + nhalo)) + (__inl20_jb[si1]))*(nk) + (si2)] + dya[((si0)*(((nhalo + nj) + nhalo)) + ((__inl20_jb[si1] + 1)))*(nk) + (si2)]));
                }
              }
            }
            for (int64_t __scs0 = 0; __scs0 < __inl2_nx; ++__scs0) {
              for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__scs0)*(((2 * nhalo) + nj)) + (__inl20_jb[__sc0]))*(nk) + (__scs1)] = (0.5 * (__inl20_left[((__scs0)*(2) + (__sc0))*(nk) + (__scs1)] + __inl20_right[((__scs0)*(2) + (__sc0))*(nk) + (__scs1)]));
                }
              }
            }
            __inl20_jc[0] = (nhalo + 1);
            __inl20_jc[1] = (((nhalo + nj) - 1) + 2);
            for (int64_t __sc0 = 0; __sc0 < 2; ++__sc0) {
              for (int64_t __scs0 = 0; __scs0 < __inl2_nx; ++__scs0) {
                for (int64_t __scs1 = 0; __scs1 < nk; ++__scs1) {
                  __inl2_al[((__scs0)*(((2 * nhalo) + nj)) + (__inl20_jc[__sc0]))*(nk) + (__scs1)] = (((0.35714285714285715 * __inl2_q_advected_x[((__scs0)*(((2 * nhalo) + nj)) + ((__inl20_jc[__sc0] - 1)))*(nk) + (__scs1)]) + (0.7857142857142857 * __inl2_q_advected_x[((__scs0)*(((2 * nhalo) + nj)) + (__inl20_jc[__sc0]))*(nk) + (__scs1)])) + (-0.14285714285714285 * __inl2_q_advected_x[((__scs0)*(((2 * nhalo) + nj)) + ((__inl20_jc[__sc0] + 1)))*(nk) + (__scs1)]));
                }
              }
            }
          }
          __inl21_j_end = ((nhalo + nj) - 1);
          __inl21_hi = (__inl21_j_end + 2);
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl21_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl21_c[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] = cry[((__w0)*(((nhalo + nj) + nhalo)) + ((__w1 + (nhalo - 0))))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl21_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl21_q_j[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] = __inl2_q_advected_x[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + (nhalo - 0))))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((__inl21_hi - 1) - (nhalo - 1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl21_q_jm1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] = __inl2_q_advected_x[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + ((nhalo - 1) - 0))))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl21_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl21_bl[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] = (__inl2_al[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + (nhalo - 0))))*(nk) + (__w2)] - __inl21_q_j[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((__inl21_hi + 1) - (nhalo + 1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl21_br[((__w0)*(((__inl21_hi + 1) - (nhalo + 1))) + (__w1))*(nk) + (__w2)] = (__inl2_al[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + ((nhalo + 1) - 0))))*(nk) + (__w2)] - __inl21_q_j[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl21_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl21_b0[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] = (__inl21_bl[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] + __inl21_br[((__w0)*(((__inl21_hi + 1) - (nhalo + 1))) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((__inl21_hi - 1) - (nhalo - 1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl21_bl_m1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] = (__inl2_al[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + ((nhalo - 1) - 0))))*(nk) + (__w2)] - __inl21_q_jm1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl21_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl21_br_m1[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] = (__inl2_al[((__w0)*(((2 * nhalo) + nj)) + ((__w1 + (nhalo - 0))))*(nk) + (__w2)] - __inl21_q_jm1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((__inl21_hi - 1) - (nhalo - 1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl21_b0_m1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] = (__inl21_bl_m1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] + __inl21_br_m1[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)]);
              }
            }
          }
          if ((llabs(hord) == 5)) {
            for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
              for (int64_t __w1 = 0; __w1 < (__inl21_hi - nhalo); ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl21_smt5[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] = ((__inl21_bl[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] * __inl21_br[((__w0)*(((__inl21_hi + 1) - (nhalo + 1))) + (__w1))*(nk) + (__w2)]) < 0.0);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
              for (int64_t __w1 = 0; __w1 < ((__inl21_hi - 1) - (nhalo - 1)); ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl21_smt5_m1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] = ((__inl21_bl_m1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] * __inl21_br_m1[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)]) < 0.0);
                }
              }
            }
          }
          else {
            for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
              for (int64_t __w1 = 0; __w1 < (__inl21_hi - nhalo); ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl21_smt5[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] = ((3.0 * fabs(__inl21_b0[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)])) < fabs((__inl21_bl[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] - __inl21_br[((__w0)*(((__inl21_hi + 1) - (nhalo + 1))) + (__w1))*(nk) + (__w2)])));
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
              for (int64_t __w1 = 0; __w1 < ((__inl21_hi - 1) - (nhalo - 1)); ++__w1) {
                for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                  __inl21_smt5_m1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] = ((3.0 * fabs(__inl21_b0_m1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)])) < fabs((__inl21_bl_m1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)] - __inl21_br_m1[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)])));
                }
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < __inl2_nx; ++__w0) {
            for (int64_t __w1 = 0; __w1 < (__inl21_hi - nhalo); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl21_mask[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] = ((double)((__inl21_smt5[((__w0)*((__inl21_hi - nhalo)) + (__w1))*(nk) + (__w2)] | __inl21_smt5_m1[((__w0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__w1))*(nk) + (__w2)])));
              }
            }
          }
          /* numpy: np.where(__inl21_c > 0.0, __inl21_q_jm1 + (1.0 - __inl21_c) * (__inl21_br_m1 - __inl21_c * __... */
          for (int64_t __r0 = 0; __r0 < ((2 * nhalo) + ni); ++__r0) {
            for (int64_t __r1 = 0; __r1 < (__inl21_hi - nhalo); ++__r1) {
              for (int64_t __r2 = 0; __r2 < nk; ++__r2) {
                __cb4[((__r0)*((nj + 1)) + (__r1))*(nk) + (__r2)] = ((__inl21_c[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)] > 0.0) ? (__inl21_q_jm1[((__r0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__r1))*(nk) + (__r2)] + (((1.0 - __inl21_c[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)]) * (__inl21_br_m1[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)] - (__inl21_c[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)] * __inl21_b0_m1[((__r0)*(((__inl21_hi - 1) - (nhalo - 1))) + (__r1))*(nk) + (__r2)]))) * __inl21_mask[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)])) : (__inl21_q_j[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)] + (((1.0 + __inl21_c[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)]) * (__inl21_bl[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)] + (__inl21_c[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)] * __inl21_b0[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)]))) * __inl21_mask[((__r0)*((__inl21_hi - nhalo)) + (__r1))*(nk) + (__r2)])));
              }
            }
          }
          for (int64_t si0 = 0; si0 < ((2 * nhalo) + ni); ++si0) {
            for (int64_t si1 = nhalo; si1 < __inl21_hi; ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                __inl2_q_axya[((si0)*(((2 * nhalo) + nj)) + (si1))*(nk) + (si2)] = __cb4[((si0)*((nj + 1)) + ((si1 - nhalo)))*(nk) + (si2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl2_xuf[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = x_area_flux[((__w0)*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < ((2 * nhalo) + ni); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((2 * nhalo) + nj); ++__w1) {
              for (int64_t __w2 = 0; __w2 < nk; ++__w2) {
                __inl2_yuf[((__w0)*(((2 * nhalo) + nj)) + (__w1))*(nk) + (__w2)] = y_area_flux[((__w0)*(((nhalo + nj) + nhalo)) + (__w1))*(nk) + (__w2)];
              }
            }
          }
          __inl11_i_end = ((nhalo + ni) - 1);
          for (int64_t si0 = nhalo; si0 < (__inl11_i_end + 2); ++si0) {
            for (int64_t si1 = nhalo; si1 < (((nhalo + nj) - 1) + 1); ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                q_x_flux[((si0)*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] = ((0.5 * (__inl2_q_ayxa[(((si0 + (nhalo - nhalo)))*(((2 * nhalo) + nj)) + ((si1 + (nhalo - nhalo))))*(nk) + (si2)] + __inl2_q_x_advected_mean[(((si0 + (nhalo - nhalo)))*(((2 * nhalo) + nj)) + ((si1 + (nhalo - nhalo))))*(nk) + (si2)])) * __inl2_xuf[(((si0 + (nhalo - nhalo)))*(((2 * nhalo) + nj)) + ((si1 + (nhalo - nhalo))))*(nk) + (si2)]);
              }
            }
          }
          for (int64_t si0 = nhalo; si0 < (__inl11_i_end + 1); ++si0) {
            for (int64_t si1 = nhalo; si1 < (((nhalo + nj) - 1) + 2); ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                q_y_flux[((si0)*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] = ((0.5 * (__inl2_q_axya[(((si0 + (nhalo - nhalo)))*(((2 * nhalo) + nj)) + ((si1 + (nhalo - nhalo))))*(nk) + (si2)] + __inl2_q_y_advected_mean[(((si0 + (nhalo - nhalo)))*(((2 * nhalo) + nj)) + ((si1 + (nhalo - nhalo))))*(nk) + (si2)])) * __inl2_yuf[(((si0 + (nhalo - nhalo)))*(((2 * nhalo) + nj)) + ((si1 + (nhalo - nhalo))))*(nk) + (si2)]);
              }
            }
          }
          for (int64_t si0 = nhalo; si0 < x_hi; ++si0) {
            for (int64_t si1 = nhalo; si1 < y_hi; ++si1) {
              for (int64_t si2 = 0; si2 < nk; ++si2) {
                q[((si0)*(((nhalo + nj) + nhalo)) + (si1))*(nk) + (si2)] -= ((0.01 * (((q_x_flux[(((si0 + ((nhalo + 1) - nhalo)))*(((nhalo + nj) + nhalo)) + ((si1 + (nhalo - nhalo))))*(nk) + (si2)] - q_x_flux[(((si0 + (nhalo - nhalo)))*(((nhalo + nj) + nhalo)) + ((si1 + (nhalo - nhalo))))*(nk) + (si2)]) + q_y_flux[(((si0 + (nhalo - nhalo)))*(((nhalo + nj) + nhalo)) + ((si1 + ((nhalo + 1) - nhalo))))*(nk) + (si2)]) - q_y_flux[(((si0 + (nhalo - nhalo)))*(((nhalo + nj) + nhalo)) + ((si1 + (nhalo - nhalo))))*(nk) + (si2)])) / area[(((si0 + (nhalo - nhalo)))*(((nhalo + nj) + nhalo)) + ((si1 + (nhalo - nhalo))))*(nk) + (si2)]);
              }
            }
          }
        }
        free(__inl2_q_y_advected_mean);
        free(__inl2_q_x_advected_mean);
        free(__inl2_q_advected_y);
        free(__inl2_q_advected_x);
        free(__inl2_q_ayxa);
        free(__inl2_q_axya);
        free(__inl2_al);
        free(__cb1);
        free(__cb2);
        free(__cb3);
        free(__cb4);
        free(__inl14_left);
        free(__inl14_right);
        free(__inl15_bl);
        free(__inl15_br);
        free(__inl15_b0);
        free(__inl15_bl_m1);
        free(__inl15_br_m1);
        free(__inl15_b0_m1);
        free(__inl15_smt5);
        free(__inl15_smt5_m1);
        free(__inl5_fyy_j);
        free(__inl5_fyy_jp1);
        free(__inl5_denom);
        free(__inl16_left);
        free(__inl16_right);
        free(__inl17_bl);
        free(__inl17_br);
        free(__inl17_b0);
        free(__inl17_bl_m1);
        free(__inl17_br_m1);
        free(__inl17_b0_m1);
        free(__inl17_smt5);
        free(__inl17_smt5_m1);
        free(__inl18_left);
        free(__inl18_right);
        free(__inl19_bl);
        free(__inl19_br);
        free(__inl19_b0);
        free(__inl19_bl_m1);
        free(__inl19_br_m1);
        free(__inl19_b0_m1);
        free(__inl19_smt5);
        free(__inl19_smt5_m1);
        free(__inl9_fx1_i);
        free(__inl9_fx1_ip1);
        free(__inl9_area_with_x_flux);
        free(__inl20_left);
        free(__inl20_right);
        free(__inl21_bl);
        free(__inl21_br);
        free(__inl21_b0);
        free(__inl21_bl_m1);
        free(__inl21_br_m1);
        free(__inl21_b0_m1);
        free(__inl21_smt5);
        free(__inl21_smt5_m1);
        free(__inl2_xuf);
        free(__inl2_yuf);
        free(__inl15_c);
        free(__inl15_q_j);
        free(__inl15_q_jm1);
        free(__inl17_c);
        free(__inl17_q_i);
        free(__inl17_q_im1);
        free(__inl19_c);
        free(__inl19_q_i);
        free(__inl19_q_im1);
        free(__inl21_c);
        free(__inl21_q_j);
        free(__inl21_q_jm1);
        free(__inl15_mask);
        free(__inl17_mask);
        free(__inl19_mask);
        free(__inl21_mask);
}
