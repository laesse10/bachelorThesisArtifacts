// hpcagent_bench-autogen -- generated from ls3df_scf_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}
#include <cblas.h>
#include <fftw3.h>

void ls3df_scf_fp64(const double *restrict V_ion, double *restrict V_tot, const double *restrict alpha, const double *restrict dij, const double *restrict occ, const int64_t *restrict offsets, const double *restrict proj, double *restrict psi_frag, double *restrict rho, const int64_t Lb, const int64_t N, const double dvol, const double half_inv_h2, const int64_t m, const double mix, const int64_t nfrag, const int64_t nproj, const int64_t nscf, const int64_t nstate, const double tol, uint8_t *restrict workspace, const int64_t workspace_size) {
        double h;
        double __cb3;
        double nelec;
        int64_t __inl7_N;
        double __cb4;
        double __cb12;
        double __cb136;
        double q;
        double __cb137;
        double __cb138;
        double rho_error;
        int64_t __inl14_N;
        double __cb139;
        double __cb147;
        int64_t __inl3_k;
        int64_t __inl18_m;
        double __inl18_w;
        double b_hi;
        double __inl4_e;
        double __inl4_c;
        double __inl4_sigma;
        double __inl4_sigma1;
        int64_t __inl19_m;
        double __inl19_w;
        int64_t __inl5_k;
        int64_t __inl21_m;
        double __inl21_w;
        int64_t __inl2_nb0;
        int64_t __inl2_nb1;
        int64_t __inl2_nb2;
        double __cb13;
        int64_t __inl2_na;
        int64_t __inl2_nb;
        double __inl2_beta;
        double __cb33;
        double __hcall1;
        double __s;
        int64_t __inv_p;
        double __inv_factor;
        double __inl3___eigh1_off;
        int64_t __inl3___eigh1_mn;
        double __ar_val___cb66;
        double __inl4_sigma_new;
        int64_t __inl20_m;
        double __inl20_w;
        double __swap2_2;
        double __inl5___eigh1_off;
        int64_t __inl5___eigh1_mn;
        double __ar_val___cb127;
        int64_t __inl17_m;
        double __inl17_w;
        double __mm28;
        double __inl2_alpha;
        double __cb29;
        double __inl2___eigh0_off;
        int64_t __inl2___eigh0_mn;
        double __inv_tmp;
        double __inl3___eigh1_tw;
        double __inl5___eigh1_tw;
        double __inl2___eigh0_tw;
        double __inl3___eigh1_apq;
        double __inl3___eigh1_app;
        double __inl3___eigh1_aqq;
        double __inl3___eigh1_s;
        double __inl3___eigh1_tv;
        double __inl5___eigh1_apq;
        double __inl5___eigh1_app;
        double __inl5___eigh1_aqq;
        double __inl5___eigh1_s;
        double __inl5___eigh1_tv;
        double __inl2___eigh0_apq;
        double __inl2___eigh0_app;
        double __inl2___eigh0_aqq;
        double __inl2___eigh0_s;
        double __inl2___eigh0_tv;
        double __inl3___eigh1_akp;
        double __inl3___eigh1_akq;
        double __inl3___eigh1_apk;
        double __inl3___eigh1_aqk;
        double __inl3___eigh1_vkp;
        double __inl3___eigh1_vkq;
        double __inl5___eigh1_akp;
        double __inl5___eigh1_akq;
        double __inl5___eigh1_apk;
        double __inl5___eigh1_aqk;
        double __inl5___eigh1_vkp;
        double __inl5___eigh1_vkq;
        double __inl2___eigh0_akp;
        double __inl2___eigh0_akq;
        double __inl2___eigh0_apk;
        double __inl2___eigh0_aqk;
        double __inl2___eigh0_vkp;
        double __inl2___eigh0_vkq;
        double *rho_in = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(rho_in, (size_t)((N) * (N) * (N)) * sizeof(double), "rho_in");
        double *b_frag = (double *)malloc((size_t)((nfrag)) * sizeof(double));
        __npb_alloc_check(b_frag, (size_t)((nfrag)) * sizeof(double), "b_frag");
        memset(b_frag, 0, (size_t)((nfrag)) * sizeof(double));
        bool *b_frag_valid = (bool *)malloc((size_t)((nfrag)) * sizeof(bool));
        __npb_alloc_check(b_frag_valid, (size_t)((nfrag)) * sizeof(bool), "b_frag_valid");
        memset(b_frag_valid, 0, (size_t)((nfrag)) * sizeof(bool));
        double *rho_out = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(rho_out, (size_t)((N) * (N) * (N)) * sizeof(double), "rho_out");
        memset(rho_out, 0, (size_t)((N) * (N) * (N)) * sizeof(double));
        double *vloc = (double *)malloc((size_t)((Lb) * (Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(vloc, (size_t)((Lb) * (Lb) * (Lb)) * sizeof(double), "vloc");
        double *__inl2_v_prev = (double *)malloc((size_t)((Lb) * (Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl2_v_prev, (size_t)((Lb) * (Lb) * (Lb)) * sizeof(double), "__inl2_v_prev");
        memset(__inl2_v_prev, 0, (size_t)((Lb) * (Lb) * (Lb)) * sizeof(double));
        double __inl2_alphas[(6)];
        memset(__inl2_alphas, 0, (size_t)((6)) * sizeof(double));
        double __inl2_betas[(6)];
        memset(__inl2_betas, 0, (size_t)((6)) * sizeof(double));
        double *__inl2_vcol = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__inl2_vcol, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__inl2_vcol");
        memset(__inl2_vcol, 0, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        double *__inl17_row = (double *)malloc((size_t)((Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl17_row, (size_t)((Lb) * (Lb)) * sizeof(double), "__inl17_row");
        memset(__inl17_row, 0, (size_t)((Lb) * (Lb)) * sizeof(double));
        double *__inl18_row = (double *)malloc((size_t)((Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl18_row, (size_t)((Lb) * (Lb)) * sizeof(double), "__inl18_row");
        memset(__inl18_row, 0, (size_t)((Lb) * (Lb)) * sizeof(double));
        double *__eye1 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__eye1, (size_t)((nstate) * (nstate)) * sizeof(double), "__eye1");
        memset(__eye1, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
        double *__inl3___eigh1_Cm = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3___eigh1_Cm, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl3___eigh1_Cm");
        memset(__inl3___eigh1_Cm, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
        double *__inl3___eigh1_jv = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3___eigh1_jv, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl3___eigh1_jv");
        memset(__inl3___eigh1_jv, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
        double *__inl3___eigh1_wa = (double *)malloc((size_t)((nstate)) * sizeof(double));
        __npb_alloc_check(__inl3___eigh1_wa, (size_t)((nstate)) * sizeof(double), "__inl3___eigh1_wa");
        memset(__inl3___eigh1_wa, 0, (size_t)((nstate)) * sizeof(double));
        double *__inl19_row = (double *)malloc((size_t)((Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl19_row, (size_t)((Lb) * (Lb)) * sizeof(double), "__inl19_row");
        memset(__inl19_row, 0, (size_t)((Lb) * (Lb)) * sizeof(double));
        double *__inl20_row = (double *)malloc((size_t)((Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl20_row, (size_t)((Lb) * (Lb)) * sizeof(double), "__inl20_row");
        memset(__inl20_row, 0, (size_t)((Lb) * (Lb)) * sizeof(double));
        double *__inl21_row = (double *)malloc((size_t)((Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl21_row, (size_t)((Lb) * (Lb)) * sizeof(double), "__inl21_row");
        memset(__inl21_row, 0, (size_t)((Lb) * (Lb)) * sizeof(double));
        double *__eye2 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__eye2, (size_t)((nstate) * (nstate)) * sizeof(double), "__eye2");
        memset(__eye2, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
        double *__inl5___eigh1_Cm = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5___eigh1_Cm, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl5___eigh1_Cm");
        memset(__inl5___eigh1_Cm, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
        double *__inl5___eigh1_jv = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5___eigh1_jv, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl5___eigh1_jv");
        memset(__inl5___eigh1_jv, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
        double *__inl5___eigh1_wa = (double *)malloc((size_t)((nstate)) * sizeof(double));
        __npb_alloc_check(__inl5___eigh1_wa, (size_t)((nstate)) * sizeof(double), "__inl5___eigh1_wa");
        memset(__inl5___eigh1_wa, 0, (size_t)((nstate)) * sizeof(double));
        int64_t *__cb1 = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__cb1, (size_t)((Lb)) * sizeof(int64_t), "__cb1");
        double *__cb2 = (double *)malloc((size_t)((nfrag) * (((Lb * Lb) * Lb)) * (nproj)) * sizeof(double));
        __npb_alloc_check(__cb2, (size_t)((nfrag) * (((Lb * Lb) * Lb)) * (nproj)) * sizeof(double), "__cb2");
        double *__cb5 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__cb5, (size_t)((N) * (N) * (N)) * sizeof(double), "__cb5");
        double _Complex *__cb6 = (double _Complex *)malloc((size_t)((N) * (N) * (N)) * sizeof(double _Complex));
        __npb_alloc_check(__cb6, (size_t)((N) * (N) * (N)) * sizeof(double _Complex), "__cb6");
        double *__cb7 = (double *)malloc((size_t)((N)) * sizeof(double));
        __npb_alloc_check(__cb7, (size_t)((N)) * sizeof(double), "__cb7");
        double _Complex *__cb8 = (double _Complex *)malloc((size_t)((N) * (N) * (N)) * sizeof(double _Complex));
        __npb_alloc_check(__cb8, (size_t)((N) * (N) * (N)) * sizeof(double _Complex), "__cb8");
        double _Complex *__cb9 = (double _Complex *)malloc((size_t)((N) * (N) * (N)) * sizeof(double _Complex));
        __npb_alloc_check(__cb9, (size_t)((N) * (N) * (N)) * sizeof(double _Complex), "__cb9");
        double *__cb10 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__cb10, (size_t)((N) * (N) * (N)) * sizeof(double), "__cb10");
        double *__cb11 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__cb11, (size_t)((N) * (N) * (N)) * sizeof(double), "__cb11");
        int64_t *__cb14 = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__cb14, (size_t)((Lb)) * sizeof(int64_t), "__cb14");
        double *__cb15 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__cb15, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__cb15");
        double *__cb16 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__cb16, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__cb16");
        double *__cb17 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__cb17, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__cb17");
        double *__cb18 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__cb18, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__cb18");
        double *__cb19 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__cb19, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__cb19");
        double *__cb20 = (double *)malloc((size_t)(((((Lb * Lb) * Lb) / 1)) * (1)) * sizeof(double));
        __npb_alloc_check(__cb20, (size_t)(((((Lb * Lb) * Lb) / 1)) * (1)) * sizeof(double), "__cb20");
        double *__cb21 = (double *)malloc((size_t)((nproj) * (((Lb * Lb) * Lb))) * sizeof(double));
        __npb_alloc_check(__cb21, (size_t)((nproj) * (((Lb * Lb) * Lb))) * sizeof(double), "__cb21");
        double *__mm22 = (double *)malloc((size_t)((nproj) * (1)) * sizeof(double));
        __npb_alloc_check(__mm22, (size_t)((nproj) * (1)) * sizeof(double), "__mm22");
        double *__mm23 = (double *)malloc((size_t)((nproj) * (1)) * sizeof(double));
        __npb_alloc_check(__mm23, (size_t)((nproj) * (1)) * sizeof(double), "__mm23");
        double *__mm24 = (double *)malloc((size_t)((((Lb * Lb) * Lb)) * (1)) * sizeof(double));
        __npb_alloc_check(__mm24, (size_t)((((Lb * Lb) * Lb)) * (1)) * sizeof(double), "__mm24");
        double *__cb25 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__cb25, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__cb25");
        double *__cb26 = (double *)malloc((size_t)((((Lb * Lb) * Lb))) * sizeof(double));
        __npb_alloc_check(__cb26, (size_t)((((Lb * Lb) * Lb))) * sizeof(double), "__cb26");
        double *__cb27 = (double *)malloc((size_t)((((Lb * Lb) * Lb))) * sizeof(double));
        __npb_alloc_check(__cb27, (size_t)((((Lb * Lb) * Lb))) * sizeof(double), "__cb27");
        double *__cb34 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb34, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb34");
        double *__cb35 = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb35, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__cb35");
        int64_t *__cb36 = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__cb36, (size_t)((Lb)) * sizeof(int64_t), "__cb36");
        double *__cb37 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb37, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb37");
        double *__cb38 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb38, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb38");
        double *__cb39 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb39, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb39");
        double *__cb40 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb40, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb40");
        double *__cb41 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb41, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb41");
        double *__cb42 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb42, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb42");
        double *__cb43 = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb43, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__cb43");
        double *__cb44 = (double *)malloc((size_t)((nproj) * (((Lb * Lb) * Lb))) * sizeof(double));
        __npb_alloc_check(__cb44, (size_t)((nproj) * (((Lb * Lb) * Lb))) * sizeof(double), "__cb44");
        double *__mm45 = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm45, (size_t)((nproj) * (nstate)) * sizeof(double), "__mm45");
        double *__mm46 = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm46, (size_t)((nproj) * (nstate)) * sizeof(double), "__mm46");
        double *__mm47 = (double *)malloc((size_t)((((Lb * Lb) * Lb)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm47, (size_t)((((Lb * Lb) * Lb)) * (nstate)) * sizeof(double), "__mm47");
        double *__cb48 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb48, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb48");
        double *__cb49 = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb49, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__cb49");
        double *__cb50 = (double *)malloc((size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double));
        __npb_alloc_check(__cb50, (size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double), "__cb50");
        double *__cb51 = (double *)malloc((size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double));
        __npb_alloc_check(__cb51, (size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double), "__cb51");
        double *__mm52 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm52, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm52");
        double *__cb53 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb53, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb53");
        double *__mm54 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm54, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm54");
        double *__cb55 = (double *)malloc((size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double));
        __npb_alloc_check(__cb55, (size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double), "__cb55");
        double *__cb56 = (double *)malloc((size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double));
        __npb_alloc_check(__cb56, (size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double), "__cb56");
        double *__mm57 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm57, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm57");
        double *__cb58 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb58, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb58");
        double *__mm59 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm59, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm59");
        double *__cb60 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb60, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb60");
        double *__cb61 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb61, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb61");
        double *__cb62 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb62, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb62");
        double *__mm63 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm63, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm63");
        double *__mm64 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm64, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm64");
        double *__cb65 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb65, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb65");
        int64_t *__cb66 = (int64_t *)malloc((size_t)((nstate)) * sizeof(int64_t));
        __npb_alloc_check(__cb66, (size_t)((nstate)) * sizeof(int64_t), "__cb66");
        int64_t *__cb67 = (int64_t *)malloc((size_t)((nstate)) * sizeof(int64_t));
        __npb_alloc_check(__cb67, (size_t)((nstate)) * sizeof(int64_t), "__cb67");
        double *__cb68 = (double *)malloc((size_t)((nstate)) * sizeof(double));
        __npb_alloc_check(__cb68, (size_t)((nstate)) * sizeof(double), "__cb68");
        double *__cb69 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb69, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb69");
        double *__mm70 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm70, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm70");
        double *__mm71 = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm71, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__mm71");
        double *__cb72 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb72, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb72");
        int64_t *__cb73 = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__cb73, (size_t)((Lb)) * sizeof(int64_t), "__cb73");
        double *__cb74 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb74, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb74");
        double *__cb75 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb75, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb75");
        double *__cb76 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb76, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb76");
        double *__cb77 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb77, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb77");
        double *__cb78 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb78, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb78");
        double *__cb79 = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb79, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__cb79");
        double *__cb80 = (double *)malloc((size_t)((nproj) * (((Lb * Lb) * Lb))) * sizeof(double));
        __npb_alloc_check(__cb80, (size_t)((nproj) * (((Lb * Lb) * Lb))) * sizeof(double), "__cb80");
        double *__mm81 = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm81, (size_t)((nproj) * (nstate)) * sizeof(double), "__mm81");
        double *__mm82 = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm82, (size_t)((nproj) * (nstate)) * sizeof(double), "__mm82");
        double *__mm83 = (double *)malloc((size_t)((((Lb * Lb) * Lb)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm83, (size_t)((((Lb * Lb) * Lb)) * (nstate)) * sizeof(double), "__mm83");
        double *__cb84 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb84, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb84");
        int64_t *__cb85 = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__cb85, (size_t)((Lb)) * sizeof(int64_t), "__cb85");
        double *__cb86 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb86, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb86");
        double *__cb87 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb87, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb87");
        double *__cb88 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb88, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb88");
        double *__cb89 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb89, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb89");
        double *__cb90 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb90, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb90");
        double *__cb91 = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb91, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__cb91");
        double *__cb92 = (double *)malloc((size_t)((nproj) * (((Lb * Lb) * Lb))) * sizeof(double));
        __npb_alloc_check(__cb92, (size_t)((nproj) * (((Lb * Lb) * Lb))) * sizeof(double), "__cb92");
        double *__mm93 = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm93, (size_t)((nproj) * (nstate)) * sizeof(double), "__mm93");
        double *__mm94 = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm94, (size_t)((nproj) * (nstate)) * sizeof(double), "__mm94");
        double *__mm95 = (double *)malloc((size_t)((((Lb * Lb) * Lb)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm95, (size_t)((((Lb * Lb) * Lb)) * (nstate)) * sizeof(double), "__mm95");
        double *__cb96 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb96, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb96");
        double *__cb97 = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb97, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__cb97");
        int64_t *__cb98 = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__cb98, (size_t)((Lb)) * sizeof(int64_t), "__cb98");
        double *__cb99 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb99, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb99");
        double *__cb100 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb100, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb100");
        double *__cb101 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb101, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb101");
        double *__cb102 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb102, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb102");
        double *__cb103 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb103, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb103");
        double *__cb104 = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb104, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__cb104");
        double *__cb105 = (double *)malloc((size_t)((nproj) * (((Lb * Lb) * Lb))) * sizeof(double));
        __npb_alloc_check(__cb105, (size_t)((nproj) * (((Lb * Lb) * Lb))) * sizeof(double), "__cb105");
        double *__mm106 = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm106, (size_t)((nproj) * (nstate)) * sizeof(double), "__mm106");
        double *__mm107 = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm107, (size_t)((nproj) * (nstate)) * sizeof(double), "__mm107");
        double *__mm108 = (double *)malloc((size_t)((((Lb * Lb) * Lb)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm108, (size_t)((((Lb * Lb) * Lb)) * (nstate)) * sizeof(double), "__mm108");
        double *__cb109 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb109, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb109");
        double *__cb110 = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb110, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__cb110");
        double *__cb111 = (double *)malloc((size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double));
        __npb_alloc_check(__cb111, (size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double), "__cb111");
        double *__cb112 = (double *)malloc((size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double));
        __npb_alloc_check(__cb112, (size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double), "__cb112");
        double *__mm113 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm113, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm113");
        double *__cb114 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb114, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb114");
        double *__mm115 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm115, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm115");
        double *__cb116 = (double *)malloc((size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double));
        __npb_alloc_check(__cb116, (size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double), "__cb116");
        double *__cb117 = (double *)malloc((size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double));
        __npb_alloc_check(__cb117, (size_t)((nstate) * (((((Lb * Lb) * Lb) * nstate) / nstate))) * sizeof(double), "__cb117");
        double *__mm118 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm118, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm118");
        double *__cb119 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb119, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb119");
        double *__mm120 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm120, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm120");
        double *__cb121 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb121, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb121");
        double *__cb122 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb122, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb122");
        double *__cb123 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb123, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb123");
        double *__mm124 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm124, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm124");
        double *__mm125 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm125, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm125");
        double *__cb126 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb126, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb126");
        int64_t *__cb127 = (int64_t *)malloc((size_t)((nstate)) * sizeof(int64_t));
        __npb_alloc_check(__cb127, (size_t)((nstate)) * sizeof(int64_t), "__cb127");
        int64_t *__cb128 = (int64_t *)malloc((size_t)((nstate)) * sizeof(int64_t));
        __npb_alloc_check(__cb128, (size_t)((nstate)) * sizeof(int64_t), "__cb128");
        double *__cb129 = (double *)malloc((size_t)((nstate)) * sizeof(double));
        __npb_alloc_check(__cb129, (size_t)((nstate)) * sizeof(double), "__cb129");
        double *__cb130 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb130, (size_t)((nstate) * (nstate)) * sizeof(double), "__cb130");
        double *__mm131 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm131, (size_t)((nstate) * (nstate)) * sizeof(double), "__mm131");
        double *__mm132 = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__mm132, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__mm132");
        double *__cb133 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__cb133, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__cb133");
        double *__cb134 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__cb134, (size_t)((Lb) * (Lb) * (Lb)) * sizeof(double), "__cb134");
        double *__cb135 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__cb135, (size_t)((N) * (N) * (N)) * sizeof(double), "__cb135");
        double *__cb140 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__cb140, (size_t)((N) * (N) * (N)) * sizeof(double), "__cb140");
        double _Complex *__cb141 = (double _Complex *)malloc((size_t)((N) * (N) * (N)) * sizeof(double _Complex));
        __npb_alloc_check(__cb141, (size_t)((N) * (N) * (N)) * sizeof(double _Complex), "__cb141");
        double *__cb142 = (double *)malloc((size_t)((N)) * sizeof(double));
        __npb_alloc_check(__cb142, (size_t)((N)) * sizeof(double), "__cb142");
        double _Complex *__cb143 = (double _Complex *)malloc((size_t)((N) * (N) * (N)) * sizeof(double _Complex));
        __npb_alloc_check(__cb143, (size_t)((N) * (N) * (N)) * sizeof(double _Complex), "__cb143");
        double _Complex *__cb144 = (double _Complex *)malloc((size_t)((N) * (N) * (N)) * sizeof(double _Complex));
        __npb_alloc_check(__cb144, (size_t)((N) * (N) * (N)) * sizeof(double _Complex), "__cb144");
        double *__cb145 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__cb145, (size_t)((N) * (N) * (N)) * sizeof(double), "__cb145");
        double *__cb146 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__cb146, (size_t)((N) * (N) * (N)) * sizeof(double), "__cb146");
        double *__td_op1 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__td_op1, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__td_op1");
        double *__td_op2 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__td_op2, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__td_op2");
        double *__td_op3 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__td_op3, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__td_op3");
        double *__inv_aw0 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inv_aw0, (size_t)((nstate) * (nstate)) * sizeof(double), "__inv_aw0");
        double *__inv_aw1 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inv_aw1, (size_t)((nstate) * (nstate)) * sizeof(double), "__inv_aw1");
        int64_t *box = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(box, (size_t)((Lb)) * sizeof(int64_t), "box");
        double *proj_flat = (double *)malloc((size_t)((nfrag) * (((Lb * Lb) * Lb)) * (nproj)) * sizeof(double));
        __npb_alloc_check(proj_flat, (size_t)((nfrag) * (((Lb * Lb) * Lb)) * (nproj)) * sizeof(double), "proj_flat");
        double _Complex *__inl7_rho_g = (double _Complex *)malloc((size_t)((N) * (N) * (N)) * sizeof(double _Complex));
        __npb_alloc_check(__inl7_rho_g, (size_t)((N) * (N) * (N)) * sizeof(double _Complex), "__inl7_rho_g");
        double *__inl16_kx = (double *)malloc((size_t)((N)) * sizeof(double));
        __npb_alloc_check(__inl16_kx, (size_t)((N)) * sizeof(double), "__inl16_kx");
        double *__inl16_gsq = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl16_gsq, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl16_gsq");
        double *__inl16_inv = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl16_inv, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl16_inv");
        double *__hcall10 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__hcall10, (size_t)((N) * (N) * (N)) * sizeof(double), "__hcall10");
        double *__inl8_n = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl8_n, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl8_n");
        double *__inl8_rs = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl8_rs, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl8_rs");
        double *__inl8_n13 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl8_n13, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl8_n13");
        double *__inl8_v_x = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl8_v_x, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl8_v_x");
        double *__inl8_denom = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl8_denom, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl8_denom");
        double *__inl8_v_c_ge1 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl8_v_c_ge1, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl8_v_c_ge1");
        double *__inl8_v_c_lt1 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl8_v_c_lt1, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl8_v_c_lt1");
        double *__hcall3 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__hcall3, (size_t)((N) * (N) * (N)) * sizeof(double), "__hcall3");
        double *__inl1_v = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl1_v, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl1_v");
        int64_t *xs = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(xs, (size_t)((Lb)) * sizeof(int64_t), "xs");
        int64_t *ys = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(ys, (size_t)((Lb)) * sizeof(int64_t), "ys");
        int64_t *zs = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(zs, (size_t)((Lb)) * sizeof(int64_t), "zs");
        double *__inl2_v = (double *)malloc((size_t)((Lb) * (Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl2_v, (size_t)((Lb) * (Lb) * (Lb)) * sizeof(double), "__inl2_v");
        int64_t *__inl17_idx = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__inl17_idx, (size_t)((Lb)) * sizeof(int64_t), "__inl17_idx");
        double *__scg0 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg0, (size_t)((Lb)) * sizeof(double), "__scg0");
        double *__scg1 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg1, (size_t)((Lb)) * sizeof(double), "__scg1");
        double *__scg2 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg2, (size_t)((Lb)) * sizeof(double), "__scg2");
        double *__scg3 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg3, (size_t)((Lb)) * sizeof(double), "__scg3");
        double *__scg4 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg4, (size_t)((Lb)) * sizeof(double), "__scg4");
        double *__scg5 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg5, (size_t)((Lb)) * sizeof(double), "__scg5");
        double *__scg6 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg6, (size_t)((Lb)) * sizeof(double), "__scg6");
        double *__scg7 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg7, (size_t)((Lb)) * sizeof(double), "__scg7");
        double *__inl9_row = (double *)malloc((size_t)((Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl9_row, (size_t)((Lb) * (Lb)) * sizeof(double), "__inl9_row");
        double *__inl9_acc = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__inl9_acc, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__inl9_acc");
        double *__inl9_hx1 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__inl9_hx1, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__inl9_hx1");
        double *__inl9_flat = (double *)malloc((size_t)(((((Lb * Lb) * Lb) / 1)) * (1)) * sizeof(double));
        __npb_alloc_check(__inl9_flat, (size_t)(((((Lb * Lb) * Lb) / 1)) * (1)) * sizeof(double), "__inl9_flat");
        double *__inl9_overlap = (double *)malloc((size_t)((nproj) * (1)) * sizeof(double));
        __npb_alloc_check(__inl9_overlap, (size_t)((nproj) * (1)) * sizeof(double), "__inl9_overlap");
        double *__inl9_hx2 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__inl9_hx2, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__inl9_hx2");
        double *__inl2_wcol = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
        __npb_alloc_check(__inl2_wcol, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double), "__inl2_wcol");
        double *__inl2_w = (double *)malloc((size_t)((Lb) * (Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl2_w, (size_t)((Lb) * (Lb) * (Lb)) * sizeof(double), "__inl2_w");
        double *__swap1_0 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__swap1_0, (size_t)((Lb) * (Lb) * (Lb)) * sizeof(double), "__swap1_0");
        double *__swap1_1 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__swap1_1, (size_t)((Lb) * (Lb) * (Lb)) * sizeof(double), "__swap1_1");
        double *__inl3_Yf = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3_Yf, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__inl3_Yf");
        int64_t *__inl18_idx = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__inl18_idx, (size_t)((Lb)) * sizeof(int64_t), "__inl18_idx");
        double *__scg8 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg8, (size_t)((Lb)) * sizeof(double), "__scg8");
        double *__scg9 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg9, (size_t)((Lb)) * sizeof(double), "__scg9");
        double *__scg10 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg10, (size_t)((Lb)) * sizeof(double), "__scg10");
        double *__scg11 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg11, (size_t)((Lb)) * sizeof(double), "__scg11");
        double *__scg12 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg12, (size_t)((Lb)) * sizeof(double), "__scg12");
        double *__scg13 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg13, (size_t)((Lb)) * sizeof(double), "__scg13");
        double *__scg14 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg14, (size_t)((Lb)) * sizeof(double), "__scg14");
        double *__scg15 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg15, (size_t)((Lb)) * sizeof(double), "__scg15");
        double *__inl10_row = (double *)malloc((size_t)((Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl10_row, (size_t)((Lb) * (Lb)) * sizeof(double), "__inl10_row");
        double *__inl10_acc = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl10_acc, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl10_acc");
        double *__inl10_hx1 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl10_hx1, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl10_hx1");
        double *__inl10_flat = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl10_flat, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__inl10_flat");
        double *__inl10_overlap = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl10_overlap, (size_t)((nproj) * (nstate)) * sizeof(double), "__inl10_overlap");
        double *__inl10_hx2 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl10_hx2, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl10_hx2");
        double *__hcall4 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__hcall4, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__hcall4");
        double *__inl3_Wf = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3_Wf, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__inl3_Wf");
        double *__inl3_h_sub = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3_h_sub, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl3_h_sub");
        double *__inl3_s_sub = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3_s_sub, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl3_s_sub");
        double *__inl3_L = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3_L, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl3_L");
        double *__inl3_Linv = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3_Linv, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl3_Linv");
        double *__inl3___eigh1_a = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3___eigh1_a, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl3___eigh1_a");
        double *__inl3___eigh1_ya = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3___eigh1_ya, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl3___eigh1_ya");
        double *__inl3_w = (double *)malloc((size_t)((nstate)) * sizeof(double));
        __npb_alloc_check(__inl3_w, (size_t)((nstate)) * sizeof(double), "__inl3_w");
        double *__inl3_U = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3_U, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl3_U");
        int64_t *__ix2 = (int64_t *)malloc((size_t)((nstate)) * sizeof(int64_t));
        __npb_alloc_check(__ix2, (size_t)((nstate)) * sizeof(int64_t), "__ix2");
        int64_t *__ix3 = (int64_t *)malloc((size_t)((nstate)) * sizeof(int64_t));
        __npb_alloc_check(__ix3, (size_t)((nstate)) * sizeof(int64_t), "__ix3");
        double *__inl3_C = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl3_C, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl3_C");
        double *X = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(X, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "X");
        double *w = (double *)malloc((size_t)((nstate)) * sizeof(double));
        __npb_alloc_check(w, (size_t)((nstate)) * sizeof(double), "w");
        double *__inl4_X = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl4_X, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl4_X");
        int64_t *__inl19_idx = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__inl19_idx, (size_t)((Lb)) * sizeof(int64_t), "__inl19_idx");
        double *__scg16 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg16, (size_t)((Lb)) * sizeof(double), "__scg16");
        double *__scg17 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg17, (size_t)((Lb)) * sizeof(double), "__scg17");
        double *__scg18 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg18, (size_t)((Lb)) * sizeof(double), "__scg18");
        double *__scg19 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg19, (size_t)((Lb)) * sizeof(double), "__scg19");
        double *__scg20 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg20, (size_t)((Lb)) * sizeof(double), "__scg20");
        double *__scg21 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg21, (size_t)((Lb)) * sizeof(double), "__scg21");
        double *__scg22 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg22, (size_t)((Lb)) * sizeof(double), "__scg22");
        double *__scg23 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg23, (size_t)((Lb)) * sizeof(double), "__scg23");
        double *__inl11_row = (double *)malloc((size_t)((Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl11_row, (size_t)((Lb) * (Lb)) * sizeof(double), "__inl11_row");
        double *__inl11_acc = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl11_acc, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl11_acc");
        double *__inl11_hx1 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl11_hx1, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl11_hx1");
        double *__inl11_flat = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl11_flat, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__inl11_flat");
        double *__inl11_overlap = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl11_overlap, (size_t)((nproj) * (nstate)) * sizeof(double), "__inl11_overlap");
        double *__inl11_hx2 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl11_hx2, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl11_hx2");
        double *__hcall5 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__hcall5, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__hcall5");
        double *__inl4_Y = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl4_Y, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl4_Y");
        int64_t *__inl20_idx = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__inl20_idx, (size_t)((Lb)) * sizeof(int64_t), "__inl20_idx");
        double *__scg24 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg24, (size_t)((Lb)) * sizeof(double), "__scg24");
        double *__scg25 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg25, (size_t)((Lb)) * sizeof(double), "__scg25");
        double *__scg26 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg26, (size_t)((Lb)) * sizeof(double), "__scg26");
        double *__scg27 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg27, (size_t)((Lb)) * sizeof(double), "__scg27");
        double *__scg28 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg28, (size_t)((Lb)) * sizeof(double), "__scg28");
        double *__scg29 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg29, (size_t)((Lb)) * sizeof(double), "__scg29");
        double *__scg30 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg30, (size_t)((Lb)) * sizeof(double), "__scg30");
        double *__scg31 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg31, (size_t)((Lb)) * sizeof(double), "__scg31");
        double *__inl12_row = (double *)malloc((size_t)((Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl12_row, (size_t)((Lb) * (Lb)) * sizeof(double), "__inl12_row");
        double *__inl12_acc = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl12_acc, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl12_acc");
        double *__inl12_hx1 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl12_hx1, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl12_hx1");
        double *__inl12_flat = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl12_flat, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__inl12_flat");
        double *__inl12_overlap = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl12_overlap, (size_t)((nproj) * (nstate)) * sizeof(double), "__inl12_overlap");
        double *__inl12_hx2 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl12_hx2, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl12_hx2");
        double *__hcall6 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__hcall6, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__hcall6");
        double *__inl4_Ynew = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl4_Ynew, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl4_Ynew");
        double *__swap2_0 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__swap2_0, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__swap2_0");
        double *__swap2_1 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__swap2_1, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__swap2_1");
        double *Y = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(Y, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "Y");
        double *__inl5_Yf = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5_Yf, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__inl5_Yf");
        int64_t *__inl21_idx = (int64_t *)malloc((size_t)((Lb)) * sizeof(int64_t));
        __npb_alloc_check(__inl21_idx, (size_t)((Lb)) * sizeof(int64_t), "__inl21_idx");
        double *__scg32 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg32, (size_t)((Lb)) * sizeof(double), "__scg32");
        double *__scg33 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg33, (size_t)((Lb)) * sizeof(double), "__scg33");
        double *__scg34 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg34, (size_t)((Lb)) * sizeof(double), "__scg34");
        double *__scg35 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg35, (size_t)((Lb)) * sizeof(double), "__scg35");
        double *__scg36 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg36, (size_t)((Lb)) * sizeof(double), "__scg36");
        double *__scg37 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg37, (size_t)((Lb)) * sizeof(double), "__scg37");
        double *__scg38 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg38, (size_t)((Lb)) * sizeof(double), "__scg38");
        double *__scg39 = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(__scg39, (size_t)((Lb)) * sizeof(double), "__scg39");
        double *__inl13_row = (double *)malloc((size_t)((Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(__inl13_row, (size_t)((Lb) * (Lb)) * sizeof(double), "__inl13_row");
        double *__inl13_acc = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl13_acc, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl13_acc");
        double *__inl13_hx1 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl13_hx1, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl13_hx1");
        double *__inl13_flat = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl13_flat, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__inl13_flat");
        double *__inl13_overlap = (double *)malloc((size_t)((nproj) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl13_overlap, (size_t)((nproj) * (nstate)) * sizeof(double), "__inl13_overlap");
        double *__inl13_hx2 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl13_hx2, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__inl13_hx2");
        double *__hcall7 = (double *)malloc((size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double));
        __npb_alloc_check(__hcall7, (size_t)((Lb) * (Lb) * (Lb) * (nstate)) * sizeof(double), "__hcall7");
        double *__inl5_Wf = (double *)malloc((size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5_Wf, (size_t)((((((Lb * Lb) * Lb) * nstate) / nstate)) * (nstate)) * sizeof(double), "__inl5_Wf");
        double *__inl5_h_sub = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5_h_sub, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl5_h_sub");
        double *__inl5_s_sub = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5_s_sub, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl5_s_sub");
        double *__inl5_L = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5_L, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl5_L");
        double *__inl5_Linv = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5_Linv, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl5_Linv");
        double *__inl5___eigh1_a = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5___eigh1_a, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl5___eigh1_a");
        double *__inl5___eigh1_ya = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5___eigh1_ya, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl5___eigh1_ya");
        double *__inl5_w = (double *)malloc((size_t)((nstate)) * sizeof(double));
        __npb_alloc_check(__inl5_w, (size_t)((nstate)) * sizeof(double), "__inl5_w");
        double *__inl5_U = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5_U, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl5_U");
        int64_t *__ix5 = (int64_t *)malloc((size_t)((nstate)) * sizeof(int64_t));
        __npb_alloc_check(__ix5, (size_t)((nstate)) * sizeof(int64_t), "__ix5");
        int64_t *__ix6 = (int64_t *)malloc((size_t)((nstate)) * sizeof(int64_t));
        __npb_alloc_check(__ix6, (size_t)((nstate)) * sizeof(int64_t), "__ix6");
        double *__inl5_C = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__inl5_C, (size_t)((nstate) * (nstate)) * sizeof(double), "__inl5_C");
        double *dens = (double *)malloc((size_t)((Lb) * (Lb) * (Lb)) * sizeof(double));
        __npb_alloc_check(dens, (size_t)((Lb) * (Lb) * (Lb)) * sizeof(double), "dens");
        double _Complex *__inl14_rho_g = (double _Complex *)malloc((size_t)((N) * (N) * (N)) * sizeof(double _Complex));
        __npb_alloc_check(__inl14_rho_g, (size_t)((N) * (N) * (N)) * sizeof(double _Complex), "__inl14_rho_g");
        double *__inl22_kx = (double *)malloc((size_t)((N)) * sizeof(double));
        __npb_alloc_check(__inl22_kx, (size_t)((N)) * sizeof(double), "__inl22_kx");
        double *__inl22_gsq = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl22_gsq, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl22_gsq");
        double *__inl22_inv = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl22_inv, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl22_inv");
        double *__hcall11 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__hcall11, (size_t)((N) * (N) * (N)) * sizeof(double), "__hcall11");
        double *__inl15_n = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl15_n, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl15_n");
        double *__inl15_rs = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl15_rs, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl15_rs");
        double *__inl15_n13 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl15_n13, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl15_n13");
        double *__inl15_v_x = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl15_v_x, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl15_v_x");
        double *__inl15_denom = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl15_denom, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl15_denom");
        double *__inl15_v_c_ge1 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl15_v_c_ge1, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl15_v_c_ge1");
        double *__inl15_v_c_lt1 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl15_v_c_lt1, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl15_v_c_lt1");
        double *__hcall9 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__hcall9, (size_t)((N) * (N) * (N)) * sizeof(double), "__hcall9");
        double *__inl6_v = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl6_v, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl6_v");
        double *__hcall2 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__hcall2, (size_t)((N) * (N) * (N)) * sizeof(double), "__hcall2");
        double *__inl8_sqrt_rs = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl8_sqrt_rs, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl8_sqrt_rs");
        double *__inl8_ln_rs = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl8_ln_rs, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl8_ln_rs");
        double *__mc1 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__mc1, (size_t)((N) * (N) * (N)) * sizeof(double), "__mc1");
        double *__mc2 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__mc2, (size_t)((N) * (N) * (N)) * sizeof(double), "__mc2");
        double *__hcall8 = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__hcall8, (size_t)((N) * (N) * (N)) * sizeof(double), "__hcall8");
        double *__inl15_sqrt_rs = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl15_sqrt_rs, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl15_sqrt_rs");
        double *__inl15_ln_rs = (double *)malloc((size_t)((N) * (N) * (N)) * sizeof(double));
        __npb_alloc_check(__inl15_ln_rs, (size_t)((N) * (N) * (N)) * sizeof(double), "__inl15_ln_rs");
        double *gx_gy_gz = (double *)malloc((size_t)((Lb)) * sizeof(double));
        __npb_alloc_check(gx_gy_gz, (size_t)((Lb)) * sizeof(double), "gx_gy_gz");
        double *pf = (double *)malloc((size_t)((((Lb * Lb) * Lb)) * (nproj)) * sizeof(double));
        __npb_alloc_check(pf, (size_t)((((Lb * Lb) * Lb)) * (nproj)) * sizeof(double), "pf");
        double *df = (double *)malloc((size_t)((nproj) * (nproj)) * sizeof(double));
        __npb_alloc_check(df, (size_t)((nproj) * (nproj)) * sizeof(double), "df");
        double *__ixa1 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__ixa1, (size_t)((nstate) * (nstate)) * sizeof(double), "__ixa1");
        double *__ixa4 = (double *)malloc((size_t)((nstate) * (nstate)) * sizeof(double));
        __npb_alloc_check(__ixa4, (size_t)((nstate) * (nstate)) * sizeof(double), "__ixa4");
        double *__inl2___eigh0_Cm = NULL;
        double *__inl2___eigh0_jv = NULL;
        double *__inl2___eigh0_wa = NULL;
        double *__cb30 = NULL;
        double *__cb31 = NULL;
        double *__cb32 = NULL;
        double *__inl2_T = NULL;
        double *__inl2___eigh0_ya = NULL;
        double *__inl2___eigv1 = NULL;
        double *__inl2_off = NULL;
        h = sqrt((0.5 / half_inv_h2));
        /* numpy: np.arange(Lb) */
        for (int64_t __i = 0; __i < Lb; ++__i) {
          __cb1[__i] = __i;
        }
        for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
          box[__w0] = __cb1[__w0];
        }
        /* numpy: np.reshape(proj, (nfrag, Lb * Lb * Lb, nproj)) */
        for (int64_t __rs0 = 0; __rs0 < nfrag; ++__rs0) {
          for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
            for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
              for (int64_t __rs3 = 0; __rs3 < Lb; ++__rs3) {
                for (int64_t __rs4 = 0; __rs4 < nproj; ++__rs4) {
                  __cb2[((__rs0)*(((Lb * Lb) * Lb)) + ((((__rs1 * (Lb * Lb)) + (__rs2 * Lb)) + __rs3)))*(nproj) + (__rs4)] = proj[((((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(Lb) + (__rs3))*(nproj) + (__rs4)];
                }
              }
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < nfrag; ++__w0) {
          for (int64_t __w1 = 0; __w1 < ((Lb * Lb) * Lb); ++__w1) {
            for (int64_t __w2 = 0; __w2 < nproj; ++__w2) {
              proj_flat[((__w0)*(((Lb * Lb) * Lb)) + (__w1))*(nproj) + (__w2)] = __cb2[((__w0)*(((Lb * Lb) * Lb)) + (__w1))*(nproj) + (__w2)];
            }
          }
        }
        for (int64_t si0 = 0; si0 < N; ++si0) {
          for (int64_t si1 = 0; si1 < N; ++si1) {
            for (int64_t si2 = 0; si2 < N; ++si2) {
              rho_in[((si0)*(N) + (si1))*(N) + (si2)] = rho[((si0)*(N) + (si1))*(N) + (si2)];
            }
          }
        }
        /* numpy: np.sum(rho_in) */
        __cb3 = 0.0;
        for (int64_t __r0 = 0; __r0 < N; ++__r0) {
          for (int64_t __r1 = 0; __r1 < N; ++__r1) {
            for (int64_t __r2 = 0; __r2 < N; ++__r2) {
              __cb3 = (__cb3 + rho_in[((__r0)*(N) + (__r1))*(N) + (__r2)]);
            }
          }
        }
        nelec = (__cb3 * dvol);
        __inl7_N = N;
        /* numpy: np.mean(rho_in) */
        __cb4 = 0.0;
        for (int64_t __r0 = 0; __r0 < N; ++__r0) {
          for (int64_t __r1 = 0; __r1 < N; ++__r1) {
            for (int64_t __r2 = 0; __r2 < N; ++__r2) {
              __cb4 = (__cb4 + rho_in[((__r0)*(N) + (__r1))*(N) + (__r2)]);
            }
          }
        }
        __cb4 = (__cb4 / (double)(((N * N) * N)));
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __cb5[((__w0)*(N) + (__w1))*(N) + (__w2)] = (rho_in[((__w0)*(N) + (__w1))*(N) + (__w2)] - __cb4);
            }
          }
        }
        /* numpy: np.fft.fftn(__cb5) */
        {
          int64_t __fft_n = (int64_t)(N) * (int64_t)(N) * (int64_t)(N);
          int64_t __fft_batch = (int64_t)1;
          if (__fft_n > 0 && __fft_batch > 0) {
            int __fft_dims[3] = {(int)(N), (int)(N), (int)(N)};
            double _Complex *__fft_in = (double _Complex *)malloc((size_t)(__fft_n * __fft_batch) * sizeof(double _Complex));
            __npb_alloc_check(__fft_in, (size_t)(__fft_n * __fft_batch) * sizeof(double _Complex), "__fft_in");
            for (int64_t __fft_i = 0; __fft_i < __fft_n * __fft_batch; ++__fft_i) {
              __fft_in[__fft_i] = (double _Complex)(__cb5[__fft_i]);
            }
            fftw_plan __fft_plan = fftw_plan_many_dft(3, __fft_dims, (int)__fft_batch, (fftw_complex *)(__fft_in), NULL, (int)__fft_batch, 1, (fftw_complex *)(__cb6), NULL, (int)__fft_batch, 1, FFTW_FORWARD, FFTW_ESTIMATE);
            fftw_execute(__fft_plan);
            fftw_destroy_plan(__fft_plan);
            free(__fft_in);
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl7_rho_g[((__w0)*(N) + (__w1))*(N) + (__w2)] = __cb6[((__w0)*(N) + (__w1))*(N) + (__w2)];
            }
          }
        }
        /* numpy: np.fft.fftfreq(N, d=h) */
        for (int64_t __ff = 0; __ff < N; ++__ff) {
          __cb7[__ff] = (((__ff <= int_floor((N - 1), 2)) ? __ff : (__ff - N)) / (N * h));
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          __inl16_kx[__w0] = ((2.0 * 3.141592653589793) * __cb7[__w0]);
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl16_gsq[((__w0)*(N) + (__w1))*(N) + (__w2)] = (((__inl16_kx[__w0] * __inl16_kx[__w0]) + (__inl16_kx[__w1] * __inl16_kx[__w1])) + (__inl16_kx[__w2] * __inl16_kx[__w2]));
            }
          }
        }
        __inl16_gsq[((0)*(N) + (0))*(N) + (0)] = 1.0;
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl16_inv[((__w0)*(N) + (__w1))*(N) + (__w2)] = (1.0 / __inl16_gsq[((__w0)*(N) + (__w1))*(N) + (__w2)]);
            }
          }
        }
        __inl16_inv[((0)*(N) + (0))*(N) + (0)] = 0.0;
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __hcall10[((__w0)*(N) + (__w1))*(N) + (__w2)] = __inl16_inv[((__w0)*(N) + (__w1))*(N) + (__w2)];
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __cb8[((__w0)*(N) + (__w1))*(N) + (__w2)] = (((4.0 * 3.141592653589793) * __inl7_rho_g[((__w0)*(N) + (__w1))*(N) + (__w2)]) * __hcall10[((__w0)*(N) + (__w1))*(N) + (__w2)]);
            }
          }
        }
        /* numpy: np.fft.ifftn(__cb8) */
        {
          int64_t __fft_n = (int64_t)(N) * (int64_t)(N) * (int64_t)(N);
          int64_t __fft_batch = (int64_t)1;
          if (__fft_n > 0 && __fft_batch > 0) {
            int __fft_dims[3] = {(int)(N), (int)(N), (int)(N)};
            fftw_plan __fft_plan = fftw_plan_many_dft(3, __fft_dims, (int)__fft_batch, (fftw_complex *)(__cb8), NULL, (int)__fft_batch, 1, (fftw_complex *)(__cb9), NULL, (int)__fft_batch, 1, FFTW_BACKWARD, FFTW_ESTIMATE);
            fftw_execute(__fft_plan);
            fftw_destroy_plan(__fft_plan);
            for (int64_t __fft_i = 0; __fft_i < __fft_n * __fft_batch; ++__fft_i) {
              __cb9[__fft_i] /= ((double)__fft_n);
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __hcall2[((__w0)*(N) + (__w1))*(N) + (__w2)] = creal(__cb9[((__w0)*(N) + (__w1))*(N) + (__w2)]);
            }
          }
        }
        /* numpy: np.maximum(rho_in, 1e-12) */
        for (int64_t __r0 = 0; __r0 < N; ++__r0) {
          for (int64_t __r1 = 0; __r1 < N; ++__r1) {
            for (int64_t __r2 = 0; __r2 < N; ++__r2) {
              __cb10[((__r0)*(N) + (__r1))*(N) + (__r2)] = max(rho_in[((__r0)*(N) + (__r1))*(N) + (__r2)], 1e-12);
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl8_n[((__w0)*(N) + (__w1))*(N) + (__w2)] = __cb10[((__w0)*(N) + (__w1))*(N) + (__w2)];
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl8_rs[((__w0)*(N) + (__w1))*(N) + (__w2)] = pow((3.0 / ((4.0 * 3.141592653589793) * __inl8_n[((__w0)*(N) + (__w1))*(N) + (__w2)])), (1.0 / 3.0));
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl8_n13[((__w0)*(N) + (__w1))*(N) + (__w2)] = pow(__inl8_n[((__w0)*(N) + (__w1))*(N) + (__w2)], (1.0 / 3.0));
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl8_v_x[((__w0)*(N) + (__w1))*(N) + (__w2)] = ((-0.9847450218426965) * __inl8_n13[((__w0)*(N) + (__w1))*(N) + (__w2)]);
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl8_sqrt_rs[((__w0)*(N) + (__w1))*(N) + (__w2)] = sqrt(__inl8_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]);
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl8_ln_rs[((__w0)*(N) + (__w1))*(N) + (__w2)] = log(__inl8_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]);
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl8_denom[((__w0)*(N) + (__w1))*(N) + (__w2)] = ((1.0 + (1.0529 * __inl8_sqrt_rs[((__w0)*(N) + (__w1))*(N) + (__w2)])) + (0.3334 * __inl8_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]));
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl8_v_c_ge1[((__w0)*(N) + (__w1))*(N) + (__w2)] = (((-0.1423 / __inl8_denom[((__w0)*(N) + (__w1))*(N) + (__w2)]) * ((1.0 + (((7.0 / 6.0) * 1.0529) * __inl8_sqrt_rs[((__w0)*(N) + (__w1))*(N) + (__w2)])) + (((4.0 / 3.0) * 0.3334) * __inl8_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]))) / __inl8_denom[((__w0)*(N) + (__w1))*(N) + (__w2)]);
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl8_v_c_lt1[((__w0)*(N) + (__w1))*(N) + (__w2)] = ((((0.0311 * __inl8_ln_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]) + (-0.048 - (0.0311 / 3.0))) + ((((2.0 / 3.0) * 0.002) * __inl8_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]) * __inl8_ln_rs[((__w0)*(N) + (__w1))*(N) + (__w2)])) + ((((2.0 * -0.0116) - 0.002) / 3.0) * __inl8_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]));
            }
          }
        }
        /* numpy: np.where(__inl8_rs < 1.0, __inl8_v_c_lt1, __inl8_v_c_ge1) */
        for (int64_t __r0 = 0; __r0 < N; ++__r0) {
          for (int64_t __r1 = 0; __r1 < N; ++__r1) {
            for (int64_t __r2 = 0; __r2 < N; ++__r2) {
              __cb11[((__r0)*(N) + (__r1))*(N) + (__r2)] = ((__inl8_rs[((__r0)*(N) + (__r1))*(N) + (__r2)] < 1.0) ? __inl8_v_c_lt1[((__r0)*(N) + (__r1))*(N) + (__r2)] : __inl8_v_c_ge1[((__r0)*(N) + (__r1))*(N) + (__r2)]);
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __hcall3[((__w0)*(N) + (__w1))*(N) + (__w2)] = (__inl8_v_x[((__w0)*(N) + (__w1))*(N) + (__w2)] + __cb11[((__w0)*(N) + (__w1))*(N) + (__w2)]);
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < N; ++__w0) {
          for (int64_t __w1 = 0; __w1 < N; ++__w1) {
            for (int64_t __w2 = 0; __w2 < N; ++__w2) {
              __inl1_v[((__w0)*(N) + (__w1))*(N) + (__w2)] = ((__hcall2[((__w0)*(N) + (__w1))*(N) + (__w2)] + V_ion[((__w0)*(N) + (__w1))*(N) + (__w2)]) + __hcall3[((__w0)*(N) + (__w1))*(N) + (__w2)]);
            }
          }
        }
        /* numpy: np.mean(__inl1_v) */
        __cb12 = 0.0;
        for (int64_t __r0 = 0; __r0 < N; ++__r0) {
          for (int64_t __r1 = 0; __r1 < N; ++__r1) {
            for (int64_t __r2 = 0; __r2 < N; ++__r2) {
              __cb12 = (__cb12 + __inl1_v[((__r0)*(N) + (__r1))*(N) + (__r2)]);
            }
          }
        }
        __cb12 = (__cb12 / (double)(((N * N) * N)));
        for (int64_t si0 = 0; si0 < N; ++si0) {
          for (int64_t si1 = 0; si1 < N; ++si1) {
            for (int64_t si2 = 0; si2 < N; ++si2) {
              V_tot[((si0)*(N) + (si1))*(N) + (si2)] = (__inl1_v[((si0)*(N) + (si1))*(N) + (si2)] - __cb12);
            }
          }
        }
        memset(b_frag, 0, (size_t)((nfrag)) * sizeof(double));
        memset(b_frag_valid, 0, (size_t)((nfrag)) * sizeof(bool));
        for (int64_t _ = 0; _ < ((int64_t)(nscf)); ++_) {
          memset(rho_out, 0, (size_t)((N) * (N) * (N)) * sizeof(double));
          for (int64_t f = 0; f < nfrag; ++f) {
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              xs[__w0] = python_mod((offsets[(f)*(3) + (0)] + box[__w0]), N);
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              ys[__w0] = python_mod((offsets[(f)*(3) + (1)] + box[__w0]), N);
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              zs[__w0] = python_mod((offsets[(f)*(3) + (2)] + box[__w0]), N);
            }
            for (int64_t __ixg1_0 = 0; __ixg1_0 < Lb; ++__ixg1_0) {
              for (int64_t __ixg1_1 = 0; __ixg1_1 < Lb; ++__ixg1_1) {
                for (int64_t __ixg1_2 = 0; __ixg1_2 < Lb; ++__ixg1_2) {
                  vloc[((__ixg1_0)*(Lb) + (__ixg1_1))*(Lb) + (__ixg1_2)] = V_tot[((xs[__ixg1_0])*(N) + (ys[__ixg1_1]))*(N) + (zs[__ixg1_2])];
                }
              }
            }
            for (int64_t si0 = 0; si0 < ((Lb * Lb) * Lb); ++si0) {
              for (int64_t si1 = 0; si1 < nproj; ++si1) {
                pf[(si0)*(nproj) + (si1)] = proj_flat[((f)*(((Lb * Lb) * Lb)) + (si0))*(nproj) + (si1)];
              }
            }
            for (int64_t si0 = 0; si0 < nproj; ++si0) {
              for (int64_t si1 = 0; si1 < nproj; ++si1) {
                df[(si0)*(nproj) + (si1)] = dij[((f)*(nproj) + (si0))*(nproj) + (si1)];
              }
            }
            if ((!b_frag_valid[f])) {
              for (int64_t si0 = 0; si0 < Lb; ++si0) {
                for (int64_t si1 = 0; si1 < Lb; ++si1) {
                  for (int64_t si2 = 0; si2 < Lb; ++si2) {
                    __inl2_v[((si0)*(Lb) + (si1))*(Lb) + (si2)] = psi_frag[((((f)*(Lb) + (si0))*(Lb) + (si1))*(Lb) + (si2))*(nstate) + (0)];
                  }
                }
              }
              __inl2_nb0 = Lb;
              __inl2_nb1 = Lb;
              __inl2_nb2 = Lb;
              /* numpy: np.linalg.norm(__inl2_v) */
              __cb13 = 0.0;
              for (int64_t __nr0 = 0; __nr0 < Lb; ++__nr0) {
                for (int64_t __nr1 = 0; __nr1 < Lb; ++__nr1) {
                  for (int64_t __nr2 = 0; __nr2 < Lb; ++__nr2) {
                    __cb13 += (__inl2_v[((__nr0)*(Lb) + (__nr1))*(Lb) + (__nr2)] * __inl2_v[((__nr0)*(Lb) + (__nr1))*(Lb) + (__nr2)]);
                  }
                }
              }
              __cb13 = sqrt(__cb13);
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    __inl2_v[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] = (__inl2_v[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] / (__cb13 + 1e-30));
                  }
                }
              }
              memset(__inl2_v_prev, 0, (size_t)((Lb) * (Lb) * (Lb)) * sizeof(double));
              memset(__inl2_alphas, 0, (size_t)((6)) * sizeof(double));
              memset(__inl2_betas, 0, (size_t)((6)) * sizeof(double));
              __inl2_na = 0;
              __inl2_nb = 0;
              __inl2_beta = 0.0;
              for (int64_t __inl2__ = 0; __inl2__ < 6; ++__inl2__) {
                memset(__inl2_vcol, 0, (size_t)((Lb) * (Lb) * (Lb) * (1)) * sizeof(double));
                for (int64_t si0 = 0; si0 < Lb; ++si0) {
                  for (int64_t si1 = 0; si1 < Lb; ++si1) {
                    for (int64_t si2 = 0; si2 < Lb; ++si2) {
                      __inl2_vcol[(((si0)*(Lb) + (si1))*(Lb) + (si2))*(1) + (0)] = __inl2_v[((si0)*(Lb) + (si1))*(Lb) + (si2)];
                    }
                  }
                }
                memset(__inl17_row, 0, (size_t)((Lb) * (Lb)) * sizeof(double));
                /* numpy: np.arange(Lb) */
                for (int64_t __i = 0; __i < Lb; ++__i) {
                  __cb14[__i] = __i;
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  __inl17_idx[__w0] = __cb14[__w0];
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __inl17_row[(__inl17_idx[__sc0])*(Lb) + (__inl17_idx[__sc0])] = -2.8472222222222223;
                }
                __inl17_m = (1 + 0);
                __inl17_w = 1.6;
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __scg0[__sc0] = __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] - __inl17_m), Lb))];
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] - __inl17_m), Lb))] = (__scg0[__sc0] + __inl17_w);
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __scg1[__sc0] = __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] + __inl17_m), Lb))];
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] + __inl17_m), Lb))] = (__scg1[__sc0] + __inl17_w);
                }
                __inl17_m = (1 + 1);
                __inl17_w = -0.2;
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __scg2[__sc0] = __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] - __inl17_m), Lb))];
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] - __inl17_m), Lb))] = (__scg2[__sc0] + __inl17_w);
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __scg3[__sc0] = __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] + __inl17_m), Lb))];
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] + __inl17_m), Lb))] = (__scg3[__sc0] + __inl17_w);
                }
                __inl17_m = (1 + 2);
                __inl17_w = 0.025396825396825397;
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __scg4[__sc0] = __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] - __inl17_m), Lb))];
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] - __inl17_m), Lb))] = (__scg4[__sc0] + __inl17_w);
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __scg5[__sc0] = __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] + __inl17_m), Lb))];
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] + __inl17_m), Lb))] = (__scg5[__sc0] + __inl17_w);
                }
                __inl17_m = (1 + 3);
                __inl17_w = -0.0017857142857142857;
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __scg6[__sc0] = __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] - __inl17_m), Lb))];
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] - __inl17_m), Lb))] = (__scg6[__sc0] + __inl17_w);
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __scg7[__sc0] = __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] + __inl17_m), Lb))];
                }
                for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                  __inl17_row[(__inl17_idx[__sc0])*(Lb) + (python_mod((__inl17_idx[__sc0] + __inl17_m), Lb))] = (__scg7[__sc0] + __inl17_w);
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    __inl9_row[(__w0)*(Lb) + (__w1)] = __inl17_row[(__w0)*(Lb) + (__w1)];
                  }
                }
                /* numpy: np.tensordot(__inl9_row, __inl2_vcol, axes=([1], [0])) */
                for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
                  for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                    for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                      for (int64_t __es_e = 0; __es_e < 1; ++__es_e) {
                        __cb15[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(1) + (__es_e)] = 0.0;
                        for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                          __cb15[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(1) + (__es_e)] += (__inl9_row[(__es_a)*(Lb) + (__es_b)] * __inl2_vcol[(((__es_b)*(Lb) + (__es_c))*(Lb) + (__es_d))*(1) + (__es_e)]);
                        }
                      }
                    }
                  }
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      for (int64_t __w3 = 0; __w3 < 1; ++__w3) {
                        __inl9_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (__w3)] = __cb15[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (0)];
                      }
                    }
                  }
                }
                /* numpy: np.tensordot(__inl9_row, __inl2_vcol, axes=([1], [1])) */
                for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
                  for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                    for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                      for (int64_t __es_e = 0; __es_e < 1; ++__es_e) {
                        __cb16[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(1) + (__es_e)] = 0.0;
                        for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                          __cb16[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(1) + (__es_e)] += (__inl9_row[(__es_a)*(Lb) + (__es_b)] * __inl2_vcol[(((__es_c)*(Lb) + (__es_b))*(Lb) + (__es_d))*(1) + (__es_e)]);
                        }
                      }
                    }
                  }
                }
                /* numpy: np.moveaxis(__cb16, 0, 1) */
                for (int64_t __t0 = 0; __t0 < Lb; ++__t0) {
                  for (int64_t __t1 = 0; __t1 < Lb; ++__t1) {
                    for (int64_t __t2 = 0; __t2 < Lb; ++__t2) {
                      for (int64_t __t3 = 0; __t3 < 1; ++__t3) {
                        __cb17[(((__t1)*(Lb) + (__t0))*(Lb) + (__t2))*(1) + (__t3)] = __cb16[(((__t0)*(Lb) + (__t1))*(Lb) + (__t2))*(1) + (__t3)];
                      }
                    }
                  }
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      for (int64_t __w3 = 0; __w3 < 1; ++__w3) {
                        __inl9_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (__w3)] += __cb17[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (0)];
                      }
                    }
                  }
                }
                /* numpy: np.tensordot(__inl9_row, __inl2_vcol, axes=([1], [2])) */
                for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
                  for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                    for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                      for (int64_t __es_e = 0; __es_e < 1; ++__es_e) {
                        __cb18[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(1) + (__es_e)] = 0.0;
                        for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                          __cb18[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(1) + (__es_e)] += (__inl9_row[(__es_a)*(Lb) + (__es_b)] * __inl2_vcol[(((__es_c)*(Lb) + (__es_d))*(Lb) + (__es_b))*(1) + (__es_e)]);
                        }
                      }
                    }
                  }
                }
                /* numpy: np.moveaxis(__cb18, 0, 2) */
                for (int64_t __t0 = 0; __t0 < Lb; ++__t0) {
                  for (int64_t __t1 = 0; __t1 < Lb; ++__t1) {
                    for (int64_t __t2 = 0; __t2 < Lb; ++__t2) {
                      for (int64_t __t3 = 0; __t3 < 1; ++__t3) {
                        __cb19[(((__t1)*(Lb) + (__t2))*(Lb) + (__t0))*(1) + (__t3)] = __cb18[(((__t0)*(Lb) + (__t1))*(Lb) + (__t2))*(1) + (__t3)];
                      }
                    }
                  }
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      for (int64_t __w3 = 0; __w3 < 1; ++__w3) {
                        __inl9_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (__w3)] += __cb19[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (0)];
                      }
                    }
                  }
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      for (int64_t __w3 = 0; __w3 < 1; ++__w3) {
                        __inl9_hx1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (__w3)] = (((-half_inv_h2) * __inl9_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (0)]) + (vloc[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] * __inl2_vcol[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (0)]));
                      }
                    }
                  }
                }
                /* numpy: np.reshape(__inl2_vcol, (-1, 1)) */
                for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
                  for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                    for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                      for (int64_t __rs3 = 0; __rs3 < 1; ++__rs3) {
                        __cb20[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(1) + (__rs3)] = __inl2_vcol[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(1) + (__rs3)];
                      }
                    }
                  }
                }
                for (int64_t __w0 = 0; __w0 < ((((Lb * Lb) * Lb) * 1) / 1); ++__w0) {
                  for (int64_t __w1 = 0; __w1 < 1; ++__w1) {
                    __inl9_flat[(__w0)*(1) + (__w1)] = __cb20[(__w0)*(1) + (0)];
                  }
                }
                /* numpy: np.transpose(pf) */
                for (int64_t __t0 = 0; __t0 < ((Lb * Lb) * Lb); ++__t0) {
                  for (int64_t __t1 = 0; __t1 < nproj; ++__t1) {
                    __cb21[(__t1)*(((Lb * Lb) * Lb)) + (__t0)] = pf[(__t0)*(nproj) + (__t1)];
                  }
                }
                cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nproj), (blasint)(1), (blasint)(((Lb * Lb) * Lb)), 1.0, __cb21, (blasint)(((Lb * Lb) * Lb)), __inl9_flat, (blasint)(1), 0.0, __mm22, (blasint)(1));
                for (int64_t __w0 = 0; __w0 < nproj; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < 1; ++__w1) {
                    __inl9_overlap[(__w0)*(1) + (__w1)] = __mm22[(__w0)*(1) + (0)];
                  }
                }
                cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nproj), (blasint)(1), (blasint)(nproj), 1.0, df, (blasint)(nproj), __inl9_overlap, (blasint)(1), 0.0, __mm23, (blasint)(1));
                cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(((Lb * Lb) * Lb)), (blasint)(1), (blasint)(nproj), 1.0, pf, (blasint)(nproj), __mm23, (blasint)(1), 0.0, __mm24, (blasint)(1));
                /* numpy: np.reshape(__mm24, (Lb, Lb, Lb, 1)) */
                for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
                  for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                    for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                      for (int64_t __rs3 = 0; __rs3 < 1; ++__rs3) {
                        __cb25[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(1) + (__rs3)] = __mm24[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(1) + (__rs3)];
                      }
                    }
                  }
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      for (int64_t __w3 = 0; __w3 < 1; ++__w3) {
                        __inl9_hx2[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (__w3)] = (__inl9_hx1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (0)] + __cb25[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (0)]);
                      }
                    }
                  }
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      for (int64_t __w3 = 0; __w3 < 1; ++__w3) {
                        __inl2_wcol[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (__w3)] = __inl9_hx2[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(1) + (0)];
                      }
                    }
                  }
                }
                for (int64_t si0 = 0; si0 < Lb; ++si0) {
                  for (int64_t si1 = 0; si1 < Lb; ++si1) {
                    for (int64_t si2 = 0; si2 < Lb; ++si2) {
                      __inl2_w[((si0)*(Lb) + (si1))*(Lb) + (si2)] = __inl2_wcol[(((si0)*(Lb) + (si1))*(Lb) + (si2))*(1) + (0)];
                    }
                  }
                }
                /* numpy: np.reshape(__inl2_v, (-1,)) */
                for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
                  for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                    for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                      __cb26[(((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2)] = __inl2_v[((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2)];
                    }
                  }
                }
                /* numpy: np.reshape(__inl2_w, (-1,)) */
                for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
                  for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                    for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                      __cb27[(((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2)] = __inl2_w[((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2)];
                    }
                  }
                }
                __mm28 = 0.0;
                for (int64_t __mml28 = 0; __mml28 < ((Lb * Lb) * Lb); ++__mml28) {
                  __mm28 += (__cb26[__mml28] * __cb27[__mml28]);
                }
                __inl2_alpha = __mm28;
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      __inl2_w[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] = ((__inl2_w[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] - (__inl2_alpha * __inl2_v[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)])) - (__inl2_beta * __inl2_v_prev[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)]));
                    }
                  }
                }
                /* numpy: np.linalg.norm(__inl2_w) */
                __cb29 = 0.0;
                for (int64_t __nr0 = 0; __nr0 < Lb; ++__nr0) {
                  for (int64_t __nr1 = 0; __nr1 < Lb; ++__nr1) {
                    for (int64_t __nr2 = 0; __nr2 < Lb; ++__nr2) {
                      __cb29 += (__inl2_w[((__nr0)*(Lb) + (__nr1))*(Lb) + (__nr2)] * __inl2_w[((__nr0)*(Lb) + (__nr1))*(Lb) + (__nr2)]);
                    }
                  }
                }
                __cb29 = sqrt(__cb29);
                __inl2_beta = __cb29;
                __inl2_alphas[__inl2_na] = __inl2_alpha;
                __inl2_na += 1;
                if ((__inl2_beta < 1e-12)) {
                  break;
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      __swap1_0[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] = __inl2_v[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)];
                    }
                  }
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      __swap1_1[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] = (__inl2_w[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] / __inl2_beta);
                    }
                  }
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      __inl2_v_prev[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] = __swap1_0[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)];
                    }
                  }
                }
                for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                    for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                      __inl2_v[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] = __swap1_1[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)];
                    }
                  }
                }
                __inl2_betas[__inl2_nb] = __inl2_beta;
                __inl2_nb += 1;
              }
              free(__inl2_off);
              __inl2_off = (double *)malloc((size_t)(((__inl2_na - 1))) * sizeof(double));
              __npb_alloc_check(__inl2_off, (size_t)(((__inl2_na - 1))) * sizeof(double), "__inl2_off");
              for (int64_t __w0 = 0; __w0 < (__inl2_na - 1); ++__w0) {
                __inl2_off[__w0] = __inl2_betas[__w0];
              }
              free(__cb30);
              __cb30 = (double *)malloc((size_t)((__inl2_na) * (__inl2_na)) * sizeof(double));
              __npb_alloc_check(__cb30, (size_t)((__inl2_na) * (__inl2_na)) * sizeof(double), "__cb30");
              /* numpy: np.diag(__inl2_alphas[:__inl2_na]) */
              for (int64_t __dg_zi = 0; __dg_zi < __inl2_na; ++__dg_zi) {
                for (int64_t __dg_zj = 0; __dg_zj < __inl2_na; ++__dg_zj) {
                  __cb30[(__dg_zi)*(__inl2_na) + (__dg_zj)] = 0.0;
                }
              }
              for (int64_t __dg_i = 0; __dg_i < __inl2_na; ++__dg_i) {
                __cb30[(__dg_i)*(__inl2_na) + (__dg_i)] = __inl2_alphas[__dg_i];
              }
              free(__inl2_T);
              __inl2_T = (double *)malloc((size_t)((__inl2_na) * (__inl2_na)) * sizeof(double));
              __npb_alloc_check(__inl2_T, (size_t)((__inl2_na) * (__inl2_na)) * sizeof(double), "__inl2_T");
              for (int64_t __w0 = 0; __w0 < __inl2_na; ++__w0) {
                for (int64_t __w1 = 0; __w1 < __inl2_na; ++__w1) {
                  __inl2_T[(__w0)*(__inl2_na) + (__w1)] = __cb30[(__w0)*(__inl2_na) + (__w1)];
                }
              }
              if ((__inl2_na - 1)) {
                free(__cb31);
                __cb31 = (double *)malloc((size_t)((((__inl2_na - 1) + 1)) * (((__inl2_na - 1) + 1))) * sizeof(double));
                __npb_alloc_check(__cb31, (size_t)((((__inl2_na - 1) + 1)) * (((__inl2_na - 1) + 1))) * sizeof(double), "__cb31");
                /* numpy: np.diag(__inl2_off, 1) */
                for (int64_t __dg_zi = 0; __dg_zi < ((__inl2_na - 1) + 1); ++__dg_zi) {
                  for (int64_t __dg_zj = 0; __dg_zj < ((__inl2_na - 1) + 1); ++__dg_zj) {
                    __cb31[(__dg_zi)*(((__inl2_na - 1) + 1)) + (__dg_zj)] = 0.0;
                  }
                }
                for (int64_t __dg_i = 0; __dg_i < (__inl2_na - 1); ++__dg_i) {
                  __cb31[(__dg_i)*(((__inl2_na - 1) + 1)) + ((__dg_i + 1))] = __inl2_off[__dg_i];
                }
                free(__cb32);
                __cb32 = (double *)malloc((size_t)((((__inl2_na - 1) + 1)) * (((__inl2_na - 1) + 1))) * sizeof(double));
                __npb_alloc_check(__cb32, (size_t)((((__inl2_na - 1) + 1)) * (((__inl2_na - 1) + 1))) * sizeof(double), "__cb32");
                /* numpy: np.diag(__inl2_off, -1) */
                for (int64_t __dg_zi = 0; __dg_zi < ((__inl2_na - 1) + 1); ++__dg_zi) {
                  for (int64_t __dg_zj = 0; __dg_zj < ((__inl2_na - 1) + 1); ++__dg_zj) {
                    __cb32[(__dg_zi)*(((__inl2_na - 1) + 1)) + (__dg_zj)] = 0.0;
                  }
                }
                for (int64_t __dg_i = 0; __dg_i < (__inl2_na - 1); ++__dg_i) {
                  __cb32[((__dg_i + 1))*(((__inl2_na - 1) + 1)) + (__dg_i)] = __inl2_off[__dg_i];
                }
                for (int64_t __w0 = 0; __w0 < __inl2_na; ++__w0) {
                  for (int64_t __w1 = 0; __w1 < __inl2_na; ++__w1) {
                    __inl2_T[(__w0)*(__inl2_na) + (__w1)] = ((__inl2_T[(__w0)*(__inl2_na) + (__w1)] + __cb31[(__w0)*(((__inl2_na - 1) + 1)) + (__w1)]) + __cb32[(__w0)*(((__inl2_na - 1) + 1)) + (__w1)]);
                  }
                }
              }
              free(__inl2___eigh0_Cm);
              __inl2___eigh0_Cm = (double *)malloc((size_t)((__inl2_na) * (__inl2_na)) * sizeof(double));
              __npb_alloc_check(__inl2___eigh0_Cm, (size_t)((__inl2_na) * (__inl2_na)) * sizeof(double), "__inl2___eigh0_Cm");
              memset(__inl2___eigh0_Cm, 0, (size_t)((__inl2_na) * (__inl2_na)) * sizeof(double));
              for (int64_t __inl2___eigh0_ci = 0; __inl2___eigh0_ci < __inl2_na; ++__inl2___eigh0_ci) {
                for (int64_t __inl2___eigh0_cj = 0; __inl2___eigh0_cj < __inl2_na; ++__inl2___eigh0_cj) {
                  __inl2___eigh0_Cm[(__inl2___eigh0_ci)*(__inl2_na) + (__inl2___eigh0_cj)] = __inl2_T[(__inl2___eigh0_ci)*(__inl2_na) + (__inl2___eigh0_cj)];
                }
              }
              free(__inl2___eigh0_jv);
              __inl2___eigh0_jv = (double *)malloc((size_t)((__inl2_na) * (__inl2_na)) * sizeof(double));
              __npb_alloc_check(__inl2___eigh0_jv, (size_t)((__inl2_na) * (__inl2_na)) * sizeof(double), "__inl2___eigh0_jv");
              memset(__inl2___eigh0_jv, 0, (size_t)((__inl2_na) * (__inl2_na)) * sizeof(double));
              for (int64_t __inl2___eigh0_di = 0; __inl2___eigh0_di < __inl2_na; ++__inl2___eigh0_di) {
                __inl2___eigh0_jv[(__inl2___eigh0_di)*(__inl2_na) + (__inl2___eigh0_di)] = 1;
              }
              for (int64_t __inl2___eigh0_sw = 0; __inl2___eigh0_sw < 80; ++__inl2___eigh0_sw) {
                __inl2___eigh0_off = 0.0;
                for (int64_t __inl2___eigh0_pp = 0; __inl2___eigh0_pp < __inl2_na; ++__inl2___eigh0_pp) {
                  for (int64_t __inl2___eigh0_qq = (__inl2___eigh0_pp + 1); __inl2___eigh0_qq < __inl2_na; ++__inl2___eigh0_qq) {
                    __inl2___eigh0_off += ((__inl2___eigh0_Cm[(__inl2___eigh0_pp)*(__inl2_na) + (__inl2___eigh0_qq)] * __inl2___eigh0_Cm[(__inl2___eigh0_pp)*(__inl2_na) + (__inl2___eigh0_qq)]) + (0.0 * 0.0));
                  }
                }
                if ((__inl2___eigh0_off <= 1e-30)) {
                  break;
                }
                for (int64_t __inl2___eigh0_pp = 0; __inl2___eigh0_pp < __inl2_na; ++__inl2___eigh0_pp) {
                  for (int64_t __inl2___eigh0_qq = (__inl2___eigh0_pp + 1); __inl2___eigh0_qq < __inl2_na; ++__inl2___eigh0_qq) {
                    __inl2___eigh0_apq = __inl2___eigh0_Cm[(__inl2___eigh0_pp)*(__inl2_na) + (__inl2___eigh0_qq)];
                    if ((hypot(__inl2___eigh0_apq, 0.0) == 0.0)) {
                      continue;
                    }
                    __inl2___eigh0_app = __inl2___eigh0_Cm[(__inl2___eigh0_pp)*(__inl2_na) + (__inl2___eigh0_pp)];
                    __inl2___eigh0_aqq = __inl2___eigh0_Cm[(__inl2___eigh0_qq)*(__inl2_na) + (__inl2___eigh0_qq)];
                    __inl2___eigh0_s = ((((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0)))) * (1.0 / sqrt((((((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0)))) * (((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0))))) + 1.0))));
                    for (int64_t __inl2___eigh0_k = 0; __inl2___eigh0_k < __inl2_na; ++__inl2___eigh0_k) {
                      __inl2___eigh0_akp = __inl2___eigh0_Cm[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_pp)];
                      __inl2___eigh0_akq = __inl2___eigh0_Cm[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_qq)];
                      __inl2___eigh0_Cm[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_pp)] = (((1.0 / sqrt((((((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0)))) * (((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl2___eigh0_akp) - ((__inl2___eigh0_s * (__inl2___eigh0_apq / hypot(__inl2___eigh0_apq, 0.0))) * __inl2___eigh0_akq));
                      __inl2___eigh0_Cm[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_qq)] = (((__inl2___eigh0_s * (__inl2___eigh0_apq / hypot(__inl2___eigh0_apq, 0.0))) * __inl2___eigh0_akp) + ((1.0 / sqrt((((((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0)))) * (((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl2___eigh0_akq));
                    }
                    for (int64_t __inl2___eigh0_k = 0; __inl2___eigh0_k < __inl2_na; ++__inl2___eigh0_k) {
                      __inl2___eigh0_apk = __inl2___eigh0_Cm[(__inl2___eigh0_pp)*(__inl2_na) + (__inl2___eigh0_k)];
                      __inl2___eigh0_aqk = __inl2___eigh0_Cm[(__inl2___eigh0_qq)*(__inl2_na) + (__inl2___eigh0_k)];
                      __inl2___eigh0_Cm[(__inl2___eigh0_pp)*(__inl2_na) + (__inl2___eigh0_k)] = (((1.0 / sqrt((((((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0)))) * (((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl2___eigh0_apk) - ((__inl2___eigh0_s * (__inl2___eigh0_apq / hypot(__inl2___eigh0_apq, 0.0))) * __inl2___eigh0_aqk));
                      __inl2___eigh0_Cm[(__inl2___eigh0_qq)*(__inl2_na) + (__inl2___eigh0_k)] = (((__inl2___eigh0_s * (__inl2___eigh0_apq / hypot(__inl2___eigh0_apq, 0.0))) * __inl2___eigh0_apk) + ((1.0 / sqrt((((((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0)))) * (((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl2___eigh0_aqk));
                    }
                    for (int64_t __inl2___eigh0_k = 0; __inl2___eigh0_k < __inl2_na; ++__inl2___eigh0_k) {
                      __inl2___eigh0_vkp = __inl2___eigh0_jv[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_pp)];
                      __inl2___eigh0_vkq = __inl2___eigh0_jv[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_qq)];
                      __inl2___eigh0_jv[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_pp)] = (((1.0 / sqrt((((((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0)))) * (((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl2___eigh0_vkp) - ((__inl2___eigh0_s * (__inl2___eigh0_apq / hypot(__inl2___eigh0_apq, 0.0))) * __inl2___eigh0_vkq));
                      __inl2___eigh0_jv[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_qq)] = (((__inl2___eigh0_s * (__inl2___eigh0_apq / hypot(__inl2___eigh0_apq, 0.0))) * __inl2___eigh0_vkp) + ((1.0 / sqrt((((((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0)))) * (((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + sqrt(((((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0))) * ((__inl2___eigh0_aqq - __inl2___eigh0_app) / (2.0 * hypot(__inl2___eigh0_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl2___eigh0_vkq));
                    }
                  }
                }
              }
              free(__inl2___eigh0_wa);
              __inl2___eigh0_wa = (double *)malloc((size_t)((__inl2_na)) * sizeof(double));
              __npb_alloc_check(__inl2___eigh0_wa, (size_t)((__inl2_na)) * sizeof(double), "__inl2___eigh0_wa");
              memset(__inl2___eigh0_wa, 0, (size_t)((__inl2_na)) * sizeof(double));
              for (int64_t __inl2___eigh0_i = 0; __inl2___eigh0_i < __inl2_na; ++__inl2___eigh0_i) {
                __inl2___eigh0_wa[__inl2___eigh0_i] = __inl2___eigh0_Cm[(__inl2___eigh0_i)*(__inl2_na) + (__inl2___eigh0_i)];
              }
              for (int64_t __inl2___eigh0_i = 0; __inl2___eigh0_i < __inl2_na; ++__inl2___eigh0_i) {
                __inl2___eigh0_mn = __inl2___eigh0_i;
                for (int64_t __inl2___eigh0_j = (__inl2___eigh0_i + 1); __inl2___eigh0_j < __inl2_na; ++__inl2___eigh0_j) {
                  if ((__inl2___eigh0_wa[__inl2___eigh0_j] < __inl2___eigh0_wa[__inl2___eigh0_mn])) {
                    __inl2___eigh0_mn = __inl2___eigh0_j;
                  }
                }
                if ((__inl2___eigh0_mn != __inl2___eigh0_i)) {
                  __inl2___eigh0_tw = __inl2___eigh0_wa[__inl2___eigh0_i];
                  __inl2___eigh0_wa[__inl2___eigh0_i] = __inl2___eigh0_wa[__inl2___eigh0_mn];
                  __inl2___eigh0_wa[__inl2___eigh0_mn] = __inl2___eigh0_tw;
                  for (int64_t __inl2___eigh0_k = 0; __inl2___eigh0_k < __inl2_na; ++__inl2___eigh0_k) {
                    __inl2___eigh0_tv = __inl2___eigh0_jv[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_i)];
                    __inl2___eigh0_jv[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_i)] = __inl2___eigh0_jv[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_mn)];
                    __inl2___eigh0_jv[(__inl2___eigh0_k)*(__inl2_na) + (__inl2___eigh0_mn)] = __inl2___eigh0_tv;
                  }
                }
              }
              free(__inl2___eigh0_ya);
              __inl2___eigh0_ya = (double *)malloc((size_t)((__inl2_na) * (__inl2_na)) * sizeof(double));
              __npb_alloc_check(__inl2___eigh0_ya, (size_t)((__inl2_na) * (__inl2_na)) * sizeof(double), "__inl2___eigh0_ya");
              for (int64_t __w0 = 0; __w0 < __inl2_na; ++__w0) {
                for (int64_t __w1 = 0; __w1 < __inl2_na; ++__w1) {
                  __inl2___eigh0_ya[(__w0)*(__inl2_na) + (__w1)] = __inl2___eigh0_jv[(__w0)*(__inl2_na) + (__w1)];
                }
              }
              free(__inl2___eigv1);
              __inl2___eigv1 = (double *)malloc((size_t)((__inl2_na)) * sizeof(double));
              __npb_alloc_check(__inl2___eigv1, (size_t)((__inl2_na)) * sizeof(double), "__inl2___eigv1");
              for (int64_t __w0 = 0; __w0 < __inl2_na; ++__w0) {
                __inl2___eigv1[__w0] = __inl2___eigh0_wa[__w0];
              }
              /* numpy: np.max(__inl2___eigv1) */
              __cb33 = __inl2___eigv1[0];
              for (int64_t __r0 = 0; __r0 < __inl2_na; ++__r0) {
                __cb33 = (((__inl2___eigv1[__r0] > __cb33) || (__inl2___eigv1[__r0] != __inl2___eigv1[__r0])) ? __inl2___eigv1[__r0] : __cb33);
              }
              __hcall1 = (__cb33 + __inl2_beta);
              b_frag[f] = (1.2 * __hcall1);
              b_frag_valid[f] = 1;
            }
            __inl3_k = nstate;
            for (int64_t si0 = 0; si0 < Lb; ++si0) {
              for (int64_t si1 = 0; si1 < Lb; ++si1) {
                for (int64_t si2 = 0; si2 < Lb; ++si2) {
                  for (int64_t si3 = 0; si3 < nstate; ++si3) {
                    __cb34[(((si0)*(Lb) + (si1))*(Lb) + (si2))*(nstate) + (si3)] = psi_frag[((((f)*(Lb) + (si0))*(Lb) + (si1))*(Lb) + (si2))*(nstate) + (si3)];
                  }
                }
              }
            }
            /* numpy: np.reshape(__cb34, (-1, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb35[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)] = __cb34[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3_Yf[(__w0)*(nstate) + (__w1)] = __cb35[(__w0)*(nstate) + (__w1)];
              }
            }
            memset(__inl18_row, 0, (size_t)((Lb) * (Lb)) * sizeof(double));
            /* numpy: np.arange(Lb) */
            for (int64_t __i = 0; __i < Lb; ++__i) {
              __cb36[__i] = __i;
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              __inl18_idx[__w0] = __cb36[__w0];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl18_row[(__inl18_idx[__sc0])*(Lb) + (__inl18_idx[__sc0])] = -2.8472222222222223;
            }
            __inl18_m = (1 + 0);
            __inl18_w = 1.6;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg8[__sc0] = __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] - __inl18_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] - __inl18_m), Lb))] = (__scg8[__sc0] + __inl18_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg9[__sc0] = __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] + __inl18_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] + __inl18_m), Lb))] = (__scg9[__sc0] + __inl18_w);
            }
            __inl18_m = (1 + 1);
            __inl18_w = -0.2;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg10[__sc0] = __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] - __inl18_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] - __inl18_m), Lb))] = (__scg10[__sc0] + __inl18_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg11[__sc0] = __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] + __inl18_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] + __inl18_m), Lb))] = (__scg11[__sc0] + __inl18_w);
            }
            __inl18_m = (1 + 2);
            __inl18_w = 0.025396825396825397;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg12[__sc0] = __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] - __inl18_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] - __inl18_m), Lb))] = (__scg12[__sc0] + __inl18_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg13[__sc0] = __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] + __inl18_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] + __inl18_m), Lb))] = (__scg13[__sc0] + __inl18_w);
            }
            __inl18_m = (1 + 3);
            __inl18_w = -0.0017857142857142857;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg14[__sc0] = __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] - __inl18_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] - __inl18_m), Lb))] = (__scg14[__sc0] + __inl18_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg15[__sc0] = __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] + __inl18_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl18_row[(__inl18_idx[__sc0])*(Lb) + (python_mod((__inl18_idx[__sc0] + __inl18_m), Lb))] = (__scg15[__sc0] + __inl18_w);
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                __inl10_row[(__w0)*(Lb) + (__w1)] = __inl18_row[(__w0)*(Lb) + (__w1)];
              }
            }
            /* numpy: np.tensordot(__inl10_row, psi_frag[f, :, :, :, :], axes=([1], [0])) */
            for (int64_t __td_c0 = 0; __td_c0 < Lb; ++__td_c0) {
              for (int64_t __td_c1 = 0; __td_c1 < Lb; ++__td_c1) {
                for (int64_t __td_c2 = 0; __td_c2 < Lb; ++__td_c2) {
                  for (int64_t __td_c3 = 0; __td_c3 < nstate; ++__td_c3) {
                    __td_op1[(((__td_c0)*(Lb) + (__td_c1))*(Lb) + (__td_c2))*(nstate) + (__td_c3)] = psi_frag[((((f)*(Lb) + (__td_c0))*(Lb) + (__td_c1))*(Lb) + (__td_c2))*(nstate) + (__td_c3)];
                  }
                }
              }
            }
            for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
              for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                  for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                    __cb37[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                    for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                      __cb37[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl10_row[(__es_a)*(Lb) + (__es_b)] * __td_op1[(((__es_b)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)]);
                    }
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl10_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __cb37[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            /* numpy: np.tensordot(__inl10_row, psi_frag[f, :, :, :, :], axes=([1], [1])) */
            for (int64_t __td_c0 = 0; __td_c0 < Lb; ++__td_c0) {
              for (int64_t __td_c1 = 0; __td_c1 < Lb; ++__td_c1) {
                for (int64_t __td_c2 = 0; __td_c2 < Lb; ++__td_c2) {
                  for (int64_t __td_c3 = 0; __td_c3 < nstate; ++__td_c3) {
                    __td_op2[(((__td_c0)*(Lb) + (__td_c1))*(Lb) + (__td_c2))*(nstate) + (__td_c3)] = psi_frag[((((f)*(Lb) + (__td_c0))*(Lb) + (__td_c1))*(Lb) + (__td_c2))*(nstate) + (__td_c3)];
                  }
                }
              }
            }
            for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
              for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                  for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                    __cb38[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                    for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                      __cb38[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl10_row[(__es_a)*(Lb) + (__es_b)] * __td_op2[(((__es_c)*(Lb) + (__es_b))*(Lb) + (__es_d))*(nstate) + (__es_e)]);
                    }
                  }
                }
              }
            }
            /* numpy: np.moveaxis(__cb38, 0, 1) */
            for (int64_t __t0 = 0; __t0 < Lb; ++__t0) {
              for (int64_t __t1 = 0; __t1 < Lb; ++__t1) {
                for (int64_t __t2 = 0; __t2 < Lb; ++__t2) {
                  for (int64_t __t3 = 0; __t3 < nstate; ++__t3) {
                    __cb39[(((__t1)*(Lb) + (__t0))*(Lb) + (__t2))*(nstate) + (__t3)] = __cb38[(((__t0)*(Lb) + (__t1))*(Lb) + (__t2))*(nstate) + (__t3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl10_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] += __cb39[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            /* numpy: np.tensordot(__inl10_row, psi_frag[f, :, :, :, :], axes=([1], [2])) */
            for (int64_t __td_c0 = 0; __td_c0 < Lb; ++__td_c0) {
              for (int64_t __td_c1 = 0; __td_c1 < Lb; ++__td_c1) {
                for (int64_t __td_c2 = 0; __td_c2 < Lb; ++__td_c2) {
                  for (int64_t __td_c3 = 0; __td_c3 < nstate; ++__td_c3) {
                    __td_op3[(((__td_c0)*(Lb) + (__td_c1))*(Lb) + (__td_c2))*(nstate) + (__td_c3)] = psi_frag[((((f)*(Lb) + (__td_c0))*(Lb) + (__td_c1))*(Lb) + (__td_c2))*(nstate) + (__td_c3)];
                  }
                }
              }
            }
            for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
              for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                  for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                    __cb40[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                    for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                      __cb40[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl10_row[(__es_a)*(Lb) + (__es_b)] * __td_op3[(((__es_c)*(Lb) + (__es_d))*(Lb) + (__es_b))*(nstate) + (__es_e)]);
                    }
                  }
                }
              }
            }
            /* numpy: np.moveaxis(__cb40, 0, 2) */
            for (int64_t __t0 = 0; __t0 < Lb; ++__t0) {
              for (int64_t __t1 = 0; __t1 < Lb; ++__t1) {
                for (int64_t __t2 = 0; __t2 < Lb; ++__t2) {
                  for (int64_t __t3 = 0; __t3 < nstate; ++__t3) {
                    __cb41[(((__t1)*(Lb) + (__t2))*(Lb) + (__t0))*(nstate) + (__t3)] = __cb40[(((__t0)*(Lb) + (__t1))*(Lb) + (__t2))*(nstate) + (__t3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl10_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] += __cb41[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl10_hx1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = (((-half_inv_h2) * __inl10_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]) + (vloc[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] * psi_frag[((((f)*(Lb) + (__w0))*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]));
                  }
                }
              }
            }
            for (int64_t si0 = 0; si0 < Lb; ++si0) {
              for (int64_t si1 = 0; si1 < Lb; ++si1) {
                for (int64_t si2 = 0; si2 < Lb; ++si2) {
                  for (int64_t si3 = 0; si3 < nstate; ++si3) {
                    __cb42[(((si0)*(Lb) + (si1))*(Lb) + (si2))*(nstate) + (si3)] = psi_frag[((((f)*(Lb) + (si0))*(Lb) + (si1))*(Lb) + (si2))*(nstate) + (si3)];
                  }
                }
              }
            }
            /* numpy: np.reshape(__cb42, (-1, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb43[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)] = __cb42[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl10_flat[(__w0)*(nstate) + (__w1)] = __cb43[(__w0)*(nstate) + (__w1)];
              }
            }
            /* numpy: np.transpose(pf) */
            for (int64_t __t0 = 0; __t0 < ((Lb * Lb) * Lb); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nproj; ++__t1) {
                __cb44[(__t1)*(((Lb * Lb) * Lb)) + (__t0)] = pf[(__t0)*(nproj) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nproj), (blasint)(nstate), (blasint)(((Lb * Lb) * Lb)), 1.0, __cb44, (blasint)(((Lb * Lb) * Lb)), __inl10_flat, (blasint)(nstate), 0.0, __mm45, (blasint)(nstate));
            for (int64_t __w0 = 0; __w0 < nproj; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl10_overlap[(__w0)*(nstate) + (__w1)] = __mm45[(__w0)*(nstate) + (__w1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nproj), (blasint)(nstate), (blasint)(nproj), 1.0, df, (blasint)(nproj), __inl10_overlap, (blasint)(nstate), 0.0, __mm46, (blasint)(nstate));
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(((Lb * Lb) * Lb)), (blasint)(nstate), (blasint)(nproj), 1.0, pf, (blasint)(nproj), __mm46, (blasint)(nstate), 0.0, __mm47, (blasint)(nstate));
            /* numpy: np.reshape(__mm47, (Lb, Lb, Lb, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb48[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)] = __mm47[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl10_hx2[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = (__inl10_hx1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] + __cb48[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]);
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __hcall4[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __inl10_hx2[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            /* numpy: np.reshape(__hcall4, (-1, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb49[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)] = __hcall4[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3_Wf[(__w0)*(nstate) + (__w1)] = __cb49[(__w0)*(nstate) + (__w1)];
              }
            }
            /* numpy: np.transpose(__inl3_Yf) */
            for (int64_t __t0 = 0; __t0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb50[(__t1)*(((((Lb * Lb) * Lb) * nstate) / nstate)) + (__t0)] = __inl3_Yf[(__t0)*(nstate) + (__t1)];
              }
            }
            /* numpy: np.transpose(__inl3_Yf) */
            for (int64_t __t0 = 0; __t0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb51[(__t1)*(((((Lb * Lb) * Lb) * nstate) / nstate)) + (__t0)] = __inl3_Yf[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), 1.0, __cb51, (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), __inl3_Wf, (blasint)(nstate), 0.0, __mm52, (blasint)(nstate));
            /* numpy: np.transpose(__mm52) */
            for (int64_t __t0 = 0; __t0 < nstate; ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb53[(__t1)*(nstate) + (__t0)] = __mm52[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), 1.0, __cb50, (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), __inl3_Wf, (blasint)(nstate), 0.0, __mm54, (blasint)(nstate));
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3_h_sub[(__w0)*(nstate) + (__w1)] = (0.5 * (__mm54[(__w0)*(nstate) + (__w1)] + __cb53[(__w0)*(nstate) + (__w1)]));
              }
            }
            memset(__eye1, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
            for (int64_t __diag0 = 0; __diag0 < nstate; ++__diag0) {
              __eye1[(__diag0)*(nstate) + (__diag0)] = 1.0;
            }
            /* numpy: np.transpose(__inl3_Yf) */
            for (int64_t __t0 = 0; __t0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb55[(__t1)*(((((Lb * Lb) * Lb) * nstate) / nstate)) + (__t0)] = __inl3_Yf[(__t0)*(nstate) + (__t1)];
              }
            }
            /* numpy: np.transpose(__inl3_Yf) */
            for (int64_t __t0 = 0; __t0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb56[(__t1)*(((((Lb * Lb) * Lb) * nstate) / nstate)) + (__t0)] = __inl3_Yf[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), 1.0, __cb56, (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), __inl3_Yf, (blasint)(nstate), 0.0, __mm57, (blasint)(nstate));
            /* numpy: np.transpose(__mm57) */
            for (int64_t __t0 = 0; __t0 < nstate; ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb58[(__t1)*(nstate) + (__t0)] = __mm57[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), 1.0, __cb55, (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), __inl3_Yf, (blasint)(nstate), 0.0, __mm59, (blasint)(nstate));
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3_s_sub[(__w0)*(nstate) + (__w1)] = ((0.5 * (__mm59[(__w0)*(nstate) + (__w1)] + __cb58[(__w0)*(nstate) + (__w1)])) + (1e-12 * __eye1[(__w0)*(nstate) + (__w1)]));
              }
            }
            /* numpy: np.linalg.cholesky(__inl3_s_sub) */
            for (int64_t __zi = 0; __zi < nstate; ++__zi) {
              for (int64_t __zj = (__zi + 1); __zj < nstate; ++__zj) {
                __cb60[(__zi)*(nstate) + (__zj)] = 0.0;
              }
            }
            for (int64_t __j = 0; __j < nstate; ++__j) {
              __s = __inl3_s_sub[(__j)*(nstate) + (__j)];
              for (int64_t __k = 0; __k < __j; ++__k) {
                __s -= (__cb60[(__j)*(nstate) + (__k)] * __cb60[(__j)*(nstate) + (__k)]);
              }
              __cb60[(__j)*(nstate) + (__j)] = sqrt(__s);
              for (int64_t __i = (__j + 1); __i < nstate; ++__i) {
                __s = __inl3_s_sub[(__i)*(nstate) + (__j)];
                for (int64_t __k = 0; __k < __j; ++__k) {
                  __s -= (__cb60[(__i)*(nstate) + (__k)] * __cb60[(__j)*(nstate) + (__k)]);
                }
                __cb60[(__i)*(nstate) + (__j)] = (__s / __cb60[(__j)*(nstate) + (__j)]);
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3_L[(__w0)*(nstate) + (__w1)] = __cb60[(__w0)*(nstate) + (__w1)];
              }
            }
            /* numpy: np.linalg.inv(__inl3_L) */
            for (int64_t __inv_i = 0; __inv_i < nstate; ++__inv_i) {
              for (int64_t __inv_j = 0; __inv_j < nstate; ++__inv_j) {
                __inv_aw0[(__inv_i)*(nstate) + (__inv_j)] = __inl3_L[(__inv_i)*(nstate) + (__inv_j)];
                __cb61[(__inv_i)*(nstate) + (__inv_j)] = ((__inv_i == __inv_j) ? 1.0 : 0.0);
              }
            }
            for (int64_t __inv_k = 0; __inv_k < nstate; ++__inv_k) {
              __inv_p = __inv_k;
              for (int64_t __inv_r = (__inv_k + 1); __inv_r < nstate; ++__inv_r) {
                if ((fabs(__inv_aw0[(__inv_r)*(nstate) + (__inv_k)]) > fabs(__inv_aw0[(__inv_p)*(nstate) + (__inv_k)]))) {
                  __inv_p = __inv_r;
                }
              }
              for (int64_t __inv_c = 0; __inv_c < nstate; ++__inv_c) {
                __inv_tmp = __inv_aw0[(__inv_k)*(nstate) + (__inv_c)];
                __inv_aw0[(__inv_k)*(nstate) + (__inv_c)] = __inv_aw0[(__inv_p)*(nstate) + (__inv_c)];
                __inv_aw0[(__inv_p)*(nstate) + (__inv_c)] = __inv_tmp;
                __inv_tmp = __cb61[(__inv_k)*(nstate) + (__inv_c)];
                __cb61[(__inv_k)*(nstate) + (__inv_c)] = __cb61[(__inv_p)*(nstate) + (__inv_c)];
                __cb61[(__inv_p)*(nstate) + (__inv_c)] = __inv_tmp;
              }
              __inv_factor = __inv_aw0[(__inv_k)*(nstate) + (__inv_k)];
              for (int64_t __inv_c = 0; __inv_c < nstate; ++__inv_c) {
                __cb61[(__inv_k)*(nstate) + (__inv_c)] = (__cb61[(__inv_k)*(nstate) + (__inv_c)] / __inv_factor);
                __inv_aw0[(__inv_k)*(nstate) + (__inv_c)] = (__inv_aw0[(__inv_k)*(nstate) + (__inv_c)] / __inv_factor);
              }
              for (int64_t __inv_r = 0; __inv_r < nstate; ++__inv_r) {
                if ((__inv_r != __inv_k)) {
                  __inv_factor = __inv_aw0[(__inv_r)*(nstate) + (__inv_k)];
                  for (int64_t __inv_c = 0; __inv_c < nstate; ++__inv_c) {
                    __cb61[(__inv_r)*(nstate) + (__inv_c)] = (__cb61[(__inv_r)*(nstate) + (__inv_c)] - (__inv_factor * __cb61[(__inv_k)*(nstate) + (__inv_c)]));
                    __inv_aw0[(__inv_r)*(nstate) + (__inv_c)] = (__inv_aw0[(__inv_r)*(nstate) + (__inv_c)] - (__inv_factor * __inv_aw0[(__inv_k)*(nstate) + (__inv_c)]));
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3_Linv[(__w0)*(nstate) + (__w1)] = __cb61[(__w0)*(nstate) + (__w1)];
              }
            }
            /* numpy: np.transpose(__inl3_Linv) */
            for (int64_t __t0 = 0; __t0 < nstate; ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb62[(__t1)*(nstate) + (__t0)] = __inl3_Linv[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(nstate), 1.0, __inl3_Linv, (blasint)(nstate), __inl3_h_sub, (blasint)(nstate), 0.0, __mm63, (blasint)(nstate));
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(nstate), 1.0, __mm63, (blasint)(nstate), __cb62, (blasint)(nstate), 0.0, __mm64, (blasint)(nstate));
            /* numpy: np.ascontiguousarray(__mm64) */
            for (int64_t __r0 = 0; __r0 < nstate; ++__r0) {
              for (int64_t __r1 = 0; __r1 < nstate; ++__r1) {
                __cb65[(__r0)*(nstate) + (__r1)] = __mm64[(__r0)*(nstate) + (__r1)];
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3___eigh1_a[(__w0)*(nstate) + (__w1)] = __cb65[(__w0)*(nstate) + (__w1)];
              }
            }
            memset(__inl3___eigh1_Cm, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
            for (int64_t __inl3___eigh1_ci = 0; __inl3___eigh1_ci < nstate; ++__inl3___eigh1_ci) {
              for (int64_t __inl3___eigh1_cj = 0; __inl3___eigh1_cj < nstate; ++__inl3___eigh1_cj) {
                __inl3___eigh1_Cm[(__inl3___eigh1_ci)*(nstate) + (__inl3___eigh1_cj)] = __inl3___eigh1_a[(__inl3___eigh1_ci)*(nstate) + (__inl3___eigh1_cj)];
              }
            }
            memset(__inl3___eigh1_jv, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
            for (int64_t __inl3___eigh1_di = 0; __inl3___eigh1_di < nstate; ++__inl3___eigh1_di) {
              __inl3___eigh1_jv[(__inl3___eigh1_di)*(nstate) + (__inl3___eigh1_di)] = 1;
            }
            for (int64_t __inl3___eigh1_sw = 0; __inl3___eigh1_sw < 80; ++__inl3___eigh1_sw) {
              __inl3___eigh1_off = 0.0;
              for (int64_t __inl3___eigh1_pp = 0; __inl3___eigh1_pp < nstate; ++__inl3___eigh1_pp) {
                for (int64_t __inl3___eigh1_qq = (__inl3___eigh1_pp + 1); __inl3___eigh1_qq < nstate; ++__inl3___eigh1_qq) {
                  __inl3___eigh1_off += ((__inl3___eigh1_Cm[(__inl3___eigh1_pp)*(nstate) + (__inl3___eigh1_qq)] * __inl3___eigh1_Cm[(__inl3___eigh1_pp)*(nstate) + (__inl3___eigh1_qq)]) + (0.0 * 0.0));
                }
              }
              if ((__inl3___eigh1_off <= 1e-30)) {
                break;
              }
              for (int64_t __inl3___eigh1_pp = 0; __inl3___eigh1_pp < nstate; ++__inl3___eigh1_pp) {
                for (int64_t __inl3___eigh1_qq = (__inl3___eigh1_pp + 1); __inl3___eigh1_qq < nstate; ++__inl3___eigh1_qq) {
                  __inl3___eigh1_apq = __inl3___eigh1_Cm[(__inl3___eigh1_pp)*(nstate) + (__inl3___eigh1_qq)];
                  if ((hypot(__inl3___eigh1_apq, 0.0) == 0.0)) {
                    continue;
                  }
                  __inl3___eigh1_app = __inl3___eigh1_Cm[(__inl3___eigh1_pp)*(nstate) + (__inl3___eigh1_pp)];
                  __inl3___eigh1_aqq = __inl3___eigh1_Cm[(__inl3___eigh1_qq)*(nstate) + (__inl3___eigh1_qq)];
                  __inl3___eigh1_s = ((((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0)))) * (1.0 / sqrt((((((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))));
                  for (int64_t __inl3___eigh1_k = 0; __inl3___eigh1_k < nstate; ++__inl3___eigh1_k) {
                    __inl3___eigh1_akp = __inl3___eigh1_Cm[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_pp)];
                    __inl3___eigh1_akq = __inl3___eigh1_Cm[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_qq)];
                    __inl3___eigh1_Cm[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_pp)] = (((1.0 / sqrt((((((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl3___eigh1_akp) - ((__inl3___eigh1_s * (__inl3___eigh1_apq / hypot(__inl3___eigh1_apq, 0.0))) * __inl3___eigh1_akq));
                    __inl3___eigh1_Cm[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_qq)] = (((__inl3___eigh1_s * (__inl3___eigh1_apq / hypot(__inl3___eigh1_apq, 0.0))) * __inl3___eigh1_akp) + ((1.0 / sqrt((((((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl3___eigh1_akq));
                  }
                  for (int64_t __inl3___eigh1_k = 0; __inl3___eigh1_k < nstate; ++__inl3___eigh1_k) {
                    __inl3___eigh1_apk = __inl3___eigh1_Cm[(__inl3___eigh1_pp)*(nstate) + (__inl3___eigh1_k)];
                    __inl3___eigh1_aqk = __inl3___eigh1_Cm[(__inl3___eigh1_qq)*(nstate) + (__inl3___eigh1_k)];
                    __inl3___eigh1_Cm[(__inl3___eigh1_pp)*(nstate) + (__inl3___eigh1_k)] = (((1.0 / sqrt((((((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl3___eigh1_apk) - ((__inl3___eigh1_s * (__inl3___eigh1_apq / hypot(__inl3___eigh1_apq, 0.0))) * __inl3___eigh1_aqk));
                    __inl3___eigh1_Cm[(__inl3___eigh1_qq)*(nstate) + (__inl3___eigh1_k)] = (((__inl3___eigh1_s * (__inl3___eigh1_apq / hypot(__inl3___eigh1_apq, 0.0))) * __inl3___eigh1_apk) + ((1.0 / sqrt((((((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl3___eigh1_aqk));
                  }
                  for (int64_t __inl3___eigh1_k = 0; __inl3___eigh1_k < nstate; ++__inl3___eigh1_k) {
                    __inl3___eigh1_vkp = __inl3___eigh1_jv[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_pp)];
                    __inl3___eigh1_vkq = __inl3___eigh1_jv[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_qq)];
                    __inl3___eigh1_jv[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_pp)] = (((1.0 / sqrt((((((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl3___eigh1_vkp) - ((__inl3___eigh1_s * (__inl3___eigh1_apq / hypot(__inl3___eigh1_apq, 0.0))) * __inl3___eigh1_vkq));
                    __inl3___eigh1_jv[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_qq)] = (((__inl3___eigh1_s * (__inl3___eigh1_apq / hypot(__inl3___eigh1_apq, 0.0))) * __inl3___eigh1_vkp) + ((1.0 / sqrt((((((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + sqrt(((((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0))) * ((__inl3___eigh1_aqq - __inl3___eigh1_app) / (2.0 * hypot(__inl3___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl3___eigh1_vkq));
                  }
                }
              }
            }
            memset(__inl3___eigh1_wa, 0, (size_t)((nstate)) * sizeof(double));
            for (int64_t __inl3___eigh1_i = 0; __inl3___eigh1_i < nstate; ++__inl3___eigh1_i) {
              __inl3___eigh1_wa[__inl3___eigh1_i] = __inl3___eigh1_Cm[(__inl3___eigh1_i)*(nstate) + (__inl3___eigh1_i)];
            }
            for (int64_t __inl3___eigh1_i = 0; __inl3___eigh1_i < nstate; ++__inl3___eigh1_i) {
              __inl3___eigh1_mn = __inl3___eigh1_i;
              for (int64_t __inl3___eigh1_j = (__inl3___eigh1_i + 1); __inl3___eigh1_j < nstate; ++__inl3___eigh1_j) {
                if ((__inl3___eigh1_wa[__inl3___eigh1_j] < __inl3___eigh1_wa[__inl3___eigh1_mn])) {
                  __inl3___eigh1_mn = __inl3___eigh1_j;
                }
              }
              if ((__inl3___eigh1_mn != __inl3___eigh1_i)) {
                __inl3___eigh1_tw = __inl3___eigh1_wa[__inl3___eigh1_i];
                __inl3___eigh1_wa[__inl3___eigh1_i] = __inl3___eigh1_wa[__inl3___eigh1_mn];
                __inl3___eigh1_wa[__inl3___eigh1_mn] = __inl3___eigh1_tw;
                for (int64_t __inl3___eigh1_k = 0; __inl3___eigh1_k < nstate; ++__inl3___eigh1_k) {
                  __inl3___eigh1_tv = __inl3___eigh1_jv[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_i)];
                  __inl3___eigh1_jv[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_i)] = __inl3___eigh1_jv[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_mn)];
                  __inl3___eigh1_jv[(__inl3___eigh1_k)*(nstate) + (__inl3___eigh1_mn)] = __inl3___eigh1_tv;
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3___eigh1_ya[(__w0)*(nstate) + (__w1)] = __inl3___eigh1_jv[(__w0)*(nstate) + (__w1)];
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              __inl3_w[__w0] = __inl3___eigh1_wa[__w0];
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3_U[(__w0)*(nstate) + (__w1)] = __inl3___eigh1_ya[(__w0)*(nstate) + (__w1)];
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __ixa1[(__w0)*(nstate) + (__w1)] = fabs(__inl3_U[(__w0)*(nstate) + (__w1)]);
              }
            }
            /* numpy: np.argmax(__ixa1, axis=0) */
            for (int64_t __aax0 = 0; __aax0 < nstate; ++__aax0) {
              __ar_val___cb66 = __ixa1[(0)*(nstate) + (__aax0)];
              __cb66[__aax0] = 0;
              for (int64_t __ard0 = 0; __ard0 < nstate; ++__ard0) {
                if (((__ar_val___cb66 == __ar_val___cb66) && ((__ixa1[(__ard0)*(nstate) + (__aax0)] != __ixa1[(__ard0)*(nstate) + (__aax0)]) || (__ixa1[(__ard0)*(nstate) + (__aax0)] > __ar_val___cb66)))) {
                  __ar_val___cb66 = __ixa1[(__ard0)*(nstate) + (__aax0)];
                  __cb66[__aax0] = __ard0;
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              __ix2[__w0] = __cb66[__w0];
            }
            /* numpy: np.arange(nstate) */
            for (int64_t __i = 0; __i < nstate; ++__i) {
              __cb67[__i] = __i;
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              __ix3[__w0] = __cb67[__w0];
            }
            /* numpy: np.sign(__inl3_U[__ix2, __ix3]) */
            for (int64_t __r0 = 0; __r0 < nstate; ++__r0) {
              __cb68[__r0] = __npb_sign(__inl3_U[(__ix2[__r0])*(nstate) + (__ix3[__r0])]);
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3_U[(__w0)*(nstate) + (__w1)] = (__inl3_U[(__w0)*(nstate) + (__w1)] * __cb68[__w1]);
              }
            }
            /* numpy: np.transpose(__inl3_Linv) */
            for (int64_t __t0 = 0; __t0 < nstate; ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb69[(__t1)*(nstate) + (__t0)] = __inl3_Linv[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(nstate), 1.0, __cb69, (blasint)(nstate), __inl3_U, (blasint)(nstate), 0.0, __mm70, (blasint)(nstate));
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl3_C[(__w0)*(nstate) + (__w1)] = __mm70[(__w0)*(nstate) + (__w1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), (blasint)(nstate), (blasint)(nstate), 1.0, __inl3_Yf, (blasint)(nstate), __inl3_C, (blasint)(nstate), 0.0, __mm71, (blasint)(nstate));
            /* numpy: np.reshape(__mm71, (Lb, Lb, Lb, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb72[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)] = __mm71[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    X[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __cb72[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              w[__w0] = __inl3_w[__w0];
            }
            b_hi = max(b_frag[f], ((w[(nstate - 1)] * 1.1) + 1.0));
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl4_X[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = X[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            __inl4_e = (0.5 * (b_hi - w[(nstate - 1)]));
            __inl4_c = (0.5 * (b_hi + w[(nstate - 1)]));
            __inl4_sigma = (__inl4_e / (w[0] - __inl4_c));
            __inl4_sigma1 = __inl4_sigma;
            memset(__inl19_row, 0, (size_t)((Lb) * (Lb)) * sizeof(double));
            /* numpy: np.arange(Lb) */
            for (int64_t __i = 0; __i < Lb; ++__i) {
              __cb73[__i] = __i;
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              __inl19_idx[__w0] = __cb73[__w0];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl19_row[(__inl19_idx[__sc0])*(Lb) + (__inl19_idx[__sc0])] = -2.8472222222222223;
            }
            __inl19_m = (1 + 0);
            __inl19_w = 1.6;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg16[__sc0] = __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] - __inl19_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] - __inl19_m), Lb))] = (__scg16[__sc0] + __inl19_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg17[__sc0] = __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] + __inl19_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] + __inl19_m), Lb))] = (__scg17[__sc0] + __inl19_w);
            }
            __inl19_m = (1 + 1);
            __inl19_w = -0.2;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg18[__sc0] = __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] - __inl19_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] - __inl19_m), Lb))] = (__scg18[__sc0] + __inl19_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg19[__sc0] = __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] + __inl19_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] + __inl19_m), Lb))] = (__scg19[__sc0] + __inl19_w);
            }
            __inl19_m = (1 + 2);
            __inl19_w = 0.025396825396825397;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg20[__sc0] = __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] - __inl19_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] - __inl19_m), Lb))] = (__scg20[__sc0] + __inl19_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg21[__sc0] = __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] + __inl19_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] + __inl19_m), Lb))] = (__scg21[__sc0] + __inl19_w);
            }
            __inl19_m = (1 + 3);
            __inl19_w = -0.0017857142857142857;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg22[__sc0] = __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] - __inl19_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] - __inl19_m), Lb))] = (__scg22[__sc0] + __inl19_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg23[__sc0] = __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] + __inl19_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl19_row[(__inl19_idx[__sc0])*(Lb) + (python_mod((__inl19_idx[__sc0] + __inl19_m), Lb))] = (__scg23[__sc0] + __inl19_w);
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                __inl11_row[(__w0)*(Lb) + (__w1)] = __inl19_row[(__w0)*(Lb) + (__w1)];
              }
            }
            /* numpy: np.tensordot(__inl11_row, __inl4_X, axes=([1], [0])) */
            for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
              for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                  for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                    __cb74[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                    for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                      __cb74[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl11_row[(__es_a)*(Lb) + (__es_b)] * __inl4_X[(((__es_b)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)]);
                    }
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl11_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __cb74[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            /* numpy: np.tensordot(__inl11_row, __inl4_X, axes=([1], [1])) */
            for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
              for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                  for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                    __cb75[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                    for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                      __cb75[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl11_row[(__es_a)*(Lb) + (__es_b)] * __inl4_X[(((__es_c)*(Lb) + (__es_b))*(Lb) + (__es_d))*(nstate) + (__es_e)]);
                    }
                  }
                }
              }
            }
            /* numpy: np.moveaxis(__cb75, 0, 1) */
            for (int64_t __t0 = 0; __t0 < Lb; ++__t0) {
              for (int64_t __t1 = 0; __t1 < Lb; ++__t1) {
                for (int64_t __t2 = 0; __t2 < Lb; ++__t2) {
                  for (int64_t __t3 = 0; __t3 < nstate; ++__t3) {
                    __cb76[(((__t1)*(Lb) + (__t0))*(Lb) + (__t2))*(nstate) + (__t3)] = __cb75[(((__t0)*(Lb) + (__t1))*(Lb) + (__t2))*(nstate) + (__t3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl11_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] += __cb76[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            /* numpy: np.tensordot(__inl11_row, __inl4_X, axes=([1], [2])) */
            for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
              for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                  for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                    __cb77[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                    for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                      __cb77[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl11_row[(__es_a)*(Lb) + (__es_b)] * __inl4_X[(((__es_c)*(Lb) + (__es_d))*(Lb) + (__es_b))*(nstate) + (__es_e)]);
                    }
                  }
                }
              }
            }
            /* numpy: np.moveaxis(__cb77, 0, 2) */
            for (int64_t __t0 = 0; __t0 < Lb; ++__t0) {
              for (int64_t __t1 = 0; __t1 < Lb; ++__t1) {
                for (int64_t __t2 = 0; __t2 < Lb; ++__t2) {
                  for (int64_t __t3 = 0; __t3 < nstate; ++__t3) {
                    __cb78[(((__t1)*(Lb) + (__t2))*(Lb) + (__t0))*(nstate) + (__t3)] = __cb77[(((__t0)*(Lb) + (__t1))*(Lb) + (__t2))*(nstate) + (__t3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl11_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] += __cb78[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl11_hx1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = (((-half_inv_h2) * __inl11_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]) + (vloc[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] * __inl4_X[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]));
                  }
                }
              }
            }
            /* numpy: np.reshape(__inl4_X, (-1, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb79[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)] = __inl4_X[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl11_flat[(__w0)*(nstate) + (__w1)] = __cb79[(__w0)*(nstate) + (__w1)];
              }
            }
            /* numpy: np.transpose(pf) */
            for (int64_t __t0 = 0; __t0 < ((Lb * Lb) * Lb); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nproj; ++__t1) {
                __cb80[(__t1)*(((Lb * Lb) * Lb)) + (__t0)] = pf[(__t0)*(nproj) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nproj), (blasint)(nstate), (blasint)(((Lb * Lb) * Lb)), 1.0, __cb80, (blasint)(((Lb * Lb) * Lb)), __inl11_flat, (blasint)(nstate), 0.0, __mm81, (blasint)(nstate));
            for (int64_t __w0 = 0; __w0 < nproj; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl11_overlap[(__w0)*(nstate) + (__w1)] = __mm81[(__w0)*(nstate) + (__w1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nproj), (blasint)(nstate), (blasint)(nproj), 1.0, df, (blasint)(nproj), __inl11_overlap, (blasint)(nstate), 0.0, __mm82, (blasint)(nstate));
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(((Lb * Lb) * Lb)), (blasint)(nstate), (blasint)(nproj), 1.0, pf, (blasint)(nproj), __mm82, (blasint)(nstate), 0.0, __mm83, (blasint)(nstate));
            /* numpy: np.reshape(__mm83, (Lb, Lb, Lb, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb84[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)] = __mm83[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl11_hx2[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = (__inl11_hx1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] + __cb84[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]);
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __hcall5[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __inl11_hx2[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl4_Y[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = ((__hcall5[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] - (__inl4_c * __inl4_X[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)])) * (__inl4_sigma1 / __inl4_e));
                  }
                }
              }
            }
            for (int64_t __inl4__ = 2; __inl4__ < (((int64_t)(m)) + 1); ++__inl4__) {
              __inl4_sigma_new = (1.0 / ((2.0 / __inl4_sigma1) - __inl4_sigma));
              memset(__inl20_row, 0, (size_t)((Lb) * (Lb)) * sizeof(double));
              /* numpy: np.arange(Lb) */
              for (int64_t __i = 0; __i < Lb; ++__i) {
                __cb85[__i] = __i;
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                __inl20_idx[__w0] = __cb85[__w0];
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __inl20_row[(__inl20_idx[__sc0])*(Lb) + (__inl20_idx[__sc0])] = -2.8472222222222223;
              }
              __inl20_m = (1 + 0);
              __inl20_w = 1.6;
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __scg24[__sc0] = __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] - __inl20_m), Lb))];
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] - __inl20_m), Lb))] = (__scg24[__sc0] + __inl20_w);
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __scg25[__sc0] = __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] + __inl20_m), Lb))];
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] + __inl20_m), Lb))] = (__scg25[__sc0] + __inl20_w);
              }
              __inl20_m = (1 + 1);
              __inl20_w = -0.2;
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __scg26[__sc0] = __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] - __inl20_m), Lb))];
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] - __inl20_m), Lb))] = (__scg26[__sc0] + __inl20_w);
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __scg27[__sc0] = __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] + __inl20_m), Lb))];
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] + __inl20_m), Lb))] = (__scg27[__sc0] + __inl20_w);
              }
              __inl20_m = (1 + 2);
              __inl20_w = 0.025396825396825397;
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __scg28[__sc0] = __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] - __inl20_m), Lb))];
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] - __inl20_m), Lb))] = (__scg28[__sc0] + __inl20_w);
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __scg29[__sc0] = __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] + __inl20_m), Lb))];
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] + __inl20_m), Lb))] = (__scg29[__sc0] + __inl20_w);
              }
              __inl20_m = (1 + 3);
              __inl20_w = -0.0017857142857142857;
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __scg30[__sc0] = __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] - __inl20_m), Lb))];
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] - __inl20_m), Lb))] = (__scg30[__sc0] + __inl20_w);
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __scg31[__sc0] = __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] + __inl20_m), Lb))];
              }
              for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
                __inl20_row[(__inl20_idx[__sc0])*(Lb) + (python_mod((__inl20_idx[__sc0] + __inl20_m), Lb))] = (__scg31[__sc0] + __inl20_w);
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  __inl12_row[(__w0)*(Lb) + (__w1)] = __inl20_row[(__w0)*(Lb) + (__w1)];
                }
              }
              /* numpy: np.tensordot(__inl12_row, __inl4_Y, axes=([1], [0])) */
              for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
                for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                  for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                    for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                      __cb86[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                      for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                        __cb86[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl12_row[(__es_a)*(Lb) + (__es_b)] * __inl4_Y[(((__es_b)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)]);
                      }
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __inl12_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __cb86[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                    }
                  }
                }
              }
              /* numpy: np.tensordot(__inl12_row, __inl4_Y, axes=([1], [1])) */
              for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
                for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                  for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                    for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                      __cb87[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                      for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                        __cb87[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl12_row[(__es_a)*(Lb) + (__es_b)] * __inl4_Y[(((__es_c)*(Lb) + (__es_b))*(Lb) + (__es_d))*(nstate) + (__es_e)]);
                      }
                    }
                  }
                }
              }
              /* numpy: np.moveaxis(__cb87, 0, 1) */
              for (int64_t __t0 = 0; __t0 < Lb; ++__t0) {
                for (int64_t __t1 = 0; __t1 < Lb; ++__t1) {
                  for (int64_t __t2 = 0; __t2 < Lb; ++__t2) {
                    for (int64_t __t3 = 0; __t3 < nstate; ++__t3) {
                      __cb88[(((__t1)*(Lb) + (__t0))*(Lb) + (__t2))*(nstate) + (__t3)] = __cb87[(((__t0)*(Lb) + (__t1))*(Lb) + (__t2))*(nstate) + (__t3)];
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __inl12_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] += __cb88[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                    }
                  }
                }
              }
              /* numpy: np.tensordot(__inl12_row, __inl4_Y, axes=([1], [2])) */
              for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
                for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                  for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                    for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                      __cb89[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                      for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                        __cb89[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl12_row[(__es_a)*(Lb) + (__es_b)] * __inl4_Y[(((__es_c)*(Lb) + (__es_d))*(Lb) + (__es_b))*(nstate) + (__es_e)]);
                      }
                    }
                  }
                }
              }
              /* numpy: np.moveaxis(__cb89, 0, 2) */
              for (int64_t __t0 = 0; __t0 < Lb; ++__t0) {
                for (int64_t __t1 = 0; __t1 < Lb; ++__t1) {
                  for (int64_t __t2 = 0; __t2 < Lb; ++__t2) {
                    for (int64_t __t3 = 0; __t3 < nstate; ++__t3) {
                      __cb90[(((__t1)*(Lb) + (__t2))*(Lb) + (__t0))*(nstate) + (__t3)] = __cb89[(((__t0)*(Lb) + (__t1))*(Lb) + (__t2))*(nstate) + (__t3)];
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __inl12_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] += __cb90[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __inl12_hx1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = (((-half_inv_h2) * __inl12_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]) + (vloc[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] * __inl4_Y[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]));
                    }
                  }
                }
              }
              /* numpy: np.reshape(__inl4_Y, (-1, nstate)) */
              for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
                for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                  for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                    for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                      __cb91[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)] = __inl4_Y[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)];
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__w0) {
                for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                  __inl12_flat[(__w0)*(nstate) + (__w1)] = __cb91[(__w0)*(nstate) + (__w1)];
                }
              }
              /* numpy: np.transpose(pf) */
              for (int64_t __t0 = 0; __t0 < ((Lb * Lb) * Lb); ++__t0) {
                for (int64_t __t1 = 0; __t1 < nproj; ++__t1) {
                  __cb92[(__t1)*(((Lb * Lb) * Lb)) + (__t0)] = pf[(__t0)*(nproj) + (__t1)];
                }
              }
              cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nproj), (blasint)(nstate), (blasint)(((Lb * Lb) * Lb)), 1.0, __cb92, (blasint)(((Lb * Lb) * Lb)), __inl12_flat, (blasint)(nstate), 0.0, __mm93, (blasint)(nstate));
              for (int64_t __w0 = 0; __w0 < nproj; ++__w0) {
                for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                  __inl12_overlap[(__w0)*(nstate) + (__w1)] = __mm93[(__w0)*(nstate) + (__w1)];
                }
              }
              cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nproj), (blasint)(nstate), (blasint)(nproj), 1.0, df, (blasint)(nproj), __inl12_overlap, (blasint)(nstate), 0.0, __mm94, (blasint)(nstate));
              cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(((Lb * Lb) * Lb)), (blasint)(nstate), (blasint)(nproj), 1.0, pf, (blasint)(nproj), __mm94, (blasint)(nstate), 0.0, __mm95, (blasint)(nstate));
              /* numpy: np.reshape(__mm95, (Lb, Lb, Lb, nstate)) */
              for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
                for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                  for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                    for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                      __cb96[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)] = __mm95[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)];
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __inl12_hx2[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = (__inl12_hx1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] + __cb96[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]);
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __hcall6[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __inl12_hx2[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __inl4_Ynew[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = (((__hcall6[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] - (__inl4_c * __inl4_Y[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)])) * ((2.0 * __inl4_sigma_new) / __inl4_e)) - ((__inl4_sigma * __inl4_sigma_new) * __inl4_X[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]));
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __swap2_0[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __inl4_Y[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __swap2_1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __inl4_Ynew[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                    }
                  }
                }
              }
              __swap2_2 = __inl4_sigma_new;
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __inl4_X[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __swap2_0[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                    }
                  }
                }
              }
              for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
                for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                  for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                    for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                      __inl4_Y[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __swap2_1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                    }
                  }
                }
              }
              __inl4_sigma = __swap2_2;
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    Y[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __inl4_Y[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            __inl5_k = nstate;
            /* numpy: np.reshape(Y, (-1, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb97[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)] = Y[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5_Yf[(__w0)*(nstate) + (__w1)] = __cb97[(__w0)*(nstate) + (__w1)];
              }
            }
            memset(__inl21_row, 0, (size_t)((Lb) * (Lb)) * sizeof(double));
            /* numpy: np.arange(Lb) */
            for (int64_t __i = 0; __i < Lb; ++__i) {
              __cb98[__i] = __i;
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              __inl21_idx[__w0] = __cb98[__w0];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl21_row[(__inl21_idx[__sc0])*(Lb) + (__inl21_idx[__sc0])] = -2.8472222222222223;
            }
            __inl21_m = (1 + 0);
            __inl21_w = 1.6;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg32[__sc0] = __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] - __inl21_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] - __inl21_m), Lb))] = (__scg32[__sc0] + __inl21_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg33[__sc0] = __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] + __inl21_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] + __inl21_m), Lb))] = (__scg33[__sc0] + __inl21_w);
            }
            __inl21_m = (1 + 1);
            __inl21_w = -0.2;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg34[__sc0] = __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] - __inl21_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] - __inl21_m), Lb))] = (__scg34[__sc0] + __inl21_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg35[__sc0] = __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] + __inl21_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] + __inl21_m), Lb))] = (__scg35[__sc0] + __inl21_w);
            }
            __inl21_m = (1 + 2);
            __inl21_w = 0.025396825396825397;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg36[__sc0] = __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] - __inl21_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] - __inl21_m), Lb))] = (__scg36[__sc0] + __inl21_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg37[__sc0] = __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] + __inl21_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] + __inl21_m), Lb))] = (__scg37[__sc0] + __inl21_w);
            }
            __inl21_m = (1 + 3);
            __inl21_w = -0.0017857142857142857;
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg38[__sc0] = __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] - __inl21_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] - __inl21_m), Lb))] = (__scg38[__sc0] + __inl21_w);
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __scg39[__sc0] = __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] + __inl21_m), Lb))];
            }
            for (int64_t __sc0 = 0; __sc0 < Lb; ++__sc0) {
              __inl21_row[(__inl21_idx[__sc0])*(Lb) + (python_mod((__inl21_idx[__sc0] + __inl21_m), Lb))] = (__scg39[__sc0] + __inl21_w);
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                __inl13_row[(__w0)*(Lb) + (__w1)] = __inl21_row[(__w0)*(Lb) + (__w1)];
              }
            }
            /* numpy: np.tensordot(__inl13_row, Y, axes=([1], [0])) */
            for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
              for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                  for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                    __cb99[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                    for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                      __cb99[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl13_row[(__es_a)*(Lb) + (__es_b)] * Y[(((__es_b)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)]);
                    }
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl13_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __cb99[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            /* numpy: np.tensordot(__inl13_row, Y, axes=([1], [1])) */
            for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
              for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                  for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                    __cb100[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                    for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                      __cb100[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl13_row[(__es_a)*(Lb) + (__es_b)] * Y[(((__es_c)*(Lb) + (__es_b))*(Lb) + (__es_d))*(nstate) + (__es_e)]);
                    }
                  }
                }
              }
            }
            /* numpy: np.moveaxis(__cb100, 0, 1) */
            for (int64_t __t0 = 0; __t0 < Lb; ++__t0) {
              for (int64_t __t1 = 0; __t1 < Lb; ++__t1) {
                for (int64_t __t2 = 0; __t2 < Lb; ++__t2) {
                  for (int64_t __t3 = 0; __t3 < nstate; ++__t3) {
                    __cb101[(((__t1)*(Lb) + (__t0))*(Lb) + (__t2))*(nstate) + (__t3)] = __cb100[(((__t0)*(Lb) + (__t1))*(Lb) + (__t2))*(nstate) + (__t3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl13_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] += __cb101[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            /* numpy: np.tensordot(__inl13_row, Y, axes=([1], [2])) */
            for (int64_t __es_a = 0; __es_a < Lb; ++__es_a) {
              for (int64_t __es_c = 0; __es_c < Lb; ++__es_c) {
                for (int64_t __es_d = 0; __es_d < Lb; ++__es_d) {
                  for (int64_t __es_e = 0; __es_e < nstate; ++__es_e) {
                    __cb102[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] = 0.0;
                    for (int64_t __es_b = 0; __es_b < Lb; ++__es_b) {
                      __cb102[(((__es_a)*(Lb) + (__es_c))*(Lb) + (__es_d))*(nstate) + (__es_e)] += (__inl13_row[(__es_a)*(Lb) + (__es_b)] * Y[(((__es_c)*(Lb) + (__es_d))*(Lb) + (__es_b))*(nstate) + (__es_e)]);
                    }
                  }
                }
              }
            }
            /* numpy: np.moveaxis(__cb102, 0, 2) */
            for (int64_t __t0 = 0; __t0 < Lb; ++__t0) {
              for (int64_t __t1 = 0; __t1 < Lb; ++__t1) {
                for (int64_t __t2 = 0; __t2 < Lb; ++__t2) {
                  for (int64_t __t3 = 0; __t3 < nstate; ++__t3) {
                    __cb103[(((__t1)*(Lb) + (__t2))*(Lb) + (__t0))*(nstate) + (__t3)] = __cb102[(((__t0)*(Lb) + (__t1))*(Lb) + (__t2))*(nstate) + (__t3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl13_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] += __cb103[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl13_hx1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = (((-half_inv_h2) * __inl13_acc[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]) + (vloc[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] * Y[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]));
                  }
                }
              }
            }
            /* numpy: np.reshape(Y, (-1, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb104[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)] = Y[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl13_flat[(__w0)*(nstate) + (__w1)] = __cb104[(__w0)*(nstate) + (__w1)];
              }
            }
            /* numpy: np.transpose(pf) */
            for (int64_t __t0 = 0; __t0 < ((Lb * Lb) * Lb); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nproj; ++__t1) {
                __cb105[(__t1)*(((Lb * Lb) * Lb)) + (__t0)] = pf[(__t0)*(nproj) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nproj), (blasint)(nstate), (blasint)(((Lb * Lb) * Lb)), 1.0, __cb105, (blasint)(((Lb * Lb) * Lb)), __inl13_flat, (blasint)(nstate), 0.0, __mm106, (blasint)(nstate));
            for (int64_t __w0 = 0; __w0 < nproj; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl13_overlap[(__w0)*(nstate) + (__w1)] = __mm106[(__w0)*(nstate) + (__w1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nproj), (blasint)(nstate), (blasint)(nproj), 1.0, df, (blasint)(nproj), __inl13_overlap, (blasint)(nstate), 0.0, __mm107, (blasint)(nstate));
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(((Lb * Lb) * Lb)), (blasint)(nstate), (blasint)(nproj), 1.0, pf, (blasint)(nproj), __mm107, (blasint)(nstate), 0.0, __mm108, (blasint)(nstate));
            /* numpy: np.reshape(__mm108, (Lb, Lb, Lb, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb109[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)] = __mm108[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __inl13_hx2[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = (__inl13_hx1[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] + __cb109[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)]);
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    __hcall7[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __inl13_hx2[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            /* numpy: np.reshape(__hcall7, (-1, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb110[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)] = __hcall7[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5_Wf[(__w0)*(nstate) + (__w1)] = __cb110[(__w0)*(nstate) + (__w1)];
              }
            }
            /* numpy: np.transpose(__inl5_Yf) */
            for (int64_t __t0 = 0; __t0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb111[(__t1)*(((((Lb * Lb) * Lb) * nstate) / nstate)) + (__t0)] = __inl5_Yf[(__t0)*(nstate) + (__t1)];
              }
            }
            /* numpy: np.transpose(__inl5_Yf) */
            for (int64_t __t0 = 0; __t0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb112[(__t1)*(((((Lb * Lb) * Lb) * nstate) / nstate)) + (__t0)] = __inl5_Yf[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), 1.0, __cb112, (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), __inl5_Wf, (blasint)(nstate), 0.0, __mm113, (blasint)(nstate));
            /* numpy: np.transpose(__mm113) */
            for (int64_t __t0 = 0; __t0 < nstate; ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb114[(__t1)*(nstate) + (__t0)] = __mm113[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), 1.0, __cb111, (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), __inl5_Wf, (blasint)(nstate), 0.0, __mm115, (blasint)(nstate));
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5_h_sub[(__w0)*(nstate) + (__w1)] = (0.5 * (__mm115[(__w0)*(nstate) + (__w1)] + __cb114[(__w0)*(nstate) + (__w1)]));
              }
            }
            memset(__eye2, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
            for (int64_t __diag1 = 0; __diag1 < nstate; ++__diag1) {
              __eye2[(__diag1)*(nstate) + (__diag1)] = 1.0;
            }
            /* numpy: np.transpose(__inl5_Yf) */
            for (int64_t __t0 = 0; __t0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb116[(__t1)*(((((Lb * Lb) * Lb) * nstate) / nstate)) + (__t0)] = __inl5_Yf[(__t0)*(nstate) + (__t1)];
              }
            }
            /* numpy: np.transpose(__inl5_Yf) */
            for (int64_t __t0 = 0; __t0 < ((((Lb * Lb) * Lb) * nstate) / nstate); ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb117[(__t1)*(((((Lb * Lb) * Lb) * nstate) / nstate)) + (__t0)] = __inl5_Yf[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), 1.0, __cb117, (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), __inl5_Yf, (blasint)(nstate), 0.0, __mm118, (blasint)(nstate));
            /* numpy: np.transpose(__mm118) */
            for (int64_t __t0 = 0; __t0 < nstate; ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb119[(__t1)*(nstate) + (__t0)] = __mm118[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), 1.0, __cb116, (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), __inl5_Yf, (blasint)(nstate), 0.0, __mm120, (blasint)(nstate));
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5_s_sub[(__w0)*(nstate) + (__w1)] = ((0.5 * (__mm120[(__w0)*(nstate) + (__w1)] + __cb119[(__w0)*(nstate) + (__w1)])) + (1e-12 * __eye2[(__w0)*(nstate) + (__w1)]));
              }
            }
            /* numpy: np.linalg.cholesky(__inl5_s_sub) */
            for (int64_t __zi = 0; __zi < nstate; ++__zi) {
              for (int64_t __zj = (__zi + 1); __zj < nstate; ++__zj) {
                __cb121[(__zi)*(nstate) + (__zj)] = 0.0;
              }
            }
            for (int64_t __j = 0; __j < nstate; ++__j) {
              __s = __inl5_s_sub[(__j)*(nstate) + (__j)];
              for (int64_t __k = 0; __k < __j; ++__k) {
                __s -= (__cb121[(__j)*(nstate) + (__k)] * __cb121[(__j)*(nstate) + (__k)]);
              }
              __cb121[(__j)*(nstate) + (__j)] = sqrt(__s);
              for (int64_t __i = (__j + 1); __i < nstate; ++__i) {
                __s = __inl5_s_sub[(__i)*(nstate) + (__j)];
                for (int64_t __k = 0; __k < __j; ++__k) {
                  __s -= (__cb121[(__i)*(nstate) + (__k)] * __cb121[(__j)*(nstate) + (__k)]);
                }
                __cb121[(__i)*(nstate) + (__j)] = (__s / __cb121[(__j)*(nstate) + (__j)]);
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5_L[(__w0)*(nstate) + (__w1)] = __cb121[(__w0)*(nstate) + (__w1)];
              }
            }
            /* numpy: np.linalg.inv(__inl5_L) */
            for (int64_t __inv_i = 0; __inv_i < nstate; ++__inv_i) {
              for (int64_t __inv_j = 0; __inv_j < nstate; ++__inv_j) {
                __inv_aw1[(__inv_i)*(nstate) + (__inv_j)] = __inl5_L[(__inv_i)*(nstate) + (__inv_j)];
                __cb122[(__inv_i)*(nstate) + (__inv_j)] = ((__inv_i == __inv_j) ? 1.0 : 0.0);
              }
            }
            for (int64_t __inv_k = 0; __inv_k < nstate; ++__inv_k) {
              __inv_p = __inv_k;
              for (int64_t __inv_r = (__inv_k + 1); __inv_r < nstate; ++__inv_r) {
                if ((fabs(__inv_aw1[(__inv_r)*(nstate) + (__inv_k)]) > fabs(__inv_aw1[(__inv_p)*(nstate) + (__inv_k)]))) {
                  __inv_p = __inv_r;
                }
              }
              for (int64_t __inv_c = 0; __inv_c < nstate; ++__inv_c) {
                __inv_tmp = __inv_aw1[(__inv_k)*(nstate) + (__inv_c)];
                __inv_aw1[(__inv_k)*(nstate) + (__inv_c)] = __inv_aw1[(__inv_p)*(nstate) + (__inv_c)];
                __inv_aw1[(__inv_p)*(nstate) + (__inv_c)] = __inv_tmp;
                __inv_tmp = __cb122[(__inv_k)*(nstate) + (__inv_c)];
                __cb122[(__inv_k)*(nstate) + (__inv_c)] = __cb122[(__inv_p)*(nstate) + (__inv_c)];
                __cb122[(__inv_p)*(nstate) + (__inv_c)] = __inv_tmp;
              }
              __inv_factor = __inv_aw1[(__inv_k)*(nstate) + (__inv_k)];
              for (int64_t __inv_c = 0; __inv_c < nstate; ++__inv_c) {
                __cb122[(__inv_k)*(nstate) + (__inv_c)] = (__cb122[(__inv_k)*(nstate) + (__inv_c)] / __inv_factor);
                __inv_aw1[(__inv_k)*(nstate) + (__inv_c)] = (__inv_aw1[(__inv_k)*(nstate) + (__inv_c)] / __inv_factor);
              }
              for (int64_t __inv_r = 0; __inv_r < nstate; ++__inv_r) {
                if ((__inv_r != __inv_k)) {
                  __inv_factor = __inv_aw1[(__inv_r)*(nstate) + (__inv_k)];
                  for (int64_t __inv_c = 0; __inv_c < nstate; ++__inv_c) {
                    __cb122[(__inv_r)*(nstate) + (__inv_c)] = (__cb122[(__inv_r)*(nstate) + (__inv_c)] - (__inv_factor * __cb122[(__inv_k)*(nstate) + (__inv_c)]));
                    __inv_aw1[(__inv_r)*(nstate) + (__inv_c)] = (__inv_aw1[(__inv_r)*(nstate) + (__inv_c)] - (__inv_factor * __inv_aw1[(__inv_k)*(nstate) + (__inv_c)]));
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5_Linv[(__w0)*(nstate) + (__w1)] = __cb122[(__w0)*(nstate) + (__w1)];
              }
            }
            /* numpy: np.transpose(__inl5_Linv) */
            for (int64_t __t0 = 0; __t0 < nstate; ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb123[(__t1)*(nstate) + (__t0)] = __inl5_Linv[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(nstate), 1.0, __inl5_Linv, (blasint)(nstate), __inl5_h_sub, (blasint)(nstate), 0.0, __mm124, (blasint)(nstate));
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(nstate), 1.0, __mm124, (blasint)(nstate), __cb123, (blasint)(nstate), 0.0, __mm125, (blasint)(nstate));
            /* numpy: np.ascontiguousarray(__mm125) */
            for (int64_t __r0 = 0; __r0 < nstate; ++__r0) {
              for (int64_t __r1 = 0; __r1 < nstate; ++__r1) {
                __cb126[(__r0)*(nstate) + (__r1)] = __mm125[(__r0)*(nstate) + (__r1)];
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5___eigh1_a[(__w0)*(nstate) + (__w1)] = __cb126[(__w0)*(nstate) + (__w1)];
              }
            }
            memset(__inl5___eigh1_Cm, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
            for (int64_t __inl5___eigh1_ci = 0; __inl5___eigh1_ci < nstate; ++__inl5___eigh1_ci) {
              for (int64_t __inl5___eigh1_cj = 0; __inl5___eigh1_cj < nstate; ++__inl5___eigh1_cj) {
                __inl5___eigh1_Cm[(__inl5___eigh1_ci)*(nstate) + (__inl5___eigh1_cj)] = __inl5___eigh1_a[(__inl5___eigh1_ci)*(nstate) + (__inl5___eigh1_cj)];
              }
            }
            memset(__inl5___eigh1_jv, 0, (size_t)((nstate) * (nstate)) * sizeof(double));
            for (int64_t __inl5___eigh1_di = 0; __inl5___eigh1_di < nstate; ++__inl5___eigh1_di) {
              __inl5___eigh1_jv[(__inl5___eigh1_di)*(nstate) + (__inl5___eigh1_di)] = 1;
            }
            for (int64_t __inl5___eigh1_sw = 0; __inl5___eigh1_sw < 80; ++__inl5___eigh1_sw) {
              __inl5___eigh1_off = 0.0;
              for (int64_t __inl5___eigh1_pp = 0; __inl5___eigh1_pp < nstate; ++__inl5___eigh1_pp) {
                for (int64_t __inl5___eigh1_qq = (__inl5___eigh1_pp + 1); __inl5___eigh1_qq < nstate; ++__inl5___eigh1_qq) {
                  __inl5___eigh1_off += ((__inl5___eigh1_Cm[(__inl5___eigh1_pp)*(nstate) + (__inl5___eigh1_qq)] * __inl5___eigh1_Cm[(__inl5___eigh1_pp)*(nstate) + (__inl5___eigh1_qq)]) + (0.0 * 0.0));
                }
              }
              if ((__inl5___eigh1_off <= 1e-30)) {
                break;
              }
              for (int64_t __inl5___eigh1_pp = 0; __inl5___eigh1_pp < nstate; ++__inl5___eigh1_pp) {
                for (int64_t __inl5___eigh1_qq = (__inl5___eigh1_pp + 1); __inl5___eigh1_qq < nstate; ++__inl5___eigh1_qq) {
                  __inl5___eigh1_apq = __inl5___eigh1_Cm[(__inl5___eigh1_pp)*(nstate) + (__inl5___eigh1_qq)];
                  if ((hypot(__inl5___eigh1_apq, 0.0) == 0.0)) {
                    continue;
                  }
                  __inl5___eigh1_app = __inl5___eigh1_Cm[(__inl5___eigh1_pp)*(nstate) + (__inl5___eigh1_pp)];
                  __inl5___eigh1_aqq = __inl5___eigh1_Cm[(__inl5___eigh1_qq)*(nstate) + (__inl5___eigh1_qq)];
                  __inl5___eigh1_s = ((((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0)))) * (1.0 / sqrt((((((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))));
                  for (int64_t __inl5___eigh1_k = 0; __inl5___eigh1_k < nstate; ++__inl5___eigh1_k) {
                    __inl5___eigh1_akp = __inl5___eigh1_Cm[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_pp)];
                    __inl5___eigh1_akq = __inl5___eigh1_Cm[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_qq)];
                    __inl5___eigh1_Cm[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_pp)] = (((1.0 / sqrt((((((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl5___eigh1_akp) - ((__inl5___eigh1_s * (__inl5___eigh1_apq / hypot(__inl5___eigh1_apq, 0.0))) * __inl5___eigh1_akq));
                    __inl5___eigh1_Cm[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_qq)] = (((__inl5___eigh1_s * (__inl5___eigh1_apq / hypot(__inl5___eigh1_apq, 0.0))) * __inl5___eigh1_akp) + ((1.0 / sqrt((((((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl5___eigh1_akq));
                  }
                  for (int64_t __inl5___eigh1_k = 0; __inl5___eigh1_k < nstate; ++__inl5___eigh1_k) {
                    __inl5___eigh1_apk = __inl5___eigh1_Cm[(__inl5___eigh1_pp)*(nstate) + (__inl5___eigh1_k)];
                    __inl5___eigh1_aqk = __inl5___eigh1_Cm[(__inl5___eigh1_qq)*(nstate) + (__inl5___eigh1_k)];
                    __inl5___eigh1_Cm[(__inl5___eigh1_pp)*(nstate) + (__inl5___eigh1_k)] = (((1.0 / sqrt((((((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl5___eigh1_apk) - ((__inl5___eigh1_s * (__inl5___eigh1_apq / hypot(__inl5___eigh1_apq, 0.0))) * __inl5___eigh1_aqk));
                    __inl5___eigh1_Cm[(__inl5___eigh1_qq)*(nstate) + (__inl5___eigh1_k)] = (((__inl5___eigh1_s * (__inl5___eigh1_apq / hypot(__inl5___eigh1_apq, 0.0))) * __inl5___eigh1_apk) + ((1.0 / sqrt((((((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl5___eigh1_aqk));
                  }
                  for (int64_t __inl5___eigh1_k = 0; __inl5___eigh1_k < nstate; ++__inl5___eigh1_k) {
                    __inl5___eigh1_vkp = __inl5___eigh1_jv[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_pp)];
                    __inl5___eigh1_vkq = __inl5___eigh1_jv[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_qq)];
                    __inl5___eigh1_jv[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_pp)] = (((1.0 / sqrt((((((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl5___eigh1_vkp) - ((__inl5___eigh1_s * (__inl5___eigh1_apq / hypot(__inl5___eigh1_apq, 0.0))) * __inl5___eigh1_vkq));
                    __inl5___eigh1_jv[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_qq)] = (((__inl5___eigh1_s * (__inl5___eigh1_apq / hypot(__inl5___eigh1_apq, 0.0))) * __inl5___eigh1_vkp) + ((1.0 / sqrt((((((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0)))) * (((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) >= 0.0) ? 1.0 : (-1.0)) / (fabs(((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + sqrt(((((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0))) * ((__inl5___eigh1_aqq - __inl5___eigh1_app) / (2.0 * hypot(__inl5___eigh1_apq, 0.0)))) + 1.0))))) + 1.0))) * __inl5___eigh1_vkq));
                  }
                }
              }
            }
            memset(__inl5___eigh1_wa, 0, (size_t)((nstate)) * sizeof(double));
            for (int64_t __inl5___eigh1_i = 0; __inl5___eigh1_i < nstate; ++__inl5___eigh1_i) {
              __inl5___eigh1_wa[__inl5___eigh1_i] = __inl5___eigh1_Cm[(__inl5___eigh1_i)*(nstate) + (__inl5___eigh1_i)];
            }
            for (int64_t __inl5___eigh1_i = 0; __inl5___eigh1_i < nstate; ++__inl5___eigh1_i) {
              __inl5___eigh1_mn = __inl5___eigh1_i;
              for (int64_t __inl5___eigh1_j = (__inl5___eigh1_i + 1); __inl5___eigh1_j < nstate; ++__inl5___eigh1_j) {
                if ((__inl5___eigh1_wa[__inl5___eigh1_j] < __inl5___eigh1_wa[__inl5___eigh1_mn])) {
                  __inl5___eigh1_mn = __inl5___eigh1_j;
                }
              }
              if ((__inl5___eigh1_mn != __inl5___eigh1_i)) {
                __inl5___eigh1_tw = __inl5___eigh1_wa[__inl5___eigh1_i];
                __inl5___eigh1_wa[__inl5___eigh1_i] = __inl5___eigh1_wa[__inl5___eigh1_mn];
                __inl5___eigh1_wa[__inl5___eigh1_mn] = __inl5___eigh1_tw;
                for (int64_t __inl5___eigh1_k = 0; __inl5___eigh1_k < nstate; ++__inl5___eigh1_k) {
                  __inl5___eigh1_tv = __inl5___eigh1_jv[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_i)];
                  __inl5___eigh1_jv[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_i)] = __inl5___eigh1_jv[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_mn)];
                  __inl5___eigh1_jv[(__inl5___eigh1_k)*(nstate) + (__inl5___eigh1_mn)] = __inl5___eigh1_tv;
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5___eigh1_ya[(__w0)*(nstate) + (__w1)] = __inl5___eigh1_jv[(__w0)*(nstate) + (__w1)];
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              __inl5_w[__w0] = __inl5___eigh1_wa[__w0];
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5_U[(__w0)*(nstate) + (__w1)] = __inl5___eigh1_ya[(__w0)*(nstate) + (__w1)];
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __ixa4[(__w0)*(nstate) + (__w1)] = fabs(__inl5_U[(__w0)*(nstate) + (__w1)]);
              }
            }
            /* numpy: np.argmax(__ixa4, axis=0) */
            for (int64_t __aax0 = 0; __aax0 < nstate; ++__aax0) {
              __ar_val___cb127 = __ixa4[(0)*(nstate) + (__aax0)];
              __cb127[__aax0] = 0;
              for (int64_t __ard0 = 0; __ard0 < nstate; ++__ard0) {
                if (((__ar_val___cb127 == __ar_val___cb127) && ((__ixa4[(__ard0)*(nstate) + (__aax0)] != __ixa4[(__ard0)*(nstate) + (__aax0)]) || (__ixa4[(__ard0)*(nstate) + (__aax0)] > __ar_val___cb127)))) {
                  __ar_val___cb127 = __ixa4[(__ard0)*(nstate) + (__aax0)];
                  __cb127[__aax0] = __ard0;
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              __ix5[__w0] = __cb127[__w0];
            }
            /* numpy: np.arange(nstate) */
            for (int64_t __i = 0; __i < nstate; ++__i) {
              __cb128[__i] = __i;
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              __ix6[__w0] = __cb128[__w0];
            }
            /* numpy: np.sign(__inl5_U[__ix5, __ix6]) */
            for (int64_t __r0 = 0; __r0 < nstate; ++__r0) {
              __cb129[__r0] = __npb_sign(__inl5_U[(__ix5[__r0])*(nstate) + (__ix6[__r0])]);
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5_U[(__w0)*(nstate) + (__w1)] = (__inl5_U[(__w0)*(nstate) + (__w1)] * __cb129[__w1]);
              }
            }
            /* numpy: np.transpose(__inl5_Linv) */
            for (int64_t __t0 = 0; __t0 < nstate; ++__t0) {
              for (int64_t __t1 = 0; __t1 < nstate; ++__t1) {
                __cb130[(__t1)*(nstate) + (__t0)] = __inl5_Linv[(__t0)*(nstate) + (__t1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(nstate), (blasint)(nstate), (blasint)(nstate), 1.0, __cb130, (blasint)(nstate), __inl5_U, (blasint)(nstate), 0.0, __mm131, (blasint)(nstate));
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              for (int64_t __w1 = 0; __w1 < nstate; ++__w1) {
                __inl5_C[(__w0)*(nstate) + (__w1)] = __mm131[(__w0)*(nstate) + (__w1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(((((Lb * Lb) * Lb) * nstate) / nstate)), (blasint)(nstate), (blasint)(nstate), 1.0, __inl5_Yf, (blasint)(nstate), __inl5_C, (blasint)(nstate), 0.0, __mm132, (blasint)(nstate));
            /* numpy: np.reshape(__mm132, (Lb, Lb, Lb, nstate)) */
            for (int64_t __rs0 = 0; __rs0 < Lb; ++__rs0) {
              for (int64_t __rs1 = 0; __rs1 < Lb; ++__rs1) {
                for (int64_t __rs2 = 0; __rs2 < Lb; ++__rs2) {
                  for (int64_t __rs3 = 0; __rs3 < nstate; ++__rs3) {
                    __cb133[(((__rs0)*(Lb) + (__rs1))*(Lb) + (__rs2))*(nstate) + (__rs3)] = __mm132[((((__rs0 * (Lb * Lb)) + (__rs1 * Lb)) + __rs2))*(nstate) + (__rs3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  for (int64_t __w3 = 0; __w3 < nstate; ++__w3) {
                    X[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)] = __cb133[(((__w0)*(Lb) + (__w1))*(Lb) + (__w2))*(nstate) + (__w3)];
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < nstate; ++__w0) {
              w[__w0] = __inl5_w[__w0];
            }
            for (int64_t si1 = 0; si1 < Lb; ++si1) {
              for (int64_t si2 = 0; si2 < Lb; ++si2) {
                for (int64_t si3 = 0; si3 < Lb; ++si3) {
                  for (int64_t si4 = 0; si4 < nstate; ++si4) {
                    psi_frag[((((f)*(Lb) + (si1))*(Lb) + (si2))*(Lb) + (si3))*(nstate) + (si4)] = X[(((si1)*(Lb) + (si2))*(Lb) + (si3))*(nstate) + (si4)];
                  }
                }
              }
            }
            /* numpy: np.einsum('xyzk,k,xyzk->xyz', X, occ, X) */
            for (int64_t __es_x = 0; __es_x < Lb; ++__es_x) {
              for (int64_t __es_y = 0; __es_y < Lb; ++__es_y) {
                for (int64_t __es_z = 0; __es_z < Lb; ++__es_z) {
                  __cb134[((__es_x)*(Lb) + (__es_y))*(Lb) + (__es_z)] = 0.0;
                  for (int64_t __es_k = 0; __es_k < nstate; ++__es_k) {
                    __cb134[((__es_x)*(Lb) + (__es_y))*(Lb) + (__es_z)] += ((X[(((__es_x)*(Lb) + (__es_y))*(Lb) + (__es_z))*(nstate) + (__es_k)] * occ[__es_k]) * X[(((__es_x)*(Lb) + (__es_y))*(Lb) + (__es_z))*(nstate) + (__es_k)]);
                  }
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < Lb; ++__w0) {
              for (int64_t __w1 = 0; __w1 < Lb; ++__w1) {
                for (int64_t __w2 = 0; __w2 < Lb; ++__w2) {
                  dens[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)] = __cb134[((__w0)*(Lb) + (__w1))*(Lb) + (__w2)];
                }
              }
            }
            for (int64_t __ixs2_0 = 0; __ixs2_0 < Lb; ++__ixs2_0) {
              for (int64_t __ixs2_1 = 0; __ixs2_1 < Lb; ++__ixs2_1) {
                for (int64_t __ixs2_2 = 0; __ixs2_2 < Lb; ++__ixs2_2) {
                  rho_out[((xs[__ixs2_0])*(N) + (ys[__ixs2_1]))*(N) + (zs[__ixs2_2])] += (alpha[f] * dens[((__ixs2_0)*(Lb) + (__ixs2_1))*(Lb) + (__ixs2_2)]);
                }
              }
            }
          }
          /* numpy: np.maximum(rho_out, 0.0) */
          for (int64_t __r0 = 0; __r0 < N; ++__r0) {
            for (int64_t __r1 = 0; __r1 < N; ++__r1) {
              for (int64_t __r2 = 0; __r2 < N; ++__r2) {
                __cb135[((__r0)*(N) + (__r1))*(N) + (__r2)] = max(rho_out[((__r0)*(N) + (__r1))*(N) + (__r2)], 0.0);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                rho_out[((__w0)*(N) + (__w1))*(N) + (__w2)] = __cb135[((__w0)*(N) + (__w1))*(N) + (__w2)];
              }
            }
          }
          /* numpy: np.sum(rho_out) */
          __cb136 = 0.0;
          for (int64_t __r0 = 0; __r0 < N; ++__r0) {
            for (int64_t __r1 = 0; __r1 < N; ++__r1) {
              for (int64_t __r2 = 0; __r2 < N; ++__r2) {
                __cb136 = (__cb136 + rho_out[((__r0)*(N) + (__r1))*(N) + (__r2)]);
              }
            }
          }
          q = (__cb136 * dvol);
          if ((q > 0.0)) {
            for (int64_t __w0 = 0; __w0 < N; ++__w0) {
              for (int64_t __w1 = 0; __w1 < N; ++__w1) {
                for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                  rho_out[((__w0)*(N) + (__w1))*(N) + (__w2)] *= (nelec / q);
                }
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __mc1[((__w0)*(N) + (__w1))*(N) + (__w2)] = fabs((rho_out[((__w0)*(N) + (__w1))*(N) + (__w2)] - rho_in[((__w0)*(N) + (__w1))*(N) + (__w2)]));
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __mc2[((__w0)*(N) + (__w1))*(N) + (__w2)] = fabs(rho_in[((__w0)*(N) + (__w1))*(N) + (__w2)]);
              }
            }
          }
          /* numpy: np.sum(__mc1) */
          __cb137 = 0.0;
          for (int64_t __r0 = 0; __r0 < N; ++__r0) {
            for (int64_t __r1 = 0; __r1 < N; ++__r1) {
              for (int64_t __r2 = 0; __r2 < N; ++__r2) {
                __cb137 = (__cb137 + __mc1[((__r0)*(N) + (__r1))*(N) + (__r2)]);
              }
            }
          }
          /* numpy: np.sum(__mc2) */
          __cb138 = 0.0;
          for (int64_t __r0 = 0; __r0 < N; ++__r0) {
            for (int64_t __r1 = 0; __r1 < N; ++__r1) {
              for (int64_t __r2 = 0; __r2 < N; ++__r2) {
                __cb138 = (__cb138 + __mc2[((__r0)*(N) + (__r1))*(N) + (__r2)]);
              }
            }
          }
          rho_error = (((double)(__cb137)) / (__cb138 + 1e-30));
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                rho_in[((__w0)*(N) + (__w1))*(N) + (__w2)] = (rho_in[((__w0)*(N) + (__w1))*(N) + (__w2)] + (mix * (rho_out[((__w0)*(N) + (__w1))*(N) + (__w2)] - rho_in[((__w0)*(N) + (__w1))*(N) + (__w2)])));
              }
            }
          }
          __inl14_N = N;
          /* numpy: np.mean(rho_in) */
          __cb139 = 0.0;
          for (int64_t __r0 = 0; __r0 < N; ++__r0) {
            for (int64_t __r1 = 0; __r1 < N; ++__r1) {
              for (int64_t __r2 = 0; __r2 < N; ++__r2) {
                __cb139 = (__cb139 + rho_in[((__r0)*(N) + (__r1))*(N) + (__r2)]);
              }
            }
          }
          __cb139 = (__cb139 / (double)(((N * N) * N)));
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __cb140[((__w0)*(N) + (__w1))*(N) + (__w2)] = (rho_in[((__w0)*(N) + (__w1))*(N) + (__w2)] - __cb139);
              }
            }
          }
          /* numpy: np.fft.fftn(__cb140) */
          {
            int64_t __fft_n = (int64_t)(N) * (int64_t)(N) * (int64_t)(N);
            int64_t __fft_batch = (int64_t)1;
            if (__fft_n > 0 && __fft_batch > 0) {
              int __fft_dims[3] = {(int)(N), (int)(N), (int)(N)};
              double _Complex *__fft_in = (double _Complex *)malloc((size_t)(__fft_n * __fft_batch) * sizeof(double _Complex));
              __npb_alloc_check(__fft_in, (size_t)(__fft_n * __fft_batch) * sizeof(double _Complex), "__fft_in");
              for (int64_t __fft_i = 0; __fft_i < __fft_n * __fft_batch; ++__fft_i) {
                __fft_in[__fft_i] = (double _Complex)(__cb140[__fft_i]);
              }
              fftw_plan __fft_plan = fftw_plan_many_dft(3, __fft_dims, (int)__fft_batch, (fftw_complex *)(__fft_in), NULL, (int)__fft_batch, 1, (fftw_complex *)(__cb141), NULL, (int)__fft_batch, 1, FFTW_FORWARD, FFTW_ESTIMATE);
              fftw_execute(__fft_plan);
              fftw_destroy_plan(__fft_plan);
              free(__fft_in);
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl14_rho_g[((__w0)*(N) + (__w1))*(N) + (__w2)] = __cb141[((__w0)*(N) + (__w1))*(N) + (__w2)];
              }
            }
          }
          /* numpy: np.fft.fftfreq(N, d=h) */
          for (int64_t __ff = 0; __ff < N; ++__ff) {
            __cb142[__ff] = (((__ff <= int_floor((N - 1), 2)) ? __ff : (__ff - N)) / (N * h));
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            __inl22_kx[__w0] = ((2.0 * 3.141592653589793) * __cb142[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl22_gsq[((__w0)*(N) + (__w1))*(N) + (__w2)] = (((__inl22_kx[__w0] * __inl22_kx[__w0]) + (__inl22_kx[__w1] * __inl22_kx[__w1])) + (__inl22_kx[__w2] * __inl22_kx[__w2]));
              }
            }
          }
          __inl22_gsq[((0)*(N) + (0))*(N) + (0)] = 1.0;
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl22_inv[((__w0)*(N) + (__w1))*(N) + (__w2)] = (1.0 / __inl22_gsq[((__w0)*(N) + (__w1))*(N) + (__w2)]);
              }
            }
          }
          __inl22_inv[((0)*(N) + (0))*(N) + (0)] = 0.0;
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __hcall11[((__w0)*(N) + (__w1))*(N) + (__w2)] = __inl22_inv[((__w0)*(N) + (__w1))*(N) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __cb143[((__w0)*(N) + (__w1))*(N) + (__w2)] = (((4.0 * 3.141592653589793) * __inl14_rho_g[((__w0)*(N) + (__w1))*(N) + (__w2)]) * __hcall11[((__w0)*(N) + (__w1))*(N) + (__w2)]);
              }
            }
          }
          /* numpy: np.fft.ifftn(__cb143) */
          {
            int64_t __fft_n = (int64_t)(N) * (int64_t)(N) * (int64_t)(N);
            int64_t __fft_batch = (int64_t)1;
            if (__fft_n > 0 && __fft_batch > 0) {
              int __fft_dims[3] = {(int)(N), (int)(N), (int)(N)};
              fftw_plan __fft_plan = fftw_plan_many_dft(3, __fft_dims, (int)__fft_batch, (fftw_complex *)(__cb143), NULL, (int)__fft_batch, 1, (fftw_complex *)(__cb144), NULL, (int)__fft_batch, 1, FFTW_BACKWARD, FFTW_ESTIMATE);
              fftw_execute(__fft_plan);
              fftw_destroy_plan(__fft_plan);
              for (int64_t __fft_i = 0; __fft_i < __fft_n * __fft_batch; ++__fft_i) {
                __cb144[__fft_i] /= ((double)__fft_n);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __hcall8[((__w0)*(N) + (__w1))*(N) + (__w2)] = creal(__cb144[((__w0)*(N) + (__w1))*(N) + (__w2)]);
              }
            }
          }
          /* numpy: np.maximum(rho_in, 1e-12) */
          for (int64_t __r0 = 0; __r0 < N; ++__r0) {
            for (int64_t __r1 = 0; __r1 < N; ++__r1) {
              for (int64_t __r2 = 0; __r2 < N; ++__r2) {
                __cb145[((__r0)*(N) + (__r1))*(N) + (__r2)] = max(rho_in[((__r0)*(N) + (__r1))*(N) + (__r2)], 1e-12);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl15_n[((__w0)*(N) + (__w1))*(N) + (__w2)] = __cb145[((__w0)*(N) + (__w1))*(N) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl15_rs[((__w0)*(N) + (__w1))*(N) + (__w2)] = pow((3.0 / ((4.0 * 3.141592653589793) * __inl15_n[((__w0)*(N) + (__w1))*(N) + (__w2)])), (1.0 / 3.0));
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl15_n13[((__w0)*(N) + (__w1))*(N) + (__w2)] = pow(__inl15_n[((__w0)*(N) + (__w1))*(N) + (__w2)], (1.0 / 3.0));
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl15_v_x[((__w0)*(N) + (__w1))*(N) + (__w2)] = ((-0.9847450218426965) * __inl15_n13[((__w0)*(N) + (__w1))*(N) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl15_sqrt_rs[((__w0)*(N) + (__w1))*(N) + (__w2)] = sqrt(__inl15_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl15_ln_rs[((__w0)*(N) + (__w1))*(N) + (__w2)] = log(__inl15_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl15_denom[((__w0)*(N) + (__w1))*(N) + (__w2)] = ((1.0 + (1.0529 * __inl15_sqrt_rs[((__w0)*(N) + (__w1))*(N) + (__w2)])) + (0.3334 * __inl15_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]));
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl15_v_c_ge1[((__w0)*(N) + (__w1))*(N) + (__w2)] = (((-0.1423 / __inl15_denom[((__w0)*(N) + (__w1))*(N) + (__w2)]) * ((1.0 + (((7.0 / 6.0) * 1.0529) * __inl15_sqrt_rs[((__w0)*(N) + (__w1))*(N) + (__w2)])) + (((4.0 / 3.0) * 0.3334) * __inl15_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]))) / __inl15_denom[((__w0)*(N) + (__w1))*(N) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl15_v_c_lt1[((__w0)*(N) + (__w1))*(N) + (__w2)] = ((((0.0311 * __inl15_ln_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]) + (-0.048 - (0.0311 / 3.0))) + ((((2.0 / 3.0) * 0.002) * __inl15_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]) * __inl15_ln_rs[((__w0)*(N) + (__w1))*(N) + (__w2)])) + ((((2.0 * -0.0116) - 0.002) / 3.0) * __inl15_rs[((__w0)*(N) + (__w1))*(N) + (__w2)]));
              }
            }
          }
          /* numpy: np.where(__inl15_rs < 1.0, __inl15_v_c_lt1, __inl15_v_c_ge1) */
          for (int64_t __r0 = 0; __r0 < N; ++__r0) {
            for (int64_t __r1 = 0; __r1 < N; ++__r1) {
              for (int64_t __r2 = 0; __r2 < N; ++__r2) {
                __cb146[((__r0)*(N) + (__r1))*(N) + (__r2)] = ((__inl15_rs[((__r0)*(N) + (__r1))*(N) + (__r2)] < 1.0) ? __inl15_v_c_lt1[((__r0)*(N) + (__r1))*(N) + (__r2)] : __inl15_v_c_ge1[((__r0)*(N) + (__r1))*(N) + (__r2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __hcall9[((__w0)*(N) + (__w1))*(N) + (__w2)] = (__inl15_v_x[((__w0)*(N) + (__w1))*(N) + (__w2)] + __cb146[((__w0)*(N) + (__w1))*(N) + (__w2)]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < N; ++__w0) {
            for (int64_t __w1 = 0; __w1 < N; ++__w1) {
              for (int64_t __w2 = 0; __w2 < N; ++__w2) {
                __inl6_v[((__w0)*(N) + (__w1))*(N) + (__w2)] = ((__hcall8[((__w0)*(N) + (__w1))*(N) + (__w2)] + V_ion[((__w0)*(N) + (__w1))*(N) + (__w2)]) + __hcall9[((__w0)*(N) + (__w1))*(N) + (__w2)]);
              }
            }
          }
          /* numpy: np.mean(__inl6_v) */
          __cb147 = 0.0;
          for (int64_t __r0 = 0; __r0 < N; ++__r0) {
            for (int64_t __r1 = 0; __r1 < N; ++__r1) {
              for (int64_t __r2 = 0; __r2 < N; ++__r2) {
                __cb147 = (__cb147 + __inl6_v[((__r0)*(N) + (__r1))*(N) + (__r2)]);
              }
            }
          }
          __cb147 = (__cb147 / (double)(((N * N) * N)));
          for (int64_t si0 = 0; si0 < N; ++si0) {
            for (int64_t si1 = 0; si1 < N; ++si1) {
              for (int64_t si2 = 0; si2 < N; ++si2) {
                V_tot[((si0)*(N) + (si1))*(N) + (si2)] = (__inl6_v[((si0)*(N) + (si1))*(N) + (si2)] - __cb147);
              }
            }
          }
          if ((rho_error < tol)) {
            break;
          }
        }
        for (int64_t si0 = 0; si0 < N; ++si0) {
          for (int64_t si1 = 0; si1 < N; ++si1) {
            for (int64_t si2 = 0; si2 < N; ++si2) {
              rho[((si0)*(N) + (si1))*(N) + (si2)] = rho_in[((si0)*(N) + (si1))*(N) + (si2)];
            }
          }
        }
        free(rho_in);
        free(b_frag);
        free(b_frag_valid);
        free(rho_out);
        free(vloc);
        free(__inl2_v_prev);
        free(__inl2_vcol);
        free(__inl17_row);
        free(__inl18_row);
        free(__eye1);
        free(__inl3___eigh1_Cm);
        free(__inl3___eigh1_jv);
        free(__inl3___eigh1_wa);
        free(__inl19_row);
        free(__inl20_row);
        free(__inl21_row);
        free(__eye2);
        free(__inl5___eigh1_Cm);
        free(__inl5___eigh1_jv);
        free(__inl5___eigh1_wa);
        free(__cb1);
        free(__cb2);
        free(__cb5);
        free(__cb6);
        free(__cb7);
        free(__cb8);
        free(__cb9);
        free(__cb10);
        free(__cb11);
        free(__cb14);
        free(__cb15);
        free(__cb16);
        free(__cb17);
        free(__cb18);
        free(__cb19);
        free(__cb20);
        free(__cb21);
        free(__mm22);
        free(__mm23);
        free(__mm24);
        free(__cb25);
        free(__cb26);
        free(__cb27);
        free(__cb34);
        free(__cb35);
        free(__cb36);
        free(__cb37);
        free(__cb38);
        free(__cb39);
        free(__cb40);
        free(__cb41);
        free(__cb42);
        free(__cb43);
        free(__cb44);
        free(__mm45);
        free(__mm46);
        free(__mm47);
        free(__cb48);
        free(__cb49);
        free(__cb50);
        free(__cb51);
        free(__mm52);
        free(__cb53);
        free(__mm54);
        free(__cb55);
        free(__cb56);
        free(__mm57);
        free(__cb58);
        free(__mm59);
        free(__cb60);
        free(__cb61);
        free(__cb62);
        free(__mm63);
        free(__mm64);
        free(__cb65);
        free(__cb66);
        free(__cb67);
        free(__cb68);
        free(__cb69);
        free(__mm70);
        free(__mm71);
        free(__cb72);
        free(__cb73);
        free(__cb74);
        free(__cb75);
        free(__cb76);
        free(__cb77);
        free(__cb78);
        free(__cb79);
        free(__cb80);
        free(__mm81);
        free(__mm82);
        free(__mm83);
        free(__cb84);
        free(__cb85);
        free(__cb86);
        free(__cb87);
        free(__cb88);
        free(__cb89);
        free(__cb90);
        free(__cb91);
        free(__cb92);
        free(__mm93);
        free(__mm94);
        free(__mm95);
        free(__cb96);
        free(__cb97);
        free(__cb98);
        free(__cb99);
        free(__cb100);
        free(__cb101);
        free(__cb102);
        free(__cb103);
        free(__cb104);
        free(__cb105);
        free(__mm106);
        free(__mm107);
        free(__mm108);
        free(__cb109);
        free(__cb110);
        free(__cb111);
        free(__cb112);
        free(__mm113);
        free(__cb114);
        free(__mm115);
        free(__cb116);
        free(__cb117);
        free(__mm118);
        free(__cb119);
        free(__mm120);
        free(__cb121);
        free(__cb122);
        free(__cb123);
        free(__mm124);
        free(__mm125);
        free(__cb126);
        free(__cb127);
        free(__cb128);
        free(__cb129);
        free(__cb130);
        free(__mm131);
        free(__mm132);
        free(__cb133);
        free(__cb134);
        free(__cb135);
        free(__cb140);
        free(__cb141);
        free(__cb142);
        free(__cb143);
        free(__cb144);
        free(__cb145);
        free(__cb146);
        free(__td_op1);
        free(__td_op2);
        free(__td_op3);
        free(__inv_aw0);
        free(__inv_aw1);
        free(box);
        free(proj_flat);
        free(__inl7_rho_g);
        free(__inl16_kx);
        free(__inl16_gsq);
        free(__inl16_inv);
        free(__hcall10);
        free(__inl8_n);
        free(__inl8_rs);
        free(__inl8_n13);
        free(__inl8_v_x);
        free(__inl8_denom);
        free(__inl8_v_c_ge1);
        free(__inl8_v_c_lt1);
        free(__hcall3);
        free(__inl1_v);
        free(xs);
        free(ys);
        free(zs);
        free(__inl2_v);
        free(__inl17_idx);
        free(__scg0);
        free(__scg1);
        free(__scg2);
        free(__scg3);
        free(__scg4);
        free(__scg5);
        free(__scg6);
        free(__scg7);
        free(__inl9_row);
        free(__inl9_acc);
        free(__inl9_hx1);
        free(__inl9_flat);
        free(__inl9_overlap);
        free(__inl9_hx2);
        free(__inl2_wcol);
        free(__inl2_w);
        free(__swap1_0);
        free(__swap1_1);
        free(__inl3_Yf);
        free(__inl18_idx);
        free(__scg8);
        free(__scg9);
        free(__scg10);
        free(__scg11);
        free(__scg12);
        free(__scg13);
        free(__scg14);
        free(__scg15);
        free(__inl10_row);
        free(__inl10_acc);
        free(__inl10_hx1);
        free(__inl10_flat);
        free(__inl10_overlap);
        free(__inl10_hx2);
        free(__hcall4);
        free(__inl3_Wf);
        free(__inl3_h_sub);
        free(__inl3_s_sub);
        free(__inl3_L);
        free(__inl3_Linv);
        free(__inl3___eigh1_a);
        free(__inl3___eigh1_ya);
        free(__inl3_w);
        free(__inl3_U);
        free(__ix2);
        free(__ix3);
        free(__inl3_C);
        free(X);
        free(w);
        free(__inl4_X);
        free(__inl19_idx);
        free(__scg16);
        free(__scg17);
        free(__scg18);
        free(__scg19);
        free(__scg20);
        free(__scg21);
        free(__scg22);
        free(__scg23);
        free(__inl11_row);
        free(__inl11_acc);
        free(__inl11_hx1);
        free(__inl11_flat);
        free(__inl11_overlap);
        free(__inl11_hx2);
        free(__hcall5);
        free(__inl4_Y);
        free(__inl20_idx);
        free(__scg24);
        free(__scg25);
        free(__scg26);
        free(__scg27);
        free(__scg28);
        free(__scg29);
        free(__scg30);
        free(__scg31);
        free(__inl12_row);
        free(__inl12_acc);
        free(__inl12_hx1);
        free(__inl12_flat);
        free(__inl12_overlap);
        free(__inl12_hx2);
        free(__hcall6);
        free(__inl4_Ynew);
        free(__swap2_0);
        free(__swap2_1);
        free(Y);
        free(__inl5_Yf);
        free(__inl21_idx);
        free(__scg32);
        free(__scg33);
        free(__scg34);
        free(__scg35);
        free(__scg36);
        free(__scg37);
        free(__scg38);
        free(__scg39);
        free(__inl13_row);
        free(__inl13_acc);
        free(__inl13_hx1);
        free(__inl13_flat);
        free(__inl13_overlap);
        free(__inl13_hx2);
        free(__hcall7);
        free(__inl5_Wf);
        free(__inl5_h_sub);
        free(__inl5_s_sub);
        free(__inl5_L);
        free(__inl5_Linv);
        free(__inl5___eigh1_a);
        free(__inl5___eigh1_ya);
        free(__inl5_w);
        free(__inl5_U);
        free(__ix5);
        free(__ix6);
        free(__inl5_C);
        free(dens);
        free(__inl14_rho_g);
        free(__inl22_kx);
        free(__inl22_gsq);
        free(__inl22_inv);
        free(__hcall11);
        free(__inl15_n);
        free(__inl15_rs);
        free(__inl15_n13);
        free(__inl15_v_x);
        free(__inl15_denom);
        free(__inl15_v_c_ge1);
        free(__inl15_v_c_lt1);
        free(__hcall9);
        free(__inl6_v);
        free(__hcall2);
        free(__inl8_sqrt_rs);
        free(__inl8_ln_rs);
        free(__mc1);
        free(__mc2);
        free(__hcall8);
        free(__inl15_sqrt_rs);
        free(__inl15_ln_rs);
        free(gx_gy_gz);
        free(pf);
        free(df);
        free(__ixa1);
        free(__ixa4);
        free(__inl2___eigh0_Cm);
        free(__inl2___eigh0_jv);
        free(__inl2___eigh0_wa);
        free(__cb30);
        free(__cb31);
        free(__cb32);
        free(__inl2_T);
        free(__inl2___eigh0_ya);
        free(__inl2___eigv1);
        free(__inl2_off);
}
