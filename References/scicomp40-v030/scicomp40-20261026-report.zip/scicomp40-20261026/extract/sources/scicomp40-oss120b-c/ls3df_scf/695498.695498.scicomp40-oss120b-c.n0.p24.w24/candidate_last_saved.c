#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include <cblas.h>
#include <lapacke.h>
#include <fftw3.h>
#include <omp.h>
extern void openblas_set_num_threads(int);


// LDA exchange‑correlation constants
static const double AX = 0.9847450218426965; // (3/pi)^(1/3)
static const double GAMMA = -0.1423;
static const double B1 = 1.0529;
static const double B2 = 0.3334;
static const double A = 0.0311;
static const double B = -0.0480;
static const double C = 0.0020;
static const double D = -0.0116;

// 8th‑order finite‑difference stencil coefficients
static const double C0 = -205.0/72.0;
static const double CW[4] = {8.0/5.0, -1.0/5.0, 8.0/315.0, -1.0/560.0}; // ±1,±2,±3,±4

// Positive modulo (Python style)
static inline int64_t py_mod(int64_t a, int64_t b) {
    int64_t r = a % b;
    return (r < 0) ? r + b : r;
}

// Build kinetic‑energy stencil (circulant matrix) for a block of size Lb
static double *make_stencil(int64_t Lb) {
    double *row = (double *)malloc((size_t)Lb * (size_t)Lb * sizeof(double));
    for (int64_t i = 0; i < Lb; ++i) {
        for (int64_t j = 0; j < Lb; ++j) {
            row[i*Lb + j] = 0.0;
        }
    }
    for (int64_t i = 0; i < Lb; ++i) {
        row[i*Lb + i] = C0;
        for (int m = 1; m <= 4; ++m) {
            double w = CW[m-1];
            int64_t ip = (i + m) % Lb;
            int64_t im = (i - m + Lb) % Lb;
            row[i*Lb + ip] = w;
            row[i*Lb + im] = w;
        }
    }
    return row;
}

// Build k‑vector and 1/|G|^2 for FFT‑based Poisson solver
static void build_poisson_terms(int64_t N, double h, double **out_kx, double **out_invgsq) {
    double *kx = (double *)malloc((size_t)N * sizeof(double));
    double *invgsq = (double *)malloc((size_t)N * N * N * sizeof(double));
    const double two_pi = 2.0 * M_PI;
    for (int64_t i = 0; i < N; ++i) {
        int64_t p = (i <= (N-1)/2) ? i : i - N;
        kx[i] = (two_pi * p) / (N * h);
    }
    for (int64_t i = 0; i < N; ++i) {
        for (int64_t j = 0; j < N; ++j) {
            for (int64_t k = 0; k < N; ++k) {
                double g2 = kx[i]*kx[i] + kx[j]*kx[j] + kx[k]*kx[k];
                size_t idx = ((size_t)i * N + j) * N + k;
                invgsq[idx] = (g2 == 0.0) ? 0.0 : 1.0 / g2;
            }
        }
    }
    *out_kx = kx;
    *out_invgsq = invgsq;
}

// LDA exchange‑correlation potential (vectorised)
static void lda_xc(const double *rho, double *vxc, int64_t N3) {
    const double eps = 1e-12;
    for (int64_t i = 0; i < N3; ++i) {
        double n = rho[i] > eps ? rho[i] : eps;
        double rs = cbrt(3.0 / (4.0 * M_PI * n));
        double n13 = cbrt(n);
        double v_x = -AX * n13;
        double sqrt_rs = sqrt(rs);
        double ln_rs = log(rs);
        double denom = 1.0 + B1*sqrt_rs + B2*rs;
        double v_c_ge1 = (GAMMA/denom) * (1.0 + (7.0/6.0)*B1*sqrt_rs + (4.0/3.0)*B2*rs) / denom;
        double v_c_lt1 = A*ln_rs + (B - A/3.0) + (2.0/3.0)*C*rs*ln_rs + (2.0*D - C)/3.0 * rs;
        double v_c = (rs < 1.0) ? v_c_lt1 : v_c_ge1;
        vxc[i] = v_x + v_c;
    }
}

// Apply H = T + V_loc + P (projector) to block X, result in Y
static void hpsi_apply(const double *X, const double *row, const double *vloc,
                       const double *proj_f, const double *dij_f,
                       int64_t Lb, int64_t nproj, int64_t nstate,
                       double half_inv_h2, double *Y) {
    const int64_t L3 = Lb*Lb*Lb;
    // kinetic + local potential
        for (int64_t i = 0; i < Lb; ++i) {
        for (int64_t j = 0; j < Lb; ++j) {
            for (int64_t k = 0; k < Lb; ++k) {
                size_t base = ((size_t)i*Lb + j)*Lb + k;
                for (int64_t s = 0; s < nstate; ++s) {
                    double sum = C0 * X[base*nstate + s];
                    // neighbours for +/- 1..4 in each direction
                    for (int m = 1; m <= 4; ++m) {
                        double w = CW[m-1];
                        int64_t ip = (i + m) % Lb;
                        int64_t im = (i - m + Lb) % Lb;
                        int64_t jp = (j + m) % Lb;
                        int64_t jm = (j - m + Lb) % Lb;
                        int64_t kp = (k + m) % Lb;
                        int64_t km = (k - m + Lb) % Lb;
                        size_t idx_ip = ((size_t)ip*Lb + j)*Lb + k;
                        size_t idx_im = ((size_t)im*Lb + j)*Lb + k;
                        size_t idx_jp = ((size_t)i*Lb + jp)*Lb + k;
                        size_t idx_jm = ((size_t)i*Lb + jm)*Lb + k;
                        size_t idx_kp = ((size_t)i*Lb + j)*Lb + kp;
                        size_t idx_km = ((size_t)i*Lb + j)*Lb + km;
                        sum += w * ( X[idx_ip*nstate + s] + X[idx_im*nstate + s] +
                                    X[idx_jp*nstate + s] + X[idx_jm*nstate + s] +
                                    X[idx_kp*nstate + s] + X[idx_km*nstate + s] );
                    }
                    double kinetic = -half_inv_h2 * sum;
                    double local = vloc[base] * X[base*nstate + s];
                    Y[base*nstate + s] = kinetic + local;
                }
            }
        }
    }
    // projection term: proj_f^T * X -> tmp -> proj_f * tmp using BLAS for efficiency
    // Projection term using BLAS with reusable static buffers
    static double *overlap = NULL;
    static double *tmp = NULL;
    static double *proj_term = NULL;
    static int64_t saved_Lb = -1, saved_nproj = -1, saved_nstate = -1;
    size_t L3_sz = (size_t)Lb * Lb * Lb;
    if (saved_Lb != Lb || saved_nproj != nproj || saved_nstate != nstate) {
        free(overlap);
        free(tmp);
        free(proj_term);
        overlap = (double *)malloc((size_t)nproj * nstate * sizeof(double));
        tmp = (double *)malloc((size_t)nproj * nstate * sizeof(double));
        proj_term = (double *)malloc(L3 * nstate * sizeof(double));
        saved_Lb = Lb;
        saved_nproj = nproj;
        saved_nstate = nstate;
    }
    // overlap = proj_f^T * X
    cblas_dgemm(CblasRowMajor, CblasTrans, CblasNoTrans,
                (int)nproj, (int)nstate, (int)L3,
                1.0, proj_f, (int)nproj,
                X, (int)nstate,
                0.0, overlap, (int)nstate);
    // tmp = dij_f * overlap
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                (int)nproj, (int)nstate, (int)nproj,
                1.0, dij_f, (int)nproj,
                overlap, (int)nstate,
                0.0, tmp, (int)nstate);
    // proj_term = proj_f * tmp
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                (int)L3, (int)nstate, (int)nproj,
                1.0, proj_f, (int)nproj,
                tmp, (int)nstate,
                0.0, proj_term, (int)nstate);
    // add projection term
    for (int64_t p = 0; p < L3; ++p) {
        for (int64_t s = 0; s < nstate; ++s) {
            Y[p*nstate + s] += proj_term[p*nstate + s];
        }
    }
    // static buffers will be freed at program termination
}

// Rayleigh‑Ritz: orthonormalize Y and solve generalized eigenproblem
#if 1
static void rayleigh_ritz(const double *vloc, const double *proj_f, const double *dij_f,
                          const double *row, int64_t Lb, int64_t nproj, int64_t nstate,
                          double half_inv_h2, const double *Yin, double *Yout, double *eigvals) {
    const int64_t L3 = Lb*Lb*Lb;
    // Allocate buffers
    double *Y = (double *)malloc((size_t)L3 * nstate * sizeof(double));
    double *W = (double *)malloc((size_t)L3 * nstate * sizeof(double));
    memcpy(Y, Yin, (size_t)L3 * nstate * sizeof(double));
    // H*Y
    hpsi_apply(Y, row, vloc, proj_f, dij_f, Lb, nproj, nstate, half_inv_h2, W);
    // h_sub = 0.5*(Y^T*W + (Y^T*W)^T)
    double *YT_W = (double *)malloc((size_t)nstate * nstate * sizeof(double));
    cblas_dgemm(CblasRowMajor, CblasTrans, CblasNoTrans,
                (int)nstate, (int)nstate, (int)L3,
                0.5, Y, (int)nstate,
                W, (int)nstate,
                0.0, YT_W, (int)nstate);
    // symmetrize
    for (int i = 0; i < nstate; ++i) {
        for (int j = i+1; j < nstate; ++j) {
            double avg = 0.5 * (YT_W[i*nstate + j] + YT_W[j*nstate + i]);
            YT_W[i*nstate + j] = avg;
            YT_W[j*nstate + i] = avg;
        }
    }
    // s_sub = 0.5*(Y^T*Y + (Y^T*Y)^T) + eps*I
    double *YT_Y = (double *)malloc((size_t)nstate * nstate * sizeof(double));
    cblas_dgemm(CblasRowMajor, CblasTrans, CblasNoTrans,
                (int)nstate, (int)nstate, (int)L3,
                0.5, Y, (int)nstate,
                Y, (int)nstate,
                0.0, YT_Y, (int)nstate);
    const double eps = 1e-12;
    for (int i = 0; i < nstate; ++i) {
        YT_Y[i*nstate + i] += eps;
        for (int j = i+1; j < nstate; ++j) {
            double avg = 0.5 * (YT_Y[i*nstate + j] + YT_Y[j*nstate + i]);
            YT_Y[i*nstate + j] = avg;
            YT_Y[j*nstate + i] = avg;
        }
    }
    // Cholesky of s_sub (lower triangular)
    int info = LAPACKE_dpotrf(LAPACK_ROW_MAJOR, 'L', (int)nstate, YT_Y, (int)nstate);
    if (info != 0) {
        // fallback to identity
        for (int i = 0; i < nstate; ++i) {
            for (int j = 0; j < nstate; ++j) {
                YT_Y[i*nstate + j] = (i==j) ? 1.0 : 0.0;
            }
        }
    }
    // Compute Linv = inverse of lower triangular L
    double *Linv = (double *)malloc((size_t)nstate * nstate * sizeof(double));
    // Copy lower triangle
    for (int i = 0; i < nstate; ++i) {
        for (int j = 0; j <= i; ++j) {
            Linv[i*nstate + j] = YT_Y[i*nstate + j];
        }
        for (int j = i+1; j < nstate; ++j) {
            Linv[i*nstate + j] = 0.0;
        }
    }
    info = LAPACKE_dtrtri(LAPACK_ROW_MAJOR, 'L', 'N', (int)nstate, Linv, (int)nstate);
    if (info != 0) {
        // fallback to identity
        for (int i = 0; i < nstate; ++i) {
            for (int j = 0; j < nstate; ++j) {
                Linv[i*nstate + j] = (i==j) ? 1.0 : 0.0;
            }
        }
    }
    // M = Linv * h_sub * Linv^T
    double *tmp2 = (double *)malloc((size_t)nstate * nstate * sizeof(double));
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                (int)nstate, (int)nstate, (int)nstate,
                1.0, Linv, (int)nstate,
                YT_W, (int)nstate,
                0.0, tmp2, (int)nstate);
    double *M = (double *)malloc((size_t)nstate * nstate * sizeof(double));
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasTrans,
                (int)nstate, (int)nstate, (int)nstate,
                1.0, tmp2, (int)nstate,
                Linv, (int)nstate,
                0.0, M, (int)nstate);
    free(tmp2);
    // Eigen‑decomposition of M (symmetric)
    double *eigvec = (double *)malloc((size_t)nstate * nstate * sizeof(double));
    memcpy(eigvec, M, (size_t)nstate * nstate * sizeof(double));
    double *w = (double *)malloc((size_t)nstate * sizeof(double));
    info = LAPACKE_dsyev(LAPACK_ROW_MAJOR, 'V', 'U', (int)nstate, eigvec, (int)nstate, w);
    if (info != 0) {
        for (int i = 0; i < nstate; ++i) {
            w[i] = 0.0;
            for (int j = 0; j < nstate; ++j) eigvec[i*nstate + j] = (i==j) ? 1.0 : 0.0;
        }
    }
    // Ensure eigenvectors have positive first component (sign consistency)
    for (int col = 0; col < nstate; ++col) {
        int piv = 0;
        double maxabs = fabs(eigvec[0*nstate + col]);
        for (int row = 1; row < nstate; ++row) {
            double val = fabs(eigvec[row*nstate + col]);
            if (val > maxabs) { maxabs = val; piv = row; }
        }
        if (eigvec[piv*nstate + col] < 0.0) {
            for (int row = 0; row < nstate; ++row) {
                eigvec[row*nstate + col] *= -1.0;
            }
        }
    }
    // C = Linv^T * U
    double *Cmat = (double *)malloc((size_t)nstate * nstate * sizeof(double));
    cblas_dgemm(CblasRowMajor, CblasTrans, CblasNoTrans,
                (int)nstate, (int)nstate, (int)nstate,
                1.0, Linv, (int)nstate,
                eigvec, (int)nstate,
                0.0, Cmat, (int)nstate);
    // Ritz vectors: Yout = Y * C
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                (int)L3, (int)nstate, (int)nstate,
                1.0, Y, (int)nstate,
                Cmat, (int)nstate,
                0.0, Yout, (int)nstate);
    // copy eigenvalues
    for (int i = 0; i < nstate; ++i) eigvals[i] = w[i];
    // cleanup
    free(Y);
    free(W);
    free(YT_W);
    free(YT_Y);
    free(Linv);
    free(M);
    free(eigvec);
    free(w);
    free(Cmat);
}

// Chebyshev filter of degree m applied to block X, result in Yout
#endif
static void cheb_filter(const double *vloc, const double *proj_f, const double *dij_f,
                         const double *row, int64_t Lb, int64_t nproj, int64_t nstate,
                         double half_inv_h2, const double *Xin, int64_t m,
                         double a, double b, double a0,
                         double *Yout) {
    double e = 0.5 * (b - a);
    double c = 0.5 * (b + a);
    double sigma = e / (a0 - c);
    double sigma1 = sigma;
    // Allocate buffers
    double *Y = (double *)malloc((size_t)Lb*Lb*Lb * nstate * sizeof(double));
    double *X = (double *)malloc((size_t)Lb*Lb*Lb * nstate * sizeof(double));
    memcpy(X, Xin, (size_t)Lb*Lb*Lb * nstate * sizeof(double));
    // First iteration
    hpsi_apply(X, row, vloc, proj_f, dij_f, Lb, nproj, nstate, half_inv_h2, Y);
        for (int64_t p = 0; p < Lb*Lb*Lb; ++p) {
        for (int64_t s = 0; s < nstate; ++s) {
            Y[p*nstate + s] = (Y[p*nstate + s] - c * X[p*nstate + s]) * (sigma1 / e);
        }
    }
    for (int64_t iter = 2; iter <= m; ++iter) {
        double sigma_new = 1.0 / (2.0 / sigma1 - sigma);
        double *HY = (double *)malloc((size_t)Lb*Lb*Lb * nstate * sizeof(double));
        hpsi_apply(Y, row, vloc, proj_f, dij_f, Lb, nproj, nstate, half_inv_h2, HY);
                for (int64_t p = 0; p < Lb*Lb*Lb; ++p) {
            for (int64_t s = 0; s < nstate; ++s) {
                double term1 = (HY[p*nstate + s] - c * Y[p*nstate + s]) * (2.0 * sigma_new / e);
                double term2 = sigma * sigma_new * X[p*nstate + s];
                double Ynew = term1 - term2;
                X[p*nstate + s] = Y[p*nstate + s];
                Y[p*nstate + s] = Ynew;
            }
        }
        free(HY);
        sigma = sigma1;
        sigma1 = sigma_new;
    }
    memcpy(Yout, Y, (size_t)Lb*Lb*Lb * nstate * sizeof(double));
    free(Y);
    free(X);
}

void ls3df_scf_fp64(const double *restrict V_ion, double *restrict V_tot,
                    const double *restrict alpha, const double *restrict dij, const double *restrict occ,
                    const int64_t *restrict offsets, const double *restrict proj,
                    double *restrict psi_frag, double *restrict rho,
                    const int64_t Lb, const int64_t N, const double dvol,
                    const double half_inv_h2, const int64_t m, const double mix,
                    const int64_t nfrag, const int64_t nproj, const int64_t nscf,
                    const int64_t nstate, const double tol,
                    uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace; // unused
    printf("Kernel start\n");
#ifdef _OPENMP
    omp_set_num_threads(1);
    omp_set_dynamic(0);
#endif
    (void)workspace_size;
    double h = sqrt(0.5 / half_inv_h2);
    omp_set_num_threads(1);
    omp_set_dynamic(0);
    /* setenv("OPENBLAS_NUM_THREADS", "1", 1); */
    // kinetic stencil
    double *row = make_stencil(Lb);
    // Poisson kernel
    double *kx, *invgsq;
    build_poisson_terms(N, h, &kx, &invgsq);
    // FFT buffers
    int64_t N3 = N*N*N;
    fftw_complex *fft_in = (fftw_complex*)fftw_malloc(sizeof(fftw_complex) * (size_t)N3);
    fftw_complex *fft_out = (fftw_complex*)fftw_malloc(sizeof(fftw_complex) * (size_t)N3);
    fftw_plan plan_fwd = fftw_plan_dft_3d((int)N, (int)N, (int)N, fft_in, fft_out, FFTW_FORWARD, FFTW_ESTIMATE);
    fftw_plan plan_bwd = fftw_plan_dft_3d((int)N, (int)N, (int)N, fft_in, fft_out, FFTW_BACKWARD, FFTW_ESTIMATE);
    // Allocate density buffers
    double *rho_cur = (double *)malloc((size_t)N3 * sizeof(double));
    double *rho_new = (double *)malloc((size_t)N3 * sizeof(double));
    memcpy(rho_cur, rho, (size_t)N3 * sizeof(double));
    // Compute total electron number
    double nelec = 0.0;
    for (int64_t i = 0; i < N3; ++i) nelec += rho_cur[i];
    nelec *= dvol;
    // Allocate helper arrays for fragment handling (reused each SCF step)
    int64_t *xs = (int64_t *)malloc((size_t)Lb * sizeof(int64_t));
    int64_t *ys = (int64_t *)malloc((size_t)Lb * sizeof(int64_t));
    int64_t *zs = (int64_t *)malloc((size_t)Lb * sizeof(int64_t));
    double *vloc = (double *)malloc((size_t)Lb*Lb*Lb * sizeof(double));
    double *X = (double *)malloc((size_t)Lb*Lb*Lb * nstate * sizeof(double));
    double *Y = (double *)malloc((size_t)Lb*Lb*Lb * nstate * sizeof(double));
    double *dens = (double *)malloc((size_t)Lb*Lb*Lb * sizeof(double));
    // Prepare box array (0..Lb-1)
    int64_t *box = (int64_t *)malloc((size_t)Lb * sizeof(int64_t));
    for (int64_t i = 0; i < Lb; ++i) box[i] = i;
    // Pre‑allocate projection buffers (shared across fragments)
    double *proj_f = (double *)malloc((size_t)Lb*Lb*Lb * nproj * sizeof(double));
    double *dij_f = (double *)malloc((size_t)nproj * nproj * sizeof(double));
    // ---- initial potential (genpot) ---------------------------------
    // Compute mean of rho_cur
    double rho_mean = 0.0;
    for (int64_t i = 0; i < N3; ++i) rho_mean += rho_cur[i];
    rho_mean /= (double)N3;
        // Compute mean of rho_cur
        rho_mean = 0.0;
    for (int64_t i = 0; i < N3; ++i) rho_mean += rho_cur[i];
    rho_mean /= (double)N3;
    for (int64_t i = 0; i < N3; ++i) {
        double val = rho_cur[i] - rho_mean;
        fft_in[i] = val + 0.0*I;
    }
    fftw_execute(plan_fwd);
    const double four_pi = 4.0 * M_PI;
    for (int64_t i = 0; i < N3; ++i) {
        double re = creal(fft_out[i]);
        double im = cimag(fft_out[i]);
        double factor = four_pi * invgsq[i];
        fft_in[i] = (re * factor) + (im * factor) * I;
    }
    fftw_execute(plan_bwd);
    for (int64_t i = 0; i < N3; ++i) {
        V_tot[i] = creal(fft_in[i]) / (double)N3; // real part normalized
    }
    // Exchange‑correlation potential
    double *vxc = (double *)malloc((size_t)N3 * sizeof(double));
    lda_xc(rho_cur, vxc, N3);
    double vtot_sum = 0.0;
    for (int64_t i = 0; i < N3; ++i) {
        V_tot[i] = V_tot[i] + V_ion[i] + vxc[i];
        vtot_sum += V_tot[i];
    }
    double vtot_mean = vtot_sum / (double)N3;
    for (int64_t i = 0; i < N3; ++i) V_tot[i] -= vtot_mean;
    free(vxc);
    printf("Kernel after init potential\n");
    // ----- SCF loop ---------------------------------------------------
    for (int64_t it = 0; it < nscf; ++it) {
        memset(rho_new, 0, (size_t)N3 * sizeof(double));
        // Loop over fragments (sequential; could be parallelised later)
        for (int64_t f = 0; f < nfrag; ++f) {
            // compute wrapped indices for this fragment
            for (int64_t i = 0; i < Lb; ++i) {
                xs[i] = py_mod(offsets[f*3 + 0] + box[i], N);
                ys[i] = py_mod(offsets[f*3 + 1] + box[i], N);
                zs[i] = py_mod(offsets[f*3 + 2] + box[i], N);
            }
            // gather local potential
            for (int64_t i = 0; i < Lb; ++i) {
                for (int64_t j = 0; j < Lb; ++j) {
                    for (int64_t k = 0; k < Lb; ++k) {
                        size_t gidx = ((size_t)xs[i] * N + ys[j]) * N + zs[k];
                        size_t lidx = ((size_t)i * Lb + j) * Lb + k;
                        vloc[lidx] = V_tot[gidx];
                    }
                }
            }
            // extract fragment‑wise projector and Dij matrices
            for (int64_t i = 0; i < Lb*Lb*Lb; ++i) {
                for (int64_t j = 0; j < nproj; ++j) {
                    proj_f[i*nproj + j] = proj[f * ((Lb*Lb*Lb) * nproj) + i*nproj + j];
                }
            }
            for (int64_t i = 0; i < nproj; ++i) {
                for (int64_t j = 0; j < nproj; ++j) {
                    dij_f[i*nproj + j] = dij[f * nproj * nproj + i*nproj + j];
                }
            }
            // extract current fragment wavefunctions into X (size L3 x nstate)
            for (int64_t p = 0; p < Lb*Lb*Lb; ++p) {
                for (int64_t s = 0; s < nstate; ++s) {
                    X[p*nstate + s] = psi_frag[f * ((Lb*Lb*Lb) * nstate) + p*nstate + s];
                }
            }
            // Rayleigh‑Ritz on X
            double wvals[64]; // assuming nstate <= 64
            rayleigh_ritz(vloc, proj_f, dij_f, row, Lb, nproj, nstate, half_inv_h2, X, Y, wvals);
            // Determine Chebyshev filter bounds
            double w_low = wvals[0];
            double w_high = wvals[nstate-1];
            double b_hi = w_high * 1.1 + 1.0;
            // Chebyshev filter (using w_low as a0)
            cheb_filter(vloc, proj_f, dij_f, row, Lb, nproj, nstate,
                        half_inv_h2, Y, (int)m, w_low, b_hi, w_low, X);
            // Second Rayleigh‑Ritz on filtered subspace
            rayleigh_ritz(vloc, proj_f, dij_f, row, Lb, nproj, nstate, half_inv_h2, X, Y, wvals);
            // Write back updated fragment wavefunctions
            for (int64_t p = 0; p < Lb*Lb*Lb; ++p) {
                for (int64_t s = 0; s < nstate; ++s) {
                    psi_frag[f * ((Lb*Lb*Lb) * nstate) + p*nstate + s] = Y[p*nstate + s];
                }
            }
            // Compute fragment density contribution
            for (int64_t p = 0; p < Lb*Lb*Lb; ++p) {
                double d = 0.0;
                for (int64_t s = 0; s < nstate; ++s) {
                    double val = Y[p*nstate + s];
                    d += occ[s] * val * val;
                }
                dens[p] = d;
            }
            // Scatter‑add to global rho_new with fragment weight alpha
            for (int64_t i = 0; i < Lb; ++i) {
                for (int64_t j = 0; j < Lb; ++j) {
                    for (int64_t k = 0; k < Lb; ++k) {
                        size_t gidx = ((size_t)xs[i] * N + ys[j]) * N + zs[k];
                        size_t lidx = ((size_t)i * Lb + j) * Lb + k;
                        rho_new[gidx] += alpha[f] * dens[lidx];
                    }
                }
            }
        }
        // Enforce positivity and normalize electron count
        for (int64_t i = 0; i < N3; ++i) {
            if (rho_new[i] < 0.0) rho_new[i] = 0.0;
        }
        double q = 0.0;
        for (int64_t i = 0; i < N3; ++i) q += rho_new[i];
        q *= dvol;
        if (q > 0.0) {
            double scale = nelec / q;
            for (int64_t i = 0; i < N3; ++i) rho_new[i] *= scale;
        }
        // Check convergence (relative density change)
        double num = 0.0, den = 0.0;
        for (int64_t i = 0; i < N3; ++i) {
            double diff = fabs(rho_new[i] - rho_cur[i]);
            num += diff;
            den += fabs(rho_cur[i]);
        }
        double rho_err = num / (den + 1e-30);
        // Mix densities
        for (int64_t i = 0; i < N3; ++i) {
            rho_cur[i] = rho_cur[i] + mix * (rho_new[i] - rho_cur[i]);
        }
        // Recompute V_tot for next iteration (same as initial step)
        rho_mean = 0.0;
        for (int64_t i = 0; i < N3; ++i) rho_mean += rho_cur[i];
        rho_mean /= (double)N3;
        // Re‑compute Hartree potential via FFT
        for (int64_t i = 0; i < N3; ++i) {
            double val = rho_cur[i] - rho_mean;
            fft_in[i] = val + 0.0*I;
        }
        fftw_execute(plan_fwd);
        for (int64_t i = 0; i < N3; ++i) {
            double re = creal(fft_out[i]);
            double im = cimag(fft_out[i]);
            double factor = four_pi * invgsq[i];
            fft_in[i] = (re * factor) + (im * factor) * I;
        }
        fftw_execute(plan_bwd);
        for (int64_t i = 0; i < N3; ++i) {
            V_tot[i] = creal(fft_in[i]) / (double)N3;
        }
        // Exchange‑correlation
        vxc = (double *)malloc((size_t)N3 * sizeof(double));
        lda_xc(rho_cur, vxc, N3);
        vtot_sum = 0.0;
        for (int64_t i = 0; i < N3; ++i) {
            V_tot[i] = V_tot[i] + V_ion[i] + vxc[i];
            vtot_sum += V_tot[i];
        }
        vtot_mean = vtot_sum / (double)N3;
        for (int64_t i = 0; i < N3; ++i) V_tot[i] -= vtot_mean;
        free(vxc);
    printf("Kernel after init potential\n");
        if (rho_err < tol) break;
    }
    // Copy final density back to output array
    memcpy(rho, rho_cur, (size_t)N3 * sizeof(double));
    // Cleanup
    free(row);
    free(kx);
    free(invgsq);
    fftw_destroy_plan(plan_fwd);
    fftw_destroy_plan(plan_bwd);
    fftw_free(fft_in);
    fftw_free(fft_out);
    free(rho_cur);
    free(rho_new);
    free(xs);
    free(ys);
    free(zs);
    free(vloc);
    free(X);
    free(Y);
    free(dens);
    free(box);
    free(proj_f);
    free(dij_f);
}

