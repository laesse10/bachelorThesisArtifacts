// hpcagent_bench-autogen -- generated from cloudsc_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

void cloudsc_fp64(const int32_t *restrict ktype, const int32_t *restrict ldcum, const double *restrict pa, const double *restrict pap, const double *restrict paph, const double *restrict pccn, const double *restrict pclv, double *restrict pcovptot, const double *restrict pdyna, const double *restrict pdyni, const double *restrict pdynl, double *restrict pfcqlng, double *restrict pfcqnng, double *restrict pfcqrng, double *restrict pfcqsng, double *restrict pfhpsl, double *restrict pfhpsn, double *restrict pfplsl, double *restrict pfplsn, double *restrict pfsqif, double *restrict pfsqitur, double *restrict pfsqlf, double *restrict pfsqltur, double *restrict pfsqrf, double *restrict pfsqsf, const double *restrict phrlw, const double *restrict phrsw, const double *restrict picrit_aer, const double *restrict plcrit_aer, const double *restrict plsm, const double *restrict plu, double *restrict plude, const double *restrict pmfd, const double *restrict pmfu, const double *restrict pnice, const double *restrict pq, double *restrict prainfrac_toprfz, const double *restrict pre_ice, const double *restrict psnde, const double *restrict psupsat, const double *restrict pt, const double *restrict pvervel, const double *restrict pvfa, const double *restrict pvfi, const double *restrict pvfl, double *restrict tendency_loc_a, double *restrict tendency_loc_cld, double *restrict tendency_loc_q, double *restrict tendency_loc_t, const double *restrict tendency_tmp_a, const double *restrict tendency_tmp_cld, const double *restrict tendency_tmp_q, const double *restrict tendency_tmp_t, const int64_t kfdia, const int64_t kidia, const int64_t klon, const int64_t nlev, const double ptsphy, uint8_t *restrict workspace, const int64_t workspace_size) {
        double ztw1;
        double ztw2;
        double ztw3;
        double ztw4;
        double ztw5;
        double zepsilon;
        int64_t iwarmrain;
        int64_t ievaprain;
        int64_t ievapsnow;
        int64_t idepice;
        double zqtmst;
        double zgdcp;
        double zrdcp;
        double zcons1a;
        double zepsec;
        double zrg_r;
        double zrldcp;
        int64_t im2;
        int64_t im;
        double zre_ice;
        double *zlcond1 = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zlcond1, (size_t)((klon)) * sizeof(double), "zlcond1");
        double *zlcond2 = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zlcond2, (size_t)((klon)) * sizeof(double), "zlcond2");
        double *zlevapl = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zlevapl, (size_t)((klon)) * sizeof(double), "zlevapl");
        double *zlevapi = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zlevapi, (size_t)((klon)) * sizeof(double), "zlevapi");
        double *zrainaut = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zrainaut, (size_t)((klon)) * sizeof(double), "zrainaut");
        double *zsnowaut = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zsnowaut, (size_t)((klon)) * sizeof(double), "zsnowaut");
        double *zliqcld = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zliqcld, (size_t)((klon)) * sizeof(double), "zliqcld");
        double *zicecld = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zicecld, (size_t)((klon)) * sizeof(double), "zicecld");
        double *zfokoop = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zfokoop, (size_t)((klon)) * sizeof(double), "zfokoop");
        double *zicenuclei = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zicenuclei, (size_t)((klon)) * sizeof(double), "zicenuclei");
        double *zlicld = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zlicld, (size_t)((klon)) * sizeof(double), "zlicld");
        double *zlfinalsum = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zlfinalsum, (size_t)((klon)) * sizeof(double), "zlfinalsum");
        double *zdqs = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zdqs, (size_t)((klon)) * sizeof(double), "zdqs");
        double *ztold = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(ztold, (size_t)((klon)) * sizeof(double), "ztold");
        double *zqold = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zqold, (size_t)((klon)) * sizeof(double), "zqold");
        double *zdtgdp = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zdtgdp, (size_t)((klon)) * sizeof(double), "zdtgdp");
        double *zrdtgdp = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zrdtgdp, (size_t)((klon)) * sizeof(double), "zrdtgdp");
        double *ztrpaus = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(ztrpaus, (size_t)((klon)) * sizeof(double), "ztrpaus");
        double *zcovpclr = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zcovpclr, (size_t)((klon)) * sizeof(double), "zcovpclr");
        double *zcovptot = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zcovptot, (size_t)((klon)) * sizeof(double), "zcovptot");
        double *zcovpmax = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zcovpmax, (size_t)((klon)) * sizeof(double), "zcovpmax");
        double *zqpretot = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zqpretot, (size_t)((klon)) * sizeof(double), "zqpretot");
        double *zldefr = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zldefr, (size_t)((klon)) * sizeof(double), "zldefr");
        double *zldifdt = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zldifdt, (size_t)((klon)) * sizeof(double), "zldifdt");
        double *zdtgdpf = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zdtgdpf, (size_t)((klon)) * sizeof(double), "zdtgdpf");
        double *zacust = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zacust, (size_t)((klon)) * sizeof(double), "zacust");
        double *zmf = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zmf, (size_t)((klon)) * sizeof(double), "zmf");
        double *zrho = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zrho, (size_t)((klon)) * sizeof(double), "zrho");
        double *ztmp1 = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(ztmp1, (size_t)((klon)) * sizeof(double), "ztmp1");
        double *ztmp2 = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(ztmp2, (size_t)((klon)) * sizeof(double), "ztmp2");
        double *ztmp3 = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(ztmp3, (size_t)((klon)) * sizeof(double), "ztmp3");
        double *ztmp4 = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(ztmp4, (size_t)((klon)) * sizeof(double), "ztmp4");
        double *ztmp5 = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(ztmp5, (size_t)((klon)) * sizeof(double), "ztmp5");
        double *ztmp6 = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(ztmp6, (size_t)((klon)) * sizeof(double), "ztmp6");
        double *ztmp7 = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(ztmp7, (size_t)((klon)) * sizeof(double), "ztmp7");
        double *zalfawm = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zalfawm, (size_t)((klon)) * sizeof(double), "zalfawm");
        double *zsolab = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zsolab, (size_t)((klon)) * sizeof(double), "zsolab");
        double *zsolac = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zsolac, (size_t)((klon)) * sizeof(double), "zsolac");
        double *zanewm1 = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zanewm1, (size_t)((klon)) * sizeof(double), "zanewm1");
        double *zgdp = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zgdp, (size_t)((klon)) * sizeof(double), "zgdp");
        double *zda = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zda, (size_t)((klon)) * sizeof(double), "zda");
        double *zdp = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zdp, (size_t)((klon)) * sizeof(double), "zdp");
        double *zpaphd = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zpaphd, (size_t)((klon)) * sizeof(double), "zpaphd");
        double *zmin = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zmin, (size_t)((klon)) * sizeof(double), "zmin");
        double *zsupsat = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zsupsat, (size_t)((klon)) * sizeof(double), "zsupsat");
        double *zmeltmax = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zmeltmax, (size_t)((klon)) * sizeof(double), "zmeltmax");
        double *zfrzmax = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zfrzmax, (size_t)((klon)) * sizeof(double), "zfrzmax");
        double *zicetot = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zicetot, (size_t)((klon)) * sizeof(double), "zicetot");
        double *zdqsliqdt = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zdqsliqdt, (size_t)((klon)) * sizeof(double), "zdqsliqdt");
        double *zdqsicedt = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zdqsicedt, (size_t)((klon)) * sizeof(double), "zdqsicedt");
        double *zdqsmixdt = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zdqsmixdt, (size_t)((klon)) * sizeof(double), "zdqsmixdt");
        double *zcorqsliq = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zcorqsliq, (size_t)((klon)) * sizeof(double), "zcorqsliq");
        double *zcorqsice = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zcorqsice, (size_t)((klon)) * sizeof(double), "zcorqsice");
        double *zcorqsmix = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zcorqsmix, (size_t)((klon)) * sizeof(double), "zcorqsmix");
        double *zevaplimliq = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zevaplimliq, (size_t)((klon)) * sizeof(double), "zevaplimliq");
        double *zevaplimice = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zevaplimice, (size_t)((klon)) * sizeof(double), "zevaplimice");
        double *zevaplimmix = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zevaplimmix, (size_t)((klon)) * sizeof(double), "zevaplimmix");
        double *zcldtopdist = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zcldtopdist, (size_t)((klon)) * sizeof(double), "zcldtopdist");
        double *zrainacc = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zrainacc, (size_t)((klon)) * sizeof(double), "zrainacc");
        double *zraincld = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zraincld, (size_t)((klon)) * sizeof(double), "zraincld");
        double *zsnowrime = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zsnowrime, (size_t)((klon)) * sizeof(double), "zsnowrime");
        double *zsnowcld = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zsnowcld, (size_t)((klon)) * sizeof(double), "zsnowcld");
        double *zrg = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(zrg, (size_t)((klon)) * sizeof(double), "zrg");
        double *psum_solqa = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(psum_solqa, (size_t)((klon)) * sizeof(double), "psum_solqa");
        double *llflag = (double *)malloc((size_t)((klon)) * sizeof(double));
        __npb_alloc_check(llflag, (size_t)((klon)) * sizeof(double), "llflag");
        int32_t *llrainliq = (int32_t *)malloc((size_t)((klon)) * sizeof(int32_t));
        __npb_alloc_check(llrainliq, (size_t)((klon)) * sizeof(int32_t), "llrainliq");
        int32_t iphase[(5)];
        int32_t imelt[(5)];
        int32_t llfall[(5)];
        double zvqx[(5)];
        double *zfoealfa = (double *)malloc((size_t)(((nlev + 1)) * (klon)) * sizeof(double));
        __npb_alloc_check(zfoealfa, (size_t)(((nlev + 1)) * (klon)) * sizeof(double), "zfoealfa");
        double *ztp1 = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(ztp1, (size_t)((nlev) * (klon)) * sizeof(double), "ztp1");
        double *zlcust = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zlcust, (size_t)((5) * (klon)) * sizeof(double), "zlcust");
        double *zli = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zli, (size_t)((nlev) * (klon)) * sizeof(double), "zli");
        double *za = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(za, (size_t)((nlev) * (klon)) * sizeof(double), "za");
        double *zaorig = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zaorig, (size_t)((nlev) * (klon)) * sizeof(double), "zaorig");
        int32_t *llindex1 = (int32_t *)malloc((size_t)((5) * (klon)) * sizeof(int32_t));
        __npb_alloc_check(llindex1, (size_t)((5) * (klon)) * sizeof(int32_t), "llindex1");
        int32_t *llindex3 = (int32_t *)malloc((size_t)((5) * (5) * (klon)) * sizeof(int32_t));
        __npb_alloc_check(llindex3, (size_t)((5) * (5) * (klon)) * sizeof(int32_t), "llindex3");
        int32_t *iorder = (int32_t *)malloc((size_t)((5) * (klon)) * sizeof(int32_t));
        __npb_alloc_check(iorder, (size_t)((5) * (klon)) * sizeof(int32_t), "iorder");
        double *zliqfrac = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zliqfrac, (size_t)((nlev) * (klon)) * sizeof(double), "zliqfrac");
        double *zicefrac = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zicefrac, (size_t)((nlev) * (klon)) * sizeof(double), "zicefrac");
        double *zqx = (double *)malloc((size_t)((5) * (nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zqx, (size_t)((5) * (nlev) * (klon)) * sizeof(double), "zqx");
        double *zqx0 = (double *)malloc((size_t)((5) * (nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zqx0, (size_t)((5) * (nlev) * (klon)) * sizeof(double), "zqx0");
        double *zqxn = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zqxn, (size_t)((5) * (klon)) * sizeof(double), "zqxn");
        double *zqxfg = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zqxfg, (size_t)((5) * (klon)) * sizeof(double), "zqxfg");
        double *zqxnm1 = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zqxnm1, (size_t)((5) * (klon)) * sizeof(double), "zqxnm1");
        double *zfluxq = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zfluxq, (size_t)((5) * (klon)) * sizeof(double), "zfluxq");
        double *zpfplsx = (double *)malloc((size_t)((5) * ((nlev + 1)) * (klon)) * sizeof(double));
        __npb_alloc_check(zpfplsx, (size_t)((5) * ((nlev + 1)) * (klon)) * sizeof(double), "zpfplsx");
        double *zlneg = (double *)malloc((size_t)((5) * (nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zlneg, (size_t)((5) * (nlev) * (klon)) * sizeof(double), "zlneg");
        double *zqxn2d = (double *)malloc((size_t)((5) * (nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zqxn2d, (size_t)((5) * (nlev) * (klon)) * sizeof(double), "zqxn2d");
        double *zqsmix = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zqsmix, (size_t)((nlev) * (klon)) * sizeof(double), "zqsmix");
        double *zqsliq = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zqsliq, (size_t)((nlev) * (klon)) * sizeof(double), "zqsliq");
        double *zqsice = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zqsice, (size_t)((nlev) * (klon)) * sizeof(double), "zqsice");
        double *zfoeewmt = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zfoeewmt, (size_t)((nlev) * (klon)) * sizeof(double), "zfoeewmt");
        double *zfoeew = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zfoeew, (size_t)((nlev) * (klon)) * sizeof(double), "zfoeew");
        double *zfoeeliqt = (double *)malloc((size_t)((nlev) * (klon)) * sizeof(double));
        __npb_alloc_check(zfoeeliqt, (size_t)((nlev) * (klon)) * sizeof(double), "zfoeeliqt");
        double *zsolqa = (double *)malloc((size_t)((5) * (5) * (klon)) * sizeof(double));
        __npb_alloc_check(zsolqa, (size_t)((5) * (5) * (klon)) * sizeof(double), "zsolqa");
        double *zsolqb = (double *)malloc((size_t)((5) * (5) * (klon)) * sizeof(double));
        __npb_alloc_check(zsolqb, (size_t)((5) * (5) * (klon)) * sizeof(double), "zsolqb");
        double *zqlhs = (double *)malloc((size_t)((5) * (5) * (klon)) * sizeof(double));
        __npb_alloc_check(zqlhs, (size_t)((5) * (5) * (klon)) * sizeof(double), "zqlhs");
        double *zratio = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zratio, (size_t)((5) * (klon)) * sizeof(double), "zratio");
        double *zsinksum = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zsinksum, (size_t)((5) * (klon)) * sizeof(double), "zsinksum");
        double *zfallsink = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zfallsink, (size_t)((5) * (klon)) * sizeof(double), "zfallsink");
        double *zfallsrce = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zfallsrce, (size_t)((5) * (klon)) * sizeof(double), "zfallsrce");
        double *zconvsrce = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zconvsrce, (size_t)((5) * (klon)) * sizeof(double), "zconvsrce");
        double *zconvsink = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zconvsink, (size_t)((5) * (klon)) * sizeof(double), "zconvsink");
        double *zpsupsatsrce = (double *)malloc((size_t)((5) * (klon)) * sizeof(double));
        __npb_alloc_check(zpsupsatsrce, (size_t)((5) * (klon)) * sizeof(double), "zpsupsatsrce");
        double *_pw1 = (double *)malloc((size_t)((nlev) * (((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw1, (size_t)((nlev) * (((kfdia - kidia) + 1))) * sizeof(double), "_pw1");
        double *_pw2 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw2, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw2");
        double *_pw3 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw3, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw3");
        double *zmfdn2 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zmfdn2, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zmfdn2");
        memset(zmfdn2, 0, (size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        double *_pw4 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw4, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw4");
        double *_pw5 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw5, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw5");
        double *_pw6 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw6, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw6");
        double *_pw7 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw7, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw7");
        double *_pw8 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw8, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw8");
        double *_pw9 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw9, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw9");
        double *_pw10 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw10, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw10");
        double *_pw11 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw11, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw11");
        double *_pw12 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw12, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw12");
        double *_pw13 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw13, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw13");
        double *_pw14 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw14, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw14");
        double *_pw15 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw15, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw15");
        double *_pw16 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw16, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw16");
        double *_pw17 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw17, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw17");
        double *_pw18 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw18, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw18");
        double *_pw19 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw19, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw19");
        double *_pw20 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw20, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw20");
        double *_pw21 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw21, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw21");
        double *_pw22 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw22, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw22");
        double *_pw23 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw23, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw23");
        double *_pw24 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw24, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw24");
        double *_pw25 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw25, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw25");
        double *zlcrit = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zlcrit, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zlcrit");
        double *_pw27 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw27, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw27");
        double *zzco_d1 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zzco_d1, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zzco_d1");
        double *_pw30 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw30, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw30");
        double *_pw31 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw31, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw31");
        double *_pw32 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw32, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw32");
        double *_pw33 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw33, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw33");
        double *_pw34 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw34, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw34");
        double *_pw35 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw35, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw35");
        double *_pw36 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw36, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw36");
        double *_pw37 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw37, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw37");
        double *_pw38 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw38, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw38");
        double *_pw39 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw39, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw39");
        double *_pw40 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw40, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw40");
        double *_pw41 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw41, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw41");
        double *_pw42 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw42, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw42");
        double *_pw43 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw43, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw43");
        double *_pw44 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw44, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw44");
        double *_pw45 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw45, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw45");
        double *_pw46 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw46, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw46");
        double *_pw47 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw47, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw47");
        double *_pw48 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw48, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw48");
        double *_pw49 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw49, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw49");
        double *_pw50 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw50, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw50");
        double *_pw51 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw51, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw51");
        double *_pw52 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw52, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw52");
        double *_pw53 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw53, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw53");
        double *_pw54 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw54, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw54");
        double *_pw55 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw55, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw55");
        double *_pw56 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw56, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw56");
        double *_pw57 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw57, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw57");
        double *zexplicit = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zexplicit, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zexplicit");
        memset(zexplicit, 0, (size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        double *__cb1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb1");
        double *__cb2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb2");
        double *__cb3 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb3, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb3");
        double *__cb4 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb4, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb4");
        double *__cb5 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb5, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb5");
        double *__cb6 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb6, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb6");
        double *__cb7 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb7, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb7");
        double *__cb8 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb8, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb8");
        double *__cb9 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb9, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb9");
        double *__cb10 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb10, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb10");
        double *__cb11 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb11, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb11");
        double *__cb12 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb12, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb12");
        double *__cb13 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb13, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb13");
        double *__cb14 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb14, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb14");
        double *__cb15 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb15, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb15");
        double *__cb16 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb16, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb16");
        double *__cb17 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb17, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb17");
        double *__cb18 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb18, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb18");
        double *__cb19 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb19, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb19");
        double *__cb20 = (double *)malloc((size_t)((nlev) * (((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(__cb20, (size_t)((nlev) * (((kfdia - kidia) + 1))) * sizeof(double), "__cb20");
        double *__cb21 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb21, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb21");
        double *__cb22 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb22, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb22");
        double *__cb23 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb23, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb23");
        double *__cb24 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb24, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb24");
        double *__cb25 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb25, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb25");
        double *__cb26 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb26, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb26");
        double *__cb27 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb27, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb27");
        double *__cb28 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb28, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb28");
        double *__cb29 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb29, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb29");
        double *__cb30 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb30, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb30");
        double *__cb31 = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb31, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "__cb31");
        double *__cb32 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb32, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb32");
        double *__cb33 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb33, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb33");
        double *__cb34 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb34, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb34");
        double *__cb35 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb35, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb35");
        double *__cb36 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb36, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb36");
        double *__cb37 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb37, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb37");
        double *__cb38 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb38, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb38");
        double *__cb39 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb39, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb39");
        double *__cb40 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb40, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb40");
        double *__cb41 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb41, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb41");
        double *__cb42 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb42, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb42");
        double *__cb43 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb43, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb43");
        double *__cb44 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb44, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb44");
        double *__cb45 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb45, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb45");
        double *__cb46 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb46, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb46");
        double *__cb47 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb47, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb47");
        double *__cb48 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb48, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb48");
        double *__cb49 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb49, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb49");
        double *__cb50 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb50, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb50");
        double *__cb51 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb51, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb51");
        double *__cb52 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb52, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb52");
        double *__cb53 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb53, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb53");
        double *__cb54 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb54, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb54");
        double *__cb55 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb55, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb55");
        double *__cb56 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb56, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb56");
        double *__cb57 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb57, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb57");
        double *__cb58 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb58, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb58");
        double *__cb59 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb59, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb59");
        double *__cb60 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb60, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb60");
        double *__cb61 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb61, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb61");
        double *__cb62 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb62, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb62");
        double *__cb63 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb63, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb63");
        double *__cb64 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb64, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb64");
        double *__cb65 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb65, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb65");
        double *__cb66 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb66, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb66");
        double *__cb67 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb67, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb67");
        double *__cb68 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb68, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb68");
        double *__cb69 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb69, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb69");
        double *__cb70 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb70, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb70");
        double *__cb71 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb71, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb71");
        double *__cb72 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb72, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb72");
        double *__cb73 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb73, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb73");
        double *__cb74 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb74, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb74");
        double *__cb75 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb75, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb75");
        double *__cb76 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb76, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb76");
        double *__cb77 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb77, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb77");
        double *__cb78 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb78, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb78");
        double *__cb79 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb79, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb79");
        double *__cb80 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb80, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb80");
        double *__cb81 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb81, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb81");
        double *__cb82 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb82, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb82");
        double *__cb83 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb83, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb83");
        double *__cb84 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb84, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb84");
        double *__cb85 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb85, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb85");
        double *__cb86 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb86, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb86");
        double *__cb87 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb87, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb87");
        double *__cb88 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb88, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb88");
        double *__cb89 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb89, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb89");
        double *__cb90 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb90, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb90");
        double *__cb91 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb91, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb91");
        double *__cb92 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb92, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb92");
        double *__cb93 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb93, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb93");
        double *__cb94 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb94, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb94");
        double *__cb95 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(__cb95, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "__cb95");
        double *__cb96 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb96, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb96");
        double *__cb97 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb97, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb97");
        double *__cb98 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(__cb98, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "__cb98");
        double *__cb99 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb99, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb99");
        double *__cb100 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb100, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb100");
        double *__cb101 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(__cb101, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "__cb101");
        double *__cb102 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb102, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb102");
        double *__cb103 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb103, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb103");
        double *__cb104 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(__cb104, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "__cb104");
        double *__cb105 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb105, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb105");
        double *__cb106 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb106, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb106");
        double *__cb107 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb107, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb107");
        double *__cb108 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb108, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb108");
        double *__cb109 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb109, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb109");
        double *__cb110 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb110, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb110");
        double *__cb111 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb111, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb111");
        double *__cb112 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb112, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb112");
        double *__cb113 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb113, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb113");
        double *__cb114 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb114, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb114");
        double *__cb115 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb115, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb115");
        double *__cb116 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb116, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb116");
        double *__cb117 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb117, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb117");
        double *__cb118 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(__cb118, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "__cb118");
        double *__cb119 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb119, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb119");
        double *__cb120 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb120, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb120");
        double *__cb121 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb121, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb121");
        double *__cb122 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb122, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb122");
        double *__cb123 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb123, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb123");
        double *__cb124 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb124, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb124");
        double *__cb125 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb125, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb125");
        double *__cb126 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb126, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb126");
        double *__cb127 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb127, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb127");
        double *__cb128 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb128, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb128");
        double *__cb129 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb129, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb129");
        double *__cb130 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb130, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb130");
        double *__cb131 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb131, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb131");
        double *__cb132 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb132, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb132");
        double *__cb133 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb133, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb133");
        double *__cb134 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb134, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb134");
        double *__cb135 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb135, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb135");
        double *__cb136 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb136, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb136");
        double *__cb137 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb137, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb137");
        double *__cb138 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb138, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb138");
        double *__cb139 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb139, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb139");
        double *__cb140 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb140, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb140");
        double *__cb141 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb141, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb141");
        double *__cb142 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb142, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb142");
        double *__cb143 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb143, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb143");
        double *__cb144 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb144, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb144");
        double *__cb145 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb145, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb145");
        double *__cb146 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb146, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb146");
        double *__cb147 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb147, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb147");
        double *__cb148 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb148, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb148");
        double *__cb149 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb149, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb149");
        double *__cb150 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb150, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb150");
        double *__cb151 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb151, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb151");
        double *__cb152 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb152, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb152");
        double *__cb153 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb153, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb153");
        double *__cb154 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb154, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb154");
        double *__cb155 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb155, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb155");
        double *__cb156 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb156, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb156");
        double *__cb157 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb157, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb157");
        double *__cb158 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb158, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb158");
        double *__cb159 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb159, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb159");
        double *__cb160 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb160, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb160");
        double *__cb161 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb161, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb161");
        double *__cb162 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb162, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb162");
        double *__cb163 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb163, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb163");
        double *__cb164 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb164, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb164");
        double *__cb165 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb165, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb165");
        double *__cb166 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb166, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb166");
        double *__cb167 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb167, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb167");
        double *__cb168 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb168, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb168");
        double *__cb169 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb169, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb169");
        double *__cb170 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb170, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb170");
        double *__cb171 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb171, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb171");
        double *__cb172 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb172, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb172");
        double *__cb173 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb173, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb173");
        double *__cb174 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb174, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb174");
        double *__cb175 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb175, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb175");
        double *__cb176 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb176, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb176");
        double *__cb177 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb177, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb177");
        double *__cb178 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb178, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb178");
        double *__cb179 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb179, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb179");
        double *__cb180 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb180, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb180");
        double *__cb181 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb181, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb181");
        double *__cb182 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb182, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb182");
        double *__cb183 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb183, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb183");
        double *__cb184 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb184, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb184");
        double *__cb185 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb185, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb185");
        double *__cb186 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb186, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb186");
        double *__cb187 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb187, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb187");
        double *__cb188 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb188, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb188");
        double *__cb189 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb189, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb189");
        double *__cb190 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb190, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb190");
        double *__cb191 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb191, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb191");
        double *__cb192 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb192, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb192");
        double *__cb193 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb193, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb193");
        double *__cb194 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb194, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb194");
        double *__cb195 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb195, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb195");
        double *__cb196 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb196, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb196");
        double *__cb197 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb197, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb197");
        double *__cb198 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb198, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb198");
        double *__cb199 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb199, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb199");
        double *__cb200 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb200, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb200");
        double *__cb201 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb201, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb201");
        double *__cb202 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb202, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb202");
        double *__cb203 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb203, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb203");
        double *__cb204 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb204, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb204");
        double *__cb205 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb205, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb205");
        double *__cb206 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb206, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb206");
        double *__cb207 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb207, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb207");
        double *__cb208 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb208, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb208");
        double *__cb209 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb209, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb209");
        double *__cb210 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb210, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb210");
        double *__cb211 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb211, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb211");
        double *__cb212 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb212, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb212");
        double *__cb213 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb213, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb213");
        double *__cb214 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb214, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb214");
        double *__cb215 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb215, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb215");
        double *__cb216 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb216, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb216");
        double *__cb217 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb217, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb217");
        double *__cb218 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb218, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb218");
        double *__cb219 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb219, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb219");
        double *__cb220 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb220, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb220");
        double *__cb221 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb221, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb221");
        double *__cb222 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb222, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb222");
        double *__cb223 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb223, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb223");
        double *__cb224 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb224, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb224");
        double *__cb225 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb225, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb225");
        double *__cb226 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb226, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb226");
        double *__cb227 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb227, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb227");
        double *__cb228 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb228, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb228");
        double *__cb229 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb229, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb229");
        double *__cb230 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb230, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb230");
        double *__cb231 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb231, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb231");
        double *__cb232 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb232, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb232");
        double *__cb233 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb233, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb233");
        double *__cb234 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb234, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb234");
        double *__cb235 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb235, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb235");
        double *__cb236 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb236, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb236");
        double *__cb237 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb237, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb237");
        double *__cb238 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb238, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb238");
        double *__cb239 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb239, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb239");
        double *__cb240 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb240, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb240");
        double *__cb241 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb241, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb241");
        double *__cb242 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb242, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb242");
        double *__cb243 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb243, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb243");
        double *__cb244 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb244, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb244");
        double *__cb245 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb245, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb245");
        double *__cb246 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb246, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb246");
        double *__cb247 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb247, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb247");
        double *__cb248 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb248, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb248");
        double *__cb249 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb249, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb249");
        double *__cb250 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb250, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb250");
        double *__cb251 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb251, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb251");
        double *__cb252 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb252, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb252");
        double *__cb253 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb253, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb253");
        double *__cb254 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb254, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb254");
        double *__cb255 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb255, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb255");
        double *__cb256 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb256, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb256");
        double *__cb257 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb257, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb257");
        double *__cb258 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb258, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb258");
        double *__cb259 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb259, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb259");
        double *__cb260 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb260, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb260");
        double *__cb261 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb261, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb261");
        double *__cb262 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb262, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb262");
        double *__cb263 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb263, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb263");
        double *__cb264 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb264, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb264");
        double *__cb265 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb265, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb265");
        double *__cb266 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb266, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb266");
        double *__cb267 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb267, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb267");
        double *__cb268 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb268, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb268");
        double *__cb269 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb269, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb269");
        double *__cb270 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb270, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb270");
        double *__cb271 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb271, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb271");
        double *__cb272 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb272, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb272");
        double *__cb273 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb273, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb273");
        double *__cb274 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb274, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb274");
        double *__cb275 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb275, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb275");
        double *__cb276 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb276, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb276");
        double *__cb277 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb277, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb277");
        double *__cb278 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb278, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb278");
        double *__cb279 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb279, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb279");
        double *__cb280 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb280, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb280");
        double *__cb281 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb281, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb281");
        double *__cb282 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb282, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb282");
        double *__cb283 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb283, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb283");
        double *__cb284 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb284, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb284");
        double *__cb285 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb285, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb285");
        double *__cb286 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb286, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb286");
        double *__cb287 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb287, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb287");
        double *__cb288 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb288, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb288");
        double *__cb289 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb289, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb289");
        double *__cb290 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb290, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb290");
        double *__cb291 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb291, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb291");
        double *__cb292 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb292, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb292");
        double *__cb293 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb293, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb293");
        double *__cb294 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb294, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb294");
        double *__cb295 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb295, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb295");
        double *__cb296 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb296, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb296");
        double *__cb297 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb297, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb297");
        double *__cb298 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb298, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb298");
        double *__cb299 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb299, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb299");
        double *__cb300 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb300, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb300");
        double *__cb301 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb301, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb301");
        double *__cb302 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb302, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb302");
        double *__cb303 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb303, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb303");
        double *__cb304 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb304, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb304");
        double *__cb305 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb305, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb305");
        double *__cb306 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb306, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb306");
        double *__cb307 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb307, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb307");
        double *__cb308 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb308, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb308");
        double *__cb309 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb309, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb309");
        double *__cb310 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb310, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb310");
        double *__cb311 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb311, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb311");
        double *__cb312 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb312, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb312");
        double *__cb313 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb313, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb313");
        double *__cb314 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb314, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb314");
        double *__cb315 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb315, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb315");
        double *__cb316 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb316, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb316");
        double *__cb317 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb317, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb317");
        double *__cb318 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb318, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb318");
        double *__cb319 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb319, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb319");
        double *__cb320 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb320, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb320");
        double *__cb321 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb321, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb321");
        double *__cb322 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb322, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb322");
        double *__cb323 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb323, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb323");
        double *__cb324 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb324, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb324");
        double *__cb325 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb325, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb325");
        double *__cb326 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb326, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb326");
        double *__cb327 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb327, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb327");
        double *__cb328 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb328, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb328");
        double *__cb329 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb329, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb329");
        double *__cb330 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb330, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb330");
        double *__cb331 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb331, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb331");
        double *__cb332 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb332, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb332");
        double *__cb333 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb333, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb333");
        double *__cb334 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb334, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb334");
        double *__cb335 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(__cb335, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "__cb335");
        bool *zneg_mask1 = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zneg_mask1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zneg_mask1");
        double *zqadj1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqadj1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqadj1");
        double *zqadj2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqadj2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqadj2");
        bool *zneg_mask2 = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zneg_mask2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zneg_mask2");
        double *zqadj3 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqadj3, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqadj3");
        double *_pw1b = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw1b, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "_pw1b");
        double *zalfa = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zalfa, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "zalfa");
        bool *zli_mask = (bool *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zli_mask, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(bool), "zli_mask");
        double *zli_safe = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zli_safe, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "zli_safe");
        double *zsig = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zsig, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zsig");
        bool *ztrpaus_cond = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(ztrpaus_cond, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "ztrpaus_cond");
        double *_pw2b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw2b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw2b");
        double *zfacw_v = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zfacw_v, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zfacw_v");
        double *zcor_v = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcor_v, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcor_v");
        double *_pw3b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw3b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw3b");
        double *zfaci_v = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zfaci_v, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zfaci_v");
        double *zfac_v = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfac_v, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfac_v");
        double *ztmpa_v = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(ztmpa_v, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "ztmpa_v");
        bool *zql_neg = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zql_neg, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zql_neg");
        bool *zqi_neg = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zqi_neg, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zqi_neg");
        double *zfac_cond = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfac_cond, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfac_cond");
        double *zfac = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfac, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfac");
        double *zfaci = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfaci, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfaci");
        bool *za_full_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(za_full_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "za_full_mask");
        double *zsupsat_full = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zsupsat_full, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zsupsat_full");
        double *zqp1env = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqp1env, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqp1env");
        double *zsupsat_env = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zsupsat_env, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zsupsat_env");
        bool *zsupsat_active = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zsupsat_active, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zsupsat_active");
        bool *zsupsat_liq = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zsupsat_liq, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zsupsat_liq");
        bool *zsupsat_ice = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zsupsat_ice, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zsupsat_ice");
        bool *zpsupsat_active = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zpsupsat_active, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zpsupsat_active");
        bool *zpsupsat_liq = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zpsupsat_liq, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zpsupsat_liq");
        bool *zpsupsat_ice = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zpsupsat_ice, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zpsupsat_ice");
        bool *zplude_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zplude_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zplude_mask");
        double *zconvsrce_liq = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zconvsrce_liq, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zconvsrce_liq");
        double *zconvsrce_ice = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zconvsrce_ice, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zconvsrce_ice");
        double *zplu_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zplu_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zplu_safe");
        bool *zldcum_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zldcum_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zldcum_mask");
        double *zdtdp_b5 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdtdp_b5, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdtdp_b5");
        double *zdtforc_b5 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdtforc_b5, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdtforc_b5");
        double *zlfinal = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlfinal, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlfinal");
        double *zevap_b5 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zevap_b5, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zevap_b5");
        double *zmfdn = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zmfdn, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zmfdn");
        bool *zldifdt_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zldifdt_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zldifdt_mask");
        bool *zli_active = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zli_active, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zli_active");
        double *ze = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(ze, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "ze");
        double *zleros = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zleros, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zleros");
        double *zlicld_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlicld_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlicld_safe");
        double *zaeros = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zaeros, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zaeros");
        double *zliq_zleros = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zliq_zleros, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zliq_zleros");
        double *zice_zleros = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zice_zleros, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zice_zleros");
        double *zdtdp = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdtdp, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdtdp");
        double *zdpmxdt = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdpmxdt, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdpmxdt");
        double *zwtot = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zwtot, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zwtot");
        double *zzzdt = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zzzdt, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zzzdt");
        double *zdtdiab = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdtdiab, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdtdiab");
        double *zdtforc = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdtforc, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdtforc");
        double *zqp = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqp, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqp");
        double *_pw4b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw4b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw4b");
        double *zalfa1 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zalfa1, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zalfa1");
        double *zqsat = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zqsat, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zqsat");
        double *zcor = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcor, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcor");
        double *_pw5b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw5b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw5b");
        double *_pw6b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw6b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw6b");
        double *zcond = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcond, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcond");
        double *_pw7b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw7b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw7b");
        double *_pw8b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw8b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw8b");
        double *_pw9b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw9b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw9b");
        double *zcond1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcond1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcond1");
        bool *zdqs_pos = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zdqs_pos, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zdqs_pos");
        double *zlevap = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlevap, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlevap");
        double *zlevapl_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlevapl_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlevapl_new");
        double *zlevapi_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlevapi_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlevapi_new");
        bool *zldcz_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zldcz_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zldcz_mask");
        double *zlcond1_0 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlcond1_0, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlcond1_0");
        bool *za_high = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(za_high, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "za_high");
        double *_pw10b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw10b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw10b");
        double *_pw11b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw11b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw11b");
        double *_pw12b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw12b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw12b");
        double *zcdmax_high = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcdmax_high, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcdmax_high");
        double *za_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(za_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "za_safe");
        double *zcdmax_low = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcdmax_low, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcdmax_low");
        double *zcdmax = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcdmax, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcdmax");
        double *zlcond1_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlcond1_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlcond1_new");
        bool *zldcz_liq = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zldcz_liq, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zldcz_liq");
        bool *zldcz_ice = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zldcz_ice, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zldcz_ice");
        bool *zdqs_neg_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zdqs_neg_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zdqs_neg_mask");
        double *zsigk = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zsigk, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zsigk");
        double *_pw13b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw13b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw13b");
        double *zrhc = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zrhc, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zrhc");
        double *zqe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqe");
        double *zfac_cond2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfac_cond2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfac_cond2");
        bool *zsat_range = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zsat_range, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zsat_range");
        bool *zac_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zac_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zac_mask");
        double *zacond = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zacond, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zacond");
        double *zlcond2_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlcond2_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlcond2_new");
        double *zzdl = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zzdl, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zzdl");
        bool *zlcondlim_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zlcondlim_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zlcondlim_mask");
        double *zlcondlim = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlcondlim, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlcondlim");
        bool *zzero_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zzero_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zzero_mask");
        bool *zac_liq = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zac_liq, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zac_liq");
        bool *zac_ice = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zac_ice, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zac_ice");
        bool *zcldtop_reset = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zcldtop_reset, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zcldtop_reset");
        bool *zdep_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zdep_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zdep_mask");
        double *zvpice = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zvpice, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zvpice");
        double *zvpliq = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zvpliq, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zvpliq");
        double *zicenuclei_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zicenuclei_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zicenuclei_new");
        double *zadd = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zadd, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zadd");
        double *zbdd = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zbdd, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zbdd");
        double *_pw14b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw14b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw14b");
        double *zcvds = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zcvds, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zcvds");
        double *zice0 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zice0, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zice0");
        double *_pw15b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw15b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw15b");
        double *_pw16b = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw16b, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw16b");
        double *zinew = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zinew, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zinew");
        double *zdepos = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdepos, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdepos");
        double *zinfactor = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zinfactor, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zinfactor");
        double *zaplusb = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zaplusb, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zaplusb");
        double *_pw18b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw18b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw18b");
        double *zcorrfac = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zcorrfac, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zcorrfac");
        double *_pw19b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw19b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw19b");
        double *zcorrfac2 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zcorrfac2, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zcorrfac2");
        double *zpr02 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zpr02, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zpr02");
        double *zterm1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zterm1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zterm1");
        double *_pw21b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw21b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw21b");
        double *_pw22b = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw22b, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw22b");
        double *_pw23b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw23b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw23b");
        double *_pw25b = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw25b, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw25b");
        double *zterm2 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zterm2, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zterm2");
        double *ztmpa = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(ztmpa, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "ztmpa");
        double *zfall = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfall, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfall");
        bool *zqpretot_active = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zqpretot_active, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zqpretot_active");
        double *zcovptot_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcovptot_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcovptot_new");
        double *zcovpclr_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcovpclr_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcovpclr_new");
        double *zcovptot_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcovptot_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcovptot_safe");
        bool *zice_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zice_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zice_mask");
        double *zzco = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zzco, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zzco");
        double *_pw27b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw27b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw27b");
        double *zsnowaut_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zsnowaut_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zsnowaut_new");
        bool *zwarm_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zwarm_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zwarm_mask");
        double *zlcrit_d1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlcrit_d1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlcrit_d1");
        double *zprecip_d1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zprecip_d1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zprecip_d1");
        double *zcfpr_d1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcfpr_d1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcfpr_d1");
        bool *zbelow20 = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zbelow20, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zbelow20");
        double *_pw30b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw30b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw30b");
        double *zrainaut_lo = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zrainaut_lo, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zrainaut_lo");
        double *zrainaut1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zrainaut1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zrainaut1");
        bool *zwarm_frz = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zwarm_frz, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zwarm_frz");
        bool *zwarm_liq = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zwarm_liq, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zwarm_liq");
        bool *zland_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zland_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zland_mask");
        double *zconst = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zconst, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zconst");
        double *zlcrit2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zlcrit2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zlcrit2");
        bool *zabove_crit = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zabove_crit, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zabove_crit");
        double *_pw31b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw31b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw31b");
        double *_pw32b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw32b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw32b");
        double *zrainaut_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zrainaut_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zrainaut_new");
        double *_pw33b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw33b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw33b");
        double *zrainacc_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zrainacc_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zrainacc_new");
        double *zrainaut2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zrainaut2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zrainaut2");
        double *zrainacc2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zrainacc2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zrainacc2");
        bool *zrime_outer = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zrime_outer, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zrime_outer");
        double *_pw34b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw34b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw34b");
        double *zfallcorr_rime = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zfallcorr_rime, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zfallcorr_rime");
        bool *zrime_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zrime_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zrime_mask");
        double *_pw35b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw35b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw35b");
        double *zsnowrime_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zsnowrime_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zsnowrime_new");
        bool *zmelt_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zmelt_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zmelt_mask");
        double *zsubsat = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zsubsat, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zsubsat");
        double *ztdmtw0 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(ztdmtw0, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "ztdmtw0");
        double *zmeltmax_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zmeltmax_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zmeltmax_new");
        bool *zmelt_mask2 = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zmelt_mask2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zmelt_mask2");
        double *zicetot_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zicetot_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zicetot_safe");
        double *zalfa2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zalfa2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zalfa2");
        double *zmelt = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zmelt, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zmelt");
        double *zqxfg_jm_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqxfg_jm_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqxfg_jm_new");
        double *zqxfg_im_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqxfg_im_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqxfg_im_new");
        bool *zrain_present = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zrain_present, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zrain_present");
        bool *ztop_reset = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(ztop_reset, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "ztop_reset");
        double *zqpretot_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqpretot_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqpretot_new");
        double *prainfrac_new = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(prainfrac_new, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "prainfrac_new");
        bool *zcold_rain = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zcold_rain, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zcold_rain");
        bool *zhigh_frac = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zhigh_frac, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zhigh_frac");
        double *zqxr_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqxr_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqxr_safe");
        double *_pw36b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw36b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw36b");
        double *zlambda = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zlambda, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zlambda");
        double *ztemp = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(ztemp, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "ztemp");
        double *_pw37b = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw37b, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw37b");
        double *zfrz_high = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfrz_high, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfrz_high");
        double *zfrzmax_high = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfrzmax_high, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfrzmax_high");
        double *zfrzmax_low = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfrzmax_low, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfrzmax_low");
        double *zfrzmax_local = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfrzmax_local, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfrzmax_local");
        bool *zfreeze_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zfreeze_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zfreeze_mask");
        double *zfrz = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zfrz, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zfrz");
        bool *zhomo_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zhomo_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zhomo_mask");
        double *zzrh1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zzrh1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zzrh1");
        double *zqe1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqe1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqe1");
        bool *zllo1 = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zllo1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zllo1");
        double *zcp_arg = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcp_arg, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcp_arg");
        double *zcp_denom = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcp_denom, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcp_denom");
        double *zcp_denom_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcp_denom_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcp_denom_safe");
        double *zpreclr = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zpreclr, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zpreclr");
        double *zbeta1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zbeta1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zbeta1");
        double *_pw38b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw38b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw38b");
        double *zbeta_e1 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zbeta_e1, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zbeta_e1");
        double *zdenom_e1 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zdenom_e1, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zdenom_e1");
        double *zdpr = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdpr, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdpr");
        double *zdpevap = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdpevap, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdpevap");
        double *zevap = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zevap, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zevap");
        double *zqxfgr_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqxfgr_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqxfgr_safe");
        double *zcovptot_e1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcovptot_e1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcovptot_e1");
        double *zzrh2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zzrh2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zzrh2");
        double *zqe2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqe2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqe2");
        bool *zllo2 = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zllo2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zllo2");
        double *zcovptot_safe2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcovptot_safe2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcovptot_safe2");
        double *zpreclr2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zpreclr2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zpreclr2");
        double *_pw39b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw39b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw39b");
        double *zfallcorr = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zfallcorr, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zfallcorr");
        double *zesatliq = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zesatliq, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zesatliq");
        double *zpreclr2_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zpreclr2_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zpreclr2_safe");
        double *_pw40b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw40b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw40b");
        double *zlambda2 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zlambda2, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zlambda2");
        double *zevap_denom = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zevap_denom, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zevap_denom");
        double *_pw42b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw42b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw42b");
        double *zcorr2 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zcorr2, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zcorr2");
        double *zka = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zka, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zka");
        double *zsubsat2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zsubsat2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zsubsat2");
        double *zevap_denom_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zevap_denom_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zevap_denom_safe");
        double *zqsliq_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqsliq_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqsliq_safe");
        double *_pw43b = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw43b, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw43b");
        double *_pw44b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw44b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw44b");
        double *_pw45b = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw45b, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw45b");
        double *_pw46b = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw46b, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw46b");
        double *zbeta2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zbeta2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zbeta2");
        double *zdenom2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdenom2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdenom2");
        double *zdpevap2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdpevap2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdpevap2");
        double *zevap2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zevap2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zevap2");
        double *zqxfgr_safe2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqxfgr_safe2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqxfgr_safe2");
        double *zcovptot_e2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcovptot_e2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcovptot_e2");
        double *zzrhs1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zzrhs1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zzrhs1");
        double *zqes1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqes1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqes1");
        bool *zllos1 = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zllos1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zllos1");
        double *zcp_args1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcp_args1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcp_args1");
        double *zcp_denoms1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcp_denoms1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcp_denoms1");
        double *zcp_denoms1_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcp_denoms1_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcp_denoms1_safe");
        double *zpreclrs1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zpreclrs1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zpreclrs1");
        double *zbeta1s1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zbeta1s1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zbeta1s1");
        double *_pw48b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw48b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw48b");
        double *zbetas1 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zbetas1, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zbetas1");
        double *zdenoms1 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zdenoms1, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zdenoms1");
        double *zdprs1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdprs1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdprs1");
        double *zdpevaps1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdpevaps1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdpevaps1");
        double *zevaps1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zevaps1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zevaps1");
        double *zqxfgs_safe1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqxfgs_safe1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqxfgs_safe1");
        double *zcovptot_s1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcovptot_s1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcovptot_s1");
        double *zzrhs2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zzrhs2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zzrhs2");
        double *zqes2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqes2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqes2");
        bool *zllos2 = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zllos2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zllos2");
        double *zcovptot_safe2s = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcovptot_safe2s, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcovptot_safe2s");
        double *zpreclrs2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zpreclrs2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zpreclrs2");
        double *zvpices2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zvpices2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zvpices2");
        double *zaplusbs2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zaplusbs2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zaplusbs2");
        double *_pw50b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw50b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw50b");
        double *zcorrfacs2 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zcorrfacs2, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zcorrfacs2");
        double *_pw51b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw51b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw51b");
        double *zcorrfac2s2 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zcorrfac2s2, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zcorrfac2s2");
        double *zpr02s2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zpr02s2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zpr02s2");
        double *zqsice_safe2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqsice_safe2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqsice_safe2");
        double *zterm1s2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zterm1s2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zterm1s2");
        double *_pw53b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw53b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw53b");
        double *_pw54b = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw54b, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw54b");
        double *_pw55b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw55b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw55b");
        double *_pw57b = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(_pw57b, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "_pw57b");
        double *zterm2s2 = (double *)malloc((size_t)((((kfdia - kidia) + 1))) * sizeof(double));
        __npb_alloc_check(zterm2s2, (size_t)((((kfdia - kidia) + 1))) * sizeof(double), "zterm2s2");
        double *zdpevaps2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zdpevaps2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zdpevaps2");
        double *zevaps2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zevaps2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zevaps2");
        double *zqxs_safe2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zqxs_safe2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zqxs_safe2");
        double *zcovptot_s2 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcovptot_s2, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcovptot_s2");
        bool *zfall_neg = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zfall_neg, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zfall_neg");
        double *zanew = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zanew, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zanew");
        double *zmax = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zmax, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zmax");
        double *zrat = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zrat, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zrat");
        double *zmm = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zmm, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zmm");
        double *zrr = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zrr, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zrr");
        bool *zneg_mask = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zneg_mask, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zneg_mask");
        bool *zneg_qxn = (bool *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(bool));
        __npb_alloc_check(zneg_qxn, (size_t)(((kfdia - (kidia - 1)))) * sizeof(bool), "zneg_qxn");
        double *zgdph_r = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zgdph_r, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zgdph_r");
        double *zt = (double *)malloc((size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zt, (size_t)((nlev) * ((kfdia - (kidia - 1)))) * sizeof(double), "zt");
        double *zalfaw_v = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zalfaw_v, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zalfaw_v");
        double *za_col = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(za_col, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "za_col");
        double *zcons1 = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcons1, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcons1");
        double *zrho_safe = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zrho_safe, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zrho_safe");
        double *zcons1b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zcons1b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zcons1b");
        double *zalfaw_tail = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zalfaw_tail, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zalfaw_tail");
        double *_pw24b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw24b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw24b");
        double *zliqcld_col = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(zliqcld_col, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "zliqcld_col");
        double *_pw56b = (double *)malloc((size_t)(((kfdia - (kidia - 1)))) * sizeof(double));
        __npb_alloc_check(_pw56b, (size_t)(((kfdia - (kidia - 1)))) * sizeof(double), "_pw56b");
        ztw1 = 1329.31;
        ztw2 = 0.0074615;
        ztw3 = 85000.0;
        ztw4 = 40.637;
        ztw5 = 275.0;
        zepsilon = 1e-14;
        iwarmrain = 2;
        ievaprain = 2;
        ievapsnow = 1;
        idepice = 1;
        zqtmst = (1.0 / ptsphy);
        zgdcp = (9.80665 / 1004.7088578330674);
        zrdcp = (287.0596736665907 / 1004.7088578330674);
        zcons1a = (1004.7088578330674 / ((333700.0 * 9.80665) * 7200.0));
        zepsec = 1e-14;
        zrg_r = (1.0 / 9.80665);
        zrldcp = (1.0 / (2821.2152982440934 - 2489.0792795374246));
        iphase[4] = 0;
        iphase[0] = 1;
        iphase[2] = 1;
        iphase[1] = 2;
        iphase[3] = 2;
        imelt[4] = -99;
        imelt[0] = 2;
        imelt[2] = 4;
        imelt[1] = 3;
        imelt[3] = 3;
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            tendency_loc_t[(si0)*(klon) + (si1)] = 0.0;
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            tendency_loc_q[(si0)*(klon) + (si1)] = 0.0;
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            tendency_loc_a[(si0)*(klon) + (si1)] = 0.0;
          }
        }
        for (int64_t si0 = 0; si0 < 4; ++si0) {
          for (int64_t si1 = 0; si1 < nlev; ++si1) {
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              tendency_loc_cld[((si0)*(nlev) + (si1))*(klon) + (si2)] = 0.0;
            }
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pcovptot[(si0)*(klon) + (si1)] = 0.0;
          }
        }
        for (int64_t si1 = 0; si1 < nlev; ++si1) {
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            tendency_loc_cld[((4)*(nlev) + (si1))*(klon) + (si2)] = 0.0;
          }
        }
        zvqx[4] = 0.0;
        zvqx[0] = 0.0;
        zvqx[1] = 0.13;
        zvqx[2] = 4.0;
        zvqx[3] = 1.0;
        for (int64_t __w0 = 0; __w0 < 5; ++__w0) {
          llfall[__w0] = 0;
        }
        for (int64_t jm = 1; jm < 6; ++jm) {
          if ((zvqx[(jm - 1)] > 0.0)) {
            llfall[(jm - 1)] = 1;
          }
        }
        llfall[1] = 0;
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            ztp1[(si0)*(klon) + (si1)] = (pt[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + (ptsphy * tendency_tmp_t[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]));
          }
        }
        for (int64_t si1 = 0; si1 < nlev; ++si1) {
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zqx[((4)*(nlev) + (si1))*(klon) + (si2)] = (pq[(si1)*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + (ptsphy * tendency_tmp_q[(si1)*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]));
          }
        }
        for (int64_t si1 = 0; si1 < nlev; ++si1) {
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zqx0[((4)*(nlev) + (si1))*(klon) + (si2)] = (pq[(si1)*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + (ptsphy * tendency_tmp_q[(si1)*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]));
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            za[(si0)*(klon) + (si1)] = (pa[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + (ptsphy * tendency_tmp_a[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]));
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zaorig[(si0)*(klon) + (si1)] = (pa[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + (ptsphy * tendency_tmp_a[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]));
          }
        }
        for (int64_t si0 = 0; si0 < 4; ++si0) {
          for (int64_t si1 = 0; si1 < nlev; ++si1) {
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zqx[((si0)*(nlev) + (si1))*(klon) + (si2)] = (pclv[((si0)*(nlev) + (si1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + (ptsphy * tendency_tmp_cld[((si0)*(nlev) + (si1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]));
            }
          }
        }
        for (int64_t si0 = 0; si0 < 4; ++si0) {
          for (int64_t si1 = 0; si1 < nlev; ++si1) {
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zqx0[((si0)*(nlev) + (si1))*(klon) + (si2)] = (pclv[((si0)*(nlev) + (si1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + (ptsphy * tendency_tmp_cld[((si0)*(nlev) + (si1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]));
            }
          }
        }
        for (int64_t si0 = 0; si0 < 5; ++si0) {
          for (int64_t si1 = 0; si1 < (nlev + 1); ++si1) {
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zpfplsx[((si0)*((nlev + 1)) + (si1))*(klon) + (si2)] = 0.0;
            }
          }
        }
        for (int64_t si0 = 0; si0 < 5; ++si0) {
          for (int64_t si1 = 0; si1 < nlev; ++si1) {
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zqxn2d[((si0)*(nlev) + (si1))*(klon) + (si2)] = 0.0;
            }
          }
        }
        for (int64_t si0 = 0; si0 < 5; ++si0) {
          for (int64_t si1 = 0; si1 < nlev; ++si1) {
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zlneg[((si0)*(nlev) + (si1))*(klon) + (si2)] = 0.0;
            }
          }
        }
        for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
          prainfrac_toprfz[si0] = 0.0;
        }
        for (int64_t __w0 = 0; __w0 < klon; ++__w0) {
          llrainliq[__w0] = 1;
        }
        for (int64_t jk = 1; jk < (nlev + 1); ++jk) {
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zneg_mask1[__w0] = (((zqx[((0)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] + zqx[((1)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) < 1e-08) | (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 1e-08));
          }
          /* numpy: np.where(zneg_mask1, zlneg[0, jk - 1, kidia - 1:kfdia] + zqx[0, jk - 1, kidia - 1:kfdia], zln... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb1[__r0] = (zneg_mask1[__r0] ? (zlneg[((0)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] + zqx[((0)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) : zlneg[((0)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zlneg[((0)*(nlev) + ((jk - 1)))*(klon) + (si2)] = __cb1[(si2 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zqadj1[__w0] = (zqx[((0)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zqtmst);
          }
          /* numpy: np.where(zneg_mask1, tendency_loc_q[jk - 1, kidia - 1:kfdia] + zqadj1, tendency_loc_q[jk - 1,... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb2[__r0] = (zneg_mask1[__r0] ? (tendency_loc_q[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] + zqadj1[__r0]) : tendency_loc_q[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            tendency_loc_q[((jk - 1))*(klon) + (si1)] = __cb2[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zneg_mask1, tendency_loc_t[jk - 1, kidia - 1:kfdia] - 2489.0792795374246 * zqadj1, t... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb3[__r0] = (zneg_mask1[__r0] ? (tendency_loc_t[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - (2489.0792795374246 * zqadj1[__r0])) : tendency_loc_t[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            tendency_loc_t[((jk - 1))*(klon) + (si1)] = __cb3[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zneg_mask1, zqx[4, jk - 1, kidia - 1:kfdia] + zqx[0, jk - 1, kidia - 1:kfdia], zqx[4... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb4[__r0] = (zneg_mask1[__r0] ? (zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] + zqx[((0)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) : zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zqx[((4)*(nlev) + ((jk - 1)))*(klon) + (si2)] = __cb4[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zneg_mask1, 0.0, zqx[0, jk - 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb5[__r0] = (zneg_mask1[__r0] ? 0.0 : zqx[((0)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zqx[((0)*(nlev) + ((jk - 1)))*(klon) + (si2)] = __cb5[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zneg_mask1, zlneg[1, jk - 1, kidia - 1:kfdia] + zqx[1, jk - 1, kidia - 1:kfdia], zln... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb6[__r0] = (zneg_mask1[__r0] ? (zlneg[((1)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] + zqx[((1)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) : zlneg[((1)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zlneg[((1)*(nlev) + ((jk - 1)))*(klon) + (si2)] = __cb6[(si2 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zqadj2[__w0] = (zqx[((1)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zqtmst);
          }
          /* numpy: np.where(zneg_mask1, tendency_loc_q[jk - 1, kidia - 1:kfdia] + zqadj2, tendency_loc_q[jk - 1,... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb7[__r0] = (zneg_mask1[__r0] ? (tendency_loc_q[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] + zqadj2[__r0]) : tendency_loc_q[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            tendency_loc_q[((jk - 1))*(klon) + (si1)] = __cb7[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zneg_mask1, tendency_loc_t[jk - 1, kidia - 1:kfdia] - 2821.2152982440934 * zqadj2, t... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb8[__r0] = (zneg_mask1[__r0] ? (tendency_loc_t[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - (2821.2152982440934 * zqadj2[__r0])) : tendency_loc_t[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            tendency_loc_t[((jk - 1))*(klon) + (si1)] = __cb8[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zneg_mask1, zqx[4, jk - 1, kidia - 1:kfdia] + zqx[1, jk - 1, kidia - 1:kfdia], zqx[4... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb9[__r0] = (zneg_mask1[__r0] ? (zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] + zqx[((1)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) : zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zqx[((4)*(nlev) + ((jk - 1)))*(klon) + (si2)] = __cb9[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zneg_mask1, 0.0, zqx[1, jk - 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb10[__r0] = (zneg_mask1[__r0] ? 0.0 : zqx[((1)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zqx[((1)*(nlev) + ((jk - 1)))*(klon) + (si2)] = __cb10[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zneg_mask1, 0.0, za[jk - 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb11[__r0] = (zneg_mask1[__r0] ? 0.0 : za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            za[((jk - 1))*(klon) + (si1)] = __cb11[(si1 - (kidia - 1))];
          }
        }
        for (int64_t jm = 1; jm < 5; ++jm) {
          for (int64_t jk = 1; jk < (nlev + 1); ++jk) {
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zneg_mask2[__w0] = (zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 1e-08);
            }
            /* numpy: np.where(zneg_mask2, zlneg[jm - 1, jk - 1, kidia - 1:kfdia] + zqx[jm - 1, jk - 1, kidia - 1:k... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb12[__r0] = (zneg_mask2[__r0] ? (zlneg[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] + zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) : zlneg[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zlneg[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + (si2)] = __cb12[(si2 - (kidia - 1))];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqadj3[__w0] = (zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zqtmst);
            }
            /* numpy: np.where(zneg_mask2, tendency_loc_q[jk - 1, kidia - 1:kfdia] + zqadj3, tendency_loc_q[jk - 1,... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb13[__r0] = (zneg_mask2[__r0] ? (tendency_loc_q[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] + zqadj3[__r0]) : tendency_loc_q[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              tendency_loc_q[((jk - 1))*(klon) + (si1)] = __cb13[(si1 - (kidia - 1))];
            }
            if ((((int64_t)(iphase[(jm - 1)])) == 1)) {
              /* numpy: np.where(zneg_mask2, tendency_loc_t[jk - 1, kidia - 1:kfdia] - 2489.0792795374246 * zqadj3, t... */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb14[__r0] = (zneg_mask2[__r0] ? (tendency_loc_t[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - (2489.0792795374246 * zqadj3[__r0])) : tendency_loc_t[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
              }
              for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                tendency_loc_t[((jk - 1))*(klon) + (si1)] = __cb14[(si1 - (kidia - 1))];
              }
            }
            if ((((int64_t)(iphase[(jm - 1)])) == 2)) {
              /* numpy: np.where(zneg_mask2, tendency_loc_t[jk - 1, kidia - 1:kfdia] - 2821.2152982440934 * zqadj3, t... */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb15[__r0] = (zneg_mask2[__r0] ? (tendency_loc_t[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - (2821.2152982440934 * zqadj3[__r0])) : tendency_loc_t[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
              }
              for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                tendency_loc_t[((jk - 1))*(klon) + (si1)] = __cb15[(si1 - (kidia - 1))];
              }
            }
            /* numpy: np.where(zneg_mask2, zqx[4, jk - 1, kidia - 1:kfdia] + zqx[jm - 1, jk - 1, kidia - 1:kfdia], ... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb16[__r0] = (zneg_mask2[__r0] ? (zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] + zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) : zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zqx[((4)*(nlev) + ((jk - 1)))*(klon) + (si2)] = __cb16[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zneg_mask2, 0.0, zqx[jm - 1, jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb17[__r0] = (zneg_mask2[__r0] ? 0.0 : zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + (si2)] = __cb17[(si2 - (kidia - 1))];
            }
          }
        }
        for (int64_t __w0 = 0; __w0 < nlev; ++__w0) {
          for (int64_t __w1 = 0; __w1 < (kfdia - (kidia - 1)); ++__w1) {
            zt[(__w0)*((kfdia - (kidia - 1))) + (__w1)] = ztp1[(__w0)*(klon) + ((__w1 + ((kidia - 1) - 0)))];
          }
        }
        /* numpy: np.minimum(273.16, zt) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb18[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = min(273.16, zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)]);
          }
        }
        /* numpy: np.maximum(250.16000000000003, __cb18) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb19[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = max(250.16000000000003, __cb18[(__r0)*((kfdia - (kidia - 1))) + (__r1)]);
          }
        }
        for (int64_t __w0 = 0; __w0 < nlev; ++__w0) {
          for (int64_t __w1 = 0; __w1 < (kfdia - (kidia - 1)); ++__w1) {
            _pw1b[(__w0)*((kfdia - (kidia - 1))) + (__w1)] = ((__cb19[(__w0)*((kfdia - (kidia - 1))) + (__w1)] - 250.16000000000003) * 0.043478260869565216);
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = 0; si1 < ((kfdia - kidia) + 1); ++si1) {
            _pw1[(si0)*(((kfdia - kidia) + 1)) + (si1)] = (_pw1b[(si0)*((kfdia - (kidia - 1))) + (si1)] * _pw1b[(si0)*((kfdia - (kidia - 1))) + (si1)]);
          }
        }
        /* numpy: np.minimum(1.0, _pw1) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < ((kfdia - kidia) + 1); ++__r1) {
            __cb20[(__r0)*(((kfdia - kidia) + 1)) + (__r1)] = min(1.0, _pw1[(__r0)*(((kfdia - kidia) + 1)) + (__r1)]);
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zfoealfa[(si0)*(klon) + (si1)] = __cb20[(si0)*(((kfdia - kidia) + 1)) + ((si1 - (kidia - 1)))];
          }
        }
        /* numpy: np.minimum(380.1608703442847 * (zfoealfa[0:nlev, kidia - 1:kfdia] * exp(17.502 * (zt - 273.16... */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb21[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = min(((380.1608703442847 * ((zfoealfa[(__r0)*(klon) + ((__r1 + (kidia - 1)))] * exp(((17.502 * (zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - 273.16)) / (zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - 32.19)))) + ((1.0 - zfoealfa[(__r0)*(klon) + ((__r1 + (kidia - 1)))]) * exp(((22.587 * (zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - 273.16)) / (zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - -0.7)))))) / pap[(__r0)*(klon) + ((__r1 + (kidia - 1)))]), 0.5);
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zfoeewmt[(si0)*(klon) + (si1)] = __cb21[(si0)*((kfdia - (kidia - 1))) + ((si1 - (kidia - 1)))];
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqsmix[(si0)*(klon) + (si1)] = zfoeewmt[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqsmix[(si0)*(klon) + (si1)] = (zqsmix[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] / (1.0 - (0.6077667316114637 * zqsmix[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))])));
          }
        }
        /* numpy: np.sign(zt - 273.16) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb22[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = __npb_sign((zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - 273.16));
          }
        }
        /* numpy: np.maximum(0.0, 1.0 * __cb22) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb23[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = max(0.0, (1.0 * __cb22[(__r0)*((kfdia - (kidia - 1))) + (__r1)]));
          }
        }
        for (int64_t __w0 = 0; __w0 < nlev; ++__w0) {
          for (int64_t __w1 = 0; __w1 < (kfdia - (kidia - 1)); ++__w1) {
            zalfa[(__w0)*((kfdia - (kidia - 1))) + (__w1)] = __cb23[(__w0)*((kfdia - (kidia - 1))) + (__w1)];
          }
        }
        /* numpy: np.minimum((zalfa * (380.1608703442847 * exp(17.502 * (zt - 273.16) / (zt - 32.19))) + (1.0 -... */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb24[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = min((((zalfa[(__r0)*((kfdia - (kidia - 1))) + (__r1)] * (380.1608703442847 * exp(((17.502 * (zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - 273.16)) / (zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - 32.19))))) + ((1.0 - zalfa[(__r0)*((kfdia - (kidia - 1))) + (__r1)]) * (380.1608703442847 * exp(((22.587 * (zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - 273.16)) / (zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - -0.7)))))) / pap[(__r0)*(klon) + ((__r1 + (kidia - 1)))]), 0.5);
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zfoeew[(si0)*(klon) + (si1)] = __cb24[(si0)*((kfdia - (kidia - 1))) + ((si1 - (kidia - 1)))];
          }
        }
        /* numpy: np.minimum(0.5, zfoeew[:, kidia - 1:kfdia]) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb25[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = min(0.5, zfoeew[(__r0)*(klon) + ((__r1 + (kidia - 1)))]);
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zfoeew[(si0)*(klon) + (si1)] = __cb25[(si0)*((kfdia - (kidia - 1))) + ((si1 - (kidia - 1)))];
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqsice[(si0)*(klon) + (si1)] = (zfoeew[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] / (1.0 - (0.6077667316114637 * zfoeew[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))])));
          }
        }
        /* numpy: np.minimum(380.1608703442847 * exp(17.502 * (zt - 273.16) / (zt - 32.19)) / pap[:, kidia - 1:... */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb26[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = min(((380.1608703442847 * exp(((17.502 * (zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - 273.16)) / (zt[(__r0)*((kfdia - (kidia - 1))) + (__r1)] - 32.19)))) / pap[(__r0)*(klon) + ((__r1 + (kidia - 1)))]), 0.5);
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zfoeeliqt[(si0)*(klon) + (si1)] = __cb26[(si0)*((kfdia - (kidia - 1))) + ((si1 - (kidia - 1)))];
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqsliq[(si0)*(klon) + (si1)] = zfoeeliqt[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqsliq[(si0)*(klon) + (si1)] = (zqsliq[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] / (1.0 - (0.6077667316114637 * zqsliq[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))])));
          }
        }
        /* numpy: np.minimum(1.0, za[:, kidia - 1:kfdia]) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb27[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = min(1.0, za[(__r0)*(klon) + ((__r1 + (kidia - 1)))]);
          }
        }
        /* numpy: np.maximum(0.0, __cb27) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb28[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = max(0.0, __cb27[(__r0)*((kfdia - (kidia - 1))) + (__r1)]);
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            za[(si0)*(klon) + (si1)] = __cb28[(si0)*((kfdia - (kidia - 1))) + ((si1 - (kidia - 1)))];
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zli[(si0)*(klon) + (si1)] = (zqx[((0)*(nlev) + (si0))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + zqx[((1)*(nlev) + (si0))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
          }
        }
        for (int64_t __w0 = 0; __w0 < nlev; ++__w0) {
          for (int64_t __w1 = 0; __w1 < (kfdia - (kidia - 1)); ++__w1) {
            zli_mask[(__w0)*((kfdia - (kidia - 1))) + (__w1)] = (zli[(__w0)*(klon) + ((__w1 + ((kidia - 1) - 0)))] > 1e-08);
          }
        }
        /* numpy: np.where(zli_mask, zli[:, kidia - 1:kfdia], 1.0) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb29[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = (zli_mask[(__r0)*((kfdia - (kidia - 1))) + (__r1)] ? zli[(__r0)*(klon) + ((__r1 + (kidia - 1)))] : 1.0);
          }
        }
        for (int64_t __w0 = 0; __w0 < nlev; ++__w0) {
          for (int64_t __w1 = 0; __w1 < (kfdia - (kidia - 1)); ++__w1) {
            zli_safe[(__w0)*((kfdia - (kidia - 1))) + (__w1)] = __cb29[(__w0)*((kfdia - (kidia - 1))) + (__w1)];
          }
        }
        /* numpy: np.where(zli_mask, zqx[0, :, kidia - 1:kfdia] / zli_safe, 0.0) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb30[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = (zli_mask[(__r0)*((kfdia - (kidia - 1))) + (__r1)] ? (zqx[((0)*(nlev) + (__r0))*(klon) + ((__r1 + (kidia - 1)))] / zli_safe[(__r0)*((kfdia - (kidia - 1))) + (__r1)]) : 0.0);
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zliqfrac[(si0)*(klon) + (si1)] = __cb30[(si0)*((kfdia - (kidia - 1))) + ((si1 - (kidia - 1)))];
          }
        }
        /* numpy: np.where(zli_mask, 1.0 - zliqfrac[:, kidia - 1:kfdia], 0.0) */
        for (int64_t __r0 = 0; __r0 < nlev; ++__r0) {
          for (int64_t __r1 = 0; __r1 < (kfdia - (kidia - 1)); ++__r1) {
            __cb31[(__r0)*((kfdia - (kidia - 1))) + (__r1)] = (zli_mask[(__r0)*((kfdia - (kidia - 1))) + (__r1)] ? (1.0 - zliqfrac[(__r0)*(klon) + ((__r1 + (kidia - 1)))]) : 0.0);
          }
        }
        for (int64_t si0 = 0; si0 < nlev; ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zicefrac[(si0)*(klon) + (si1)] = __cb31[(si0)*((kfdia - (kidia - 1))) + ((si1 - (kidia - 1)))];
          }
        }
        for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
          ztrpaus[si0] = 0.1;
        }
        for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
          zpaphd[si0] = (1.0 / paph[(((nlev + 1) - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]);
        }
        for (int64_t jk = 1; jk < ((nlev - 1) + 1); ++jk) {
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zsig[__w0] = (pap[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zpaphd[(__w0 + ((kidia - 1) - 0))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            ztrpaus_cond[__w0] = (((zsig[__w0] > 0.1) & (zsig[__w0] < 0.4)) & (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > ztp1[(jk)*(klon) + ((__w0 + ((kidia - 1) - 0)))]));
          }
          /* numpy: np.where(ztrpaus_cond, zsig, ztrpaus[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb32[__r0] = (ztrpaus_cond[__r0] ? zsig[__r0] : ztrpaus[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            ztrpaus[si0] = __cb32[(si0 - (kidia - 1))];
          }
        }
        for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
          zanewm1[si0] = 0.0;
        }
        for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
          zda[si0] = 0.0;
        }
        for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
          zcovpclr[si0] = 0.0;
        }
        for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
          zcovpmax[si0] = 0.0;
        }
        for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
          zcovptot[si0] = 0.0;
        }
        for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
          zcldtopdist[si0] = 0.0;
        }
        for (int64_t jk = 15; jk < (nlev + 1); ++jk) {
          for (int64_t si0 = 0; si0 < 5; ++si0) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxfg[(si0)*(klon) + (si1)] = zqx[((si0)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
            }
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlicld[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zrainaut[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zrainacc[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsnowaut[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zldefr[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zacust[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zqpretot[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlfinalsum[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlcond1[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlcond2[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsupsat[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlevapl[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlevapi[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsolab[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsolac[si0] = 0.0;
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zicetot[si0] = 0.0;
          }
          for (int64_t si0 = 0; si0 < 5; ++si0) {
            for (int64_t si1 = 0; si1 < 5; ++si1) {
              for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                zsolqb[((si0)*(5) + (si1))*(klon) + (si2)] = 0.0;
              }
            }
          }
          for (int64_t si0 = 0; si0 < 5; ++si0) {
            for (int64_t si1 = 0; si1 < 5; ++si1) {
              for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                zsolqa[((si0)*(5) + (si1))*(klon) + (si2)] = 0.0;
              }
            }
          }
          for (int64_t si0 = 0; si0 < 5; ++si0) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zfallsrce[(si0)*(klon) + (si1)] = 0.0;
            }
          }
          for (int64_t si0 = 0; si0 < 5; ++si0) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zfallsink[(si0)*(klon) + (si1)] = 0.0;
            }
          }
          for (int64_t si0 = 0; si0 < 5; ++si0) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zconvsrce[(si0)*(klon) + (si1)] = 0.0;
            }
          }
          for (int64_t si0 = 0; si0 < 5; ++si0) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zconvsink[(si0)*(klon) + (si1)] = 0.0;
            }
          }
          for (int64_t si0 = 0; si0 < 5; ++si0) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zpsupsatsrce[(si0)*(klon) + (si1)] = 0.0;
            }
          }
          for (int64_t si0 = 0; si0 < 5; ++si0) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zratio[(si0)*(klon) + (si1)] = 0.0;
            }
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zdp[si0] = (paph[(jk)*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] - paph[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zgdp[si0] = (9.80665 / zdp[(si0 + ((kidia - 1) - (kidia - 1)))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zrho[si0] = (pap[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] / (287.0596736665907 * ztp1[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]));
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zdtgdp[si0] = (ptsphy * zgdp[(si0 + ((kidia - 1) - (kidia - 1)))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zrdtgdp[si0] = (zdp[(si0 + ((kidia - 1) - (kidia - 1)))] * (1.0 / (ptsphy * 9.80665)));
          }
          if ((jk > 1)) {
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zdtgdpf[si0] = ((ptsphy * 9.80665) / (pap[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] - pap[((jk - 2))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]));
            }
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw2b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - 32.19);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw2[__w0] = (_pw2b[__w0] * _pw2b[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zfacw_v[__w0] = (4217.45694 / _pw2[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcor_v[__w0] = (1.0 / (1.0 - (0.6077667316114637 * zfoeeliqt[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])));
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zdqsliqdt[si0] = ((zfacw_v[(si0 - (kidia - 1))] * zcor_v[(si0 - (kidia - 1))]) * zqsliq[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zcorqsliq[si0] = (1.0 + (2489.0792795374246 * zdqsliqdt[(si0 + ((kidia - 1) - (kidia - 1)))]));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw3b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - -0.7);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw3[__w0] = (_pw3b[__w0] * _pw3b[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zfaci_v[__w0] = (6185.67582 / _pw3[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcor_v[__w0] = (1.0 / (1.0 - (0.6077667316114637 * zfoeew[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])));
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zdqsicedt[si0] = ((zfaci_v[(si0 - (kidia - 1))] * zcor_v[(si0 - (kidia - 1))]) * zqsice[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zcorqsice[si0] = (1.0 + (2821.2152982440934 * zdqsicedt[(si0 + ((kidia - 1) - (kidia - 1)))]));
          }
          for (int64_t si0 = 0; si0 < (kfdia - (kidia - 1)); ++si0) {
            zalfaw_v[si0] = zfoealfa[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - 0)))];
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zalfawm[si0] = zalfaw_v[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfac_v[__w0] = ((zalfaw_v[__w0] * zfacw_v[__w0]) + ((1.0 - zalfaw_v[__w0]) * zfaci_v[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcor_v[__w0] = (1.0 / (1.0 - (0.6077667316114637 * zfoeewmt[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])));
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zdqsmixdt[si0] = ((zfac_v[(si0 - (kidia - 1))] * zcor_v[(si0 - (kidia - 1))]) * zqsmix[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zcorqsmix[si0] = (1.0 + (((zfoealfa[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] * 2489.0792795374246) + ((1.0 - zfoealfa[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]) * 2821.2152982440934)) * zdqsmixdt[(si0 + ((kidia - 1) - (kidia - 1)))]));
          }
          /* numpy: np.maximum((zqsmix[jk - 1, kidia - 1:kfdia] - zqx[4, jk - 1, kidia - 1:kfdia]) / zcorqsmix[ki... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb33[__r0] = max(((zqsmix[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) / zcorqsmix[(__r0 + (kidia - 1))]), 0.0);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zevaplimmix[si0] = __cb33[(si0 - (kidia - 1))];
          }
          /* numpy: np.maximum((zqsliq[jk - 1, kidia - 1:kfdia] - zqx[4, jk - 1, kidia - 1:kfdia]) / zcorqsliq[ki... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb34[__r0] = max(((zqsliq[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) / zcorqsliq[(__r0 + (kidia - 1))]), 0.0);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zevaplimliq[si0] = __cb34[(si0 - (kidia - 1))];
          }
          /* numpy: np.maximum((zqsice[jk - 1, kidia - 1:kfdia] - zqx[4, jk - 1, kidia - 1:kfdia]) / zcorqsice[ki... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb35[__r0] = max(((zqsice[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) / zcorqsice[(__r0 + (kidia - 1))]), 0.0);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zevaplimice[si0] = __cb35[(si0 - (kidia - 1))];
          }
          /* numpy: np.maximum(za[jk - 1, kidia - 1:kfdia], zepsec) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb36[__r0] = max(za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))], zepsec);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            ztmpa_v[__w0] = (1.0 / __cb36[__w0]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zliqcld[si0] = (zqx[((0)*(nlev) + ((jk - 1)))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] * ztmpa_v[(si0 - (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zicecld[si0] = (zqx[((1)*(nlev) + ((jk - 1)))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] * ztmpa_v[(si0 - (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlicld[si0] = (zliqcld[(si0 + ((kidia - 1) - (kidia - 1)))] + zicecld[(si0 + ((kidia - 1) - (kidia - 1)))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zql_neg[__w0] = (zqx[((0)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 1e-08);
          }
          /* numpy: np.where(zql_neg, zqx[0, jk - 1, kidia - 1:kfdia], zsolqa[0, 4, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb37[__r0] = (zql_neg[__r0] ? zqx[((0)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] : zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((0)*(5) + (4))*(klon) + (si2)] = __cb37[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zql_neg, -zqx[0, jk - 1, kidia - 1:kfdia], zsolqa[4, 0, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb38[__r0] = (zql_neg[__r0] ? (-zqx[((0)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) : zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (0))*(klon) + (si2)] = __cb38[(si2 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zqi_neg[__w0] = (zqx[((1)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 1e-08);
          }
          /* numpy: np.where(zqi_neg, zqx[1, jk - 1, kidia - 1:kfdia], zsolqa[1, 4, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb39[__r0] = (zqi_neg[__r0] ? zqx[((1)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] : zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((1)*(5) + (4))*(klon) + (si2)] = __cb39[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zqi_neg, -zqx[1, jk - 1, kidia - 1:kfdia], zsolqa[4, 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb40[__r0] = (zqi_neg[__r0] ? (-zqx[((1)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]) : zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (1))*(klon) + (si2)] = __cb40[(si2 - (kidia - 1))];
          }
          /* numpy: np.exp(17.502 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16) / (ztp1[jk - 1, kidia - 1:kfdia] - 3... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb41[__r0] = exp(((17.502 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)) / (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 32.19)));
          }
          /* numpy: np.exp(22.587 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16) / (ztp1[jk - 1, kidia - 1:kfdia] - -... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb42[__r0] = exp(((22.587 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)) / (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - -0.7)));
          }
          /* numpy: np.minimum(2.583 - 0.0048116 * ztp1[jk - 1, kidia - 1:kfdia], 380.1608703442847 * __cb41 / (3... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb43[__r0] = min((2.583 - (0.0048116 * ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))])), ((380.1608703442847 * __cb41[__r0]) / (380.1608703442847 * __cb42[__r0])));
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zfokoop[si0] = __cb43[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfac_cond[__w0] = ((ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] >= 273.16) | 0);
          }
          /* numpy: np.where(zfac_cond, 1.0, za[jk - 1, kidia - 1:kfdia] + zfokoop[kidia - 1:kfdia] * (1.0 - za[j... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb44[__r0] = (zfac_cond[__r0] ? 1.0 : (za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] + (zfokoop[(__r0 + (kidia - 1))] * (1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]))));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfac[__w0] = __cb44[__w0];
          }
          /* numpy: np.where(zfac_cond, 1.0, ptsphy / 10800.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb45[__r0] = (zfac_cond[__r0] ? 1.0 : (ptsphy / 10800.0));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfaci[__w0] = __cb45[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            za_full_mask[__w0] = (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > (1.0 - 1e-08));
          }
          /* numpy: np.maximum((zqx[4, jk - 1, kidia - 1:kfdia] - zfac * zqsice[jk - 1, kidia - 1:kfdia]) / zcorq... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb46[__r0] = max(((zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] - (zfac[__r0] * zqsice[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))])) / zcorqsice[(__r0 + (kidia - 1))]), 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zsupsat_full[__w0] = __cb46[__w0];
          }
          /* numpy: np.maximum(1.0 - za[jk - 1, kidia - 1:kfdia], zepsilon) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb47[__r0] = max((1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]), zepsilon);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zqp1env[__w0] = ((zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) / __cb47[__w0]);
          }
          /* numpy: np.maximum((1.0 - za[jk - 1, kidia - 1:kfdia]) * (zqp1env - zfac * zqsice[jk - 1, kidia - 1:k... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb48[__r0] = max((((1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) * (zqp1env[__r0] - (zfac[__r0] * zqsice[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]))) / zcorqsice[(__r0 + (kidia - 1))]), 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zsupsat_env[__w0] = __cb48[__w0];
          }
          /* numpy: np.where(za_full_mask, zsupsat_full, zsupsat_env) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb49[__r0] = (za_full_mask[__r0] ? zsupsat_full[__r0] : zsupsat_env[__r0]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsupsat[si0] = __cb49[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zsupsat_active[__w0] = (zsupsat[(__w0 + ((kidia - 1) - 0))] > zepsec);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zsupsat_liq[__w0] = (zsupsat_active[__w0] & (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 235.16000000000003));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zsupsat_ice[__w0] = (zsupsat_active[__w0] & (!(ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 235.16000000000003)));
          }
          /* numpy: np.where(zsupsat_liq, zsolqa[4, 0, kidia - 1:kfdia] + zsupsat[kidia - 1:kfdia], zsolqa[4, 0, ... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb50[__r0] = (zsupsat_liq[__r0] ? (zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] + zsupsat[(__r0 + (kidia - 1))]) : zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (0))*(klon) + (si2)] = __cb50[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zsupsat_liq, zsolqa[0, 4, kidia - 1:kfdia] - zsupsat[kidia - 1:kfdia], zsolqa[0, 4, ... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb51[__r0] = (zsupsat_liq[__r0] ? (zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] - zsupsat[(__r0 + (kidia - 1))]) : zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((0)*(5) + (4))*(klon) + (si2)] = __cb51[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zsupsat_liq, zqxfg[0, kidia - 1:kfdia] + zsupsat[kidia - 1:kfdia], zqxfg[0, kidia - ... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb52[__r0] = (zsupsat_liq[__r0] ? (zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))] + zsupsat[(__r0 + (kidia - 1))]) : zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqxfg[(0)*(klon) + (si1)] = __cb52[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zsupsat_ice, zsolqa[4, 1, kidia - 1:kfdia] + zsupsat[kidia - 1:kfdia], zsolqa[4, 1, ... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb53[__r0] = (zsupsat_ice[__r0] ? (zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))] + zsupsat[(__r0 + (kidia - 1))]) : zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (1))*(klon) + (si2)] = __cb53[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zsupsat_ice, zsolqa[1, 4, kidia - 1:kfdia] - zsupsat[kidia - 1:kfdia], zsolqa[1, 4, ... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb54[__r0] = (zsupsat_ice[__r0] ? (zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] - zsupsat[(__r0 + (kidia - 1))]) : zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((1)*(5) + (4))*(klon) + (si2)] = __cb54[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zsupsat_ice, zqxfg[1, kidia - 1:kfdia] + zsupsat[kidia - 1:kfdia], zqxfg[1, kidia - ... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb55[__r0] = (zsupsat_ice[__r0] ? (zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))] + zsupsat[(__r0 + (kidia - 1))]) : zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqxfg[(1)*(klon) + (si1)] = __cb55[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zsupsat_active, (1.0 - za[jk - 1, kidia - 1:kfdia]) * zfaci, zsolac[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb56[__r0] = (zsupsat_active[__r0] ? ((1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) * zfaci[__r0]) : zsolac[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsolac[si0] = __cb56[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zpsupsat_active[__w0] = (psupsat[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zpsupsat_liq[__w0] = (zpsupsat_active[__w0] & (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 235.16000000000003));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zpsupsat_ice[__w0] = (zpsupsat_active[__w0] & (!(ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 235.16000000000003)));
          }
          /* numpy: np.where(zpsupsat_liq, zsolqa[0, 0, kidia - 1:kfdia] + psupsat[jk - 1, kidia - 1:kfdia], zsol... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb57[__r0] = (zpsupsat_liq[__r0] ? (zsolqa[((0)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] + psupsat[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) : zsolqa[((0)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((0)*(5) + (0))*(klon) + (si2)] = __cb57[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zpsupsat_liq, psupsat[jk - 1, kidia - 1:kfdia], zpsupsatsrce[0, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb58[__r0] = (zpsupsat_liq[__r0] ? psupsat[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] : zpsupsatsrce[(0)*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zpsupsatsrce[(0)*(klon) + (si1)] = __cb58[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zpsupsat_liq, zqxfg[0, kidia - 1:kfdia] + psupsat[jk - 1, kidia - 1:kfdia], zqxfg[0,... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb59[__r0] = (zpsupsat_liq[__r0] ? (zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))] + psupsat[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) : zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqxfg[(0)*(klon) + (si1)] = __cb59[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zpsupsat_ice, zsolqa[1, 1, kidia - 1:kfdia] + psupsat[jk - 1, kidia - 1:kfdia], zsol... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb60[__r0] = (zpsupsat_ice[__r0] ? (zsolqa[((1)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))] + psupsat[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) : zsolqa[((1)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((1)*(5) + (1))*(klon) + (si2)] = __cb60[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zpsupsat_ice, psupsat[jk - 1, kidia - 1:kfdia], zpsupsatsrce[1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb61[__r0] = (zpsupsat_ice[__r0] ? psupsat[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] : zpsupsatsrce[(1)*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zpsupsatsrce[(1)*(klon) + (si1)] = __cb61[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zpsupsat_ice, zqxfg[1, kidia - 1:kfdia] + psupsat[jk - 1, kidia - 1:kfdia], zqxfg[1,... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb62[__r0] = (zpsupsat_ice[__r0] ? (zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))] + psupsat[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) : zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqxfg[(1)*(klon) + (si1)] = __cb62[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zpsupsat_active, (1.0 - za[jk - 1, kidia - 1:kfdia]) * zfaci, zsolac[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb63[__r0] = (zpsupsat_active[__r0] ? ((1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) * zfaci[__r0]) : zsolac[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsolac[si0] = __cb63[(si0 - (kidia - 1))];
          }
          if (((jk < nlev) && (jk >= 15))) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              plude[((jk - 1))*(klon) + (si1)] = (plude[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * zdtgdp[(si1 + ((kidia - 1) - (kidia - 1)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zplude_mask[__w0] = (((((int64_t)(ldcum[(__w0 + ((kidia - 1) - 0))])) != 0) & (plude[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 1e-08)) & (plu[(jk)*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zconvsrce_liq[__w0] = (zfoealfa[((jk - 1))*(klon) + (((kidia - 1) + __w0))] * plude[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zconvsrce_ice[__w0] = ((1.0 - zfoealfa[((jk - 1))*(klon) + (((kidia - 1) + __w0))]) * plude[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]);
            }
            /* numpy: np.where(zplude_mask, plu[jk, kidia - 1:kfdia], 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb64[__r0] = (zplude_mask[__r0] ? plu[(jk)*(klon) + ((__r0 + (kidia - 1)))] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zplu_safe[__w0] = __cb64[__w0];
            }
            /* numpy: np.where(zplude_mask, zsolac[kidia - 1:kfdia] + plude[jk - 1, kidia - 1:kfdia] / zplu_safe, z... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb65[__r0] = (zplude_mask[__r0] ? (zsolac[(__r0 + (kidia - 1))] + (plude[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] / zplu_safe[__r0])) : zsolac[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zsolac[si0] = __cb65[(si0 - (kidia - 1))];
            }
            /* numpy: np.where(zplude_mask, zconvsrce_liq, zconvsrce[0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb66[__r0] = (zplude_mask[__r0] ? zconvsrce_liq[__r0] : zconvsrce[(0)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zconvsrce[(0)*(klon) + (si1)] = __cb66[(si1 - (kidia - 1))];
            }
            /* numpy: np.where(zplude_mask, zconvsrce_ice, zconvsrce[1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb67[__r0] = (zplude_mask[__r0] ? zconvsrce_ice[__r0] : zconvsrce[(1)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zconvsrce[(1)*(klon) + (si1)] = __cb67[(si1 - (kidia - 1))];
            }
            /* numpy: np.where(zplude_mask, zsolqa[0, 0, kidia - 1:kfdia] + zconvsrce[0, kidia - 1:kfdia], zsolqa[0... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb68[__r0] = (zplude_mask[__r0] ? (zsolqa[((0)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] + zconvsrce[(0)*(klon) + ((__r0 + (kidia - 1)))]) : zsolqa[((0)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((0)*(5) + (0))*(klon) + (si2)] = __cb68[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zplude_mask, zsolqa[1, 1, kidia - 1:kfdia] + zconvsrce[1, kidia - 1:kfdia], zsolqa[1... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb69[__r0] = (zplude_mask[__r0] ? (zsolqa[((1)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))] + zconvsrce[(1)*(klon) + ((__r0 + (kidia - 1)))]) : zsolqa[((1)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((1)*(5) + (1))*(klon) + (si2)] = __cb69[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zplude_mask, plude[jk - 1, kidia - 1:kfdia], 0.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb70[__r0] = (zplude_mask[__r0] ? plude[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] : 0.0);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              plude[((jk - 1))*(klon) + (si1)] = __cb70[(si1 - (kidia - 1))];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zldcum_mask[__w0] = (((int64_t)(ldcum[(__w0 + ((kidia - 1) - 0))])) != 0);
            }
            /* numpy: np.where(zldcum_mask, zsolqa[3, 3, kidia - 1:kfdia] + psnde[jk - 1, kidia - 1:kfdia] * zdtgdp... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb71[__r0] = (zldcum_mask[__r0] ? (zsolqa[((3)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))] + (psnde[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] * zdtgdp[(__r0 + (kidia - 1))])) : zsolqa[((3)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((3)*(5) + (3))*(klon) + (si2)] = __cb71[(si2 - (kidia - 1))];
            }
          }
          if ((jk > 15)) {
            /* numpy: np.maximum(0.0, (pmfu[jk - 1, kidia - 1:kfdia] + pmfd[jk - 1, kidia - 1:kfdia]) * zdtgdp[kidi... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb72[__r0] = max(0.0, ((pmfu[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] + pmfd[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) * zdtgdp[(__r0 + (kidia - 1))]));
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zmf[si0] = __cb72[(si0 - (kidia - 1))];
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zacust[si0] = (zmf[(si0 + ((kidia - 1) - (kidia - 1)))] * zanewm1[(si0 + ((kidia - 1) - (kidia - 1)))]);
            }
            for (int64_t jm = 1; jm < 6; ++jm) {
              if (((!((int64_t)(llfall[(jm - 1)]))) && (((int64_t)(iphase[(jm - 1)])) > 0))) {
                for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                  zlcust[((jm - 1))*(klon) + (si1)] = (zmf[(si1 + ((kidia - 1) - (kidia - 1)))] * zqxnm1[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
                }
                for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                  zconvsrce[((jm - 1))*(klon) + (si1)] = (zconvsrce[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + zlcust[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdtdp_b5[__w0] = (((zrdcp * 0.5) * (ztp1[((jk - 2))*(klon) + ((__w0 + ((kidia - 1) - 0)))] + ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) / paph[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdtforc_b5[__w0] = (zdtdp_b5[__w0] * (pap[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - pap[((jk - 2))*(klon) + ((__w0 + ((kidia - 1) - 0)))]));
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zdqs[si0] = ((zanewm1[(si0 + ((kidia - 1) - (kidia - 1)))] * zdtforc_b5[(si0 - (kidia - 1))]) * zdqsmixdt[(si0 + ((kidia - 1) - (kidia - 1)))]);
            }
            for (int64_t jm = 1; jm < 6; ++jm) {
              if (((!((int64_t)(llfall[(jm - 1)]))) && (((int64_t)(iphase[(jm - 1)])) > 0))) {
                /* numpy: np.maximum(0.0, zlcust[jm - 1, kidia - 1:kfdia] - zdqs[kidia - 1:kfdia]) */
                for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                  __cb73[__r0] = max(0.0, (zlcust[((jm - 1))*(klon) + ((__r0 + (kidia - 1)))] - zdqs[(__r0 + (kidia - 1))]));
                }
                for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                  zlfinal[__w0] = __cb73[__w0];
                }
                /* numpy: np.minimum(zlcust[jm - 1, kidia - 1:kfdia] - zlfinal, zevaplimmix[kidia - 1:kfdia]) */
                for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                  __cb74[__r0] = min((zlcust[((jm - 1))*(klon) + ((__r0 + (kidia - 1)))] - zlfinal[__r0]), zevaplimmix[(__r0 + (kidia - 1))]);
                }
                for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                  zevap_b5[__w0] = __cb74[__w0];
                }
                for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                  zlfinal[__w0] = (zlcust[((jm - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - zevap_b5[__w0]);
                }
                for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
                  zlfinalsum[si0] = (zlfinalsum[(si0 + ((kidia - 1) - (kidia - 1)))] + zlfinal[(si0 - (kidia - 1))]);
                }
                for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                  zsolqa[(((jm - 1))*(5) + ((jm - 1)))*(klon) + (si2)] = (zsolqa[(((jm - 1))*(5) + ((jm - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + zlcust[((jm - 1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]);
                }
                for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                  zsolqa[(((jm - 1))*(5) + (4))*(klon) + (si2)] = (zsolqa[(((jm - 1))*(5) + (4))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + zevap_b5[(si2 - (kidia - 1))]);
                }
                for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                  zsolqa[((4)*(5) + ((jm - 1)))*(klon) + (si2)] = (zsolqa[((4)*(5) + ((jm - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] - zevap_b5[(si2 - (kidia - 1))]);
                }
              }
            }
            /* numpy: np.where(zlfinalsum[kidia - 1:kfdia] < zepsec, 0.0, zacust[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb75[__r0] = ((zlfinalsum[(__r0 + (kidia - 1))] < zepsec) ? 0.0 : zacust[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zacust[si0] = __cb75[(si0 - (kidia - 1))];
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zsolac[si0] = (zsolac[(si0 + ((kidia - 1) - (kidia - 1)))] + zacust[(si0 + ((kidia - 1) - (kidia - 1)))]);
            }
          }
          if ((jk < nlev)) {
            /* numpy: np.maximum(0.0, (pmfu[jk, kidia - 1:kfdia] + pmfd[jk, kidia - 1:kfdia]) * zdtgdp[kidia - 1:kf... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb76[__r0] = max(0.0, ((pmfu[(jk)*(klon) + ((__r0 + (kidia - 1)))] + pmfd[(jk)*(klon) + ((__r0 + (kidia - 1)))]) * zdtgdp[(__r0 + (kidia - 1))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zmfdn[__w0] = __cb76[__w0];
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zsolab[si0] = (zsolab[(si0 + ((kidia - 1) - (kidia - 1)))] + zmfdn[(si0 - (kidia - 1))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqb[((0)*(5) + (0))*(klon) + (si2)] = (zsolqb[((0)*(5) + (0))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + zmfdn[(si2 - (kidia - 1))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqb[((1)*(5) + (1))*(klon) + (si2)] = (zsolqb[((1)*(5) + (1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + zmfdn[(si2 - (kidia - 1))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zconvsink[(0)*(klon) + (si1)] = zmfdn[(si1 - (kidia - 1))];
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zconvsink[(1)*(klon) + (si1)] = zmfdn[(si1 - (kidia - 1))];
            }
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zldifdt[si0] = (3e-06 * ptsphy);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zldifdt_mask[__w0] = ((((int64_t)(ktype[(__w0 + ((kidia - 1) - 0))])) > 0) & (plude[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec));
          }
          /* numpy: np.where(zldifdt_mask, 7.0 * zldifdt[kidia - 1:kfdia], zldifdt[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb77[__r0] = (zldifdt_mask[__r0] ? (7.0 * zldifdt[(__r0 + (kidia - 1))]) : zldifdt[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zldifdt[si0] = __cb77[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zli_active[__w0] = (zli[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec);
          }
          /* numpy: np.maximum(zqsmix[jk - 1, kidia - 1:kfdia] - zqx[4, jk - 1, kidia - 1:kfdia], 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb78[__r0] = max((zqsmix[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]), 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            ze[__w0] = (zldifdt[(__w0 + ((kidia - 1) - 0))] * __cb78[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zleros[__w0] = (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * ze[__w0]);
          }
          /* numpy: np.minimum(zleros, zevaplimmix[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb79[__r0] = min(zleros[__r0], zevaplimmix[(__r0 + (kidia - 1))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zleros[__w0] = __cb79[__w0];
          }
          /* numpy: np.minimum(zleros, zli[jk - 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb80[__r0] = min(zleros[__r0], zli[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zleros[__w0] = __cb80[__w0];
          }
          /* numpy: np.where(zli_active, zlicld[kidia - 1:kfdia], 1.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb81[__r0] = (zli_active[__r0] ? zlicld[(__r0 + (kidia - 1))] : 1.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlicld_safe[__w0] = __cb81[__w0];
          }
          /* numpy: np.where(zli_active, zleros / zlicld_safe, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb82[__r0] = (zli_active[__r0] ? (zleros[__r0] / zlicld_safe[__r0]) : 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zaeros[__w0] = __cb82[__w0];
          }
          /* numpy: np.where(zli_active, zsolac[kidia - 1:kfdia] - zaeros, zsolac[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb83[__r0] = (zli_active[__r0] ? (zsolac[(__r0 + (kidia - 1))] - zaeros[__r0]) : zsolac[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsolac[si0] = __cb83[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zliq_zleros[__w0] = (zliqfrac[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zleros[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zice_zleros[__w0] = (zicefrac[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zleros[__w0]);
          }
          /* numpy: np.where(zli_active, zsolqa[0, 4, kidia - 1:kfdia] + zliq_zleros, zsolqa[0, 4, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb84[__r0] = (zli_active[__r0] ? (zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] + zliq_zleros[__r0]) : zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((0)*(5) + (4))*(klon) + (si2)] = __cb84[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zli_active, zsolqa[4, 0, kidia - 1:kfdia] - zliq_zleros, zsolqa[4, 0, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb85[__r0] = (zli_active[__r0] ? (zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] - zliq_zleros[__r0]) : zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (0))*(klon) + (si2)] = __cb85[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zli_active, zsolqa[1, 4, kidia - 1:kfdia] + zice_zleros, zsolqa[1, 4, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb86[__r0] = (zli_active[__r0] ? (zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] + zice_zleros[__r0]) : zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((1)*(5) + (4))*(klon) + (si2)] = __cb86[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zli_active, zsolqa[4, 1, kidia - 1:kfdia] - zice_zleros, zsolqa[4, 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb87[__r0] = (zli_active[__r0] ? (zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))] - zice_zleros[__r0]) : zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (1))*(klon) + (si2)] = __cb87[(si2 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zdtdp[__w0] = ((zrdcp * ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) / pap[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zdpmxdt[__w0] = (zdp[(__w0 + ((kidia - 1) - 0))] * zqtmst);
          }
          memset(zmfdn2, 0, (size_t)((((kfdia - kidia) + 1))) * sizeof(double));
          if ((jk < nlev)) {
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zmfdn2[__w0] = (pmfu[(jk)*(klon) + ((__w0 + ((kidia - 1) - 0)))] + pmfd[(jk)*(klon) + ((__w0 + ((kidia - 1) - 0)))]);
            }
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zwtot[__w0] = (pvervel[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] + ((0.5 * 9.80665) * ((pmfu[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] + pmfd[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) + zmfdn2[__w0])));
          }
          /* numpy: np.maximum(-zdpmxdt, zwtot) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb88[__r0] = max((-zdpmxdt[__r0]), zwtot[__r0]);
          }
          /* numpy: np.minimum(zdpmxdt, __cb88) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb89[__r0] = min(zdpmxdt[__r0], __cb88[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zwtot[__w0] = __cb89[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zzzdt[__w0] = (phrsw[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] + phrlw[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]);
          }
          /* numpy: np.maximum(-zdpmxdt * zdtdp, zzzdt) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb90[__r0] = max(((-zdpmxdt[__r0]) * zdtdp[__r0]), zzzdt[__r0]);
          }
          /* numpy: np.minimum(zdpmxdt * zdtdp, __cb90) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb91[__r0] = min((zdpmxdt[__r0] * zdtdp[__r0]), __cb90[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zdtdiab[__w0] = ((__cb91[__w0] * ptsphy) + (332.1360187066693 * zldefr[(__w0 + ((kidia - 1) - 0))]));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zdtforc[__w0] = (((zdtdp[__w0] * zwtot[__w0]) * ptsphy) + zdtdiab[__w0]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zqold[si0] = zqsmix[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            ztold[si0] = ztp1[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            ztp1[((jk - 1))*(klon) + (si1)] = (ztp1[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + zdtforc[(si1 - (kidia - 1))]);
          }
          /* numpy: np.maximum(ztp1[jk - 1, kidia - 1:kfdia], 160.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb92[__r0] = max(ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))], 160.0);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            ztp1[((jk - 1))*(klon) + (si1)] = __cb92[(si1 - (kidia - 1))];
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            llflag[si0] = 1;
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zqp[__w0] = (1.0 / pap[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]);
          }
          /* numpy: np.minimum(273.16, ztp1[jk - 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb93[__r0] = min(273.16, ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          /* numpy: np.maximum(250.16000000000003, __cb93) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb94[__r0] = max(250.16000000000003, __cb93[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw4b[__w0] = ((__cb94[__w0] - 250.16000000000003) * 0.043478260869565216);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw4[__w0] = (_pw4b[__w0] * _pw4b[__w0]);
          }
          /* numpy: np.minimum(1.0, _pw4) */
          for (int64_t __r0 = 0; __r0 < ((kfdia - kidia) + 1); ++__r0) {
            __cb95[__r0] = min(1.0, _pw4[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zalfa1[__w0] = __cb95[__w0];
          }
          /* numpy: np.exp(17.502 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16) / (ztp1[jk - 1, kidia - 1:kfdia] - 3... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb96[__r0] = exp(((17.502 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)) / (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 32.19)));
          }
          /* numpy: np.exp(22.587 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16) / (ztp1[jk - 1, kidia - 1:kfdia] - -... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb97[__r0] = exp(((22.587 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)) / (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - -0.7)));
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zqsat[__w0] = ((380.1608703442847 * ((zalfa1[__w0] * __cb96[__w0]) + ((1.0 - zalfa1[__w0]) * __cb97[__w0]))) * zqp[__w0]);
          }
          /* numpy: np.minimum(0.5, zqsat) */
          for (int64_t __r0 = 0; __r0 < ((kfdia - kidia) + 1); ++__r0) {
            __cb98[__r0] = min(0.5, zqsat[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zqsat[__w0] = __cb98[__w0];
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zcor[__w0] = (1.0 / (1.0 - (0.6077667316114637 * zqsat[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zqsat[__w0] = (zqsat[__w0] * zcor[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw5b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - 32.19);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw5[__w0] = (_pw5b[__w0] * _pw5b[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw6b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - -0.7);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw6[__w0] = (_pw6b[__w0] * _pw6b[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcond[__w0] = ((zqsmix[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - zqsat[__w0]) / (1.0 + ((zqsat[__w0] * zcor[__w0]) * (((zalfa1[__w0] * 10497584.68169531) * (1.0 / _pw5[__w0])) + (((1.0 - zalfa1[__w0]) * 17451123.253362577) * (1.0 / _pw6[__w0]))))));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            ztp1[((jk - 1))*(klon) + (si1)] = (ztp1[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + (((zalfa1[(si1 - (kidia - 1))] * 2489.0792795374246) + ((1.0 - zalfa1[(si1 - (kidia - 1))]) * 2821.2152982440934)) * zcond[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqsmix[((jk - 1))*(klon) + (si1)] = (zqsmix[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - zcond[(si1 - (kidia - 1))]);
          }
          /* numpy: np.minimum(273.16, ztp1[jk - 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb99[__r0] = min(273.16, ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          /* numpy: np.maximum(250.16000000000003, __cb99) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb100[__r0] = max(250.16000000000003, __cb99[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw7b[__w0] = ((__cb100[__w0] - 250.16000000000003) * 0.043478260869565216);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw7[__w0] = (_pw7b[__w0] * _pw7b[__w0]);
          }
          /* numpy: np.minimum(1.0, _pw7) */
          for (int64_t __r0 = 0; __r0 < ((kfdia - kidia) + 1); ++__r0) {
            __cb101[__r0] = min(1.0, _pw7[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zalfa1[__w0] = __cb101[__w0];
          }
          /* numpy: np.exp(17.502 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16) / (ztp1[jk - 1, kidia - 1:kfdia] - 3... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb102[__r0] = exp(((17.502 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)) / (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 32.19)));
          }
          /* numpy: np.exp(22.587 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16) / (ztp1[jk - 1, kidia - 1:kfdia] - -... */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb103[__r0] = exp(((22.587 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)) / (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - -0.7)));
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zqsat[__w0] = ((380.1608703442847 * ((zalfa1[__w0] * __cb102[__w0]) + ((1.0 - zalfa1[__w0]) * __cb103[__w0]))) * zqp[__w0]);
          }
          /* numpy: np.minimum(0.5, zqsat) */
          for (int64_t __r0 = 0; __r0 < ((kfdia - kidia) + 1); ++__r0) {
            __cb104[__r0] = min(0.5, zqsat[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zqsat[__w0] = __cb104[__w0];
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zcor[__w0] = (1.0 / (1.0 - (0.6077667316114637 * zqsat[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zqsat[__w0] = (zqsat[__w0] * zcor[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw8b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - 32.19);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw8[__w0] = (_pw8b[__w0] * _pw8b[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw9b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - -0.7);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw9[__w0] = (_pw9b[__w0] * _pw9b[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcond1[__w0] = ((zqsmix[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - zqsat[__w0]) / (1.0 + ((zqsat[__w0] * zcor[__w0]) * (((zalfa1[__w0] * 10497584.68169531) * (1.0 / _pw8[__w0])) + (((1.0 - zalfa1[__w0]) * 17451123.253362577) * (1.0 / _pw9[__w0]))))));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            ztp1[((jk - 1))*(klon) + (si1)] = (ztp1[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + (((zalfa1[(si1 - (kidia - 1))] * 2489.0792795374246) + ((1.0 - zalfa1[(si1 - (kidia - 1))]) * 2821.2152982440934)) * zcond1[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqsmix[((jk - 1))*(klon) + (si1)] = (zqsmix[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - zcond1[(si1 - (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zdqs[si0] = (zqsmix[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] - zqold[(si0 + ((kidia - 1) - (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqsmix[((jk - 1))*(klon) + (si1)] = zqold[(si1 + ((kidia - 1) - (kidia - 1)))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            ztp1[((jk - 1))*(klon) + (si1)] = ztold[(si1 + ((kidia - 1) - (kidia - 1)))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zdqs_pos[__w0] = (zdqs[(__w0 + ((kidia - 1) - 0))] > 0.0);
          }
          /* numpy: np.minimum(zdqs[kidia - 1:kfdia], zlicld[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb105[__r0] = min(zdqs[(__r0 + (kidia - 1))], zlicld[(__r0 + (kidia - 1))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlevap[__w0] = (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * __cb105[__w0]);
          }
          /* numpy: np.minimum(zlevap, zevaplimmix[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb106[__r0] = min(zlevap[__r0], zevaplimmix[(__r0 + (kidia - 1))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlevap[__w0] = __cb106[__w0];
          }
          /* numpy: np.maximum(zqsmix[jk - 1, kidia - 1:kfdia] - zqx[4, jk - 1, kidia - 1:kfdia], 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb107[__r0] = max((zqsmix[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]), 0.0);
          }
          /* numpy: np.minimum(zlevap, __cb107) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb108[__r0] = min(zlevap[__r0], __cb107[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlevap[__w0] = __cb108[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlevapl_new[__w0] = (zliqfrac[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zlevap[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlevapi_new[__w0] = (zicefrac[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zlevap[__w0]);
          }
          /* numpy: np.where(zdqs_pos, zlevapl_new, zlevapl[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb109[__r0] = (zdqs_pos[__r0] ? zlevapl_new[__r0] : zlevapl[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlevapl[si0] = __cb109[(si0 - (kidia - 1))];
          }
          /* numpy: np.where(zdqs_pos, zlevapi_new, zlevapi[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb110[__r0] = (zdqs_pos[__r0] ? zlevapi_new[__r0] : zlevapi[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlevapi[si0] = __cb110[(si0 - (kidia - 1))];
          }
          /* numpy: np.where(zdqs_pos, zsolqa[0, 4, kidia - 1:kfdia] + zlevapl_new, zsolqa[0, 4, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb111[__r0] = (zdqs_pos[__r0] ? (zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] + zlevapl_new[__r0]) : zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((0)*(5) + (4))*(klon) + (si2)] = __cb111[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zdqs_pos, zsolqa[4, 0, kidia - 1:kfdia] - zlevapl_new, zsolqa[4, 0, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb112[__r0] = (zdqs_pos[__r0] ? (zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] - zlevapl_new[__r0]) : zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (0))*(klon) + (si2)] = __cb112[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zdqs_pos, zsolqa[1, 4, kidia - 1:kfdia] + zlevapi_new, zsolqa[1, 4, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb113[__r0] = (zdqs_pos[__r0] ? (zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] + zlevapi_new[__r0]) : zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((1)*(5) + (4))*(klon) + (si2)] = __cb113[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zdqs_pos, zsolqa[4, 1, kidia - 1:kfdia] - zlevapi_new, zsolqa[4, 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb114[__r0] = (zdqs_pos[__r0] ? (zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))] - zlevapi_new[__r0]) : zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (1))*(klon) + (si2)] = __cb114[(si2 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zldcz_mask[__w0] = ((za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec) & (zdqs[(__w0 + ((kidia - 1) - 0))] <= (-1e-08)));
          }
          /* numpy: np.maximum(-zdqs[kidia - 1:kfdia], 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb115[__r0] = max((-zdqs[(__r0 + (kidia - 1))]), 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlcond1_0[__w0] = __cb115[__w0];
          }
          for (int64_t si0 = 0; si0 < (kfdia - (kidia - 1)); ++si0) {
            za_col[si0] = za[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - 0)))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            za_high[__w0] = (za_col[__w0] > 0.99);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcor[__w0] = (1.0 / (1.0 - (0.6077667316114637 * zqsmix[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])));
          }
          /* numpy: np.minimum(273.16, ztp1[jk - 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb116[__r0] = min(273.16, ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          /* numpy: np.maximum(250.16000000000003, __cb116) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb117[__r0] = max(250.16000000000003, __cb116[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw10b[__w0] = ((__cb117[__w0] - 250.16000000000003) * 0.043478260869565216);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw10[__w0] = (_pw10b[__w0] * _pw10b[__w0]);
          }
          /* numpy: np.minimum(1.0, _pw10) */
          for (int64_t __r0 = 0; __r0 < ((kfdia - kidia) + 1); ++__r0) {
            __cb118[__r0] = min(1.0, _pw10[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zalfa1[__w0] = __cb118[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw11b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - 32.19);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw11[__w0] = (_pw11b[__w0] * _pw11b[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw12b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - -0.7);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw12[__w0] = (_pw12b[__w0] * _pw12b[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcdmax_high[__w0] = ((zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - zqsmix[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) / (1.0 + ((zcor[__w0] * zqsmix[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) * (((zalfa1[__w0] * 10497584.68169531) * (1.0 / _pw11[__w0])) + (((1.0 - zalfa1[__w0]) * 17451123.253362577) * (1.0 / _pw12[__w0]))))));
          }
          /* numpy: np.where(za_col != 0.0, za_col, 1.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb119[__r0] = ((za_col[__r0] != 0.0) ? za_col[__r0] : 1.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            za_safe[__w0] = __cb119[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcdmax_low[__w0] = ((zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - (za_col[__w0] * zqsmix[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) / za_safe[__w0]);
          }
          /* numpy: np.where(za_high, zcdmax_high, zcdmax_low) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb120[__r0] = (za_high[__r0] ? zcdmax_high[__r0] : zcdmax_low[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcdmax[__w0] = __cb120[__w0];
          }
          /* numpy: np.minimum(zlcond1_0, zcdmax) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb121[__r0] = min(zlcond1_0[__r0], zcdmax[__r0]);
          }
          /* numpy: np.maximum(__cb121, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb122[__r0] = max(__cb121[__r0], 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlcond1_new[__w0] = __cb122[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlcond1_new[__w0] = (za_col[__w0] * zlcond1_new[__w0]);
          }
          /* numpy: np.where(zlcond1_new < 1e-08, 0.0, zlcond1_new) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb123[__r0] = ((zlcond1_new[__r0] < 1e-08) ? 0.0 : zlcond1_new[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlcond1_new[__w0] = __cb123[__w0];
          }
          /* numpy: np.where(zldcz_mask, zlcond1_new, zlcond1[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb124[__r0] = (zldcz_mask[__r0] ? zlcond1_new[__r0] : zlcond1[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlcond1[si0] = __cb124[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zldcz_liq[__w0] = (zldcz_mask[__w0] & (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 235.16000000000003));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zldcz_ice[__w0] = (zldcz_mask[__w0] & (!(ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 235.16000000000003)));
          }
          /* numpy: np.where(zldcz_liq, zsolqa[4, 0, kidia - 1:kfdia] + zlcond1_new, zsolqa[4, 0, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb125[__r0] = (zldcz_liq[__r0] ? (zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] + zlcond1_new[__r0]) : zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (0))*(klon) + (si2)] = __cb125[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zldcz_liq, zsolqa[0, 4, kidia - 1:kfdia] - zlcond1_new, zsolqa[0, 4, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb126[__r0] = (zldcz_liq[__r0] ? (zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] - zlcond1_new[__r0]) : zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((0)*(5) + (4))*(klon) + (si2)] = __cb126[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zldcz_liq, zqxfg[0, kidia - 1:kfdia] + zlcond1_new, zqxfg[0, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb127[__r0] = (zldcz_liq[__r0] ? (zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))] + zlcond1_new[__r0]) : zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqxfg[(0)*(klon) + (si1)] = __cb127[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zldcz_ice, zsolqa[4, 1, kidia - 1:kfdia] + zlcond1_new, zsolqa[4, 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb128[__r0] = (zldcz_ice[__r0] ? (zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))] + zlcond1_new[__r0]) : zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (1))*(klon) + (si2)] = __cb128[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zldcz_ice, zsolqa[1, 4, kidia - 1:kfdia] - zlcond1_new, zsolqa[1, 4, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb129[__r0] = (zldcz_ice[__r0] ? (zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] - zlcond1_new[__r0]) : zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((1)*(5) + (4))*(klon) + (si2)] = __cb129[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zldcz_ice, zqxfg[1, kidia - 1:kfdia] + zlcond1_new, zqxfg[1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb130[__r0] = (zldcz_ice[__r0] ? (zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))] + zlcond1_new[__r0]) : zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqxfg[(1)*(klon) + (si1)] = __cb130[(si1 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zdqs_neg_mask[__w0] = ((zdqs[(__w0 + ((kidia - 1) - 0))] <= (-1e-08)) & (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < (1.0 - zepsec)));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zsigk[__w0] = (pap[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] / paph[(nlev)*(klon) + ((__w0 + ((kidia - 1) - 0)))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw13b[__w0] = ((zsigk[__w0] - 0.8) / 0.2);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw13[__w0] = (_pw13b[__w0] * _pw13b[__w0]);
          }
          /* numpy: np.where(zsigk > 0.8, 0.8 + (1.0 - 0.8) * _pw13, 0.8) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb131[__r0] = ((zsigk[__r0] > 0.8) ? (0.8 + ((1.0 - 0.8) * _pw13[__r0])) : 0.8);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zrhc[__w0] = __cb131[__w0];
          }
          /* numpy: np.maximum(zepsec, 1.0 - za[jk - 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb132[__r0] = max(zepsec, (1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zqe[__w0] = ((zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) / __cb132[__w0]);
          }
          /* numpy: np.maximum(0.0, zqe) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb133[__r0] = max(0.0, zqe[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zqe[__w0] = __cb133[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfac_cond2[__w0] = ((ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] >= 273.16) | 0);
          }
          /* numpy: np.where(zfac_cond2, 1.0, zfokoop[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb134[__r0] = (zfac_cond2[__r0] ? 1.0 : zfokoop[(__r0 + (kidia - 1))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfac[__w0] = __cb134[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zsat_range[__w0] = ((zqe[__w0] >= ((zrhc[__w0] * zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) * zfac[__w0])) & (zqe[__w0] < (zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zfac[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zac_mask[__w0] = (zdqs_neg_mask[__w0] & zsat_range[__w0]);
          }
          for (int64_t si0 = 0; si0 < (kfdia - (kidia - 1)); ++si0) {
            za_col[si0] = za[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - 0)))];
          }
          /* numpy: np.maximum(2.0 * (zfac * zqsice[jk - 1, kidia - 1:kfdia] - zqe), zepsec) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb135[__r0] = max((2.0 * ((zfac[__r0] * zqsice[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) - zqe[__r0])), zepsec);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zacond[__w0] = ((((-(1.0 - za_col[__w0])) * zfac[__w0]) * zdqs[(__w0 + ((kidia - 1) - 0))]) / __cb135[__w0]);
          }
          /* numpy: np.minimum(zacond, 1.0 - za_col) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb136[__r0] = min(zacond[__r0], (1.0 - za_col[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zacond[__w0] = __cb136[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlcond2_new[__w0] = ((((-zfac[__w0]) * zdqs[(__w0 + ((kidia - 1) - 0))]) * 0.5) * zacond[__w0]);
          }
          /* numpy: np.maximum(zepsec, 1.0 - za_col) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb137[__r0] = max(zepsec, (1.0 - za_col[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zzdl[__w0] = ((2.0 * ((zfac[__w0] * zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) - zqe[__w0])) / __cb137[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlcondlim_mask[__w0] = ((zfac[__w0] * zdqs[(__w0 + ((kidia - 1) - 0))]) < (-zzdl[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlcondlim[__w0] = (((((za_col[__w0] - 1.0) * zfac[__w0]) * zdqs[(__w0 + ((kidia - 1) - 0))]) - (zfac[__w0] * zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) + zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))]);
          }
          /* numpy: np.minimum(zlcond2_new, zlcondlim) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb138[__r0] = min(zlcond2_new[__r0], zlcondlim[__r0]);
          }
          /* numpy: np.where(zlcondlim_mask, __cb138, zlcond2_new) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb139[__r0] = (zlcondlim_mask[__r0] ? __cb138[__r0] : zlcond2_new[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlcond2_new[__w0] = __cb139[__w0];
          }
          /* numpy: np.maximum(zlcond2_new, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb140[__r0] = max(zlcond2_new[__r0], 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlcond2_new[__w0] = __cb140[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zzero_mask[__w0] = ((zlcond2_new[__w0] < 1e-08) | ((1.0 - za_col[__w0]) < zepsec));
          }
          /* numpy: np.where(zzero_mask, 0.0, zlcond2_new) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb141[__r0] = (zzero_mask[__r0] ? 0.0 : zlcond2_new[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zlcond2_new[__w0] = __cb141[__w0];
          }
          /* numpy: np.where(zzero_mask, 0.0, zacond) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb142[__r0] = (zzero_mask[__r0] ? 0.0 : zacond[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zacond[__w0] = __cb142[__w0];
          }
          /* numpy: np.where(zlcond2_new == 0.0, 0.0, zacond) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb143[__r0] = ((zlcond2_new[__r0] == 0.0) ? 0.0 : zacond[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zacond[__w0] = __cb143[__w0];
          }
          /* numpy: np.where(zac_mask, zlcond2_new, zlcond2[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb144[__r0] = (zac_mask[__r0] ? zlcond2_new[__r0] : zlcond2[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlcond2[si0] = __cb144[(si0 - (kidia - 1))];
          }
          /* numpy: np.where(zac_mask, zsolac[kidia - 1:kfdia] + zacond, zsolac[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb145[__r0] = (zac_mask[__r0] ? (zsolac[(__r0 + (kidia - 1))] + zacond[__r0]) : zsolac[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsolac[si0] = __cb145[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zac_liq[__w0] = (zac_mask[__w0] & (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 235.16000000000003));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zac_ice[__w0] = (zac_mask[__w0] & (!(ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 235.16000000000003)));
          }
          /* numpy: np.where(zac_liq, zsolqa[4, 0, kidia - 1:kfdia] + zlcond2_new, zsolqa[4, 0, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb146[__r0] = (zac_liq[__r0] ? (zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] + zlcond2_new[__r0]) : zsolqa[((4)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (0))*(klon) + (si2)] = __cb146[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zac_liq, zsolqa[0, 4, kidia - 1:kfdia] - zlcond2_new, zsolqa[0, 4, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb147[__r0] = (zac_liq[__r0] ? (zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] - zlcond2_new[__r0]) : zsolqa[((0)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((0)*(5) + (4))*(klon) + (si2)] = __cb147[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zac_liq, zqxfg[0, kidia - 1:kfdia] + zlcond2_new, zqxfg[0, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb148[__r0] = (zac_liq[__r0] ? (zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))] + zlcond2_new[__r0]) : zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqxfg[(0)*(klon) + (si1)] = __cb148[(si1 - (kidia - 1))];
          }
          /* numpy: np.where(zac_ice, zsolqa[4, 1, kidia - 1:kfdia] + zlcond2_new, zsolqa[4, 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb149[__r0] = (zac_ice[__r0] ? (zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))] + zlcond2_new[__r0]) : zsolqa[((4)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((4)*(5) + (1))*(klon) + (si2)] = __cb149[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zac_ice, zsolqa[1, 4, kidia - 1:kfdia] - zlcond2_new, zsolqa[1, 4, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb150[__r0] = (zac_ice[__r0] ? (zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] - zlcond2_new[__r0]) : zsolqa[((1)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((1)*(5) + (4))*(klon) + (si2)] = __cb150[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zac_ice, zqxfg[1, kidia - 1:kfdia] + zlcond2_new, zqxfg[1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb151[__r0] = (zac_ice[__r0] ? (zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))] + zlcond2_new[__r0]) : zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqxfg[(1)*(klon) + (si1)] = __cb151[(si1 - (kidia - 1))];
          }
          if ((idepice == 1)) {
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcldtop_reset[__w0] = ((za[((jk - 2))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 0.01) & (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] >= 0.01));
            }
            /* numpy: np.where(zcldtop_reset, 0.0, zcldtopdist[kidia - 1:kfdia] + zdp[kidia - 1:kfdia] / (zrho[kidi... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb152[__r0] = (zcldtop_reset[__r0] ? 0.0 : (zcldtopdist[(__r0 + (kidia - 1))] + (zdp[(__r0 + (kidia - 1))] / (zrho[(__r0 + (kidia - 1))] * 9.80665))));
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zcldtopdist[si0] = __cb152[(si0 - (kidia - 1))];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdep_mask[__w0] = ((ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 273.16) & (zqxfg[(0)*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 1e-08));
            }
            /* numpy: np.exp(22.587 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16) / (ztp1[jk - 1, kidia - 1:kfdia] - -... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb153[__r0] = exp(((22.587 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)) / (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - -0.7)));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zvpice[__w0] = (((380.1608703442847 * __cb153[__w0]) * 461.5249933083879) / 287.0596736665907);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zvpliq[__w0] = (zvpice[__w0] * zfokoop[(__w0 + ((kidia - 1) - 0))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zicenuclei_new[__w0] = (1000.0 * exp((((12.96 * (zvpliq[__w0] - zvpice[__w0])) / zvpliq[__w0]) - 0.639)));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zadd[__w0] = ((2834500.0 * ((2834500.0 / (461.5249933083879 * ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) - 1.0)) / (0.024 * ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zbdd[__w0] = (((461.5249933083879 * ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) * pap[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) / (2.21 * zvpice[__w0]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw14b[__w0] = (zicenuclei_new[__w0] / zrho[(__w0 + ((kidia - 1) - 0))]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw14[__w0] = pow(_pw14b[__w0], 0.666);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zcvds[__w0] = (((7.8 * _pw14[__w0]) * (zvpliq[__w0] - zvpice[__w0])) / ((8.87 * (zadd[__w0] + zbdd[__w0])) * zvpice[__w0]));
            }
            /* numpy: np.maximum(zicecld[kidia - 1:kfdia], zicenuclei_new * 1e-12 / zrho[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb154[__r0] = max(zicecld[(__r0 + (kidia - 1))], ((zicenuclei_new[__r0] * 1e-12) / zrho[(__r0 + (kidia - 1))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zice0[__w0] = __cb154[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw15b[__w0] = zice0[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw15[__w0] = pow(_pw15b[__w0], 0.666);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw16b[__w0] = (((0.666 * zcvds[__w0]) * ptsphy) + _pw15[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw16[__w0] = pow(_pw16b[__w0], 1.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zinew[__w0] = _pw16[__w0];
            }
            /* numpy: np.maximum(za[jk - 1, kidia - 1:kfdia] * (zinew - zice0), 0.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb155[__r0] = max((za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] * (zinew[__r0] - zice0[__r0])), 0.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdepos[__w0] = __cb155[__w0];
            }
            /* numpy: np.minimum(zdepos, zqxfg[0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb156[__r0] = min(zdepos[__r0], zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdepos[__w0] = __cb156[__w0];
            }
            /* numpy: np.minimum(zicenuclei_new / 15000.0, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb157[__r0] = min((zicenuclei_new[__r0] / 15000.0), 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zinfactor[__w0] = __cb157[__w0];
            }
            /* numpy: np.minimum(zinfactor + (1.0 - zinfactor) * (0.1 + zcldtopdist[kidia - 1:kfdia] / 500.0), 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb158[__r0] = min((zinfactor[__r0] + ((1.0 - zinfactor[__r0]) * (0.1 + (zcldtopdist[(__r0 + (kidia - 1))] / 500.0)))), 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdepos[__w0] = (zdepos[__w0] * __cb158[__w0]);
            }
            /* numpy: np.where(zdep_mask, zicenuclei_new, zicenuclei[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb159[__r0] = (zdep_mask[__r0] ? zicenuclei_new[__r0] : zicenuclei[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zicenuclei[si0] = __cb159[(si0 - (kidia - 1))];
            }
            /* numpy: np.where(zdep_mask, zsolqa[0, 1, kidia - 1:kfdia] + zdepos, zsolqa[0, 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb160[__r0] = (zdep_mask[__r0] ? (zsolqa[((0)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))] + zdepos[__r0]) : zsolqa[((0)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((0)*(5) + (1))*(klon) + (si2)] = __cb160[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zdep_mask, zsolqa[1, 0, kidia - 1:kfdia] - zdepos, zsolqa[1, 0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb161[__r0] = (zdep_mask[__r0] ? (zsolqa[((1)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] - zdepos[__r0]) : zsolqa[((1)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((1)*(5) + (0))*(klon) + (si2)] = __cb161[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zdep_mask, zqxfg[1, kidia - 1:kfdia] + zdepos, zqxfg[1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb162[__r0] = (zdep_mask[__r0] ? (zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))] + zdepos[__r0]) : zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxfg[(1)*(klon) + (si1)] = __cb162[(si1 - (kidia - 1))];
            }
            /* numpy: np.where(zdep_mask, zqxfg[0, kidia - 1:kfdia] - zdepos, zqxfg[0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb163[__r0] = (zdep_mask[__r0] ? (zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))] - zdepos[__r0]) : zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxfg[(0)*(klon) + (si1)] = __cb163[(si1 - (kidia - 1))];
            }
          }
          else if ((idepice == 2)) {
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcldtop_reset[__w0] = ((za[((jk - 2))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 0.01) & (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] >= 0.01));
            }
            /* numpy: np.where(zcldtop_reset, 0.0, zcldtopdist[kidia - 1:kfdia] + zdp[kidia - 1:kfdia] / (zrho[kidi... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb164[__r0] = (zcldtop_reset[__r0] ? 0.0 : (zcldtopdist[(__r0 + (kidia - 1))] + (zdp[(__r0 + (kidia - 1))] / (zrho[(__r0 + (kidia - 1))] * 9.80665))));
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zcldtopdist[si0] = __cb164[(si0 - (kidia - 1))];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdep_mask[__w0] = ((ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 273.16) & (zqxfg[(0)*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 1e-08));
            }
            /* numpy: np.exp(22.587 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16) / (ztp1[jk - 1, kidia - 1:kfdia] - -... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb165[__r0] = exp(((22.587 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)) / (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - -0.7)));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zvpice[__w0] = (((380.1608703442847 * __cb165[__w0]) * 461.5249933083879) / 287.0596736665907);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zvpliq[__w0] = (zvpice[__w0] * zfokoop[(__w0 + ((kidia - 1) - 0))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zicenuclei_new[__w0] = (1000.0 * exp((((12.96 * (zvpliq[__w0] - zvpice[__w0])) / zvpliq[__w0]) - 0.639)));
            }
            /* numpy: np.maximum(zicecld[kidia - 1:kfdia], zicenuclei_new * 1e-12 / zrho[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb166[__r0] = max(zicecld[(__r0 + (kidia - 1))], ((zicenuclei_new[__r0] * 1e-12) / zrho[(__r0 + (kidia - 1))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zice0[__w0] = __cb166[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw17[__w0] = ((ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))] * ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))]) * ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zaplusb[__w0] = (((714000000000.0 * zvpice[__w0]) - ((116000000.0 * zvpice[__w0]) * ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) + ((pap[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * 241.6) * _pw17[__w0]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw18b[__w0] = (1.0 / zrho[(__w0 + ((kidia - 1) - 0))]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw18[__w0] = pow(_pw18b[__w0], 0.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zcorrfac[__w0] = _pw18[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw19b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] / 273.0);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw19[__w0] = pow(_pw19b[__w0], 1.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zcorrfac2[__w0] = (_pw19[__w0] * (393.0 / (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] + 120.0)));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zpr02[__w0] = (((zrho[(__w0 + ((kidia - 1) - 0))] * zice0[__w0]) * 3.6231880115136998e-06) / (1.0 * 1.0));
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw20[__w0] = (ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))] * ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zterm1[__w0] = ((((((((zvpliq[__w0] - zvpice[__w0]) * _pw20[__w0]) * zvpice[__w0]) * zcorrfac2[__w0]) * 1.0) * 6283185.307179586) * 1.0) / ((zrho[(__w0 + ((kidia - 1) - 0))] * zaplusb[__w0]) * zvpice[__w0]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw21b[__w0] = zpr02[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw21[__w0] = pow(_pw21b[__w0], 0.6666666666666666);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw22b[__w0] = zcorrfac2[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw22[__w0] = pow(_pw22b[__w0], 0.5);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw23b[__w0] = zpr02[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw23[__w0] = pow(_pw23b[__w0], 0.9211666666666667);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw24b[__w0] = zrho[(__w0 + ((kidia - 1) - 0))];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw24[__w0] = pow(_pw24b[__w0], 0.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw25b[__w0] = zcorrfac[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw25[__w0] = pow(_pw25b[__w0], 0.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zterm2[__w0] = (((0.65 * 1.0000000948961185) * _pw21[__w0]) + ((((596.9998475835998 * _pw25[__w0]) * _pw24[__w0]) * _pw23[__w0]) / _pw22[__w0]));
            }
            /* numpy: np.maximum(za[jk - 1, kidia - 1:kfdia] * zterm1 * zterm2 * ptsphy, 0.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb167[__r0] = max((((za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] * zterm1[__r0]) * zterm2[__r0]) * ptsphy), 0.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdepos[__w0] = __cb167[__w0];
            }
            /* numpy: np.minimum(zdepos, zqxfg[0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb168[__r0] = min(zdepos[__r0], zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdepos[__w0] = __cb168[__w0];
            }
            /* numpy: np.minimum(zicenuclei_new / 15000.0, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb169[__r0] = min((zicenuclei_new[__r0] / 15000.0), 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zinfactor[__w0] = __cb169[__w0];
            }
            /* numpy: np.minimum(zinfactor + (1.0 - zinfactor) * (0.1 + zcldtopdist[kidia - 1:kfdia] / 500.0), 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb170[__r0] = min((zinfactor[__r0] + ((1.0 - zinfactor[__r0]) * (0.1 + (zcldtopdist[(__r0 + (kidia - 1))] / 500.0)))), 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdepos[__w0] = (zdepos[__w0] * __cb170[__w0]);
            }
            /* numpy: np.where(zdep_mask, zicenuclei_new, zicenuclei[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb171[__r0] = (zdep_mask[__r0] ? zicenuclei_new[__r0] : zicenuclei[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zicenuclei[si0] = __cb171[(si0 - (kidia - 1))];
            }
            /* numpy: np.where(zdep_mask, zsolqa[0, 1, kidia - 1:kfdia] + zdepos, zsolqa[0, 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb172[__r0] = (zdep_mask[__r0] ? (zsolqa[((0)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))] + zdepos[__r0]) : zsolqa[((0)*(5) + (1))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((0)*(5) + (1))*(klon) + (si2)] = __cb172[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zdep_mask, zsolqa[1, 0, kidia - 1:kfdia] - zdepos, zsolqa[1, 0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb173[__r0] = (zdep_mask[__r0] ? (zsolqa[((1)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] - zdepos[__r0]) : zsolqa[((1)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((1)*(5) + (0))*(klon) + (si2)] = __cb173[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zdep_mask, zqxfg[1, kidia - 1:kfdia] + zdepos, zqxfg[1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb174[__r0] = (zdep_mask[__r0] ? (zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))] + zdepos[__r0]) : zqxfg[(1)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxfg[(1)*(klon) + (si1)] = __cb174[(si1 - (kidia - 1))];
            }
            /* numpy: np.where(zdep_mask, zqxfg[0, kidia - 1:kfdia] - zdepos, zqxfg[0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb175[__r0] = (zdep_mask[__r0] ? (zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))] - zdepos[__r0]) : zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxfg[(0)*(klon) + (si1)] = __cb175[(si1 - (kidia - 1))];
            }
          }
          /* numpy: np.maximum(za[jk - 1, kidia - 1:kfdia], zepsec) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb176[__r0] = max(za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))], zepsec);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            ztmpa[__w0] = (1.0 / __cb176[__w0]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zliqcld[si0] = (zqxfg[(0)*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] * ztmpa[(si0 - (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zicecld[si0] = (zqxfg[(1)*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] * ztmpa[(si0 - (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zlicld[si0] = (zliqcld[(si0 + ((kidia - 1) - (kidia - 1)))] + zicecld[(si0 + ((kidia - 1) - (kidia - 1)))]);
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            if ((((int64_t)(llfall[(jm - 1)])) || (jm == 2))) {
              if ((jk > 15)) {
                for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                  zfallsrce[((jm - 1))*(klon) + (si1)] = (zpfplsx[(((jm - 1))*((nlev + 1)) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * zdtgdp[(si1 + ((kidia - 1) - (kidia - 1)))]);
                }
                for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                  zsolqa[(((jm - 1))*(5) + ((jm - 1)))*(klon) + (si2)] = (zsolqa[(((jm - 1))*(5) + ((jm - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + zfallsrce[((jm - 1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]);
                }
                for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                  zqxfg[((jm - 1))*(klon) + (si1)] = (zqxfg[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + zfallsrce[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
                }
                for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
                  zqpretot[si0] = (zqpretot[(si0 + ((kidia - 1) - (kidia - 1)))] + zqxfg[((jm - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]);
                }
              }
              if ((0 && (jm == 2))) {
                for (int64_t jl = kidia; jl < (kfdia + 1); ++jl) {
                  zre_ice = pre_ice[((jk - 1))*(klon) + ((jl - 1))];
                  zvqx[1] = (0.002 * zre_ice);
                }
              }
              for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                zfall[__w0] = (zvqx[(jm - 1)] * zrho[(__w0 + ((kidia - 1) - 0))]);
              }
              for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                zfallsink[((jm - 1))*(klon) + (si1)] = (zdtgdp[(si1 + ((kidia - 1) - (kidia - 1)))] * zfall[(si1 - (kidia - 1))]);
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zqpretot_active[__w0] = (zqpretot[(__w0 + ((kidia - 1) - 0))] > zepsec);
          }
          /* numpy: np.maximum(za[jk - 1, kidia - 1:kfdia], za[jk - 2, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb177[__r0] = max(za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))], za[((jk - 2))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          /* numpy: np.minimum(za[jk - 2, kidia - 1:kfdia], 1.0 - 1e-06) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb178[__r0] = min(za[((jk - 2))*(klon) + ((__r0 + (kidia - 1)))], (1.0 - 1e-06));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcovptot_new[__w0] = (1.0 - (((1.0 - zcovptot[(__w0 + ((kidia - 1) - 0))]) * (1.0 - __cb177[__w0])) / (1.0 - __cb178[__w0])));
          }
          /* numpy: np.maximum(zcovptot_new, 0.1) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb179[__r0] = max(zcovptot_new[__r0], 0.1);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcovptot_new[__w0] = __cb179[__w0];
          }
          /* numpy: np.where(zqpretot_active, zcovptot_new, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb180[__r0] = (zqpretot_active[__r0] ? zcovptot_new[__r0] : 0.0);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zcovptot[si0] = __cb180[(si0 - (kidia - 1))];
          }
          /* numpy: np.maximum(0.0, zcovptot_new - za[jk - 1, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb181[__r0] = max(0.0, (zcovptot_new[__r0] - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcovpclr_new[__w0] = __cb181[__w0];
          }
          /* numpy: np.where(zqpretot_active, zcovpclr_new, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb182[__r0] = (zqpretot_active[__r0] ? zcovpclr_new[__r0] : 0.0);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zcovpclr[si0] = __cb182[(si0 - (kidia - 1))];
          }
          /* numpy: np.where(zqpretot_active, zcovptot_new, 1.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb183[__r0] = (zqpretot_active[__r0] ? zcovptot_new[__r0] : 1.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcovptot_safe[__w0] = __cb183[__w0];
          }
          /* numpy: np.where(zqpretot_active, zqxfg[2, kidia - 1:kfdia] / zcovptot_safe, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb184[__r0] = (zqpretot_active[__r0] ? (zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))] / zcovptot_safe[__r0]) : 0.0);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zraincld[si0] = __cb184[(si0 - (kidia - 1))];
          }
          /* numpy: np.where(zqpretot_active, zqxfg[3, kidia - 1:kfdia] / zcovptot_safe, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb185[__r0] = (zqpretot_active[__r0] ? (zqxfg[(3)*(klon) + ((__r0 + (kidia - 1)))] / zcovptot_safe[__r0]) : 0.0);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsnowcld[si0] = __cb185[(si0 - (kidia - 1))];
          }
          /* numpy: np.maximum(zcovptot_new, zcovpmax[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb186[__r0] = max(zcovptot_new[__r0], zcovpmax[(__r0 + (kidia - 1))]);
          }
          /* numpy: np.where(zqpretot_active, __cb186, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb187[__r0] = (zqpretot_active[__r0] ? __cb186[__r0] : 0.0);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zcovpmax[si0] = __cb187[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zice_mask[__w0] = ((ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] <= 273.16) & (zicecld[(__w0 + ((kidia - 1) - 0))] > zepsec));
          }
          /* numpy: np.exp(0.03 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16)) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb188[__r0] = exp((0.03 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zzco[__w0] = ((ptsphy * 0.001) * __cb188[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zlcrit[__w0] = 3e-05;
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw27b[__w0] = (zicecld[(__w0 + ((kidia - 1) - 0))] / zlcrit[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw27[__w0] = (_pw27b[__w0] * _pw27b[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zsnowaut_new[__w0] = (zzco[__w0] * (1.0 - exp((-_pw27[__w0]))));
          }
          /* numpy: np.where(zice_mask, zsnowaut_new, zsnowaut[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb189[__r0] = (zice_mask[__r0] ? zsnowaut_new[__r0] : zsnowaut[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zsnowaut[si0] = __cb189[(si0 - (kidia - 1))];
          }
          /* numpy: np.where(zice_mask, zsolqb[1, 3, kidia - 1:kfdia] + zsnowaut_new, zsolqb[1, 3, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb190[__r0] = (zice_mask[__r0] ? (zsolqb[((1)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))] + zsnowaut_new[__r0]) : zsolqb[((1)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqb[((1)*(5) + (3))*(klon) + (si2)] = __cb190[(si2 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zwarm_mask[__w0] = (zliqcld[(__w0 + ((kidia - 1) - 0))] > zepsec);
          }
          if ((iwarmrain == 1)) {
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zzco_d1[__w0] = (0.00016666666666666666 * ptsphy);
            }
            /* numpy: np.where(plsm[kidia - 1:kfdia] > 0.5, 0.00055, 0.00025) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb191[__r0] = ((plsm[(__r0 + (kidia - 1))] > 0.5) ? 0.00055 : 0.00025);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zlcrit_d1[__w0] = __cb191[__w0];
            }
            /* numpy: np.maximum(zepsec, zcovptot[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb192[__r0] = max(zepsec, zcovptot[(__r0 + (kidia - 1))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zprecip_d1[__w0] = ((zpfplsx[((3)*((nlev + 1)) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] + zpfplsx[((2)*((nlev + 1)) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) / __cb192[__w0]);
            }
            /* numpy: np.maximum(zprecip_d1, 0.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb193[__r0] = max(zprecip_d1[__r0], 0.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcfpr_d1[__w0] = (1.0 + (100.0 * sqrt(__cb193[__w0])));
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zzco_d1[__w0] *= zcfpr_d1[__w0];
            }
            /* numpy: np.maximum(zcfpr_d1, zepsec) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb194[__r0] = max(zcfpr_d1[__r0], zepsec);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zlcrit_d1[__w0] /= __cb194[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zbelow20[__w0] = ((zliqcld[(__w0 + ((kidia - 1) - 0))] / zlcrit_d1[__w0]) < 20.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw30b[__w0] = (zliqcld[(__w0 + ((kidia - 1) - 0))] / zlcrit_d1[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw30[__w0] = (_pw30b[__w0] * _pw30b[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zrainaut_lo[__w0] = (zzco_d1[__w0] * (1.0 - exp((-_pw30[__w0]))));
            }
            /* numpy: np.where(zbelow20, zrainaut_lo, zzco_d1) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb195[__r0] = (zbelow20[__r0] ? zrainaut_lo[__r0] : zzco_d1[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrainaut1[__w0] = __cb195[__w0];
            }
            /* numpy: np.where(zwarm_mask, zrainaut1, zrainaut[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb196[__r0] = (zwarm_mask[__r0] ? zrainaut1[__r0] : zrainaut[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zrainaut[si0] = __cb196[(si0 - (kidia - 1))];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zwarm_frz[__w0] = (zwarm_mask[__w0] & (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] <= 273.16));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zwarm_liq[__w0] = (zwarm_mask[__w0] & (!(ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] <= 273.16)));
            }
            /* numpy: np.where(zwarm_frz, zsolqb[0, 3, kidia - 1:kfdia] + zrainaut1, zsolqb[0, 3, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb197[__r0] = (zwarm_frz[__r0] ? (zsolqb[((0)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))] + zrainaut1[__r0]) : zsolqb[((0)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqb[((0)*(5) + (3))*(klon) + (si2)] = __cb197[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zwarm_liq, zsolqb[0, 2, kidia - 1:kfdia] + zrainaut1, zsolqb[0, 2, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb198[__r0] = (zwarm_liq[__r0] ? (zsolqb[((0)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))] + zrainaut1[__r0]) : zsolqb[((0)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqb[((0)*(5) + (2))*(klon) + (si2)] = __cb198[(si2 - (kidia - 1))];
            }
          }
          else if ((iwarmrain == 2)) {
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zland_mask[__w0] = (plsm[(__w0 + ((kidia - 1) - 0))] > 0.5);
            }
            /* numpy: np.where(zland_mask, 300.0, 50.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb199[__r0] = (zland_mask[__r0] ? 300.0 : 50.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zconst[__w0] = __cb199[__w0];
            }
            /* numpy: np.where(zland_mask, 0.00055, 0.00025) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb200[__r0] = (zland_mask[__r0] ? 0.00055 : 0.00025);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zlcrit2[__w0] = __cb200[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zliqcld_col[__w0] = zliqcld[(__w0 + ((kidia - 1) - 0))];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zabove_crit[__w0] = (zliqcld_col[__w0] > zlcrit2[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw31b[__w0] = zconst[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw31[__w0] = pow(_pw31b[__w0], -1.79);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw32b[__w0] = zliqcld_col[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw32[__w0] = pow(_pw32b[__w0], 2.47);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrainaut_new[__w0] = (((((1.5 * za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) * ptsphy) * 1350.0) * _pw32[__w0]) * _pw31[__w0]);
            }
            /* numpy: np.minimum(zrainaut_new, zqxfg[0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb201[__r0] = min(zrainaut_new[__r0], zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrainaut_new[__w0] = __cb201[__w0];
            }
            /* numpy: np.where(zrainaut_new < zepsec, 0.0, zrainaut_new) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb202[__r0] = ((zrainaut_new[__r0] < zepsec) ? 0.0 : zrainaut_new[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrainaut_new[__w0] = __cb202[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw33b[__w0] = (zliqcld_col[__w0] * zraincld[(__w0 + ((kidia - 1) - 0))]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw33[__w0] = pow(_pw33b[__w0], 1.15);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrainacc_new[__w0] = ((((2.0 * za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) * ptsphy) * 67.0) * _pw33[__w0]);
            }
            /* numpy: np.minimum(zrainacc_new, zqxfg[0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb203[__r0] = min(zrainacc_new[__r0], zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrainacc_new[__w0] = __cb203[__w0];
            }
            /* numpy: np.where(zrainacc_new < zepsec, 0.0, zrainacc_new) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb204[__r0] = ((zrainacc_new[__r0] < zepsec) ? 0.0 : zrainacc_new[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrainacc_new[__w0] = __cb204[__w0];
            }
            /* numpy: np.where(zabove_crit, zrainaut_new, 0.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb205[__r0] = (zabove_crit[__r0] ? zrainaut_new[__r0] : 0.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrainaut2[__w0] = __cb205[__w0];
            }
            /* numpy: np.where(zabove_crit, zrainacc_new, 0.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb206[__r0] = (zabove_crit[__r0] ? zrainacc_new[__r0] : 0.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrainacc2[__w0] = __cb206[__w0];
            }
            /* numpy: np.where(zwarm_mask, zrainaut2, zrainaut[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb207[__r0] = (zwarm_mask[__r0] ? zrainaut2[__r0] : zrainaut[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zrainaut[si0] = __cb207[(si0 - (kidia - 1))];
            }
            /* numpy: np.where(zwarm_mask, zrainacc2, zrainacc[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb208[__r0] = (zwarm_mask[__r0] ? zrainacc2[__r0] : zrainacc[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zrainacc[si0] = __cb208[(si0 - (kidia - 1))];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zwarm_frz[__w0] = (zwarm_mask[__w0] & (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] <= 273.16));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zwarm_liq[__w0] = (zwarm_mask[__w0] & (!(ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] <= 273.16)));
            }
            /* numpy: np.where(zwarm_frz, zsolqa[0, 3, kidia - 1:kfdia] + zrainaut2, zsolqa[0, 3, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb209[__r0] = (zwarm_frz[__r0] ? (zsolqa[((0)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))] + zrainaut2[__r0]) : zsolqa[((0)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((0)*(5) + (3))*(klon) + (si2)] = __cb209[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zwarm_frz, zsolqa[0, 3, kidia - 1:kfdia] + zrainacc2, zsolqa[0, 3, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb210[__r0] = (zwarm_frz[__r0] ? (zsolqa[((0)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))] + zrainacc2[__r0]) : zsolqa[((0)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((0)*(5) + (3))*(klon) + (si2)] = __cb210[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zwarm_frz, zsolqa[3, 0, kidia - 1:kfdia] - zrainaut2, zsolqa[3, 0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb211[__r0] = (zwarm_frz[__r0] ? (zsolqa[((3)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] - zrainaut2[__r0]) : zsolqa[((3)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((3)*(5) + (0))*(klon) + (si2)] = __cb211[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zwarm_frz, zsolqa[3, 0, kidia - 1:kfdia] - zrainacc2, zsolqa[3, 0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb212[__r0] = (zwarm_frz[__r0] ? (zsolqa[((3)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] - zrainacc2[__r0]) : zsolqa[((3)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((3)*(5) + (0))*(klon) + (si2)] = __cb212[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zwarm_liq, zsolqa[0, 2, kidia - 1:kfdia] + zrainaut2, zsolqa[0, 2, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb213[__r0] = (zwarm_liq[__r0] ? (zsolqa[((0)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))] + zrainaut2[__r0]) : zsolqa[((0)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((0)*(5) + (2))*(klon) + (si2)] = __cb213[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zwarm_liq, zsolqa[0, 2, kidia - 1:kfdia] + zrainacc2, zsolqa[0, 2, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb214[__r0] = (zwarm_liq[__r0] ? (zsolqa[((0)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))] + zrainacc2[__r0]) : zsolqa[((0)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((0)*(5) + (2))*(klon) + (si2)] = __cb214[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zwarm_liq, zsolqa[2, 0, kidia - 1:kfdia] - zrainaut2, zsolqa[2, 0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb215[__r0] = (zwarm_liq[__r0] ? (zsolqa[((2)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] - zrainaut2[__r0]) : zsolqa[((2)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((2)*(5) + (0))*(klon) + (si2)] = __cb215[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zwarm_liq, zsolqa[2, 0, kidia - 1:kfdia] - zrainacc2, zsolqa[2, 0, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb216[__r0] = (zwarm_liq[__r0] ? (zsolqa[((2)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] - zrainacc2[__r0]) : zsolqa[((2)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((2)*(5) + (0))*(klon) + (si2)] = __cb216[(si2 - (kidia - 1))];
            }
          }
          if ((iwarmrain > 1)) {
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrime_outer[__w0] = ((ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] <= 273.16) & (zliqcld[(__w0 + ((kidia - 1) - 0))] > zepsec));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw34b[__w0] = (1.0 / zrho[(__w0 + ((kidia - 1) - 0))]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw34[__w0] = pow(_pw34b[__w0], 0.4);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zfallcorr_rime[__w0] = _pw34[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrime_mask[__w0] = ((zrime_outer[__w0] & (zsnowcld[(__w0 + ((kidia - 1) - 0))] > zepsec)) & (zcovptot[(__w0 + ((kidia - 1) - 0))] > 0.01));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw35b[__w0] = ((zrho[(__w0 + ((kidia - 1) - 0))] * zsnowcld[(__w0 + ((kidia - 1) - 0))]) * 3.6231880115136998e-06);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw35[__w0] = pow(_pw35b[__w0], 1.1756666666666666);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zsnowrime_new[__w0] = (((((0.3 * zcovptot[(__w0 + ((kidia - 1) - 0))]) * ptsphy) * 90363515.76351073) * zfallcorr_rime[__w0]) * _pw35[__w0]);
            }
            /* numpy: np.minimum(zsnowrime_new, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb217[__r0] = min(zsnowrime_new[__r0], 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zsnowrime_new[__w0] = __cb217[__w0];
            }
            /* numpy: np.where(zrime_mask, zsnowrime_new, zsnowrime[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb218[__r0] = (zrime_mask[__r0] ? zsnowrime_new[__r0] : zsnowrime[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zsnowrime[si0] = __cb218[(si0 - (kidia - 1))];
            }
            /* numpy: np.where(zrime_mask, zsolqb[0, 3, kidia - 1:kfdia] + zsnowrime_new, zsolqb[0, 3, kidia - 1:kf... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb219[__r0] = (zrime_mask[__r0] ? (zsolqb[((0)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))] + zsnowrime_new[__r0]) : zsolqb[((0)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqb[((0)*(5) + (3))*(klon) + (si2)] = __cb219[(si2 - (kidia - 1))];
            }
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zicetot[si0] = (zqxfg[(1)*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] + zqxfg[(3)*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zmelt_mask[__w0] = ((zicetot[(__w0 + ((kidia - 1) - 0))] > zepsec) & (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 273.16));
          }
          /* numpy: np.maximum(zqsice[jk - 1, kidia - 1:kfdia] - zqx[4, jk - 1, kidia - 1:kfdia], 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb220[__r0] = max((zqsice[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]), 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zsubsat[__w0] = __cb220[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            ztdmtw0[__w0] = ((ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - 273.16) - (zsubsat[__w0] * ((ztw1 + (ztw2 * (pap[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - ztw3))) - (ztw4 * (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - ztw5)))));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcons1[__w0] = fabs(((ptsphy * (1.0 + (0.5 * ztdmtw0[__w0]))) / 7200.0));
          }
          /* numpy: np.maximum(ztdmtw0 * zcons1 * zrldcp, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb221[__r0] = max(((ztdmtw0[__r0] * zcons1[__r0]) * zrldcp), 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zmeltmax_new[__w0] = __cb221[__w0];
          }
          /* numpy: np.where(zmelt_mask, zmeltmax_new, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb222[__r0] = (zmelt_mask[__r0] ? zmeltmax_new[__r0] : 0.0);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zmeltmax[si0] = __cb222[(si0 - (kidia - 1))];
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            if ((((int64_t)(iphase[(jm - 1)])) == 2)) {
              for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                zmelt_mask2[__w0] = ((zmeltmax[(__w0 + ((kidia - 1) - 0))] > zepsec) & (zicetot[(__w0 + ((kidia - 1) - 0))] > zepsec));
              }
              /* numpy: np.where(zicetot[kidia - 1:kfdia] != 0.0, zicetot[kidia - 1:kfdia], 1.0) */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb223[__r0] = ((zicetot[(__r0 + (kidia - 1))] != 0.0) ? zicetot[(__r0 + (kidia - 1))] : 1.0);
              }
              for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                zicetot_safe[__w0] = __cb223[__w0];
              }
              for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                zalfa2[__w0] = (zqxfg[((jm - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] / zicetot_safe[__w0]);
              }
              /* numpy: np.minimum(zqxfg[jm - 1, kidia - 1:kfdia], zalfa2 * zmeltmax[kidia - 1:kfdia]) */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb224[__r0] = min(zqxfg[((jm - 1))*(klon) + ((__r0 + (kidia - 1)))], (zalfa2[__r0] * zmeltmax[(__r0 + (kidia - 1))]));
              }
              for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                zmelt[__w0] = __cb224[__w0];
              }
              im = ((int32_t)((((int64_t)(imelt[(jm - 1)])) - 1)));
              for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                zqxfg_jm_new[__w0] = (zqxfg[((jm - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - zmelt[__w0]);
              }
              for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                zqxfg_im_new[__w0] = (zqxfg[(im)*(klon) + ((__w0 + ((kidia - 1) - 0)))] + zmelt[__w0]);
              }
              /* numpy: np.where(zmelt_mask2, zqxfg_jm_new, zqxfg[jm - 1, kidia - 1:kfdia]) */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb225[__r0] = (zmelt_mask2[__r0] ? zqxfg_jm_new[__r0] : zqxfg[((jm - 1))*(klon) + ((__r0 + (kidia - 1)))]);
              }
              for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                zqxfg[((jm - 1))*(klon) + (si1)] = __cb225[(si1 - (kidia - 1))];
              }
              /* numpy: np.where(zmelt_mask2, zqxfg_im_new, zqxfg[im, kidia - 1:kfdia]) */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb226[__r0] = (zmelt_mask2[__r0] ? zqxfg_im_new[__r0] : zqxfg[(im)*(klon) + ((__r0 + (kidia - 1)))]);
              }
              for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                zqxfg[(im)*(klon) + (si1)] = __cb226[(si1 - (kidia - 1))];
              }
              /* numpy: np.where(zmelt_mask2, zsolqa[jm - 1, im, kidia - 1:kfdia] + zmelt, zsolqa[jm - 1, im, kidia -... */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb227[__r0] = (zmelt_mask2[__r0] ? (zsolqa[(((jm - 1))*(5) + (im))*(klon) + ((__r0 + (kidia - 1)))] + zmelt[__r0]) : zsolqa[(((jm - 1))*(5) + (im))*(klon) + ((__r0 + (kidia - 1)))]);
              }
              for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                zsolqa[(((jm - 1))*(5) + (im))*(klon) + (si2)] = __cb227[(si2 - (kidia - 1))];
              }
              /* numpy: np.where(zmelt_mask2, zsolqa[im, jm - 1, kidia - 1:kfdia] - zmelt, zsolqa[im, jm - 1, kidia -... */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb228[__r0] = (zmelt_mask2[__r0] ? (zsolqa[((im)*(5) + ((jm - 1)))*(klon) + ((__r0 + (kidia - 1)))] - zmelt[__r0]) : zsolqa[((im)*(5) + ((jm - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
              }
              for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                zsolqa[((im)*(5) + ((jm - 1)))*(klon) + (si2)] = __cb228[(si2 - (kidia - 1))];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zrain_present[__w0] = (zqx[((2)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            ztop_reset[__w0] = ((zrain_present[__w0] & (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] <= 273.16)) & (ztp1[((jk - 2))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > 273.16));
          }
          /* numpy: np.maximum(zqx[3, jk - 1, kidia - 1:kfdia] + zqx[2, jk - 1, kidia - 1:kfdia], zepsec) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb229[__r0] = max((zqx[((3)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] + zqx[((2)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]), zepsec);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zqpretot_new[__w0] = __cb229[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            prainfrac_new[__w0] = (zqx[((2)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] / zqpretot_new[__w0]);
          }
          /* numpy: np.where(ztop_reset, zqpretot_new, zqpretot[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb230[__r0] = (ztop_reset[__r0] ? zqpretot_new[__r0] : zqpretot[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zqpretot[si0] = __cb230[(si0 - (kidia - 1))];
          }
          /* numpy: np.where(ztop_reset, prainfrac_new, prainfrac_toprfz[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb231[__r0] = (ztop_reset[__r0] ? prainfrac_new[__r0] : prainfrac_toprfz[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            prainfrac_toprfz[si0] = __cb231[(si0 - (kidia - 1))];
          }
          /* numpy: np.where(ztop_reset, prainfrac_new > 0.8, llrainliq[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb232[__r0] = (ztop_reset[__r0] ? (prainfrac_new[__r0] > 0.8) : ((int64_t)(llrainliq[(__r0 + (kidia - 1))])));
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            llrainliq[si0] = __cb232[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcold_rain[__w0] = (zrain_present[__w0] & (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 273.16));
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zhigh_frac[__w0] = (prainfrac_toprfz[(__w0 + ((kidia - 1) - 0))] > 0.8);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zrho_safe[__w0] = zrho[(__w0 + ((kidia - 1) - 0))];
          }
          /* numpy: np.where(zqx[2, jk - 1, kidia - 1:kfdia] != 0.0, zqx[2, jk - 1, kidia - 1:kfdia], 1.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb233[__r0] = ((zqx[((2)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] != 0.0) ? zqx[((2)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] : 1.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zqxr_safe[__w0] = __cb233[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            _pw36b[__w0] = (4146.902789847063 / (zrho_safe[__w0] * zqxr_safe[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw36[__w0] = pow(_pw36b[__w0], 0.5555555555555556);
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            zlambda[__w0] = _pw36[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            ztemp[__w0] = (-0.66 * (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - 273.16));
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw37b[__w0] = zlambda[__w0];
          }
          for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
            _pw37[__w0] = pow(_pw37b[__w0], -4.8);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfrz_high[__w0] = (((ptsphy * (8685252.965082133 / zrho_safe[__w0])) * (exp(ztemp[__w0]) - 1.0)) * _pw37[__w0]);
          }
          /* numpy: np.maximum(zfrz_high, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb234[__r0] = max(zfrz_high[__r0], 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfrzmax_high[__w0] = __cb234[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zcons1b[__w0] = fabs(((ptsphy * (1.0 + (0.5 * (273.16 - ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])))) / 7200.0));
          }
          /* numpy: np.maximum((273.16 - ztp1[jk - 1, kidia - 1:kfdia]) * zcons1b * zrldcp, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb235[__r0] = max((((273.16 - ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) * zcons1b[__r0]) * zrldcp), 0.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfrzmax_low[__w0] = __cb235[__w0];
          }
          /* numpy: np.where(zhigh_frac, zfrzmax_high, zfrzmax_low) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb236[__r0] = (zhigh_frac[__r0] ? zfrzmax_high[__r0] : zfrzmax_low[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfrzmax_local[__w0] = __cb236[__w0];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfreeze_mask[__w0] = (zcold_rain[__w0] & (zfrzmax_local[__w0] > zepsec));
          }
          /* numpy: np.minimum(zqx[2, jk - 1, kidia - 1:kfdia], zfrzmax_local) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb237[__r0] = min(zqx[((2)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))], zfrzmax_local[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfrz[__w0] = __cb237[__w0];
          }
          /* numpy: np.where(zfreeze_mask, zsolqa[2, 3, kidia - 1:kfdia] + zfrz, zsolqa[2, 3, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb238[__r0] = (zfreeze_mask[__r0] ? (zsolqa[((2)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))] + zfrz[__r0]) : zsolqa[((2)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((2)*(5) + (3))*(klon) + (si2)] = __cb238[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zfreeze_mask, zsolqa[3, 2, kidia - 1:kfdia] - zfrz, zsolqa[3, 2, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb239[__r0] = (zfreeze_mask[__r0] ? (zsolqa[((3)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))] - zfrz[__r0]) : zsolqa[((3)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((3)*(5) + (2))*(klon) + (si2)] = __cb239[(si2 - (kidia - 1))];
          }
          /* numpy: np.maximum((235.16000000000003 - ztp1[jk - 1, kidia - 1:kfdia]) * zrldcp, 0.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb240[__r0] = max(((235.16000000000003 - ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) * zrldcp), 0.0);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zfrzmax[si0] = __cb240[(si0 - (kidia - 1))];
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zhomo_mask[__w0] = ((zfrzmax[(__w0 + ((kidia - 1) - 0))] > zepsec) & (zqxfg[(0)*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec));
          }
          /* numpy: np.minimum(zqxfg[0, kidia - 1:kfdia], zfrzmax[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb241[__r0] = min(zqxfg[(0)*(klon) + ((__r0 + (kidia - 1)))], zfrzmax[(__r0 + (kidia - 1))]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zfrz[__w0] = __cb241[__w0];
          }
          im2 = ((int32_t)((((int64_t)(imelt[0])) - 1)));
          /* numpy: np.where(zhomo_mask, zsolqa[0, im2, kidia - 1:kfdia] + zfrz, zsolqa[0, im2, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb242[__r0] = (zhomo_mask[__r0] ? (zsolqa[((0)*(5) + (im2))*(klon) + ((__r0 + (kidia - 1)))] + zfrz[__r0]) : zsolqa[((0)*(5) + (im2))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((0)*(5) + (im2))*(klon) + (si2)] = __cb242[(si2 - (kidia - 1))];
          }
          /* numpy: np.where(zhomo_mask, zsolqa[im2, 0, kidia - 1:kfdia] - zfrz, zsolqa[im2, 0, kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb243[__r0] = (zhomo_mask[__r0] ? (zsolqa[((im2)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))] - zfrz[__r0]) : zsolqa[((im2)*(5) + (0))*(klon) + ((__r0 + (kidia - 1)))]);
          }
          for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
            zsolqa[((im2)*(5) + (0))*(klon) + (si2)] = __cb243[(si2 - (kidia - 1))];
          }
          if ((ievaprain == 1)) {
            /* numpy: np.maximum(zepsec, 1.0 - za[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb244[__r0] = max(zepsec, (1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zzrh1[__w0] = (0.7 + (((1.0 - 0.7) * zcovpmax[(__w0 + ((kidia - 1) - 0))]) / __cb244[__w0]));
            }
            /* numpy: np.maximum(zzrh1, 0.7) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb245[__r0] = max(zzrh1[__r0], 0.7);
            }
            /* numpy: np.minimum(__cb245, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb246[__r0] = min(__cb245[__r0], 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zzrh1[__w0] = __cb246[__w0];
            }
            /* numpy: np.maximum(zepsec, 1.0 - za[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb247[__r0] = max(zepsec, (1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqe1[__w0] = ((zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zqsliq[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) / __cb247[__w0]);
            }
            /* numpy: np.minimum(zqe1, zqsliq[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb248[__r0] = min(zqe1[__r0], zqsliq[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            /* numpy: np.maximum(0.0, __cb248) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb249[__r0] = max(0.0, __cb248[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqe1[__w0] = __cb249[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zllo1[__w0] = (((zcovpclr[(__w0 + ((kidia - 1) - 0))] > zepsec) & (zqxfg[(2)*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec)) & (zqe1[__w0] < (zzrh1[__w0] * zqsliq[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcp_arg[__w0] = (zcovptot[(__w0 + ((kidia - 1) - 0))] * zdtgdp[(__w0 + ((kidia - 1) - 0))]);
            }
            /* numpy: np.maximum(fabs(zcp_arg), zepsilon) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb250[__r0] = max(fabs(zcp_arg[__r0]), zepsilon);
            }
            /* numpy: np.sign(zcp_arg) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb251[__r0] = __npb_sign(zcp_arg[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcp_denom[__w0] = (__cb250[__w0] * __cb251[__w0]);
            }
            /* numpy: np.where(zcp_denom != 0.0, zcp_denom, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb252[__r0] = ((zcp_denom[__r0] != 0.0) ? zcp_denom[__r0] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcp_denom_safe[__w0] = __cb252[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zpreclr[__w0] = ((zqxfg[(2)*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zcovpclr[(__w0 + ((kidia - 1) - 0))]) / zcp_denom_safe[__w0]);
            }
            /* numpy: np.sqrt(pap[jk - 1, kidia - 1:kfdia] / paph[nlev, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb253[__r0] = sqrt((pap[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] / paph[(nlev)*(klon) + ((__r0 + (kidia - 1)))]));
            }
            /* numpy: np.maximum(zcovpclr[kidia - 1:kfdia], zepsec) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb254[__r0] = max(zcovpclr[(__r0 + (kidia - 1))], zepsec);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zbeta1[__w0] = (((__cb253[__w0] / 0.00509) * zpreclr[__w0]) / __cb254[__w0]);
            }
            /* numpy: np.maximum(zbeta1, 0.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb255[__r0] = max(zbeta1[__r0], 0.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw38b[__w0] = __cb255[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw38[__w0] = pow(_pw38b[__w0], 0.5777);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zbeta_e1[__w0] = (((9.80665 * 5.54725619859993e-05) * 0.5) * _pw38[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zdenom_e1[__w0] = (1.0 + ((zbeta_e1[__w0] * ptsphy) * zcorqsliq[(__w0 + ((kidia - 1) - 0))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdpr[__w0] = (((((zcovpclr[(__w0 + ((kidia - 1) - 0))] * zbeta_e1[__w0]) * (zqsliq[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - zqe1[__w0])) / zdenom_e1[__w0]) * zdp[(__w0 + ((kidia - 1) - 0))]) * zrg_r);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdpevap[__w0] = (zdpr[__w0] * zdtgdp[(__w0 + ((kidia - 1) - 0))]);
            }
            /* numpy: np.minimum(zdpevap, zqxfg[2, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb256[__r0] = min(zdpevap[__r0], zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zevap[__w0] = __cb256[__w0];
            }
            /* numpy: np.where(zllo1, zsolqa[2, 4, kidia - 1:kfdia] + zevap, zsolqa[2, 4, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb257[__r0] = (zllo1[__r0] ? (zsolqa[((2)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] + zevap[__r0]) : zsolqa[((2)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((2)*(5) + (4))*(klon) + (si2)] = __cb257[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zllo1, zsolqa[4, 2, kidia - 1:kfdia] - zevap, zsolqa[4, 2, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb258[__r0] = (zllo1[__r0] ? (zsolqa[((4)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))] - zevap[__r0]) : zsolqa[((4)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((4)*(5) + (2))*(klon) + (si2)] = __cb258[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zqxfg[2, kidia - 1:kfdia] != 0.0, zqxfg[2, kidia - 1:kfdia], 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb259[__r0] = ((zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))] != 0.0) ? zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqxfgr_safe[__w0] = __cb259[__w0];
            }
            /* numpy: np.maximum(0.0, (zcovptot[kidia - 1:kfdia] - za[jk - 1, kidia - 1:kfdia]) * zevap / zqxfgr_safe) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb260[__r0] = max(0.0, (((zcovptot[(__r0 + (kidia - 1))] - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) * zevap[__r0]) / zqxfgr_safe[__r0]));
            }
            /* numpy: np.maximum(0.1, zcovptot[kidia - 1:kfdia] - __cb260) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb261[__r0] = max(0.1, (zcovptot[(__r0 + (kidia - 1))] - __cb260[__r0]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcovptot_e1[__w0] = __cb261[__w0];
            }
            /* numpy: np.where(zllo1, zcovptot_e1, zcovptot[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb262[__r0] = (zllo1[__r0] ? zcovptot_e1[__r0] : zcovptot[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zcovptot[si0] = __cb262[(si0 - (kidia - 1))];
            }
            /* numpy: np.where(zllo1, zqxfg[2, kidia - 1:kfdia] - zevap, zqxfg[2, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb263[__r0] = (zllo1[__r0] ? (zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))] - zevap[__r0]) : zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxfg[(2)*(klon) + (si1)] = __cb263[(si1 - (kidia - 1))];
            }
          }
          else if ((ievaprain == 2)) {
            /* numpy: np.maximum(zepsec, 1.0 - za[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb264[__r0] = max(zepsec, (1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zzrh2[__w0] = (0.7 + (((1.0 - 0.7) * zcovpmax[(__w0 + ((kidia - 1) - 0))]) / __cb264[__w0]));
            }
            /* numpy: np.maximum(zzrh2, 0.7) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb265[__r0] = max(zzrh2[__r0], 0.7);
            }
            /* numpy: np.minimum(__cb265, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb266[__r0] = min(__cb265[__r0], 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zzrh2[__w0] = __cb266[__w0];
            }
            /* numpy: np.minimum(0.8, zzrh2) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb267[__r0] = min(0.8, zzrh2[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zzrh2[__w0] = __cb267[__w0];
            }
            /* numpy: np.minimum(zqx[4, jk - 1, kidia - 1:kfdia], zqsliq[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb268[__r0] = min(zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))], zqsliq[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            /* numpy: np.maximum(0.0, __cb268) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb269[__r0] = max(0.0, __cb268[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqe2[__w0] = __cb269[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zllo2[__w0] = (((zcovpclr[(__w0 + ((kidia - 1) - 0))] > zepsec) & (zqxfg[(2)*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec)) & (zqe2[__w0] < (zzrh2[__w0] * zqsliq[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])));
            }
            /* numpy: np.where(zcovptot[kidia - 1:kfdia] != 0.0, zcovptot[kidia - 1:kfdia], 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb270[__r0] = ((zcovptot[(__r0 + (kidia - 1))] != 0.0) ? zcovptot[(__r0 + (kidia - 1))] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcovptot_safe2[__w0] = __cb270[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zpreclr2[__w0] = (zqxfg[(2)*(klon) + ((__w0 + ((kidia - 1) - 0)))] / zcovptot_safe2[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw39b[__w0] = (1.0 / zrho[(__w0 + ((kidia - 1) - 0))]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw39[__w0] = pow(_pw39b[__w0], 0.4);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zfallcorr[__w0] = _pw39[__w0];
            }
            /* numpy: np.exp(17.502 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16) / (ztp1[jk - 1, kidia - 1:kfdia] - 3... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb271[__r0] = exp(((17.502 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)) / (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 32.19)));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zesatliq[__w0] = ((461.5249933083879 / 287.0596736665907) * (380.1608703442847 * __cb271[__w0]));
            }
            /* numpy: np.where(zpreclr2 != 0.0, zpreclr2, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb272[__r0] = ((zpreclr2[__r0] != 0.0) ? zpreclr2[__r0] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zpreclr2_safe[__w0] = __cb272[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw40b[__w0] = (4146.902789847063 / (zrho[(__w0 + ((kidia - 1) - 0))] * zpreclr2_safe[__w0]));
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw40[__w0] = pow(_pw40b[__w0], 0.5555555555555556);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zlambda2[__w0] = _pw40[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw41[__w0] = ((ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))] * ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))]) * ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zevap_denom[__w0] = (((557000000000.0 * zesatliq[__w0]) - ((103000000.0 * ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]) * zesatliq[__w0])) + ((204.0 * _pw41[__w0]) * pap[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw42b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] / 273.0);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw42[__w0] = pow(_pw42b[__w0], 1.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zcorr2[__w0] = ((_pw42[__w0] * 393.0) / (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] + 120.0));
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zka[__w0] = (0.024 * zcorr2[__w0]);
            }
            /* numpy: np.maximum(zzrh2 * zqsliq[jk - 1, kidia - 1:kfdia] - zqe2, 0.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb273[__r0] = max(((zzrh2[__r0] * zqsliq[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) - zqe2[__r0]), 0.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zsubsat2[__w0] = __cb273[__w0];
            }
            /* numpy: np.where(zevap_denom != 0.0, zevap_denom, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb274[__r0] = ((zevap_denom[__r0] != 0.0) ? zevap_denom[__r0] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zevap_denom_safe[__w0] = __cb274[__w0];
            }
            /* numpy: np.where(zqsliq[jk - 1, kidia - 1:kfdia] != 0.0, zqsliq[jk - 1, kidia - 1:kfdia], 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb275[__r0] = ((zqsliq[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] != 0.0) ? zqsliq[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqsliq_safe[__w0] = __cb275[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw43b[__w0] = zlambda2[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw43[__w0] = pow(_pw43b[__w0], -0.20000000000000018);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw44b[__w0] = (zrho[(__w0 + ((kidia - 1) - 0))] * zfallcorr[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw44[__w0] = pow(_pw44b[__w0], 0.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw45b[__w0] = zcorr2[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw45[__w0] = pow(_pw45b[__w0], 0.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw46b[__w0] = zlambda2[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw46[__w0] = pow(_pw46b[__w0], 0.6349999999999998);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw47[__w0] = (ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))] * ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zbeta2[__w0] = ((((((0.5 / zqsliq_safe[__w0]) * _pw47[__w0]) * zesatliq[__w0]) * 1.382300767579509) * (zcorr2[__w0] / zevap_denom_safe[__w0])) * ((0.78 / _pw43[__w0]) + ((2143.2299120517614 * _pw44[__w0]) / (_pw45[__w0] * _pw46[__w0]))));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdenom2[__w0] = (1.0 + (zbeta2[__w0] * ptsphy));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdpevap2[__w0] = ((((zcovpclr[(__w0 + ((kidia - 1) - 0))] * zbeta2[__w0]) * ptsphy) * zsubsat2[__w0]) / zdenom2[__w0]);
            }
            /* numpy: np.minimum(zdpevap2, zqxfg[2, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb276[__r0] = min(zdpevap2[__r0], zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zevap2[__w0] = __cb276[__w0];
            }
            /* numpy: np.where(zllo2, zsolqa[2, 4, kidia - 1:kfdia] + zevap2, zsolqa[2, 4, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb277[__r0] = (zllo2[__r0] ? (zsolqa[((2)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] + zevap2[__r0]) : zsolqa[((2)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((2)*(5) + (4))*(klon) + (si2)] = __cb277[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zllo2, zsolqa[4, 2, kidia - 1:kfdia] - zevap2, zsolqa[4, 2, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb278[__r0] = (zllo2[__r0] ? (zsolqa[((4)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))] - zevap2[__r0]) : zsolqa[((4)*(5) + (2))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((4)*(5) + (2))*(klon) + (si2)] = __cb278[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zqxfg[2, kidia - 1:kfdia] != 0.0, zqxfg[2, kidia - 1:kfdia], 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb279[__r0] = ((zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))] != 0.0) ? zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqxfgr_safe2[__w0] = __cb279[__w0];
            }
            /* numpy: np.maximum(0.0, (zcovptot[kidia - 1:kfdia] - za[jk - 1, kidia - 1:kfdia]) * zevap2 / zqxfgr_s... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb280[__r0] = max(0.0, (((zcovptot[(__r0 + (kidia - 1))] - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) * zevap2[__r0]) / zqxfgr_safe2[__r0]));
            }
            /* numpy: np.maximum(0.1, zcovptot[kidia - 1:kfdia] - __cb280) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb281[__r0] = max(0.1, (zcovptot[(__r0 + (kidia - 1))] - __cb280[__r0]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcovptot_e2[__w0] = __cb281[__w0];
            }
            /* numpy: np.where(zllo2, zcovptot_e2, zcovptot[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb282[__r0] = (zllo2[__r0] ? zcovptot_e2[__r0] : zcovptot[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zcovptot[si0] = __cb282[(si0 - (kidia - 1))];
            }
            /* numpy: np.where(zllo2, zqxfg[2, kidia - 1:kfdia] - zevap2, zqxfg[2, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb283[__r0] = (zllo2[__r0] ? (zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))] - zevap2[__r0]) : zqxfg[(2)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxfg[(2)*(klon) + (si1)] = __cb283[(si1 - (kidia - 1))];
            }
          }
          if ((ievapsnow == 1)) {
            /* numpy: np.maximum(zepsec, 1.0 - za[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb284[__r0] = max(zepsec, (1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zzrhs1[__w0] = (0.7 + (((1.0 - 0.7) * zcovpmax[(__w0 + ((kidia - 1) - 0))]) / __cb284[__w0]));
            }
            /* numpy: np.maximum(zzrhs1, 0.7) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb285[__r0] = max(zzrhs1[__r0], 0.7);
            }
            /* numpy: np.minimum(__cb285, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb286[__r0] = min(__cb285[__r0], 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zzrhs1[__w0] = __cb286[__w0];
            }
            /* numpy: np.maximum(zepsec, 1.0 - za[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb287[__r0] = max(zepsec, (1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqes1[__w0] = ((zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) / __cb287[__w0]);
            }
            /* numpy: np.minimum(zqes1, zqsice[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb288[__r0] = min(zqes1[__r0], zqsice[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            /* numpy: np.maximum(0.0, __cb288) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb289[__r0] = max(0.0, __cb288[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqes1[__w0] = __cb289[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zllos1[__w0] = (((zcovpclr[(__w0 + ((kidia - 1) - 0))] > zepsec) & (zqxfg[(3)*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec)) & (zqes1[__w0] < (zzrhs1[__w0] * zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcp_args1[__w0] = (zcovptot[(__w0 + ((kidia - 1) - 0))] * zdtgdp[(__w0 + ((kidia - 1) - 0))]);
            }
            /* numpy: np.maximum(fabs(zcp_args1), zepsilon) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb290[__r0] = max(fabs(zcp_args1[__r0]), zepsilon);
            }
            /* numpy: np.sign(zcp_args1) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb291[__r0] = __npb_sign(zcp_args1[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcp_denoms1[__w0] = (__cb290[__w0] * __cb291[__w0]);
            }
            /* numpy: np.where(zcp_denoms1 != 0.0, zcp_denoms1, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb292[__r0] = ((zcp_denoms1[__r0] != 0.0) ? zcp_denoms1[__r0] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcp_denoms1_safe[__w0] = __cb292[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zpreclrs1[__w0] = ((zqxfg[(3)*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zcovpclr[(__w0 + ((kidia - 1) - 0))]) / zcp_denoms1_safe[__w0]);
            }
            /* numpy: np.sqrt(pap[jk - 1, kidia - 1:kfdia] / paph[nlev, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb293[__r0] = sqrt((pap[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] / paph[(nlev)*(klon) + ((__r0 + (kidia - 1)))]));
            }
            /* numpy: np.maximum(zcovpclr[kidia - 1:kfdia], zepsec) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb294[__r0] = max(zcovpclr[(__r0 + (kidia - 1))], zepsec);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zbeta1s1[__w0] = (((__cb293[__w0] / 0.00509) * zpreclrs1[__w0]) / __cb294[__w0]);
            }
            /* numpy: np.maximum(zbeta1s1, 0.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb295[__r0] = max(zbeta1s1[__r0], 0.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw48b[__w0] = __cb295[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw48[__w0] = pow(_pw48b[__w0], 0.5777);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zbetas1[__w0] = ((9.80665 * 5.54725619859993e-05) * _pw48[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zdenoms1[__w0] = (1.0 + ((zbetas1[__w0] * ptsphy) * zcorqsice[(__w0 + ((kidia - 1) - 0))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdprs1[__w0] = (((((zcovpclr[(__w0 + ((kidia - 1) - 0))] * zbetas1[__w0]) * (zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - zqes1[__w0])) / zdenoms1[__w0]) * zdp[(__w0 + ((kidia - 1) - 0))]) * zrg_r);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdpevaps1[__w0] = (zdprs1[__w0] * zdtgdp[(__w0 + ((kidia - 1) - 0))]);
            }
            /* numpy: np.minimum(zdpevaps1, zqxfg[3, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb296[__r0] = min(zdpevaps1[__r0], zqxfg[(3)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zevaps1[__w0] = __cb296[__w0];
            }
            /* numpy: np.where(zllos1, zsolqa[3, 4, kidia - 1:kfdia] + zevaps1, zsolqa[3, 4, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb297[__r0] = (zllos1[__r0] ? (zsolqa[((3)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] + zevaps1[__r0]) : zsolqa[((3)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((3)*(5) + (4))*(klon) + (si2)] = __cb297[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zllos1, zsolqa[4, 3, kidia - 1:kfdia] - zevaps1, zsolqa[4, 3, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb298[__r0] = (zllos1[__r0] ? (zsolqa[((4)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))] - zevaps1[__r0]) : zsolqa[((4)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((4)*(5) + (3))*(klon) + (si2)] = __cb298[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zqxfg[3, kidia - 1:kfdia] != 0.0, zqxfg[3, kidia - 1:kfdia], 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb299[__r0] = ((zqxfg[(3)*(klon) + ((__r0 + (kidia - 1)))] != 0.0) ? zqxfg[(3)*(klon) + ((__r0 + (kidia - 1)))] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqxfgs_safe1[__w0] = __cb299[__w0];
            }
            /* numpy: np.maximum(0.0, (zcovptot[kidia - 1:kfdia] - za[jk - 1, kidia - 1:kfdia]) * zevaps1 / zqxfgs_... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb300[__r0] = max(0.0, (((zcovptot[(__r0 + (kidia - 1))] - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) * zevaps1[__r0]) / zqxfgs_safe1[__r0]));
            }
            /* numpy: np.maximum(0.1, zcovptot[kidia - 1:kfdia] - __cb300) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb301[__r0] = max(0.1, (zcovptot[(__r0 + (kidia - 1))] - __cb300[__r0]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcovptot_s1[__w0] = __cb301[__w0];
            }
            /* numpy: np.where(zllos1, zcovptot_s1, zcovptot[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb302[__r0] = (zllos1[__r0] ? zcovptot_s1[__r0] : zcovptot[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zcovptot[si0] = __cb302[(si0 - (kidia - 1))];
            }
            /* numpy: np.where(zllos1, zqxfg[3, kidia - 1:kfdia] - zevaps1, zqxfg[3, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb303[__r0] = (zllos1[__r0] ? (zqxfg[(3)*(klon) + ((__r0 + (kidia - 1)))] - zevaps1[__r0]) : zqxfg[(3)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxfg[(3)*(klon) + (si1)] = __cb303[(si1 - (kidia - 1))];
            }
          }
          else if ((ievapsnow == 2)) {
            /* numpy: np.maximum(zepsec, 1.0 - za[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb304[__r0] = max(zepsec, (1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zzrhs2[__w0] = (0.7 + (((1.0 - 0.7) * zcovpmax[(__w0 + ((kidia - 1) - 0))]) / __cb304[__w0]));
            }
            /* numpy: np.maximum(zzrhs2, 0.7) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb305[__r0] = max(zzrhs2[__r0], 0.7);
            }
            /* numpy: np.minimum(__cb305, 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb306[__r0] = min(__cb305[__r0], 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zzrhs2[__w0] = __cb306[__w0];
            }
            /* numpy: np.maximum(zepsec, 1.0 - za[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb307[__r0] = max(zepsec, (1.0 - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqes2[__w0] = ((zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - (za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) / __cb307[__w0]);
            }
            /* numpy: np.minimum(zqes2, zqsice[jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb308[__r0] = min(zqes2[__r0], zqsice[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            /* numpy: np.maximum(0.0, __cb308) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb309[__r0] = max(0.0, __cb308[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqes2[__w0] = __cb309[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zllos2[__w0] = (((zcovpclr[(__w0 + ((kidia - 1) - 0))] > zepsec) & (zqx[((3)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] > zepsec)) & (zqes2[__w0] < (zzrhs2[__w0] * zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])));
            }
            /* numpy: np.where(zcovptot[kidia - 1:kfdia] != 0.0, zcovptot[kidia - 1:kfdia], 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb310[__r0] = ((zcovptot[(__r0 + (kidia - 1))] != 0.0) ? zcovptot[(__r0 + (kidia - 1))] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcovptot_safe2s[__w0] = __cb310[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zpreclrs2[__w0] = (zqx[((3)*(nlev) + ((jk - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] / zcovptot_safe2s[__w0]);
            }
            /* numpy: np.exp(22.587 * (ztp1[jk - 1, kidia - 1:kfdia] - 273.16) / (ztp1[jk - 1, kidia - 1:kfdia] - -... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb311[__r0] = exp(((22.587 * (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - 273.16)) / (ztp1[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] - -0.7)));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zvpices2[__w0] = (((380.1608703442847 * __cb311[__w0]) * 461.5249933083879) / 287.0596736665907);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw49[__w0] = ((ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))] * ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))]) * ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zaplusbs2[__w0] = (((714000000000.0 * zvpices2[__w0]) - ((116000000.0 * zvpices2[__w0]) * ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) + ((pap[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] * 241.6) * _pw49[__w0]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw50b[__w0] = (1.0 / zrho[(__w0 + ((kidia - 1) - 0))]);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw50[__w0] = pow(_pw50b[__w0], 0.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zcorrfacs2[__w0] = _pw50[__w0];
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw51b[__w0] = (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] / 273.0);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw51[__w0] = pow(_pw51b[__w0], 1.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zcorrfac2s2[__w0] = (_pw51[__w0] * (393.0 / (ztp1[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] + 120.0)));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zpr02s2[__w0] = (((zrho[(__w0 + ((kidia - 1) - 0))] * zpreclrs2[__w0]) * 3.6231880115136998e-06) / (1.0 * 1.0));
            }
            /* numpy: np.where(zqsice[jk - 1, kidia - 1:kfdia] != 0.0, zqsice[jk - 1, kidia - 1:kfdia], 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb312[__r0] = ((zqsice[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] != 0.0) ? zqsice[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqsice_safe2[__w0] = __cb312[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw52[__w0] = (ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))] * ztp1[((jk - 1))*(klon) + (((kidia - 1) + __w0))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zterm1s2[__w0] = ((((((((zqsice[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] - zqes2[__w0]) * _pw52[__w0]) * zvpices2[__w0]) * zcorrfac2s2[__w0]) * 1.0) * 6283185.307179586) * 1.0) / ((zrho[(__w0 + ((kidia - 1) - 0))] * zaplusbs2[__w0]) * zqsice_safe2[__w0]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw53b[__w0] = zpr02s2[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw53[__w0] = pow(_pw53b[__w0], 0.6666666666666666);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw54b[__w0] = zcorrfac2s2[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw54[__w0] = pow(_pw54b[__w0], 0.5);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw55b[__w0] = zpr02s2[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw55[__w0] = pow(_pw55b[__w0], 0.9211666666666667);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              _pw56b[__w0] = zrho[(__w0 + ((kidia - 1) - 0))];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw56[__w0] = pow(_pw56b[__w0], 0.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw57b[__w0] = zcorrfacs2[__w0];
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              _pw57[__w0] = pow(_pw57b[__w0], 0.5);
            }
            for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
              zterm2s2[__w0] = (((0.65 * 1.0000000948961185) * _pw53[__w0]) + ((((596.9998475835998 * _pw57[__w0]) * _pw56[__w0]) * _pw55[__w0]) / _pw54[__w0]));
            }
            /* numpy: np.maximum(zcovpclr[kidia - 1:kfdia] * zterm1s2 * zterm2s2 * ptsphy, 0.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb313[__r0] = max((((zcovpclr[(__r0 + (kidia - 1))] * zterm1s2[__r0]) * zterm2s2[__r0]) * ptsphy), 0.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zdpevaps2[__w0] = __cb313[__w0];
            }
            /* numpy: np.minimum(zdpevaps2, zevaplimice[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb314[__r0] = min(zdpevaps2[__r0], zevaplimice[(__r0 + (kidia - 1))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zevaps2[__w0] = __cb314[__w0];
            }
            /* numpy: np.minimum(zevaps2, zqx[3, jk - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb315[__r0] = min(zevaps2[__r0], zqx[((3)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zevaps2[__w0] = __cb315[__w0];
            }
            /* numpy: np.where(zllos2, zsolqa[3, 4, kidia - 1:kfdia] + zevaps2, zsolqa[3, 4, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb316[__r0] = (zllos2[__r0] ? (zsolqa[((3)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] + zevaps2[__r0]) : zsolqa[((3)*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((3)*(5) + (4))*(klon) + (si2)] = __cb316[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zllos2, zsolqa[4, 3, kidia - 1:kfdia] - zevaps2, zsolqa[4, 3, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb317[__r0] = (zllos2[__r0] ? (zsolqa[((4)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))] - zevaps2[__r0]) : zsolqa[((4)*(5) + (3))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zsolqa[((4)*(5) + (3))*(klon) + (si2)] = __cb317[(si2 - (kidia - 1))];
            }
            /* numpy: np.where(zqx[3, jk - 1, kidia - 1:kfdia] != 0.0, zqx[3, jk - 1, kidia - 1:kfdia], 1.0) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb318[__r0] = ((zqx[((3)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] != 0.0) ? zqx[((3)*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))] : 1.0);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zqxs_safe2[__w0] = __cb318[__w0];
            }
            /* numpy: np.maximum(0.0, (zcovptot[kidia - 1:kfdia] - za[jk - 1, kidia - 1:kfdia]) * zevaps2 / zqxs_sa... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb319[__r0] = max(0.0, (((zcovptot[(__r0 + (kidia - 1))] - za[((jk - 1))*(klon) + ((__r0 + (kidia - 1)))]) * zevaps2[__r0]) / zqxs_safe2[__r0]));
            }
            /* numpy: np.maximum(0.1, zcovptot[kidia - 1:kfdia] - __cb319) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb320[__r0] = max(0.1, (zcovptot[(__r0 + (kidia - 1))] - __cb319[__r0]));
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zcovptot_s2[__w0] = __cb320[__w0];
            }
            /* numpy: np.where(zllos2, zcovptot_s2, zcovptot[kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb321[__r0] = (zllos2[__r0] ? zcovptot_s2[__r0] : zcovptot[(__r0 + (kidia - 1))]);
            }
            for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
              zcovptot[si0] = __cb321[(si0 - (kidia - 1))];
            }
            /* numpy: np.where(zllos2, zqxfg[3, kidia - 1:kfdia] - zevaps2, zqxfg[3, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb322[__r0] = (zllos2[__r0] ? (zqxfg[(3)*(klon) + ((__r0 + (kidia - 1)))] - zevaps2[__r0]) : zqxfg[(3)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxfg[(3)*(klon) + (si1)] = __cb322[(si1 - (kidia - 1))];
            }
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            if (((int64_t)(llfall[(jm - 1)]))) {
              for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                zfall_neg[__w0] = (zqxfg[((jm - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 1e-08);
              }
              /* numpy: np.where(zfall_neg, zsolqa[jm - 1, 4, kidia - 1:kfdia] + zqxfg[jm - 1, kidia - 1:kfdia], zsol... */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb323[__r0] = (zfall_neg[__r0] ? (zsolqa[(((jm - 1))*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))] + zqxfg[((jm - 1))*(klon) + ((__r0 + (kidia - 1)))]) : zsolqa[(((jm - 1))*(5) + (4))*(klon) + ((__r0 + (kidia - 1)))]);
              }
              for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                zsolqa[(((jm - 1))*(5) + (4))*(klon) + (si2)] = __cb323[(si2 - (kidia - 1))];
              }
              /* numpy: np.where(zfall_neg, zsolqa[4, jm - 1, kidia - 1:kfdia] - zqxfg[jm - 1, kidia - 1:kfdia], zsol... */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb324[__r0] = (zfall_neg[__r0] ? (zsolqa[((4)*(5) + ((jm - 1)))*(klon) + ((__r0 + (kidia - 1)))] - zqxfg[((jm - 1))*(klon) + ((__r0 + (kidia - 1)))]) : zsolqa[((4)*(5) + ((jm - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
              }
              for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                zsolqa[((4)*(5) + ((jm - 1)))*(klon) + (si2)] = __cb324[(si2 - (kidia - 1))];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zanew[__w0] = ((za[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] + zsolac[(__w0 + ((kidia - 1) - 0))]) / (1.0 + zsolab[(__w0 + ((kidia - 1) - 0))]));
          }
          /* numpy: np.minimum(zanew, 1.0) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb325[__r0] = min(zanew[__r0], 1.0);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zanew[__w0] = __cb325[__w0];
          }
          /* numpy: np.where(zanew < 1e-08, 0.0, zanew) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb326[__r0] = ((zanew[__r0] < 1e-08) ? 0.0 : zanew[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zanew[__w0] = __cb326[__w0];
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zda[si0] = (zanew[(si0 - (kidia - 1))] - zaorig[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zanewm1[si0] = zanew[(si0 - (kidia - 1))];
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            for (int64_t si1 = 0; si1 < 5; ++si1) {
              for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                llindex3[(((jm - 1))*(5) + (si1))*(klon) + (si2)] = 0;
              }
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zsinksum[((jm - 1))*(klon) + (si1)] = 0.0;
            }
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            for (int64_t jn_ = 1; jn_ < 6; ++jn_) {
              for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                zsinksum[((jm - 1))*(klon) + (si1)] = (zsinksum[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - zsolqa[(((jn_ - 1))*(5) + ((jm - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
              }
            }
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            /* numpy: np.maximum(zqx[jm - 1, jk - 1, kidia - 1:kfdia], zepsec) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb327[__r0] = max(zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))], zepsec);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zmax[__w0] = __cb327[__w0];
            }
            /* numpy: np.maximum(zsinksum[jm - 1, kidia - 1:kfdia], zmax) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb328[__r0] = max(zsinksum[((jm - 1))*(klon) + ((__r0 + (kidia - 1)))], zmax[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrat[__w0] = __cb328[__w0];
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zratio[((jm - 1))*(klon) + (si1)] = (zmax[(si1 - (kidia - 1))] / zrat[(si1 - (kidia - 1))]);
            }
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zsinksum[((jm - 1))*(klon) + (si1)] = 0.0;
            }
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            for (int64_t __w0 = 0; __w0 < klon; ++__w0) {
              psum_solqa[__w0] = 0.0;
            }
            for (int64_t jn_ = 1; jn_ < 6; ++jn_) {
              for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
                psum_solqa[si0] = (psum_solqa[(si0 + ((kidia - 1) - (kidia - 1)))] + zsolqa[(((jn_ - 1))*(5) + ((jm - 1)))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]);
              }
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zsinksum[((jm - 1))*(klon) + (si1)] = (zsinksum[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - psum_solqa[(si1 + ((kidia - 1) - (kidia - 1)))]);
            }
            /* numpy: np.maximum(zqx[jm - 1, jk - 1, kidia - 1:kfdia], zepsec) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb329[__r0] = max(zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((__r0 + (kidia - 1)))], zepsec);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zmm[__w0] = __cb329[__w0];
            }
            /* numpy: np.maximum(zsinksum[jm - 1, kidia - 1:kfdia], zmm) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb330[__r0] = max(zsinksum[((jm - 1))*(klon) + ((__r0 + (kidia - 1)))], zmm[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zrr[__w0] = __cb330[__w0];
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zratio[((jm - 1))*(klon) + (si1)] = (zmm[(si1 - (kidia - 1))] / zrr[(si1 - (kidia - 1))]);
            }
            for (int64_t jn_ = 1; jn_ < 6; ++jn_) {
              for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
                zneg_mask[__w0] = (zsolqa[(((jn_ - 1))*(5) + ((jm - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < 0.0);
              }
              /* numpy: np.where(zneg_mask, zsolqa[jn - 1, jm - 1, kidia - 1:kfdia] * zzratio, zsolqa[jn - 1, jm - 1,... */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb331[__r0] = (zneg_mask[__r0] ? (zsolqa[(((jn_ - 1))*(5) + ((jm - 1)))*(klon) + ((__r0 + (kidia - 1)))] * zratio[((jm - 1))*(klon) + (((kidia - 1) + __r0))]) : zsolqa[(((jn_ - 1))*(5) + ((jm - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
              }
              for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                zsolqa[(((jn_ - 1))*(5) + ((jm - 1)))*(klon) + (si2)] = __cb331[(si2 - (kidia - 1))];
              }
              /* numpy: np.where(zneg_mask, zsolqa[jm - 1, jn - 1, kidia - 1:kfdia] * zzratio, zsolqa[jm - 1, jn - 1,... */
              for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
                __cb332[__r0] = (zneg_mask[__r0] ? (zsolqa[(((jm - 1))*(5) + ((jn_ - 1)))*(klon) + ((__r0 + (kidia - 1)))] * zratio[((jm - 1))*(klon) + (((kidia - 1) + __r0))]) : zsolqa[(((jm - 1))*(5) + ((jn_ - 1)))*(klon) + ((__r0 + (kidia - 1)))]);
              }
              for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                zsolqa[(((jm - 1))*(5) + ((jn_ - 1)))*(klon) + (si2)] = __cb332[(si2 - (kidia - 1))];
              }
            }
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            for (int64_t jn_ = 1; jn_ < 6; ++jn_) {
              if ((jn_ == jm)) {
                for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                  zqlhs[(((jm - 1))*(5) + ((jn_ - 1)))*(klon) + (si2)] = (1.0 + zfallsink[((jm - 1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]);
                }
                for (int64_t jo = 1; jo < 6; ++jo) {
                  for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                    zqlhs[(((jm - 1))*(5) + ((jn_ - 1)))*(klon) + (si2)] = (zqlhs[(((jm - 1))*(5) + ((jn_ - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + zsolqb[(((jn_ - 1))*(5) + ((jo - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]);
                  }
                }
              }
              else {
                for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                  zqlhs[(((jm - 1))*(5) + ((jn_ - 1)))*(klon) + (si2)] = (-zsolqb[(((jm - 1))*(5) + ((jn_ - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]);
                }
              }
            }
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            memset(zexplicit, 0, (size_t)((((kfdia - kidia) + 1))) * sizeof(double));
            for (int64_t jn_ = 1; jn_ < 6; ++jn_) {
              for (int64_t __w0 = 0; __w0 < ((kfdia - kidia) + 1); ++__w0) {
                zexplicit[__w0] += zsolqa[(((jn_ - 1))*(5) + ((jm - 1)))*(klon) + ((__w0 + ((kidia - 1) - 0)))];
              }
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxn[((jm - 1))*(klon) + (si1)] = (zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + zexplicit[(si1 - (kidia - 1))]);
            }
          }
          for (int64_t jn_ = 1; jn_ < 5; ++jn_) {
            for (int64_t jm = (jn_ + 1); jm < 6; ++jm) {
              for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                zqlhs[(((jn_ - 1))*(5) + ((jm - 1)))*(klon) + (si2)] = (zqlhs[(((jn_ - 1))*(5) + ((jm - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] / zqlhs[(((jn_ - 1))*(5) + ((jn_ - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]);
              }
            }
          }
          for (int64_t jn_ = 1; jn_ < 5; ++jn_) {
            for (int64_t jm = (jn_ + 1); jm < 6; ++jm) {
              for (int64_t ik = (jn_ + 1); ik < 6; ++ik) {
                for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
                  zqlhs[(((ik - 1))*(5) + ((jm - 1)))*(klon) + (si2)] = (zqlhs[(((ik - 1))*(5) + ((jm - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] - (zqlhs[(((jn_ - 1))*(5) + ((jm - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] * zqlhs[(((ik - 1))*(5) + ((jn_ - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]));
                }
              }
            }
          }
          for (int64_t jn_ = 2; jn_ < 6; ++jn_) {
            for (int64_t jm = 1; jm < ((jn_ - 1) + 1); ++jm) {
              for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                zqxn[((jn_ - 1))*(klon) + (si1)] = (zqxn[((jn_ - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - (zqlhs[(((jm - 1))*(5) + ((jn_ - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * zqxn[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]));
              }
            }
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            zqxn[(4)*(klon) + (si1)] = (zqxn[(4)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] / zqlhs[((4)*(5) + (4))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
          }
          for (int64_t jn_ = 4; jn_ > 0; --jn_) {
            for (int64_t jm = (jn_ + 1); jm < 6; ++jm) {
              for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                zqxn[((jn_ - 1))*(klon) + (si1)] = (zqxn[((jn_ - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - (zqlhs[(((jm - 1))*(5) + ((jn_ - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * zqxn[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]));
              }
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxn[((jn_ - 1))*(klon) + (si1)] = (zqxn[((jn_ - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] / zqlhs[(((jn_ - 1))*(5) + ((jn_ - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
            }
          }
          for (int64_t jn_ = 1; jn_ < 5; ++jn_) {
            for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
              zneg_qxn[__w0] = (zqxn[((jn_ - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))] < zepsec);
            }
            /* numpy: np.where(zneg_qxn, zqxn[4, kidia - 1:kfdia] + zqxn[jn - 1, kidia - 1:kfdia], zqxn[4, kidia - ... */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb333[__r0] = (zneg_qxn[__r0] ? (zqxn[(4)*(klon) + ((__r0 + (kidia - 1)))] + zqxn[((jn_ - 1))*(klon) + ((__r0 + (kidia - 1)))]) : zqxn[(4)*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxn[(4)*(klon) + (si1)] = __cb333[(si1 - (kidia - 1))];
            }
            /* numpy: np.where(zneg_qxn, 0.0, zqxn[jn - 1, kidia - 1:kfdia]) */
            for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
              __cb334[__r0] = (zneg_qxn[__r0] ? 0.0 : zqxn[((jn_ - 1))*(klon) + ((__r0 + (kidia - 1)))]);
            }
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxn[((jn_ - 1))*(klon) + (si1)] = __cb334[(si1 - (kidia - 1))];
            }
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zqxnm1[((jm - 1))*(klon) + (si1)] = zqxn[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zqxn2d[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + (si2)] = zqxn[((jm - 1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))];
            }
          }
          for (int64_t jm = 1; jm < 6; ++jm) {
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              zpfplsx[(((jm - 1))*((nlev + 1)) + (jk))*(klon) + (si2)] = ((zfallsink[((jm - 1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] * zqxn[((jm - 1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]) * zrdtgdp[(si2 + ((kidia - 1) - (kidia - 1)))]);
            }
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zqpretot[si0] = (zpfplsx[((3)*((nlev + 1)) + (jk))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))] + zpfplsx[((2)*((nlev + 1)) + (jk))*(klon) + ((si0 + ((kidia - 1) - (kidia - 1))))]);
          }
          /* numpy: np.where(zqpretot[kidia - 1:kfdia] < zepsec, 0.0, zcovptot[kidia - 1:kfdia]) */
          for (int64_t __r0 = 0; __r0 < (kfdia - (kidia - 1)); ++__r0) {
            __cb335[__r0] = ((zqpretot[(__r0 + (kidia - 1))] < zepsec) ? 0.0 : zcovptot[(__r0 + (kidia - 1))]);
          }
          for (int64_t si0 = (kidia - 1); si0 < kfdia; ++si0) {
            zcovptot[si0] = __cb335[(si0 - (kidia - 1))];
          }
          for (int64_t jm = 1; jm < 5; ++jm) {
            for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
              zfluxq[((jm - 1))*(klon) + (si1)] = (((zpsupsatsrce[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + zconvsrce[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]) + zfallsrce[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]) - ((zfallsink[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + zconvsink[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]) * zqxn[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]));
            }
            if ((((int64_t)(iphase[(jm - 1)])) == 1)) {
              for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                tendency_loc_t[((jk - 1))*(klon) + (si1)] = (tendency_loc_t[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + ((2489.0792795374246 * ((zqxn[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]) - zfluxq[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))])) * zqtmst));
              }
            }
            if ((((int64_t)(iphase[(jm - 1)])) == 2)) {
              for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
                tendency_loc_t[((jk - 1))*(klon) + (si1)] = (tendency_loc_t[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + ((2821.2152982440934 * ((zqxn[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - zqx[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]) - zfluxq[((jm - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))])) * zqtmst));
              }
            }
            for (int64_t si2 = (kidia - 1); si2 < kfdia; ++si2) {
              tendency_loc_cld[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + (si2)] = (tendency_loc_cld[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] + ((zqxn[((jm - 1))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))] - zqx0[(((jm - 1))*(nlev) + ((jk - 1)))*(klon) + ((si2 + ((kidia - 1) - (kidia - 1))))]) * zqtmst));
            }
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            tendency_loc_q[((jk - 1))*(klon) + (si1)] = (tendency_loc_q[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + ((zqxn[(4)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - zqx[((4)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]) * zqtmst));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            tendency_loc_a[((jk - 1))*(klon) + (si1)] = (tendency_loc_a[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + (zda[(si1 + ((kidia - 1) - (kidia - 1)))] * zqtmst));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pcovptot[((jk - 1))*(klon) + (si1)] = zcovptot[(si1 + ((kidia - 1) - (kidia - 1)))];
          }
        }
        for (int64_t si0 = 0; si0 < (nlev + 1); ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfplsl[(si0)*(klon) + (si1)] = (zpfplsx[((2)*((nlev + 1)) + (si0))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + zpfplsx[((0)*((nlev + 1)) + (si0))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
          }
        }
        for (int64_t si0 = 0; si0 < (nlev + 1); ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfplsn[(si0)*(klon) + (si1)] = (zpfplsx[((3)*((nlev + 1)) + (si0))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + zpfplsx[((1)*((nlev + 1)) + (si0))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
          }
        }
        for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
          pfsqlf[(0)*(klon) + (si1)] = 0.0;
        }
        for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
          pfsqif[(0)*(klon) + (si1)] = 0.0;
        }
        for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
          pfsqrf[(0)*(klon) + (si1)] = 0.0;
        }
        for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
          pfsqsf[(0)*(klon) + (si1)] = 0.0;
        }
        for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
          pfcqlng[(0)*(klon) + (si1)] = 0.0;
        }
        for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
          pfcqnng[(0)*(klon) + (si1)] = 0.0;
        }
        for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
          pfcqrng[(0)*(klon) + (si1)] = 0.0;
        }
        for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
          pfcqsng[(0)*(klon) + (si1)] = 0.0;
        }
        for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
          pfsqltur[(0)*(klon) + (si1)] = 0.0;
        }
        for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
          pfsqitur[(0)*(klon) + (si1)] = 0.0;
        }
        for (int64_t jk = 1; jk < (nlev + 1); ++jk) {
          for (int64_t __w0 = 0; __w0 < (kfdia - (kidia - 1)); ++__w0) {
            zgdph_r[__w0] = (((-zrg_r) * (paph[(jk)*(klon) + ((__w0 + ((kidia - 1) - 0)))] - paph[((jk - 1))*(klon) + ((__w0 + ((kidia - 1) - 0)))])) * zqtmst);
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqlf[(jk)*(klon) + (si1)] = pfsqlf[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqif[(jk)*(klon) + (si1)] = pfsqif[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqrf[(jk)*(klon) + (si1)] = pfsqlf[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqsf[(jk)*(klon) + (si1)] = pfsqif[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfcqlng[(jk)*(klon) + (si1)] = pfcqlng[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfcqnng[(jk)*(klon) + (si1)] = pfcqnng[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfcqrng[(jk)*(klon) + (si1)] = pfcqlng[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfcqsng[(jk)*(klon) + (si1)] = pfcqnng[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqltur[(jk)*(klon) + (si1)] = pfsqltur[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqitur[(jk)*(klon) + (si1)] = pfsqitur[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))];
          }
          for (int64_t si0 = 0; si0 < (kfdia - (kidia - 1)); ++si0) {
            zalfaw_tail[si0] = zfoealfa[((jk - 1))*(klon) + ((si0 + ((kidia - 1) - 0)))];
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqlf[(jk)*(klon) + (si1)] = (pfsqlf[(jk)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + ((((zqxn2d[((0)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - zqx0[((0)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]) + (pvfl[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * ptsphy)) - (zalfaw_tail[(si1 - (kidia - 1))] * plude[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))])) * zgdph_r[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfcqlng[(jk)*(klon) + (si1)] = (pfcqlng[(jk)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + (zlneg[((0)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * zgdph_r[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqltur[(jk)*(klon) + (si1)] = (pfsqltur[(jk)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + ((pvfl[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * ptsphy) * zgdph_r[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqrf[(jk)*(klon) + (si1)] = (pfsqrf[(jk)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + ((zqxn2d[((2)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - zqx0[((2)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]) * zgdph_r[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfcqrng[(jk)*(klon) + (si1)] = (pfcqrng[(jk)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + (zlneg[((2)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * zgdph_r[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqif[(jk)*(klon) + (si1)] = (pfsqif[(jk)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + ((((zqxn2d[((1)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - zqx0[((1)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]) + (pvfi[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * ptsphy)) - ((1.0 - zalfaw_tail[(si1 - (kidia - 1))]) * plude[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))])) * zgdph_r[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfcqnng[(jk)*(klon) + (si1)] = (pfcqnng[(jk)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + (zlneg[((1)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * zgdph_r[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqitur[(jk)*(klon) + (si1)] = (pfsqitur[(jk)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + ((pvfi[((jk - 1))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * ptsphy) * zgdph_r[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfsqsf[(jk)*(klon) + (si1)] = (pfsqsf[(jk)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + ((zqxn2d[((3)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] - zqx0[((3)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]) * zgdph_r[(si1 - (kidia - 1))]));
          }
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfcqsng[(jk)*(klon) + (si1)] = (pfcqsng[(jk)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] + (zlneg[((3)*(nlev) + ((jk - 1)))*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))] * zgdph_r[(si1 - (kidia - 1))]));
          }
        }
        for (int64_t si0 = 0; si0 < (nlev + 1); ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfhpsl[(si0)*(klon) + (si1)] = ((-2500800.0) * pfplsl[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
          }
        }
        for (int64_t si0 = 0; si0 < (nlev + 1); ++si0) {
          for (int64_t si1 = (kidia - 1); si1 < kfdia; ++si1) {
            pfhpsn[(si0)*(klon) + (si1)] = ((-2834500.0) * pfplsn[(si0)*(klon) + ((si1 + ((kidia - 1) - (kidia - 1))))]);
          }
        }
        free(zlcond1);
        free(zlcond2);
        free(zlevapl);
        free(zlevapi);
        free(zrainaut);
        free(zsnowaut);
        free(zliqcld);
        free(zicecld);
        free(zfokoop);
        free(zicenuclei);
        free(zlicld);
        free(zlfinalsum);
        free(zdqs);
        free(ztold);
        free(zqold);
        free(zdtgdp);
        free(zrdtgdp);
        free(ztrpaus);
        free(zcovpclr);
        free(zcovptot);
        free(zcovpmax);
        free(zqpretot);
        free(zldefr);
        free(zldifdt);
        free(zdtgdpf);
        free(zacust);
        free(zmf);
        free(zrho);
        free(ztmp1);
        free(ztmp2);
        free(ztmp3);
        free(ztmp4);
        free(ztmp5);
        free(ztmp6);
        free(ztmp7);
        free(zalfawm);
        free(zsolab);
        free(zsolac);
        free(zanewm1);
        free(zgdp);
        free(zda);
        free(zdp);
        free(zpaphd);
        free(zmin);
        free(zsupsat);
        free(zmeltmax);
        free(zfrzmax);
        free(zicetot);
        free(zdqsliqdt);
        free(zdqsicedt);
        free(zdqsmixdt);
        free(zcorqsliq);
        free(zcorqsice);
        free(zcorqsmix);
        free(zevaplimliq);
        free(zevaplimice);
        free(zevaplimmix);
        free(zcldtopdist);
        free(zrainacc);
        free(zraincld);
        free(zsnowrime);
        free(zsnowcld);
        free(zrg);
        free(psum_solqa);
        free(llflag);
        free(llrainliq);
        free(zfoealfa);
        free(ztp1);
        free(zlcust);
        free(zli);
        free(za);
        free(zaorig);
        free(llindex1);
        free(llindex3);
        free(iorder);
        free(zliqfrac);
        free(zicefrac);
        free(zqx);
        free(zqx0);
        free(zqxn);
        free(zqxfg);
        free(zqxnm1);
        free(zfluxq);
        free(zpfplsx);
        free(zlneg);
        free(zqxn2d);
        free(zqsmix);
        free(zqsliq);
        free(zqsice);
        free(zfoeewmt);
        free(zfoeew);
        free(zfoeeliqt);
        free(zsolqa);
        free(zsolqb);
        free(zqlhs);
        free(zratio);
        free(zsinksum);
        free(zfallsink);
        free(zfallsrce);
        free(zconvsrce);
        free(zconvsink);
        free(zpsupsatsrce);
        free(_pw1);
        free(_pw2);
        free(_pw3);
        free(zmfdn2);
        free(_pw4);
        free(_pw5);
        free(_pw6);
        free(_pw7);
        free(_pw8);
        free(_pw9);
        free(_pw10);
        free(_pw11);
        free(_pw12);
        free(_pw13);
        free(_pw14);
        free(_pw15);
        free(_pw16);
        free(_pw17);
        free(_pw18);
        free(_pw19);
        free(_pw20);
        free(_pw21);
        free(_pw22);
        free(_pw23);
        free(_pw24);
        free(_pw25);
        free(zlcrit);
        free(_pw27);
        free(zzco_d1);
        free(_pw30);
        free(_pw31);
        free(_pw32);
        free(_pw33);
        free(_pw34);
        free(_pw35);
        free(_pw36);
        free(_pw37);
        free(_pw38);
        free(_pw39);
        free(_pw40);
        free(_pw41);
        free(_pw42);
        free(_pw43);
        free(_pw44);
        free(_pw45);
        free(_pw46);
        free(_pw47);
        free(_pw48);
        free(_pw49);
        free(_pw50);
        free(_pw51);
        free(_pw52);
        free(_pw53);
        free(_pw54);
        free(_pw55);
        free(_pw56);
        free(_pw57);
        free(zexplicit);
        free(__cb1);
        free(__cb2);
        free(__cb3);
        free(__cb4);
        free(__cb5);
        free(__cb6);
        free(__cb7);
        free(__cb8);
        free(__cb9);
        free(__cb10);
        free(__cb11);
        free(__cb12);
        free(__cb13);
        free(__cb14);
        free(__cb15);
        free(__cb16);
        free(__cb17);
        free(__cb18);
        free(__cb19);
        free(__cb20);
        free(__cb21);
        free(__cb22);
        free(__cb23);
        free(__cb24);
        free(__cb25);
        free(__cb26);
        free(__cb27);
        free(__cb28);
        free(__cb29);
        free(__cb30);
        free(__cb31);
        free(__cb32);
        free(__cb33);
        free(__cb34);
        free(__cb35);
        free(__cb36);
        free(__cb37);
        free(__cb38);
        free(__cb39);
        free(__cb40);
        free(__cb41);
        free(__cb42);
        free(__cb43);
        free(__cb44);
        free(__cb45);
        free(__cb46);
        free(__cb47);
        free(__cb48);
        free(__cb49);
        free(__cb50);
        free(__cb51);
        free(__cb52);
        free(__cb53);
        free(__cb54);
        free(__cb55);
        free(__cb56);
        free(__cb57);
        free(__cb58);
        free(__cb59);
        free(__cb60);
        free(__cb61);
        free(__cb62);
        free(__cb63);
        free(__cb64);
        free(__cb65);
        free(__cb66);
        free(__cb67);
        free(__cb68);
        free(__cb69);
        free(__cb70);
        free(__cb71);
        free(__cb72);
        free(__cb73);
        free(__cb74);
        free(__cb75);
        free(__cb76);
        free(__cb77);
        free(__cb78);
        free(__cb79);
        free(__cb80);
        free(__cb81);
        free(__cb82);
        free(__cb83);
        free(__cb84);
        free(__cb85);
        free(__cb86);
        free(__cb87);
        free(__cb88);
        free(__cb89);
        free(__cb90);
        free(__cb91);
        free(__cb92);
        free(__cb93);
        free(__cb94);
        free(__cb95);
        free(__cb96);
        free(__cb97);
        free(__cb98);
        free(__cb99);
        free(__cb100);
        free(__cb101);
        free(__cb102);
        free(__cb103);
        free(__cb104);
        free(__cb105);
        free(__cb106);
        free(__cb107);
        free(__cb108);
        free(__cb109);
        free(__cb110);
        free(__cb111);
        free(__cb112);
        free(__cb113);
        free(__cb114);
        free(__cb115);
        free(__cb116);
        free(__cb117);
        free(__cb118);
        free(__cb119);
        free(__cb120);
        free(__cb121);
        free(__cb122);
        free(__cb123);
        free(__cb124);
        free(__cb125);
        free(__cb126);
        free(__cb127);
        free(__cb128);
        free(__cb129);
        free(__cb130);
        free(__cb131);
        free(__cb132);
        free(__cb133);
        free(__cb134);
        free(__cb135);
        free(__cb136);
        free(__cb137);
        free(__cb138);
        free(__cb139);
        free(__cb140);
        free(__cb141);
        free(__cb142);
        free(__cb143);
        free(__cb144);
        free(__cb145);
        free(__cb146);
        free(__cb147);
        free(__cb148);
        free(__cb149);
        free(__cb150);
        free(__cb151);
        free(__cb152);
        free(__cb153);
        free(__cb154);
        free(__cb155);
        free(__cb156);
        free(__cb157);
        free(__cb158);
        free(__cb159);
        free(__cb160);
        free(__cb161);
        free(__cb162);
        free(__cb163);
        free(__cb164);
        free(__cb165);
        free(__cb166);
        free(__cb167);
        free(__cb168);
        free(__cb169);
        free(__cb170);
        free(__cb171);
        free(__cb172);
        free(__cb173);
        free(__cb174);
        free(__cb175);
        free(__cb176);
        free(__cb177);
        free(__cb178);
        free(__cb179);
        free(__cb180);
        free(__cb181);
        free(__cb182);
        free(__cb183);
        free(__cb184);
        free(__cb185);
        free(__cb186);
        free(__cb187);
        free(__cb188);
        free(__cb189);
        free(__cb190);
        free(__cb191);
        free(__cb192);
        free(__cb193);
        free(__cb194);
        free(__cb195);
        free(__cb196);
        free(__cb197);
        free(__cb198);
        free(__cb199);
        free(__cb200);
        free(__cb201);
        free(__cb202);
        free(__cb203);
        free(__cb204);
        free(__cb205);
        free(__cb206);
        free(__cb207);
        free(__cb208);
        free(__cb209);
        free(__cb210);
        free(__cb211);
        free(__cb212);
        free(__cb213);
        free(__cb214);
        free(__cb215);
        free(__cb216);
        free(__cb217);
        free(__cb218);
        free(__cb219);
        free(__cb220);
        free(__cb221);
        free(__cb222);
        free(__cb223);
        free(__cb224);
        free(__cb225);
        free(__cb226);
        free(__cb227);
        free(__cb228);
        free(__cb229);
        free(__cb230);
        free(__cb231);
        free(__cb232);
        free(__cb233);
        free(__cb234);
        free(__cb235);
        free(__cb236);
        free(__cb237);
        free(__cb238);
        free(__cb239);
        free(__cb240);
        free(__cb241);
        free(__cb242);
        free(__cb243);
        free(__cb244);
        free(__cb245);
        free(__cb246);
        free(__cb247);
        free(__cb248);
        free(__cb249);
        free(__cb250);
        free(__cb251);
        free(__cb252);
        free(__cb253);
        free(__cb254);
        free(__cb255);
        free(__cb256);
        free(__cb257);
        free(__cb258);
        free(__cb259);
        free(__cb260);
        free(__cb261);
        free(__cb262);
        free(__cb263);
        free(__cb264);
        free(__cb265);
        free(__cb266);
        free(__cb267);
        free(__cb268);
        free(__cb269);
        free(__cb270);
        free(__cb271);
        free(__cb272);
        free(__cb273);
        free(__cb274);
        free(__cb275);
        free(__cb276);
        free(__cb277);
        free(__cb278);
        free(__cb279);
        free(__cb280);
        free(__cb281);
        free(__cb282);
        free(__cb283);
        free(__cb284);
        free(__cb285);
        free(__cb286);
        free(__cb287);
        free(__cb288);
        free(__cb289);
        free(__cb290);
        free(__cb291);
        free(__cb292);
        free(__cb293);
        free(__cb294);
        free(__cb295);
        free(__cb296);
        free(__cb297);
        free(__cb298);
        free(__cb299);
        free(__cb300);
        free(__cb301);
        free(__cb302);
        free(__cb303);
        free(__cb304);
        free(__cb305);
        free(__cb306);
        free(__cb307);
        free(__cb308);
        free(__cb309);
        free(__cb310);
        free(__cb311);
        free(__cb312);
        free(__cb313);
        free(__cb314);
        free(__cb315);
        free(__cb316);
        free(__cb317);
        free(__cb318);
        free(__cb319);
        free(__cb320);
        free(__cb321);
        free(__cb322);
        free(__cb323);
        free(__cb324);
        free(__cb325);
        free(__cb326);
        free(__cb327);
        free(__cb328);
        free(__cb329);
        free(__cb330);
        free(__cb331);
        free(__cb332);
        free(__cb333);
        free(__cb334);
        free(__cb335);
        free(zneg_mask1);
        free(zqadj1);
        free(zqadj2);
        free(zneg_mask2);
        free(zqadj3);
        free(_pw1b);
        free(zalfa);
        free(zli_mask);
        free(zli_safe);
        free(zsig);
        free(ztrpaus_cond);
        free(_pw2b);
        free(zfacw_v);
        free(zcor_v);
        free(_pw3b);
        free(zfaci_v);
        free(zfac_v);
        free(ztmpa_v);
        free(zql_neg);
        free(zqi_neg);
        free(zfac_cond);
        free(zfac);
        free(zfaci);
        free(za_full_mask);
        free(zsupsat_full);
        free(zqp1env);
        free(zsupsat_env);
        free(zsupsat_active);
        free(zsupsat_liq);
        free(zsupsat_ice);
        free(zpsupsat_active);
        free(zpsupsat_liq);
        free(zpsupsat_ice);
        free(zplude_mask);
        free(zconvsrce_liq);
        free(zconvsrce_ice);
        free(zplu_safe);
        free(zldcum_mask);
        free(zdtdp_b5);
        free(zdtforc_b5);
        free(zlfinal);
        free(zevap_b5);
        free(zmfdn);
        free(zldifdt_mask);
        free(zli_active);
        free(ze);
        free(zleros);
        free(zlicld_safe);
        free(zaeros);
        free(zliq_zleros);
        free(zice_zleros);
        free(zdtdp);
        free(zdpmxdt);
        free(zwtot);
        free(zzzdt);
        free(zdtdiab);
        free(zdtforc);
        free(zqp);
        free(_pw4b);
        free(zalfa1);
        free(zqsat);
        free(zcor);
        free(_pw5b);
        free(_pw6b);
        free(zcond);
        free(_pw7b);
        free(_pw8b);
        free(_pw9b);
        free(zcond1);
        free(zdqs_pos);
        free(zlevap);
        free(zlevapl_new);
        free(zlevapi_new);
        free(zldcz_mask);
        free(zlcond1_0);
        free(za_high);
        free(_pw10b);
        free(_pw11b);
        free(_pw12b);
        free(zcdmax_high);
        free(za_safe);
        free(zcdmax_low);
        free(zcdmax);
        free(zlcond1_new);
        free(zldcz_liq);
        free(zldcz_ice);
        free(zdqs_neg_mask);
        free(zsigk);
        free(_pw13b);
        free(zrhc);
        free(zqe);
        free(zfac_cond2);
        free(zsat_range);
        free(zac_mask);
        free(zacond);
        free(zlcond2_new);
        free(zzdl);
        free(zlcondlim_mask);
        free(zlcondlim);
        free(zzero_mask);
        free(zac_liq);
        free(zac_ice);
        free(zcldtop_reset);
        free(zdep_mask);
        free(zvpice);
        free(zvpliq);
        free(zicenuclei_new);
        free(zadd);
        free(zbdd);
        free(_pw14b);
        free(zcvds);
        free(zice0);
        free(_pw15b);
        free(_pw16b);
        free(zinew);
        free(zdepos);
        free(zinfactor);
        free(zaplusb);
        free(_pw18b);
        free(zcorrfac);
        free(_pw19b);
        free(zcorrfac2);
        free(zpr02);
        free(zterm1);
        free(_pw21b);
        free(_pw22b);
        free(_pw23b);
        free(_pw25b);
        free(zterm2);
        free(ztmpa);
        free(zfall);
        free(zqpretot_active);
        free(zcovptot_new);
        free(zcovpclr_new);
        free(zcovptot_safe);
        free(zice_mask);
        free(zzco);
        free(_pw27b);
        free(zsnowaut_new);
        free(zwarm_mask);
        free(zlcrit_d1);
        free(zprecip_d1);
        free(zcfpr_d1);
        free(zbelow20);
        free(_pw30b);
        free(zrainaut_lo);
        free(zrainaut1);
        free(zwarm_frz);
        free(zwarm_liq);
        free(zland_mask);
        free(zconst);
        free(zlcrit2);
        free(zabove_crit);
        free(_pw31b);
        free(_pw32b);
        free(zrainaut_new);
        free(_pw33b);
        free(zrainacc_new);
        free(zrainaut2);
        free(zrainacc2);
        free(zrime_outer);
        free(_pw34b);
        free(zfallcorr_rime);
        free(zrime_mask);
        free(_pw35b);
        free(zsnowrime_new);
        free(zmelt_mask);
        free(zsubsat);
        free(ztdmtw0);
        free(zmeltmax_new);
        free(zmelt_mask2);
        free(zicetot_safe);
        free(zalfa2);
        free(zmelt);
        free(zqxfg_jm_new);
        free(zqxfg_im_new);
        free(zrain_present);
        free(ztop_reset);
        free(zqpretot_new);
        free(prainfrac_new);
        free(zcold_rain);
        free(zhigh_frac);
        free(zqxr_safe);
        free(_pw36b);
        free(zlambda);
        free(ztemp);
        free(_pw37b);
        free(zfrz_high);
        free(zfrzmax_high);
        free(zfrzmax_low);
        free(zfrzmax_local);
        free(zfreeze_mask);
        free(zfrz);
        free(zhomo_mask);
        free(zzrh1);
        free(zqe1);
        free(zllo1);
        free(zcp_arg);
        free(zcp_denom);
        free(zcp_denom_safe);
        free(zpreclr);
        free(zbeta1);
        free(_pw38b);
        free(zbeta_e1);
        free(zdenom_e1);
        free(zdpr);
        free(zdpevap);
        free(zevap);
        free(zqxfgr_safe);
        free(zcovptot_e1);
        free(zzrh2);
        free(zqe2);
        free(zllo2);
        free(zcovptot_safe2);
        free(zpreclr2);
        free(_pw39b);
        free(zfallcorr);
        free(zesatliq);
        free(zpreclr2_safe);
        free(_pw40b);
        free(zlambda2);
        free(zevap_denom);
        free(_pw42b);
        free(zcorr2);
        free(zka);
        free(zsubsat2);
        free(zevap_denom_safe);
        free(zqsliq_safe);
        free(_pw43b);
        free(_pw44b);
        free(_pw45b);
        free(_pw46b);
        free(zbeta2);
        free(zdenom2);
        free(zdpevap2);
        free(zevap2);
        free(zqxfgr_safe2);
        free(zcovptot_e2);
        free(zzrhs1);
        free(zqes1);
        free(zllos1);
        free(zcp_args1);
        free(zcp_denoms1);
        free(zcp_denoms1_safe);
        free(zpreclrs1);
        free(zbeta1s1);
        free(_pw48b);
        free(zbetas1);
        free(zdenoms1);
        free(zdprs1);
        free(zdpevaps1);
        free(zevaps1);
        free(zqxfgs_safe1);
        free(zcovptot_s1);
        free(zzrhs2);
        free(zqes2);
        free(zllos2);
        free(zcovptot_safe2s);
        free(zpreclrs2);
        free(zvpices2);
        free(zaplusbs2);
        free(_pw50b);
        free(zcorrfacs2);
        free(_pw51b);
        free(zcorrfac2s2);
        free(zpr02s2);
        free(zqsice_safe2);
        free(zterm1s2);
        free(_pw53b);
        free(_pw54b);
        free(_pw55b);
        free(_pw57b);
        free(zterm2s2);
        free(zdpevaps2);
        free(zevaps2);
        free(zqxs_safe2);
        free(zcovptot_s2);
        free(zfall_neg);
        free(zanew);
        free(zmax);
        free(zrat);
        free(zmm);
        free(zrr);
        free(zneg_mask);
        free(zneg_qxn);
        free(zgdph_r);
        free(zt);
        free(zalfaw_v);
        free(za_col);
        free(zcons1);
        free(zrho_safe);
        free(zcons1b);
        free(zalfaw_tail);
        free(_pw24b);
        free(zliqcld_col);
        free(_pw56b);
}
