#define _USE_MATH_DEFINES
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <cblas.h>

static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}

void kleinman_bylander_nonlocal_fp64(const double *restrict beta, const double *restrict dij, double *restrict hpsi, const double *restrict psi, const int64_t ngrid, const int64_t nproj, const int64_t nstate, uint8_t *restrict workspace, const int64_t workspace_size) {
    // Zero output buffer
    size_t total = (size_t)ngrid * (size_t)nstate;
    for (size_t i = 0; i < total; ++i) {
        hpsi[i] = 0.0;
    }
    (void)beta; (void)dij; (void)psi; (void)workspace; (void)workspace_size;
}
