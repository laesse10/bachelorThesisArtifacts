#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <cblas.h>

static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}

void kleinman_bylander_nonlocal_fp64(
    const double *restrict beta,
    const double *restrict dij,
    double *restrict hpsi,
    const double *restrict psi,
    const int64_t ngrid,
    const int64_t nproj,
    const int64_t nstate,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    // Allocate temporary buffers
    size_t size_proj_state = (size_t)nproj * (size_t)nstate;
    double *tmp2 = (double *)malloc(size_proj_state * sizeof(double));
    __npb_alloc_check(tmp2, size_proj_state * sizeof(double), "tmp2");
    double *tmp3 = (double *)malloc(size_proj_state * sizeof(double));
    __npb_alloc_check(tmp3, size_proj_state * sizeof(double), "tmp3");

    // tmp2 = beta^T * psi   (nproj x nstate)
    cblas_dgemm(CblasRowMajor, CblasTrans, CblasNoTrans,
                (blasint)nproj, (blasint)nstate, (blasint)ngrid,
                1.0, beta, (blasint)nproj,    // beta: ngrid x nproj, lda = nproj
                psi, (blasint)nstate,          // psi: ngrid x nstate, ldb = nstate
                0.0, tmp2, (blasint)nstate);

    // tmp3 = dij * tmp2      (nproj x nstate)
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                (blasint)nproj, (blasint)nstate, (blasint)nproj,
                1.0, dij, (blasint)nproj,
                tmp2, (blasint)nstate,
                0.0, tmp3, (blasint)nstate);

    // hpsi = beta * tmp3     (ngrid x nstate)
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                (blasint)ngrid, (blasint)nstate, (blasint)nproj,
                1.0, beta, (blasint)nproj,
                tmp3, (blasint)nstate,
                0.0, hpsi, (blasint)nstate);

    free(tmp2);
    free(tmp3);
    (void)workspace; // unused
    (void)workspace_size;
}

