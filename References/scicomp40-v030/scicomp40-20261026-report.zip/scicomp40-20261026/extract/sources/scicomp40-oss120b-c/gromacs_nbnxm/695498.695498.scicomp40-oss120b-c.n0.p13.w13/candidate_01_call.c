#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <omp.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

static void _nbnxm_4x4_qstab_lj_force_arrays(const int32_t *restrict atom_type, const int32_t *restrict ci_cj_end, const int32_t *restrict ci_cj_start, const int32_t *restrict ci_cluster, const int32_t *restrict ci_flags, const int32_t *restrict ci_shift, const int32_t *restrict cj_cluster, const uint16_t *restrict cj_excl, const double *restrict coulomb_table_f, double *restrict f, double *restrict fshift, const double *restrict nbfp, const double *restrict q, const double *restrict shift_vec, const double *restrict x, const double epsfac, const double min_distance_squared, const int64_t n_clusters, const int64_t num_types, const double rcut, const double tab_coul_scale, const int64_t table_size);
static void _inner_4x4(const int32_t *restrict atom_type, const double *restrict coulomb_table_f, double *restrict f, double *restrict fi, const double *restrict nbfp, const double *restrict q, const double *restrict qi, const double *restrict x, const double *restrict xi, const bool check_exclusions, const int64_t ci, const double ci_sh, const int64_t cj, const bool do_coul, const bool do_lj, const int64_t excl_mask, const bool half_lj, const double min_distance_squared, const int64_t n_clusters, const int64_t num_types, const double rcut2, const double tab_coul_scale, const int64_t table_size);
static void _inner_4x4__s2(const int32_t *restrict atom_type, const double *restrict coulomb_table_f, double *restrict f, double *restrict fi, const double *restrict nbfp, const double *restrict q, const double *restrict qi, const double *restrict x, const double *restrict xi, const bool check_exclusions, const int64_t ci, const double ci_sh, const int64_t cj, const bool do_coul, const bool do_lj, const int64_t excl_mask, const bool half_lj, const double min_distance_squared, const int64_t n_clusters, const int64_t num_types, const double rcut2, const double tab_coul_scale, const int64_t table_size);

static void _nbnxm_4x4_qstab_lj_force_arrays(const int32_t *restrict atom_type, const int32_t *restrict ci_cj_end, const int32_t *restrict ci_cj_start, const int32_t *restrict ci_cluster, const int32_t *restrict ci_flags, const int32_t *restrict ci_shift, const int32_t *restrict cj_cluster, const uint16_t *restrict cj_excl, const double *restrict coulomb_table_f, double *restrict f, double *restrict fshift, const double *restrict nbfp, const double *restrict q, const double *restrict shift_vec, const double *restrict x, const double epsfac, const double min_distance_squared, const int64_t n_clusters, const int64_t num_types, const double rcut, const double tab_coul_scale, const int64_t table_size) {
    double rcut2;
    int64_t cjind0;
    int64_t cjind1;
    int64_t ci;
    bool half_lj;
    int64_t cjind;
    double fi[(4) * (3)];
    memset(fi, 0, (size_t)((4) * (3)) * sizeof(double));
    double xi[4 * 3];
    double qi[4];
    rcut2 = (rcut * rcut);
    for (int64_t ci_entry = 0; ci_entry < n_clusters; ++ci_entry) {
      cjind0 = ((int64_t)(((int64_t)(ci_cj_start[ci_entry]))));
      cjind1 = ((int64_t)(((int64_t)(ci_cj_end[ci_entry]))));
      ci = ((int64_t)(((int64_t)(ci_cluster[ci_entry]))));
      half_lj = ((((((int64_t)(((int64_t)(ci_flags[ci_entry])))) & 4) != 0) || (!((((int64_t)(((int64_t)(ci_flags[ci_entry])))) & 1) != 0))) && ((((int64_t)(((int64_t)(ci_flags[ci_entry])))) & 2) != 0));
      for (int64_t __w0 = 0; __w0 < (((ci + 1) * 4) - (ci * 4)); ++__w0) {
        for (int64_t __w1 = 0; __w1 < 3; ++__w1) {
          xi[(__w0)*(3) + (__w1)] = (x[((__w0 + ((ci * 4) - 0)))*(3) + (__w1)] + shift_vec[(((int64_t)(((int64_t)(ci_shift[ci_entry])))))*(3) + (__w1)]);
        }
      }
      for (int64_t __w0 = 0; __w0 < (((ci + 1) * 4) - (ci * 4)); ++__w0) {
        qi[__w0] = (epsfac * q[(__w0 + ((ci * 4) - 0))]);
      }
      memset(fi, 0, (size_t)((4) * (3)) * sizeof(double));
      cjind = cjind0;
      while (((cjind < cjind1) && (((int64_t)(((int64_t)(cj_excl[cjind])))) != 65535))) {
        _inner_4x4(atom_type, coulomb_table_f, f, fi, nbfp, q, qi, x, xi, 1, ci, ((((int64_t)(((int64_t)(ci_shift[ci_entry])))) == 0) ? ci : -1), ((int64_t)(((int64_t)(cj_cluster[cjind])))), ((((int64_t)(((int64_t)(ci_flags[ci_entry])))) & 2) != 0), ((((int64_t)(((int64_t)(ci_flags[ci_entry])))) & 1) != 0), ((int64_t)(((int64_t)(cj_excl[cjind])))), half_lj, min_distance_squared, n_clusters, num_types, rcut2, tab_coul_scale, table_size);
        cjind += 1;
      }
      while ((cjind < cjind1)) {
        _inner_4x4__s2(atom_type, coulomb_table_f, f, fi, nbfp, q, qi, x, xi, 0, ci, ((((int64_t)(((int64_t)(ci_shift[ci_entry])))) == 0) ? ci : -1), ((int64_t)(((int64_t)(cj_cluster[cjind])))), ((((int64_t)(((int64_t)(ci_flags[ci_entry])))) & 2) != 0), ((((int64_t)(((int64_t)(ci_flags[ci_entry])))) & 1) != 0), 65535, half_lj, min_distance_squared, n_clusters, num_types, rcut2, tab_coul_scale, table_size);
        cjind += 1;
      }
      for (int64_t si0 = (ci * 4); si0 < ((ci + 1) * 4); ++si0) {
        for (int64_t si1 = 0; si1 < 3; ++si1) {
          f[(si0)*(3) + (si1)] += fi[((si0 - (ci * 4)))*(3) + (si1)];
        }
      }
      for (int64_t i = 0; i < 4; ++i) {
        for (int64_t si1 = 0; si1 < 3; ++si1) {
          fshift[(((int64_t)(((int64_t)(ci_shift[ci_entry])))))*(3) + (si1)] += fi[(i)*(3) + (si1)];
        }
      }
    }
}

static void _inner_4x4(const int32_t *restrict atom_type, const double *restrict coulomb_table_f, double *restrict f, double *restrict fi, const double *restrict nbfp, const double *restrict q, const double *restrict qi, const double *restrict x, const double *restrict xi, const bool check_exclusions, const int64_t ci, const double ci_sh, const int64_t cj, const bool do_coul, const bool do_lj, const int64_t excl_mask, const bool half_lj, const double min_distance_squared, const int64_t n_clusters, const int64_t num_types, const double rcut2, const double tab_coul_scale, const int64_t table_size) {
    int64_t bit_index;
    int64_t interact;
    double skipmask;
    int64_t aj;
    double dx;
    double dy;
    double dz;
    double rsq;
    double rinv;
    double rinvsq;
    double fr_lj;
    double fcoul;
    double fscal;
    double fx;
    double fy;
    double fz;
    int64_t type_j;
    double c6;
    double c12;
    double rinvsix;
    double fr_lj6;
    double fr_lj12;
    double qq;
    double rs;
    int64_t ri;
    double frac;
    double fexcl;
    for (int64_t i = 0; i < 4; ++i) {
      for (int64_t j = 0; j < 4; ++j) {
        bit_index = ((i * 4) + j);
        interact = ((excl_mask >> bit_index) & 1);
        skipmask = (((cj == ci_sh) && (j <= i)) ? 0.0 : 1.0);
        aj = ((cj * 4) + j);
        dx = (xi[(i)*(3) + (0)] - x[(aj)*(3) + (0)]);
        dy = (xi[(i)*(3) + (1)] - x[(aj)*(3) + (1)]);
        dz = (xi[(i)*(3) + (2)] - x[(aj)*(3) + (2)]);
        rsq = (((dx * dx) + (dy * dy)) + (dz * dz));
        if ((rsq >= rcut2)) {
          skipmask = 0.0;
        }
        rsq = max(rsq, min_distance_squared);
        rinv = ((1.0 / sqrt(rsq)) * skipmask);
        rinvsq = (rinv * rinv);
        fr_lj = 0.0;
        if ((do_lj && ((!half_lj) || (i < 2)))) {
          type_j = ((int64_t)(((int64_t)(atom_type[aj]))));
          c6 = nbfp[((((int64_t)(((int64_t)(atom_type[((ci * 4) + i)])))))*(num_types) + (type_j))*(2) + (0)];
          c12 = nbfp[((((int64_t)(((int64_t)(atom_type[((ci * 4) + i)])))))*(num_types) + (type_j))*(2) + (1)];
          rinvsix = (((interact * rinvsq) * rinvsq) * rinvsq);
          fr_lj6 = (c6 * rinvsix);
          fr_lj12 = ((c12 * rinvsix) * rinvsix);
          fr_lj = (fr_lj12 - fr_lj6);
        }
        fcoul = 0.0;
        if (do_coul) {
          qq = ((skipmask * qi[i]) * q[aj]);
          rs = ((rsq * rinv) * tab_coul_scale);
          ri = ((int64_t)(rs));
          ri = min(max(ri, 0), ((table_size + 1) - 2));
          frac = (rs - ri);
          fexcl = (((1.0 - frac) * coulomb_table_f[ri]) + (frac * coulomb_table_f[(ri + 1)]));
          fcoul = ((interact * rinvsq) - fexcl);
          fcoul *= (qq * rinv);
        }
        fscal = ((fr_lj * rinvsq) + fcoul);
        fx = (fscal * dx);
        fy = (fscal * dy);
        fz = (fscal * dz);
        fi[(i)*(3) + (0)] += fx;
        fi[(i)*(3) + (1)] += fy;
        fi[(i)*(3) + (2)] += fz;
        f[(aj)*(3) + (0)] -= fx;
        f[(aj)*(3) + (1)] -= fy;
        f[(aj)*(3) + (2)] -= fz;
      }
    }
}

static void _inner_4x4__s2(const int32_t *restrict atom_type, const double *restrict coulomb_table_f, double *restrict f, double *restrict fi, const double *restrict nbfp, const double *restrict q, const double *restrict qi, const double *restrict x, const double *restrict xi, const bool check_exclusions, const int64_t ci, const double ci_sh, const int64_t cj, const bool do_coul, const bool do_lj, const int64_t excl_mask, const bool half_lj, const double min_distance_squared, const int64_t n_clusters, const int64_t num_types, const double rcut2, const double tab_coul_scale, const int64_t table_size) {
    double interact;
    double skipmask;
    int64_t aj;
    double dx;
    double dy;
    double dz;
    double rsq;
    double rinv;
    double rinvsq;
    double fr_lj;
    double fcoul;
    double fscal;
    double fx;
    double fy;
    double fz;
    int64_t type_j;
    double c6;
    double c12;
    double rinvsix;
    double fr_lj6;
    double fr_lj12;
    double qq;
    double rs;
    int64_t ri;
    double frac;
    double fexcl;
    for (int64_t i = 0; i < 4; ++i) {
      for (int64_t j = 0; j < 4; ++j) {
        interact = 1.0;
        skipmask = 1.0;
        aj = ((cj * 4) + j);
        dx = (xi[(i)*(3) + (0)] - x[(aj)*(3) + (0)]);
        dy = (xi[(i)*(3) + (1)] - x[(aj)*(3) + (1)]);
        dz = (xi[(i)*(3) + (2)] - x[(aj)*(3) + (2)]);
        rsq = (((dx * dx) + (dy * dy)) + (dz * dz));
        if ((rsq >= rcut2)) {
          skipmask = 0.0;
        }
        rsq = max(rsq, min_distance_squared);
        rinv = ((1.0 / sqrt(rsq)) * skipmask);
        rinvsq = (rinv * rinv);
        fr_lj = 0.0;
        if ((do_lj && ((!half_lj) || (i < 2)))) {
          type_j = ((int64_t)(((int64_t)(atom_type[aj]))));
          c6 = nbfp[((((int64_t)(((int64_t)(atom_type[((ci * 4) + i)])))))*(num_types) + (type_j))*(2) + (0)];
          c12 = nbfp[((((int64_t)(((int64_t)(atom_type[((ci * 4) + i)])))))*(num_types) + (type_j))*(2) + (1)];
          rinvsix = (((interact * rinvsq) * rinvsq) * rinvsq);
          fr_lj6 = (c6 * rinvsix);
          fr_lj12 = ((c12 * rinvsix) * rinvsix);
          fr_lj = (fr_lj12 - fr_lj6);
        }
        fcoul = 0.0;
        if (do_coul) {
          qq = ((skipmask * qi[i]) * q[aj]);
          rs = ((rsq * rinv) * tab_coul_scale);
          ri = ((int64_t)(rs));
          ri = min(max(ri, 0), ((table_size + 1) - 2));
          frac = (rs - ri);
          fexcl = (((1.0 - frac) * coulomb_table_f[ri]) + (frac * coulomb_table_f[(ri + 1)]));
          fcoul = ((interact * rinvsq) - fexcl);
          fcoul *= (qq * rinv);
        }
        fscal = ((fr_lj * rinvsq) + fcoul);
        fx = (fscal * dx);
        fy = (fscal * dy);
        fz = (fscal * dz);
        fi[(i)*(3) + (0)] += fx;
        fi[(i)*(3) + (1)] += fy;
        fi[(i)*(3) + (2)] += fz;
        f[(aj)*(3) + (0)] -= fx;
        f[(aj)*(3) + (1)] -= fy;
        f[(aj)*(3) + (2)] -= fz;
      }
    }
}

void gromacs_nbnxm_fp64(const int32_t *restrict atom_type, const int32_t *restrict ci_cj_end, const int32_t *restrict ci_cj_start, const int32_t *restrict ci_cluster, const int32_t *restrict ci_flags, const int32_t *restrict ci_shift, const int32_t *restrict cj_cluster, const uint16_t *restrict cj_excl, const double *restrict coulomb_table_f, double *restrict f, double *restrict fshift, const double *restrict nbfp, const double *restrict q, const double *restrict shift_vec, const double *restrict x, const double epsfac, const double min_distance_squared, const int64_t n_clusters, const int64_t num_types, const double rcut, const double tab_coul_scale, const int64_t table_size, uint8_t *restrict workspace, const int64_t workspace_size) {
        _nbnxm_4x4_qstab_lj_force_arrays(atom_type, ci_cj_end, ci_cj_start, ci_cluster, ci_flags, ci_shift, cj_cluster, cj_excl, coulomb_table_f, f, fshift, nbfp, q, shift_vec, x, epsfac, min_distance_squared, n_clusters, num_types, rcut, tab_coul_scale, table_size);
}
