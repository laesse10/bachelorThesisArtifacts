#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

/* Optimized implementation of fdtd_2d kernel.
 * The algorithm follows the reference implementation but adds parallelism
 * with OpenMP and uses pointer arithmetic to improve locality.
 * All floating‑point operations remain identical to the reference, preserving
 * numerical results.
 */

void fdtd_2d_fp64(
    double *restrict ex,
    double *restrict ey,
    const double *restrict fict,
    double *restrict hz,
    const int64_t NX,
    const int64_t NY,
    const int64_t TMAX,
    const double ex_courant,
    const double ey_courant,
    const double hz_courant,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    // Stride for the 2‑D arrays stored in row‑major order.
    const int64_t ny = NY;

    // Main time loop.
    for (int64_t t = 0; t < TMAX; ++t) {
        // -----------------------------------------------------------------
        // 1. Update the first column of ey with the fictitious source.
        // -----------------------------------------------------------------
        #pragma omp simd
        for (int64_t si1 = 0; si1 < ny; ++si1) {
            ey[si1] = fict[t];
        }

        // -----------------------------------------------------------------
        // 2. Update ey for si0 >= 1.  This loop only reads from hz and writes
        //    to ey, so it is safe to parallelise over the outer dimension.
        // -----------------------------------------------------------------
        #pragma omp parallel for schedule(static)
        for (int64_t si0 = 1; si0 < NX; ++si0) {
            double *restrict ey_row = &ey[si0 * ny];
            const double *restrict hz_row = &hz[si0 * ny];
            const double *restrict hz_prev = &hz[(si0 - 1) * ny];
            #pragma omp simd
            for (int64_t si1 = 0; si1 < ny; ++si1) {
                ey_row[si1] -= ey_courant * (hz_row[si1] - hz_prev[si1]);
            }
        }

        // -----------------------------------------------------------------
        // 3. Update ex for si1 >= 1.  Again only reads from hz, safe to parallel
        //    over si0.
        // -----------------------------------------------------------------
        #pragma omp parallel for schedule(static)
        for (int64_t si0 = 0; si0 < NX; ++si0) {
            double *restrict ex_row = &ex[si0 * ny];
            const double *restrict hz_row = &hz[si0 * ny];
            #pragma omp simd
            for (int64_t si1 = 1; si1 < ny; ++si1) {
                ex_row[si1] -= ex_courant * (hz_row[si1] - hz_row[si1 - 1]);
            }
        }

        // -----------------------------------------------------------------
        // 4. Update hz for the interior points.  All reads are from ex/ey
        //    which have already been updated, and the writes are independent.
        //    Collapse the two loops to give more work per thread.
        // -----------------------------------------------------------------
        #pragma omp parallel for schedule(static) collapse(2)
        for (int64_t si0 = 0; si0 < NX - 1; ++si0) {
            for (int64_t si1 = 0; si1 < ny - 1; ++si1) {
                int64_t idx = si0 * ny + si1;
                // ex[idx+1] accesses (si0, si1+1)
                // ey[(si0+1)*ny + si1] accesses (si0+1, si1)
                hz[idx] -= hz_courant * ((ex[idx + 1] - ex[idx]) + (ey[(si0 + 1) * ny + si1] - ey[idx]));
            }
        }
    }
    // workspace is unused but part of the ABI; suppress unused warnings.
    (void)workspace;
    (void)workspace_size;
}

