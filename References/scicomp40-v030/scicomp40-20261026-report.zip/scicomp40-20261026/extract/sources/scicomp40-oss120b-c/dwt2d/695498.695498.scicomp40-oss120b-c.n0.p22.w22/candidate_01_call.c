// Optimized 2D Discrete Wavelet Transform (Haar) implementation
// Target language: C
// The reference algorithm is from dwt2d_reference.c and dwt2d_numpy.py.
// This implementation removes unnecessary temporaries, uses the provided workspace
// for intermediate buffers, and parallelizes the computation with OpenMP.
// It preserves the exact numerical results of the reference implementation.

#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <omp.h>

// Forward declaration of the internal level function with workspace support.
static void dwt2d_levels(const double *restrict image,
                         double *restrict out,
                         const int64_t N,
                         const int64_t nlevels,
                         double *restrict ws,
                         const int64_t ws_bytes);

// Entry point required by the benchmark harness.
void dwt2d_fp64(double *restrict image,
                double *restrict out,
                const int64_t N,
                const int64_t nlevels,
                const int64_t nsteps,
                uint8_t *restrict workspace,
                const int64_t workspace_size) {
    // Cast the workspace to a double pointer for convenience.
    double *ws = (double *)workspace;

    // Loop over the requested number of steps.
    for (int64_t step = 0; step < nsteps; ++step) {
        // Perform the multi‑level 2D Haar transform.
        dwt2d_levels(image, out, N, nlevels, ws, workspace_size);

        // Average the original image with the decomposition (in‑place update of image).
        const int64_t total = N * N;
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < total; ++i) {
            image[i] = 0.5 * (image[i] + out[i]);
        }
    }
}

// ---------------------------------------------------------------------------
// Helper: multi‑level 2D Haar transform.
// ---------------------------------------------------------------------------
static void dwt2d_levels(const double *restrict image,
                         double *restrict out,
                         const int64_t N,
                         const int64_t nlevels,
                         double *restrict ws,
                         const int64_t ws_bytes) {
    // Copy the input image into the output buffer (full N×N copy).
    const int64_t total = N * N;
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < total; ++i) {
        out[i] = image[i];
    }

    // Temporary buffers for the horizontal pass (low and high components).
    // We reuse the workspace for every level. If the workspace is missing or too small,
    // fall back to a malloc‑based buffer (allocated once per level).
    double *alloc_buf = NULL; // non‑NULL when we allocate ourselves.

    for (int64_t lvl = 0; lvl < nlevels; ++lvl) {
        // Current region size (s × s).
        const int64_t s = N >> lvl;          // floor(N / 2^lvl)
        if (s <= 1) break;                  // nothing to decompose further
        const int64_t h = s >> 1;            // floor(s / 2)
        if (h == 0) break;

        // Number of elements for each of L and H buffers.
        const size_t Lsize = (size_t)s * (size_t)h; // s * h doubles
        const size_t bytes_needed = 2 * Lsize * sizeof(double);

        double *L, *H;
        if (ws != NULL && (size_t)ws_bytes >= bytes_needed) {
            L = ws;                // use the beginning of the workspace
            H = ws + Lsize;        // second half directly after L
        } else {
            // Allocate a temporary buffer for this level.
            alloc_buf = (double *)malloc(bytes_needed);
            if (!alloc_buf) {
                // Allocation failure – fall back to a safe abort.
                abort();
            }
            L = alloc_buf;
            H = alloc_buf + Lsize;
        }

        // -------------------------------------------------------------------
        // Horizontal 1‑D Haar transform: compute L (average) and H (difference).
        // -------------------------------------------------------------------
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < s; ++i) {
            const double *src_row = out + i * N;      // original values for this level
            double *L_row = L + i * h;
            double *H_row = H + i * h;
            for (int64_t j = 0; j < h; ++j) {
                const double a = src_row[2 * j];
                const double b = src_row[2 * j + 1];
                const double avg = (a + b) * 0.5;
                const double diff = (a - b) * 0.5;
                L_row[j] = avg;
                H_row[j] = diff;
            }
        }

        // -------------------------------------------------------------------
        // Vertical 1‑D Haar transform: combine pairs of rows from L and H into
        // the four sub‑bands (LL, LH, HL, HH) stored directly in the output.
        // -------------------------------------------------------------------
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < h; ++i) {
            const double *L_even = L + (2 * i) * h;
            const double *L_odd  = L + (2 * i + 1) * h;
            const double *H_even = H + (2 * i) * h;
            const double *H_odd  = H + (2 * i + 1) * h;

            double *out_tl = out + i * N;           // top‑left quadrant start row i, col 0
            double *out_tr = out + i * N + h;       // top‑right quadrant
            double *out_bl = out + (i + h) * N;     // bottom‑left quadrant
            double *out_br = out + (i + h) * N + h; // bottom‑right quadrant

            for (int64_t j = 0; j < h; ++j) {
                const double L0 = L_even[j];
                const double L1 = L_odd[j];
                const double H0 = H_even[j];
                const double H1 = H_odd[j];
                out_tl[j] = (L0 + L1) * 0.5;   // LL
                out_tr[j] = (H0 + H1) * 0.5;   // LH
                out_bl[j] = (L0 - L1) * 0.5;   // HL
                out_br[j] = (H0 - H1) * 0.5;   // HH
            }
        }

        // Free temporary allocation if we used it for this level.
        if (alloc_buf) {
            free(alloc_buf);
            alloc_buf = NULL;
        }
        // No need to keep L/H for next level – they will be overwritten.
    }

    // If we allocated a buffer for the last level (unlikely) – free it.
    if (alloc_buf) {
        free(alloc_buf);
    }
}

/*
 * Note on correctness:
 * The implementation follows exactly the reference algorithm (see dwt2d_numpy.py).
 * It deliberately discards the final column/row when the size is odd, matching the
 * reference's behaviour (the extra element is never used in the Haar transform).
 * All arithmetic uses double‑precision and the factor 0.5 is applied via a single
 * multiplication, ensuring bit‑identical results to the reference.
 */

