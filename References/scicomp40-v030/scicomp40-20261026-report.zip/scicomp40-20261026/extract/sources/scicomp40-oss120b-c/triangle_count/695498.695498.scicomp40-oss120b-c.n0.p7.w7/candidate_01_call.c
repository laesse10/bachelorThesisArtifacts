// Optimized triangle count kernel with OpenMP parallelization
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

// The kernel signature is defined in signature.json. The implementation follows the reference
// algorithm, but parallelizes the outer edge loop using OpenMP reduction. The inner binary
// search uses the same two‑phase bucket approach.

void triangle_count_fp64(const int64_t *restrict colidx,
                        const int64_t *restrict esrc,
                        const int64_t *restrict rowptr,
                        int64_t *restrict total,
                        const int64_t NE,
                        const int64_t NV,
                        uint8_t *restrict workspace,
                        const int64_t workspace_size) {
    (void)NV; // unused (graph size is encoded in edges)
    (void)workspace;
    (void)workspace_size;
    int64_t count = 0;
    // Parallel reduction over edges. Each iteration reads only from read‑only arrays.
    #pragma omp parallel for reduction(+:count) schedule(dynamic, 1024)
    for (int64_t e = 0; e < NE; ++e) {
        int64_t v = esrc[e];
        int64_t u = colidx[e];
        int64_t v_begin = rowptr[v];
        int64_t v_size = rowptr[v + 1] - v_begin;
        int64_t u_begin = rowptr[u];
        int64_t u_size = rowptr[u + 1] - u_begin;
        if (v_size > 0 && u_size > 0) {
            // Choose the shorter list for lookup and the longer for search
            int64_t lookup_begin, lookup_size;
            int64_t search_begin, search_size;
            if (v_size > u_size) {
                lookup_begin = u_begin;
                lookup_size = u_size;
                search_begin = v_begin;
                search_size = v_size;
            } else {
                lookup_begin = v_begin;
                lookup_size = v_size;
                search_begin = u_begin;
                search_size = u_size;
            }
            // Iterate over each element of the smaller adjacency list
            for (int64_t i = 0; i < lookup_size; ++i) {
                int64_t key = colidx[lookup_begin + i];
                int hit = 0;
                // Two‑phase binary search: first locate bucket among 32 samples
                int64_t bottom = 0;
                int64_t top = 32; // number of buckets (warp size)
                while (top > bottom + 1 && hit == 0) {
                    int64_t mid = (top + bottom) / 2;
                    // Compute sample index: floor(mid * search_size / 32)
                    int64_t idx = (mid * search_size) / 32;
                    int64_t y = colidx[search_begin + idx];
                    if (key == y) {
                        hit = 1;
                    } else if (key < y) {
                        top = mid;
                    } else {
                        bottom = mid;
                    }
                }
                if (hit == 0) {
                    // Binary search inside the bucket [bottom, top)
                    int64_t lo = (bottom * search_size) / 32;
                    int64_t hi = ((top * search_size) / 32) - 1;
                    while (hi >= lo && hit == 0) {
                        int64_t mid = (lo + hi) / 2;
                        int64_t y = colidx[search_begin + mid];
                        if (key == y) {
                            hit = 1;
                        } else if (key < y) {
                            hi = mid - 1;
                        } else {
                            lo = mid + 1;
                        }
                    }
                }
                count += hit;
            }
        }
    }
    total[0] = count;
}
