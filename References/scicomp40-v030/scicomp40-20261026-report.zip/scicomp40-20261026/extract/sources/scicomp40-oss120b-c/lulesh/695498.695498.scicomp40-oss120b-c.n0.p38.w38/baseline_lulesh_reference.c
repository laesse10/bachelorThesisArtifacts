// hpcagent_bench-autogen -- generated from lulesh_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}
#include <cblas.h>

void lulesh_fp64(double *restrict arealg, double *restrict delv, double *restrict delv_eta, double *restrict delv_xi, double *restrict delv_zeta, double *restrict delx_eta, double *restrict delx_xi, double *restrict delx_zeta, double *restrict dxx, double *restrict dyy, double *restrict dzz, double *restrict e, const int64_t *restrict elemBC, const double *restrict elemMass, double *restrict fx, double *restrict fy, double *restrict fz, const int64_t *restrict letam, const int64_t *restrict letap, const int64_t *restrict lxim, const int64_t *restrict lxip, const int64_t *restrict lzetam, const int64_t *restrict lzetap, const double *restrict nodalMass, const int64_t *restrict nodelist, double *restrict p, double *restrict q, double *restrict ql, double *restrict qq, double *restrict ss, const int64_t *restrict symmX, const int64_t *restrict symmY, const int64_t *restrict symmZ, double *restrict v, double *restrict vdov, double *restrict vnew, const double *restrict volo, double *restrict x, double *restrict xd, double *restrict xdd, double *restrict y, double *restrict yd, double *restrict ydd, double *restrict z, double *restrict zd, double *restrict zdd, const int64_t nsteps, const int64_t numElem, const int64_t numNode, const int64_t numSymm, uint8_t *restrict workspace, const int64_t workspace_size) {
        double deltatime;
        double time;
        int64_t cycle;
        double dtcourant;
        double dthydro;
        double targetdt;
        double __inl15_dt2;
        double __cb102;
        double __inl3_cand;
        double __cb104;
        double __inl4_cand;
        double olddt;
        double gnewdt;
        double newdt;
        double ratio;
        double _GAMMA[(8) * (4)];
        memset(_GAMMA, 0, (size_t)((8) * (4)) * sizeof(double));
        int64_t _VOLU_PERM[(8) * (6)];
        memset(_VOLU_PERM, 0, (size_t)((8) * (6)) * sizeof(int64_t));
        double *__inl36_b = (double *)malloc((size_t)((numElem) * (8) * (3)) * sizeof(double));
        __npb_alloc_check(__inl36_b, (size_t)((numElem) * (8) * (3)) * sizeof(double), "__inl36_b");
        double *__inl37_pf = (double *)malloc((size_t)((numElem) * (8) * (3)) * sizeof(double));
        __npb_alloc_check(__inl37_pf, (size_t)((numElem) * (8) * (3)) * sizeof(double), "__inl37_pf");
        memset(__inl37_pf, 0, (size_t)((numElem) * (8) * (3)) * sizeof(double));
        int64_t __inl43_corners[(4)];
        int64_t __inl44_corners[(4)];
        int64_t __inl45_corners[(4)];
        int64_t __inl46_corners[(4)];
        int64_t __inl47_corners[(4)];
        int64_t __inl48_corners[(4)];
        double *__inl22_charl = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl22_charl, (size_t)((numElem)) * sizeof(double), "__inl22_charl");
        memset(__inl22_charl, 0, (size_t)((numElem)) * sizeof(double));
        double *__inl23_b = (double *)malloc((size_t)((numElem) * (8) * (3)) * sizeof(double));
        __npb_alloc_check(__inl23_b, (size_t)((numElem) * (8) * (3)) * sizeof(double), "__inl23_b");
        double *__inl24_d = (double *)malloc((size_t)((numElem) * (6)) * sizeof(double));
        __npb_alloc_check(__inl24_d, (size_t)((numElem) * (6)) * sizeof(double), "__inl24_d");
        double *__inl12_vnewc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl12_vnewc, (size_t)((numElem)) * sizeof(double), "__inl12_vnewc");
        double *__inl12_vc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl12_vc, (size_t)((numElem)) * sizeof(double), "__inl12_vc");
        double *__inl18_e_old = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_e_old, (size_t)((numElem)) * sizeof(double), "__inl18_e_old");
        double *__inl18_delvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_delvc, (size_t)((numElem)) * sizeof(double), "__inl18_delvc");
        double *__inl18_p_old = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_p_old, (size_t)((numElem)) * sizeof(double), "__inl18_p_old");
        double *__inl18_q_old = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_q_old, (size_t)((numElem)) * sizeof(double), "__inl18_q_old");
        double *__inl18_qqc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_qqc, (size_t)((numElem)) * sizeof(double), "__inl18_qqc");
        double *__inl18_qlc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_qlc, (size_t)((numElem)) * sizeof(double), "__inl18_qlc");
        double *__inl18_work = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_work, (size_t)((numElem)) * sizeof(double), "__inl18_work");
        memset(__inl18_work, 0, (size_t)((numElem)) * sizeof(double));
        double *__inl40_pbvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl40_pbvc, (size_t)((numElem)) * sizeof(double), "__inl40_pbvc");
        double *__inl41_pbvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl41_pbvc, (size_t)((numElem)) * sizeof(double), "__inl41_pbvc");
        double *__inl42_pbvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl42_pbvc, (size_t)((numElem)) * sizeof(double), "__inl42_pbvc");
        double *__mm1 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__mm1, (size_t)((numElem) * (4)) * sizeof(double), "__mm1");
        double *__mm2 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__mm2, (size_t)((numElem) * (4)) * sizeof(double), "__mm2");
        double *__mm3 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__mm3, (size_t)((numElem) * (4)) * sizeof(double), "__mm3");
        double *__cb4 = (double *)malloc((size_t)((numElem) * (4) * (8)) * sizeof(double));
        __npb_alloc_check(__cb4, (size_t)((numElem) * (4) * (8)) * sizeof(double), "__cb4");
        double *__cb5 = (double *)malloc((size_t)((numElem) * (4) * (8)) * sizeof(double));
        __npb_alloc_check(__cb5, (size_t)((numElem) * (4) * (8)) * sizeof(double), "__cb5");
        double *__cb6 = (double *)malloc((size_t)((numElem) * (4) * (8)) * sizeof(double));
        __npb_alloc_check(__cb6, (size_t)((numElem) * (4) * (8)) * sizeof(double), "__cb6");
        double __cb7[(4) * (8)];
        double *__cb8 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__cb8, (size_t)((numElem) * (4)) * sizeof(double), "__cb8");
        double *__cb9 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__cb9, (size_t)((numElem) * (8)) * sizeof(double), "__cb9");
        double *__cb10 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__cb10, (size_t)((numElem) * (4)) * sizeof(double), "__cb10");
        double *__cb11 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__cb11, (size_t)((numElem) * (8)) * sizeof(double), "__cb11");
        double *__cb12 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__cb12, (size_t)((numElem) * (4)) * sizeof(double), "__cb12");
        double *__cb13 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__cb13, (size_t)((numElem) * (8)) * sizeof(double), "__cb13");
        double *__cb14 = (double *)malloc((size_t)((numNode)) * sizeof(double));
        __npb_alloc_check(__cb14, (size_t)((numNode)) * sizeof(double), "__cb14");
        double *__cb15 = (double *)malloc((size_t)((numNode)) * sizeof(double));
        __npb_alloc_check(__cb15, (size_t)((numNode)) * sizeof(double), "__cb15");
        double *__cb16 = (double *)malloc((size_t)((numNode)) * sizeof(double));
        __npb_alloc_check(__cb16, (size_t)((numNode)) * sizeof(double), "__cb16");
        double *__cb17 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__cb17, (size_t)((numElem) * (8)) * sizeof(double), "__cb17");
        double *__cb18 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__cb18, (size_t)((numElem) * (8)) * sizeof(double), "__cb18");
        double *__cb19 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__cb19, (size_t)((numElem) * (8)) * sizeof(double), "__cb19");
        double *__cb20 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__cb20, (size_t)((numElem) * (8)) * sizeof(double), "__cb20");
        double *__cb21 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__cb21, (size_t)((numElem) * (8)) * sizeof(double), "__cb21");
        double *__cb22 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__cb22, (size_t)((numElem) * (8)) * sizeof(double), "__cb22");
        double *__cb23 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb23, (size_t)((numElem)) * sizeof(double), "__cb23");
        double *__cb24 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb24, (size_t)((numElem)) * sizeof(double), "__cb24");
        double *__cb25 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb25, (size_t)((numElem)) * sizeof(double), "__cb25");
        double *__cb26 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb26, (size_t)((numElem)) * sizeof(double), "__cb26");
        double *__cb27 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb27, (size_t)((numElem)) * sizeof(double), "__cb27");
        double *__cb28 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb28, (size_t)((numElem)) * sizeof(double), "__cb28");
        int64_t *__cb29 = (int64_t *)malloc((size_t)((numElem)) * sizeof(int64_t));
        __npb_alloc_check(__cb29, (size_t)((numElem)) * sizeof(int64_t), "__cb29");
        double *__cb30 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb30, (size_t)((numElem)) * sizeof(double), "__cb30");
        double *__cb31 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb31, (size_t)((numElem)) * sizeof(double), "__cb31");
        double *__cb32 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb32, (size_t)((numElem)) * sizeof(double), "__cb32");
        double *__cb33 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb33, (size_t)((numElem)) * sizeof(double), "__cb33");
        double *__cb34 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb34, (size_t)((numElem)) * sizeof(double), "__cb34");
        double *__cb35 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb35, (size_t)((numElem)) * sizeof(double), "__cb35");
        double *__cb36 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb36, (size_t)((numElem)) * sizeof(double), "__cb36");
        double *__cb37 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb37, (size_t)((numElem)) * sizeof(double), "__cb37");
        double *__cb38 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb38, (size_t)((numElem)) * sizeof(double), "__cb38");
        double *__cb39 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb39, (size_t)((numElem)) * sizeof(double), "__cb39");
        double *__cb40 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb40, (size_t)((numElem)) * sizeof(double), "__cb40");
        double *__cb41 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb41, (size_t)((numElem)) * sizeof(double), "__cb41");
        double *__cb42 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb42, (size_t)((numElem)) * sizeof(double), "__cb42");
        double *__cb43 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb43, (size_t)((numElem)) * sizeof(double), "__cb43");
        double *__cb44 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb44, (size_t)((numElem)) * sizeof(double), "__cb44");
        double *__cb45 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb45, (size_t)((numElem)) * sizeof(double), "__cb45");
        double *__cb46 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb46, (size_t)((numElem)) * sizeof(double), "__cb46");
        double *__cb47 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb47, (size_t)((numElem)) * sizeof(double), "__cb47");
        double *__cb48 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb48, (size_t)((numElem)) * sizeof(double), "__cb48");
        double *__cb49 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb49, (size_t)((numElem)) * sizeof(double), "__cb49");
        double *__cb50 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb50, (size_t)((numElem)) * sizeof(double), "__cb50");
        double *__cb51 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb51, (size_t)((numElem)) * sizeof(double), "__cb51");
        double *__cb52 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb52, (size_t)((numElem)) * sizeof(double), "__cb52");
        double *__cb53 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb53, (size_t)((numElem)) * sizeof(double), "__cb53");
        double *__cb54 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb54, (size_t)((numElem)) * sizeof(double), "__cb54");
        double *__cb55 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb55, (size_t)((numElem)) * sizeof(double), "__cb55");
        double *__cb56 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb56, (size_t)((numElem)) * sizeof(double), "__cb56");
        double *__cb57 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb57, (size_t)((numElem)) * sizeof(double), "__cb57");
        double *__cb58 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb58, (size_t)((numElem)) * sizeof(double), "__cb58");
        double *__cb59 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb59, (size_t)((numElem)) * sizeof(double), "__cb59");
        double *__cb60 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb60, (size_t)((numElem)) * sizeof(double), "__cb60");
        double *__cb61 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb61, (size_t)((numElem)) * sizeof(double), "__cb61");
        double *__cb62 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb62, (size_t)((numElem)) * sizeof(double), "__cb62");
        double *__cb63 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb63, (size_t)((numElem)) * sizeof(double), "__cb63");
        double *__cb64 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb64, (size_t)((numElem)) * sizeof(double), "__cb64");
        double *__cb65 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb65, (size_t)((numElem)) * sizeof(double), "__cb65");
        double *__cb66 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb66, (size_t)((numElem)) * sizeof(double), "__cb66");
        double *__cb67 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb67, (size_t)((numElem)) * sizeof(double), "__cb67");
        double *__cb68 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb68, (size_t)((numElem)) * sizeof(double), "__cb68");
        double *__cb69 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb69, (size_t)((numElem)) * sizeof(double), "__cb69");
        double *__cb70 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb70, (size_t)((numElem)) * sizeof(double), "__cb70");
        double *__cb71 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb71, (size_t)((numElem)) * sizeof(double), "__cb71");
        double *__cb72 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb72, (size_t)((numElem)) * sizeof(double), "__cb72");
        double *__cb73 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb73, (size_t)((numElem)) * sizeof(double), "__cb73");
        double *__cb74 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb74, (size_t)((numElem)) * sizeof(double), "__cb74");
        double *__cb75 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb75, (size_t)((numElem)) * sizeof(double), "__cb75");
        double *__cb76 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb76, (size_t)((numElem)) * sizeof(double), "__cb76");
        double *__cb77 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb77, (size_t)((numElem)) * sizeof(double), "__cb77");
        double *__cb78 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb78, (size_t)((numElem)) * sizeof(double), "__cb78");
        double *__cb79 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb79, (size_t)((numElem)) * sizeof(double), "__cb79");
        double *__cb80 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb80, (size_t)((numElem)) * sizeof(double), "__cb80");
        double *__cb81 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb81, (size_t)((numElem)) * sizeof(double), "__cb81");
        double *__cb82 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb82, (size_t)((numElem)) * sizeof(double), "__cb82");
        double *__cb83 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb83, (size_t)((numElem)) * sizeof(double), "__cb83");
        double *__cb84 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb84, (size_t)((numElem)) * sizeof(double), "__cb84");
        double *__cb85 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb85, (size_t)((numElem)) * sizeof(double), "__cb85");
        double *__cb86 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb86, (size_t)((numElem)) * sizeof(double), "__cb86");
        double *__cb87 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb87, (size_t)((numElem)) * sizeof(double), "__cb87");
        double *__cb88 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb88, (size_t)((numElem)) * sizeof(double), "__cb88");
        double *__cb89 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb89, (size_t)((numElem)) * sizeof(double), "__cb89");
        double *__cb90 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb90, (size_t)((numElem)) * sizeof(double), "__cb90");
        double *__cb91 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb91, (size_t)((numElem)) * sizeof(double), "__cb91");
        double *__cb92 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb92, (size_t)((numElem)) * sizeof(double), "__cb92");
        double *__cb93 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb93, (size_t)((numElem)) * sizeof(double), "__cb93");
        double *__cb94 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb94, (size_t)((numElem)) * sizeof(double), "__cb94");
        double *__cb95 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb95, (size_t)((numElem)) * sizeof(double), "__cb95");
        double *__cb96 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb96, (size_t)((numElem)) * sizeof(double), "__cb96");
        double *__cb97 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb97, (size_t)((numElem)) * sizeof(double), "__cb97");
        double *__cb98 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb98, (size_t)((numElem)) * sizeof(double), "__cb98");
        double *__cb99 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb99, (size_t)((numElem)) * sizeof(double), "__cb99");
        double *__cb100 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb100, (size_t)((numElem)) * sizeof(double), "__cb100");
        double *__cb101 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb101, (size_t)((numElem)) * sizeof(double), "__cb101");
        double *__cb103 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__cb103, (size_t)((numElem)) * sizeof(double), "__cb103");
        double *__inl14_sig = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl14_sig, (size_t)((numElem)) * sizeof(double), "__inl14_sig");
        double *__inl36_fjxxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_fjxxi, (size_t)((numElem)) * sizeof(double), "__inl36_fjxxi");
        double *__inl36_fjxet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_fjxet, (size_t)((numElem)) * sizeof(double), "__inl36_fjxet");
        double *__inl36_fjxze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_fjxze, (size_t)((numElem)) * sizeof(double), "__inl36_fjxze");
        double *__inl36_fjyxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_fjyxi, (size_t)((numElem)) * sizeof(double), "__inl36_fjyxi");
        double *__inl36_fjyet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_fjyet, (size_t)((numElem)) * sizeof(double), "__inl36_fjyet");
        double *__inl36_fjyze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_fjyze, (size_t)((numElem)) * sizeof(double), "__inl36_fjyze");
        double *__inl36_fjzxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_fjzxi, (size_t)((numElem)) * sizeof(double), "__inl36_fjzxi");
        double *__inl36_fjzet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_fjzet, (size_t)((numElem)) * sizeof(double), "__inl36_fjzet");
        double *__inl36_fjzze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_fjzze, (size_t)((numElem)) * sizeof(double), "__inl36_fjzze");
        double *__inl36_cjxxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_cjxxi, (size_t)((numElem)) * sizeof(double), "__inl36_cjxxi");
        double *__inl36_cjxet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_cjxet, (size_t)((numElem)) * sizeof(double), "__inl36_cjxet");
        double *__inl36_cjxze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_cjxze, (size_t)((numElem)) * sizeof(double), "__inl36_cjxze");
        double *__inl36_cjyxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_cjyxi, (size_t)((numElem)) * sizeof(double), "__inl36_cjyxi");
        double *__inl36_cjyet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_cjyet, (size_t)((numElem)) * sizeof(double), "__inl36_cjyet");
        double *__inl36_cjyze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_cjyze, (size_t)((numElem)) * sizeof(double), "__inl36_cjyze");
        double *__inl36_cjzxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_cjzxi, (size_t)((numElem)) * sizeof(double), "__inl36_cjzxi");
        double *__inl36_cjzet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_cjzet, (size_t)((numElem)) * sizeof(double), "__inl36_cjzet");
        double *__inl36_cjzze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_cjzze, (size_t)((numElem)) * sizeof(double), "__inl36_cjzze");
        double *__inl36_volume = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl36_volume, (size_t)((numElem)) * sizeof(double), "__inl36_volume");
        double *__inl19__ = (double *)malloc((size_t)((numElem) * (8) * (3)) * sizeof(double));
        __npb_alloc_check(__inl19__, (size_t)((numElem) * (8) * (3)) * sizeof(double), "__inl19__");
        double *__inl19_determ = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl19_determ, (size_t)((numElem)) * sizeof(double), "__inl19_determ");
        double *__inl43_bX0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl43_bX0, (size_t)((numElem)) * sizeof(double), "__inl43_bX0");
        double *__inl43_bY0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl43_bY0, (size_t)((numElem)) * sizeof(double), "__inl43_bY0");
        double *__inl43_bZ0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl43_bZ0, (size_t)((numElem)) * sizeof(double), "__inl43_bZ0");
        double *__inl43_bX1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl43_bX1, (size_t)((numElem)) * sizeof(double), "__inl43_bX1");
        double *__inl43_bY1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl43_bY1, (size_t)((numElem)) * sizeof(double), "__inl43_bY1");
        double *__inl43_bZ1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl43_bZ1, (size_t)((numElem)) * sizeof(double), "__inl43_bZ1");
        double *__inl43_areaX = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl43_areaX, (size_t)((numElem)) * sizeof(double), "__inl43_areaX");
        double *__inl43_areaY = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl43_areaY, (size_t)((numElem)) * sizeof(double), "__inl43_areaY");
        double *__inl43_areaZ = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl43_areaZ, (size_t)((numElem)) * sizeof(double), "__inl43_areaZ");
        double *__scg0 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg0, (size_t)((numElem) * (4)) * sizeof(double), "__scg0");
        double *__scg1 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg1, (size_t)((numElem) * (4)) * sizeof(double), "__scg1");
        double *__scg2 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg2, (size_t)((numElem) * (4)) * sizeof(double), "__scg2");
        double *__inl44_bX0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl44_bX0, (size_t)((numElem)) * sizeof(double), "__inl44_bX0");
        double *__inl44_bY0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl44_bY0, (size_t)((numElem)) * sizeof(double), "__inl44_bY0");
        double *__inl44_bZ0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl44_bZ0, (size_t)((numElem)) * sizeof(double), "__inl44_bZ0");
        double *__inl44_bX1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl44_bX1, (size_t)((numElem)) * sizeof(double), "__inl44_bX1");
        double *__inl44_bY1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl44_bY1, (size_t)((numElem)) * sizeof(double), "__inl44_bY1");
        double *__inl44_bZ1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl44_bZ1, (size_t)((numElem)) * sizeof(double), "__inl44_bZ1");
        double *__inl44_areaX = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl44_areaX, (size_t)((numElem)) * sizeof(double), "__inl44_areaX");
        double *__inl44_areaY = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl44_areaY, (size_t)((numElem)) * sizeof(double), "__inl44_areaY");
        double *__inl44_areaZ = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl44_areaZ, (size_t)((numElem)) * sizeof(double), "__inl44_areaZ");
        double *__scg3 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg3, (size_t)((numElem) * (4)) * sizeof(double), "__scg3");
        double *__scg4 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg4, (size_t)((numElem) * (4)) * sizeof(double), "__scg4");
        double *__scg5 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg5, (size_t)((numElem) * (4)) * sizeof(double), "__scg5");
        double *__inl45_bX0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl45_bX0, (size_t)((numElem)) * sizeof(double), "__inl45_bX0");
        double *__inl45_bY0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl45_bY0, (size_t)((numElem)) * sizeof(double), "__inl45_bY0");
        double *__inl45_bZ0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl45_bZ0, (size_t)((numElem)) * sizeof(double), "__inl45_bZ0");
        double *__inl45_bX1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl45_bX1, (size_t)((numElem)) * sizeof(double), "__inl45_bX1");
        double *__inl45_bY1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl45_bY1, (size_t)((numElem)) * sizeof(double), "__inl45_bY1");
        double *__inl45_bZ1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl45_bZ1, (size_t)((numElem)) * sizeof(double), "__inl45_bZ1");
        double *__inl45_areaX = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl45_areaX, (size_t)((numElem)) * sizeof(double), "__inl45_areaX");
        double *__inl45_areaY = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl45_areaY, (size_t)((numElem)) * sizeof(double), "__inl45_areaY");
        double *__inl45_areaZ = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl45_areaZ, (size_t)((numElem)) * sizeof(double), "__inl45_areaZ");
        double *__scg6 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg6, (size_t)((numElem) * (4)) * sizeof(double), "__scg6");
        double *__scg7 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg7, (size_t)((numElem) * (4)) * sizeof(double), "__scg7");
        double *__scg8 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg8, (size_t)((numElem) * (4)) * sizeof(double), "__scg8");
        double *__inl46_bX0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl46_bX0, (size_t)((numElem)) * sizeof(double), "__inl46_bX0");
        double *__inl46_bY0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl46_bY0, (size_t)((numElem)) * sizeof(double), "__inl46_bY0");
        double *__inl46_bZ0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl46_bZ0, (size_t)((numElem)) * sizeof(double), "__inl46_bZ0");
        double *__inl46_bX1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl46_bX1, (size_t)((numElem)) * sizeof(double), "__inl46_bX1");
        double *__inl46_bY1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl46_bY1, (size_t)((numElem)) * sizeof(double), "__inl46_bY1");
        double *__inl46_bZ1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl46_bZ1, (size_t)((numElem)) * sizeof(double), "__inl46_bZ1");
        double *__inl46_areaX = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl46_areaX, (size_t)((numElem)) * sizeof(double), "__inl46_areaX");
        double *__inl46_areaY = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl46_areaY, (size_t)((numElem)) * sizeof(double), "__inl46_areaY");
        double *__inl46_areaZ = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl46_areaZ, (size_t)((numElem)) * sizeof(double), "__inl46_areaZ");
        double *__scg9 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg9, (size_t)((numElem) * (4)) * sizeof(double), "__scg9");
        double *__scg10 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg10, (size_t)((numElem) * (4)) * sizeof(double), "__scg10");
        double *__scg11 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg11, (size_t)((numElem) * (4)) * sizeof(double), "__scg11");
        double *__inl47_bX0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl47_bX0, (size_t)((numElem)) * sizeof(double), "__inl47_bX0");
        double *__inl47_bY0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl47_bY0, (size_t)((numElem)) * sizeof(double), "__inl47_bY0");
        double *__inl47_bZ0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl47_bZ0, (size_t)((numElem)) * sizeof(double), "__inl47_bZ0");
        double *__inl47_bX1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl47_bX1, (size_t)((numElem)) * sizeof(double), "__inl47_bX1");
        double *__inl47_bY1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl47_bY1, (size_t)((numElem)) * sizeof(double), "__inl47_bY1");
        double *__inl47_bZ1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl47_bZ1, (size_t)((numElem)) * sizeof(double), "__inl47_bZ1");
        double *__inl47_areaX = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl47_areaX, (size_t)((numElem)) * sizeof(double), "__inl47_areaX");
        double *__inl47_areaY = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl47_areaY, (size_t)((numElem)) * sizeof(double), "__inl47_areaY");
        double *__inl47_areaZ = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl47_areaZ, (size_t)((numElem)) * sizeof(double), "__inl47_areaZ");
        double *__scg12 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg12, (size_t)((numElem) * (4)) * sizeof(double), "__scg12");
        double *__scg13 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg13, (size_t)((numElem) * (4)) * sizeof(double), "__scg13");
        double *__scg14 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg14, (size_t)((numElem) * (4)) * sizeof(double), "__scg14");
        double *__inl48_bX0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl48_bX0, (size_t)((numElem)) * sizeof(double), "__inl48_bX0");
        double *__inl48_bY0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl48_bY0, (size_t)((numElem)) * sizeof(double), "__inl48_bY0");
        double *__inl48_bZ0 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl48_bZ0, (size_t)((numElem)) * sizeof(double), "__inl48_bZ0");
        double *__inl48_bX1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl48_bX1, (size_t)((numElem)) * sizeof(double), "__inl48_bX1");
        double *__inl48_bY1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl48_bY1, (size_t)((numElem)) * sizeof(double), "__inl48_bY1");
        double *__inl48_bZ1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl48_bZ1, (size_t)((numElem)) * sizeof(double), "__inl48_bZ1");
        double *__inl48_areaX = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl48_areaX, (size_t)((numElem)) * sizeof(double), "__inl48_areaX");
        double *__inl48_areaY = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl48_areaY, (size_t)((numElem)) * sizeof(double), "__inl48_areaY");
        double *__inl48_areaZ = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl48_areaZ, (size_t)((numElem)) * sizeof(double), "__inl48_areaZ");
        double *__scg15 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg15, (size_t)((numElem) * (4)) * sizeof(double), "__scg15");
        double *__scg16 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg16, (size_t)((numElem) * (4)) * sizeof(double), "__scg16");
        double *__scg17 = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__scg17, (size_t)((numElem) * (4)) * sizeof(double), "__scg17");
        double *__inl19_b = (double *)malloc((size_t)((numElem) * (8) * (3)) * sizeof(double));
        __npb_alloc_check(__inl19_b, (size_t)((numElem) * (8) * (3)) * sizeof(double), "__inl19_b");
        double *__inl19_sfx = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl19_sfx, (size_t)((numElem) * (8)) * sizeof(double), "__inl19_sfx");
        double *__inl19_sfy = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl19_sfy, (size_t)((numElem) * (8)) * sizeof(double), "__inl19_sfy");
        double *__inl19_sfz = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl19_sfz, (size_t)((numElem) * (8)) * sizeof(double), "__inl19_sfz");
        double *__inl14_determ = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl14_determ, (size_t)((numElem)) * sizeof(double), "__inl14_determ");
        double *__inl49_dvdx = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl49_dvdx, (size_t)((numElem) * (8)) * sizeof(double), "__inl49_dvdx");
        double *__inl49_dvdy = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl49_dvdy, (size_t)((numElem) * (8)) * sizeof(double), "__inl49_dvdy");
        double *__inl49_dvdz = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl49_dvdz, (size_t)((numElem) * (8)) * sizeof(double), "__inl49_dvdz");
        double *__inl20_dvdx = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl20_dvdx, (size_t)((numElem) * (8)) * sizeof(double), "__inl20_dvdx");
        double *__inl20_dvdy = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl20_dvdy, (size_t)((numElem) * (8)) * sizeof(double), "__inl20_dvdy");
        double *__inl20_dvdz = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl20_dvdz, (size_t)((numElem) * (8)) * sizeof(double), "__inl20_dvdz");
        double *__inl39_volinv = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl39_volinv, (size_t)((numElem)) * sizeof(double), "__inl39_volinv");
        double __inl39_gamma[(8) * (4)];
        double *__inl39_hourmodx = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__inl39_hourmodx, (size_t)((numElem) * (4)) * sizeof(double), "__inl39_hourmodx");
        double *__inl39_hourmody = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__inl39_hourmody, (size_t)((numElem) * (4)) * sizeof(double), "__inl39_hourmody");
        double *__inl39_hourmodz = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__inl39_hourmodz, (size_t)((numElem) * (4)) * sizeof(double), "__inl39_hourmodz");
        double *__inl39_term = (double *)malloc((size_t)((numElem) * (4) * (8)) * sizeof(double));
        __npb_alloc_check(__inl39_term, (size_t)((numElem) * (4) * (8)) * sizeof(double), "__inl39_term");
        double *__inl39_hourgam = (double *)malloc((size_t)((numElem) * (4) * (8)) * sizeof(double));
        __npb_alloc_check(__inl39_hourgam, (size_t)((numElem) * (4) * (8)) * sizeof(double), "__inl39_hourgam");
        double *__inl39_coefficient = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl39_coefficient, (size_t)((numElem)) * sizeof(double), "__inl39_coefficient");
        double *__inl39___inl1_hxx = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__inl39___inl1_hxx, (size_t)((numElem) * (4)) * sizeof(double), "__inl39___inl1_hxx");
        double *__inl39_hgfx = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl39_hgfx, (size_t)((numElem) * (8)) * sizeof(double), "__inl39_hgfx");
        double *__inl39___inl2_hxx = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__inl39___inl2_hxx, (size_t)((numElem) * (4)) * sizeof(double), "__inl39___inl2_hxx");
        double *__inl39_hgfy = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl39_hgfy, (size_t)((numElem) * (8)) * sizeof(double), "__inl39_hgfy");
        double *__inl39___inl3_hxx = (double *)malloc((size_t)((numElem) * (4)) * sizeof(double));
        __npb_alloc_check(__inl39___inl3_hxx, (size_t)((numElem) * (4)) * sizeof(double), "__inl39___inl3_hxx");
        double *__inl39_hgfz = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl39_hgfz, (size_t)((numElem) * (8)) * sizeof(double), "__inl39_hgfz");
        double *__inl8_txd = (double *)malloc((size_t)((numNode)) * sizeof(double));
        __npb_alloc_check(__inl8_txd, (size_t)((numNode)) * sizeof(double), "__inl8_txd");
        double *__inl8_tyd = (double *)malloc((size_t)((numNode)) * sizeof(double));
        __npb_alloc_check(__inl8_tyd, (size_t)((numNode)) * sizeof(double), "__inl8_tyd");
        double *__inl8_tzd = (double *)malloc((size_t)((numNode)) * sizeof(double));
        __npb_alloc_check(__inl8_tzd, (size_t)((numNode)) * sizeof(double), "__inl8_tzd");
        double *__inl15_xl1 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl15_xl1, (size_t)((numElem) * (8)) * sizeof(double), "__inl15_xl1");
        double *__inl15_yl1 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl15_yl1, (size_t)((numElem) * (8)) * sizeof(double), "__inl15_yl1");
        double *__inl15_zl1 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl15_zl1, (size_t)((numElem) * (8)) * sizeof(double), "__inl15_zl1");
        double *__inl21_dx61 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx61, (size_t)((numElem)) * sizeof(double), "__inl21_dx61");
        double *__inl21_dy61 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy61, (size_t)((numElem)) * sizeof(double), "__inl21_dy61");
        double *__inl21_dz61 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz61, (size_t)((numElem)) * sizeof(double), "__inl21_dz61");
        double *__inl21_dx70 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx70, (size_t)((numElem)) * sizeof(double), "__inl21_dx70");
        double *__inl21_dy70 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy70, (size_t)((numElem)) * sizeof(double), "__inl21_dy70");
        double *__inl21_dz70 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz70, (size_t)((numElem)) * sizeof(double), "__inl21_dz70");
        double *__inl21_dx63 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx63, (size_t)((numElem)) * sizeof(double), "__inl21_dx63");
        double *__inl21_dy63 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy63, (size_t)((numElem)) * sizeof(double), "__inl21_dy63");
        double *__inl21_dz63 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz63, (size_t)((numElem)) * sizeof(double), "__inl21_dz63");
        double *__inl21_dx20 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx20, (size_t)((numElem)) * sizeof(double), "__inl21_dx20");
        double *__inl21_dy20 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy20, (size_t)((numElem)) * sizeof(double), "__inl21_dy20");
        double *__inl21_dz20 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz20, (size_t)((numElem)) * sizeof(double), "__inl21_dz20");
        double *__inl21_dx50 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx50, (size_t)((numElem)) * sizeof(double), "__inl21_dx50");
        double *__inl21_dy50 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy50, (size_t)((numElem)) * sizeof(double), "__inl21_dy50");
        double *__inl21_dz50 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz50, (size_t)((numElem)) * sizeof(double), "__inl21_dz50");
        double *__inl21_dx64 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx64, (size_t)((numElem)) * sizeof(double), "__inl21_dx64");
        double *__inl21_dy64 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy64, (size_t)((numElem)) * sizeof(double), "__inl21_dy64");
        double *__inl21_dz64 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz64, (size_t)((numElem)) * sizeof(double), "__inl21_dz64");
        double *__inl21_dx31 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx31, (size_t)((numElem)) * sizeof(double), "__inl21_dx31");
        double *__inl21_dy31 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy31, (size_t)((numElem)) * sizeof(double), "__inl21_dy31");
        double *__inl21_dz31 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz31, (size_t)((numElem)) * sizeof(double), "__inl21_dz31");
        double *__inl21_dx72 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx72, (size_t)((numElem)) * sizeof(double), "__inl21_dx72");
        double *__inl21_dy72 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy72, (size_t)((numElem)) * sizeof(double), "__inl21_dy72");
        double *__inl21_dz72 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz72, (size_t)((numElem)) * sizeof(double), "__inl21_dz72");
        double *__inl21_dx43 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx43, (size_t)((numElem)) * sizeof(double), "__inl21_dx43");
        double *__inl21_dy43 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy43, (size_t)((numElem)) * sizeof(double), "__inl21_dy43");
        double *__inl21_dz43 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz43, (size_t)((numElem)) * sizeof(double), "__inl21_dz43");
        double *__inl21_dx57 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx57, (size_t)((numElem)) * sizeof(double), "__inl21_dx57");
        double *__inl21_dy57 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy57, (size_t)((numElem)) * sizeof(double), "__inl21_dy57");
        double *__inl21_dz57 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz57, (size_t)((numElem)) * sizeof(double), "__inl21_dz57");
        double *__inl21_dx14 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx14, (size_t)((numElem)) * sizeof(double), "__inl21_dx14");
        double *__inl21_dy14 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy14, (size_t)((numElem)) * sizeof(double), "__inl21_dy14");
        double *__inl21_dz14 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz14, (size_t)((numElem)) * sizeof(double), "__inl21_dz14");
        double *__inl21_dx25 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dx25, (size_t)((numElem)) * sizeof(double), "__inl21_dx25");
        double *__inl21_dy25 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dy25, (size_t)((numElem)) * sizeof(double), "__inl21_dy25");
        double *__inl21_dz25 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_dz25, (size_t)((numElem)) * sizeof(double), "__inl21_dz25");
        double *__inl21_vol = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl21_vol, (size_t)((numElem)) * sizeof(double), "__inl21_vol");
        double *__inl15_volume = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl15_volume, (size_t)((numElem)) * sizeof(double), "__inl15_volume");
        double *__inl15_relvol = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl15_relvol, (size_t)((numElem)) * sizeof(double), "__inl15_relvol");
        double *__inl22___inl1_fx = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl22___inl1_fx, (size_t)((numElem)) * sizeof(double), "__inl22___inl1_fx");
        double *__inl22___inl1_fy = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl22___inl1_fy, (size_t)((numElem)) * sizeof(double), "__inl22___inl1_fy");
        double *__inl22___inl1_fz = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl22___inl1_fz, (size_t)((numElem)) * sizeof(double), "__inl22___inl1_fz");
        double *__inl22___inl1_gx = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl22___inl1_gx, (size_t)((numElem)) * sizeof(double), "__inl22___inl1_gx");
        double *__inl22___inl1_gy = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl22___inl1_gy, (size_t)((numElem)) * sizeof(double), "__inl22___inl1_gy");
        double *__inl22___inl1_gz = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl22___inl1_gz, (size_t)((numElem)) * sizeof(double), "__inl22___inl1_gz");
        double *__inl22_ar = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl22_ar, (size_t)((numElem)) * sizeof(double), "__inl22_ar");
        double *__inl15_xl2 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl15_xl2, (size_t)((numElem) * (8)) * sizeof(double), "__inl15_xl2");
        double *__inl15_yl2 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl15_yl2, (size_t)((numElem) * (8)) * sizeof(double), "__inl15_yl2");
        double *__inl15_zl2 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl15_zl2, (size_t)((numElem) * (8)) * sizeof(double), "__inl15_zl2");
        double *__inl23_fjxxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_fjxxi, (size_t)((numElem)) * sizeof(double), "__inl23_fjxxi");
        double *__inl23_fjxet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_fjxet, (size_t)((numElem)) * sizeof(double), "__inl23_fjxet");
        double *__inl23_fjxze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_fjxze, (size_t)((numElem)) * sizeof(double), "__inl23_fjxze");
        double *__inl23_fjyxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_fjyxi, (size_t)((numElem)) * sizeof(double), "__inl23_fjyxi");
        double *__inl23_fjyet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_fjyet, (size_t)((numElem)) * sizeof(double), "__inl23_fjyet");
        double *__inl23_fjyze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_fjyze, (size_t)((numElem)) * sizeof(double), "__inl23_fjyze");
        double *__inl23_fjzxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_fjzxi, (size_t)((numElem)) * sizeof(double), "__inl23_fjzxi");
        double *__inl23_fjzet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_fjzet, (size_t)((numElem)) * sizeof(double), "__inl23_fjzet");
        double *__inl23_fjzze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_fjzze, (size_t)((numElem)) * sizeof(double), "__inl23_fjzze");
        double *__inl23_cjxxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_cjxxi, (size_t)((numElem)) * sizeof(double), "__inl23_cjxxi");
        double *__inl23_cjxet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_cjxet, (size_t)((numElem)) * sizeof(double), "__inl23_cjxet");
        double *__inl23_cjxze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_cjxze, (size_t)((numElem)) * sizeof(double), "__inl23_cjxze");
        double *__inl23_cjyxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_cjyxi, (size_t)((numElem)) * sizeof(double), "__inl23_cjyxi");
        double *__inl23_cjyet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_cjyet, (size_t)((numElem)) * sizeof(double), "__inl23_cjyet");
        double *__inl23_cjyze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_cjyze, (size_t)((numElem)) * sizeof(double), "__inl23_cjyze");
        double *__inl23_cjzxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_cjzxi, (size_t)((numElem)) * sizeof(double), "__inl23_cjzxi");
        double *__inl23_cjzet = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_cjzet, (size_t)((numElem)) * sizeof(double), "__inl23_cjzet");
        double *__inl23_cjzze = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_cjzze, (size_t)((numElem)) * sizeof(double), "__inl23_cjzze");
        double *__inl23_volume = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl23_volume, (size_t)((numElem)) * sizeof(double), "__inl23_volume");
        double *__inl15_b = (double *)malloc((size_t)((numElem) * (8) * (3)) * sizeof(double));
        __npb_alloc_check(__inl15_b, (size_t)((numElem) * (8) * (3)) * sizeof(double), "__inl15_b");
        double *__inl15_detJ = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl15_detJ, (size_t)((numElem)) * sizeof(double), "__inl15_detJ");
        double *__inl24_inv = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl24_inv, (size_t)((numElem)) * sizeof(double), "__inl24_inv");
        double *__inl24_dyddx = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl24_dyddx, (size_t)((numElem)) * sizeof(double), "__inl24_dyddx");
        double *__inl24_dxddy = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl24_dxddy, (size_t)((numElem)) * sizeof(double), "__inl24_dxddy");
        double *__inl24_dzddx = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl24_dzddx, (size_t)((numElem)) * sizeof(double), "__inl24_dzddx");
        double *__inl24_dxddz = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl24_dxddz, (size_t)((numElem)) * sizeof(double), "__inl24_dxddz");
        double *__inl24_dzddy = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl24_dzddy, (size_t)((numElem)) * sizeof(double), "__inl24_dzddy");
        double *__inl24_dyddz = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl24_dyddz, (size_t)((numElem)) * sizeof(double), "__inl24_dyddz");
        double *__inl15_d = (double *)malloc((size_t)((numElem) * (6)) * sizeof(double));
        __npb_alloc_check(__inl15_d, (size_t)((numElem) * (6)) * sizeof(double), "__inl15_d");
        double *__inl10_vd = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl10_vd, (size_t)((numElem)) * sizeof(double), "__inl10_vd");
        double *__inl10_vdovthird = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl10_vdovthird, (size_t)((numElem)) * sizeof(double), "__inl10_vdovthird");
        double *__inl16_vol = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_vol, (size_t)((numElem)) * sizeof(double), "__inl16_vol");
        double *__inl16_norm = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_norm, (size_t)((numElem)) * sizeof(double), "__inl16_norm");
        double *__inl16_dxj = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dxj, (size_t)((numElem)) * sizeof(double), "__inl16_dxj");
        double *__inl16_dyj = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dyj, (size_t)((numElem)) * sizeof(double), "__inl16_dyj");
        double *__inl16_dzj = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dzj, (size_t)((numElem)) * sizeof(double), "__inl16_dzj");
        double *__inl16_dxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dxi, (size_t)((numElem)) * sizeof(double), "__inl16_dxi");
        double *__inl16_dyi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dyi, (size_t)((numElem)) * sizeof(double), "__inl16_dyi");
        double *__inl16_dzi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dzi, (size_t)((numElem)) * sizeof(double), "__inl16_dzi");
        double *__inl16_dxk = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dxk, (size_t)((numElem)) * sizeof(double), "__inl16_dxk");
        double *__inl16_dyk = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dyk, (size_t)((numElem)) * sizeof(double), "__inl16_dyk");
        double *__inl16_dzk = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dzk, (size_t)((numElem)) * sizeof(double), "__inl16_dzk");
        double *__inl16_ax1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_ax1, (size_t)((numElem)) * sizeof(double), "__inl16_ax1");
        double *__inl16_ay1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_ay1, (size_t)((numElem)) * sizeof(double), "__inl16_ay1");
        double *__inl16_az1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_az1, (size_t)((numElem)) * sizeof(double), "__inl16_az1");
        double *__inl16_axn = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_axn, (size_t)((numElem)) * sizeof(double), "__inl16_axn");
        double *__inl16_ayn = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_ayn, (size_t)((numElem)) * sizeof(double), "__inl16_ayn");
        double *__inl16_azn = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_azn, (size_t)((numElem)) * sizeof(double), "__inl16_azn");
        double *__inl16_dxv1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dxv1, (size_t)((numElem)) * sizeof(double), "__inl16_dxv1");
        double *__inl16_dyv1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dyv1, (size_t)((numElem)) * sizeof(double), "__inl16_dyv1");
        double *__inl16_dzv1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dzv1, (size_t)((numElem)) * sizeof(double), "__inl16_dzv1");
        double *__inl16_ax2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_ax2, (size_t)((numElem)) * sizeof(double), "__inl16_ax2");
        double *__inl16_ay2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_ay2, (size_t)((numElem)) * sizeof(double), "__inl16_ay2");
        double *__inl16_az2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_az2, (size_t)((numElem)) * sizeof(double), "__inl16_az2");
        double *__inl16_dxv2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dxv2, (size_t)((numElem)) * sizeof(double), "__inl16_dxv2");
        double *__inl16_dyv2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dyv2, (size_t)((numElem)) * sizeof(double), "__inl16_dyv2");
        double *__inl16_dzv2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dzv2, (size_t)((numElem)) * sizeof(double), "__inl16_dzv2");
        double *__inl16_ax3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_ax3, (size_t)((numElem)) * sizeof(double), "__inl16_ax3");
        double *__inl16_ay3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_ay3, (size_t)((numElem)) * sizeof(double), "__inl16_ay3");
        double *__inl16_az3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_az3, (size_t)((numElem)) * sizeof(double), "__inl16_az3");
        double *__inl16_dxv3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dxv3, (size_t)((numElem)) * sizeof(double), "__inl16_dxv3");
        double *__inl16_dyv3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dyv3, (size_t)((numElem)) * sizeof(double), "__inl16_dyv3");
        double *__inl16_dzv3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl16_dzv3, (size_t)((numElem)) * sizeof(double), "__inl16_dzv3");
        int64_t *__inl17_ielem = (int64_t *)malloc((size_t)((numElem)) * sizeof(int64_t));
        __npb_alloc_check(__inl17_ielem, (size_t)((numElem)) * sizeof(int64_t), "__inl17_ielem");
        double *__inl17_norm1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_norm1, (size_t)((numElem)) * sizeof(double), "__inl17_norm1");
        double *__inl25_sel = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl25_sel, (size_t)((numElem)) * sizeof(double), "__inl25_sel");
        int64_t *__inl25_neigh_safe = (int64_t *)malloc((size_t)((numElem)) * sizeof(int64_t));
        __npb_alloc_check(__inl25_neigh_safe, (size_t)((numElem)) * sizeof(int64_t), "__inl25_neigh_safe");
        double *__inl25_out2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl25_out2, (size_t)((numElem)) * sizeof(double), "__inl25_out2");
        double *__inl25_out3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl25_out3, (size_t)((numElem)) * sizeof(double), "__inl25_out3");
        double *__inl17_dm1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_dm1, (size_t)((numElem)) * sizeof(double), "__inl17_dm1");
        double *__inl26_sel = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl26_sel, (size_t)((numElem)) * sizeof(double), "__inl26_sel");
        int64_t *__inl26_neigh_safe = (int64_t *)malloc((size_t)((numElem)) * sizeof(int64_t));
        __npb_alloc_check(__inl26_neigh_safe, (size_t)((numElem)) * sizeof(int64_t), "__inl26_neigh_safe");
        double *__inl26_out2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl26_out2, (size_t)((numElem)) * sizeof(double), "__inl26_out2");
        double *__inl26_out3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl26_out3, (size_t)((numElem)) * sizeof(double), "__inl26_out3");
        double *__inl17_dp1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_dp1, (size_t)((numElem)) * sizeof(double), "__inl17_dp1");
        double *__inl27_delvm1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl27_delvm1, (size_t)((numElem)) * sizeof(double), "__inl27_delvm1");
        double *__inl27_delvp1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl27_delvp1, (size_t)((numElem)) * sizeof(double), "__inl27_delvp1");
        double *__inl27_phi1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl27_phi1, (size_t)((numElem)) * sizeof(double), "__inl27_phi1");
        double *__inl27_delvm2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl27_delvm2, (size_t)((numElem)) * sizeof(double), "__inl27_delvm2");
        double *__inl27_delvp2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl27_delvp2, (size_t)((numElem)) * sizeof(double), "__inl27_delvp2");
        double *__inl27_phi2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl27_phi2, (size_t)((numElem)) * sizeof(double), "__inl27_phi2");
        double *__inl27_phi3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl27_phi3, (size_t)((numElem)) * sizeof(double), "__inl27_phi3");
        double *__inl27_phi4 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl27_phi4, (size_t)((numElem)) * sizeof(double), "__inl27_phi4");
        double *__inl27_phi5 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl27_phi5, (size_t)((numElem)) * sizeof(double), "__inl27_phi5");
        double *__inl17_phixi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_phixi, (size_t)((numElem)) * sizeof(double), "__inl17_phixi");
        double *__inl17_norm2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_norm2, (size_t)((numElem)) * sizeof(double), "__inl17_norm2");
        double *__inl28_sel = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl28_sel, (size_t)((numElem)) * sizeof(double), "__inl28_sel");
        int64_t *__inl28_neigh_safe = (int64_t *)malloc((size_t)((numElem)) * sizeof(int64_t));
        __npb_alloc_check(__inl28_neigh_safe, (size_t)((numElem)) * sizeof(int64_t), "__inl28_neigh_safe");
        double *__inl28_out2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl28_out2, (size_t)((numElem)) * sizeof(double), "__inl28_out2");
        double *__inl28_out3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl28_out3, (size_t)((numElem)) * sizeof(double), "__inl28_out3");
        double *__inl17_dm2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_dm2, (size_t)((numElem)) * sizeof(double), "__inl17_dm2");
        double *__inl29_sel = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl29_sel, (size_t)((numElem)) * sizeof(double), "__inl29_sel");
        int64_t *__inl29_neigh_safe = (int64_t *)malloc((size_t)((numElem)) * sizeof(int64_t));
        __npb_alloc_check(__inl29_neigh_safe, (size_t)((numElem)) * sizeof(int64_t), "__inl29_neigh_safe");
        double *__inl29_out2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl29_out2, (size_t)((numElem)) * sizeof(double), "__inl29_out2");
        double *__inl29_out3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl29_out3, (size_t)((numElem)) * sizeof(double), "__inl29_out3");
        double *__inl17_dp2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_dp2, (size_t)((numElem)) * sizeof(double), "__inl17_dp2");
        double *__inl30_delvm1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl30_delvm1, (size_t)((numElem)) * sizeof(double), "__inl30_delvm1");
        double *__inl30_delvp1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl30_delvp1, (size_t)((numElem)) * sizeof(double), "__inl30_delvp1");
        double *__inl30_phi1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl30_phi1, (size_t)((numElem)) * sizeof(double), "__inl30_phi1");
        double *__inl30_delvm2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl30_delvm2, (size_t)((numElem)) * sizeof(double), "__inl30_delvm2");
        double *__inl30_delvp2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl30_delvp2, (size_t)((numElem)) * sizeof(double), "__inl30_delvp2");
        double *__inl30_phi2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl30_phi2, (size_t)((numElem)) * sizeof(double), "__inl30_phi2");
        double *__inl30_phi3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl30_phi3, (size_t)((numElem)) * sizeof(double), "__inl30_phi3");
        double *__inl30_phi4 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl30_phi4, (size_t)((numElem)) * sizeof(double), "__inl30_phi4");
        double *__inl30_phi5 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl30_phi5, (size_t)((numElem)) * sizeof(double), "__inl30_phi5");
        double *__inl17_phieta = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_phieta, (size_t)((numElem)) * sizeof(double), "__inl17_phieta");
        double *__inl17_norm3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_norm3, (size_t)((numElem)) * sizeof(double), "__inl17_norm3");
        double *__inl31_sel = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl31_sel, (size_t)((numElem)) * sizeof(double), "__inl31_sel");
        int64_t *__inl31_neigh_safe = (int64_t *)malloc((size_t)((numElem)) * sizeof(int64_t));
        __npb_alloc_check(__inl31_neigh_safe, (size_t)((numElem)) * sizeof(int64_t), "__inl31_neigh_safe");
        double *__inl31_out2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl31_out2, (size_t)((numElem)) * sizeof(double), "__inl31_out2");
        double *__inl31_out3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl31_out3, (size_t)((numElem)) * sizeof(double), "__inl31_out3");
        double *__inl17_dm3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_dm3, (size_t)((numElem)) * sizeof(double), "__inl17_dm3");
        double *__inl32_sel = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl32_sel, (size_t)((numElem)) * sizeof(double), "__inl32_sel");
        int64_t *__inl32_neigh_safe = (int64_t *)malloc((size_t)((numElem)) * sizeof(int64_t));
        __npb_alloc_check(__inl32_neigh_safe, (size_t)((numElem)) * sizeof(int64_t), "__inl32_neigh_safe");
        double *__inl32_out2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl32_out2, (size_t)((numElem)) * sizeof(double), "__inl32_out2");
        double *__inl32_out3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl32_out3, (size_t)((numElem)) * sizeof(double), "__inl32_out3");
        double *__inl17_dp3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_dp3, (size_t)((numElem)) * sizeof(double), "__inl17_dp3");
        double *__inl33_delvm1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl33_delvm1, (size_t)((numElem)) * sizeof(double), "__inl33_delvm1");
        double *__inl33_delvp1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl33_delvp1, (size_t)((numElem)) * sizeof(double), "__inl33_delvp1");
        double *__inl33_phi1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl33_phi1, (size_t)((numElem)) * sizeof(double), "__inl33_phi1");
        double *__inl33_delvm2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl33_delvm2, (size_t)((numElem)) * sizeof(double), "__inl33_delvm2");
        double *__inl33_delvp2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl33_delvp2, (size_t)((numElem)) * sizeof(double), "__inl33_delvp2");
        double *__inl33_phi2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl33_phi2, (size_t)((numElem)) * sizeof(double), "__inl33_phi2");
        double *__inl33_phi3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl33_phi3, (size_t)((numElem)) * sizeof(double), "__inl33_phi3");
        double *__inl33_phi4 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl33_phi4, (size_t)((numElem)) * sizeof(double), "__inl33_phi4");
        double *__inl33_phi5 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl33_phi5, (size_t)((numElem)) * sizeof(double), "__inl33_phi5");
        double *__inl17_phizeta = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_phizeta, (size_t)((numElem)) * sizeof(double), "__inl17_phizeta");
        double *__inl17_delvxxi = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_delvxxi, (size_t)((numElem)) * sizeof(double), "__inl17_delvxxi");
        double *__inl17_delvxeta = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_delvxeta, (size_t)((numElem)) * sizeof(double), "__inl17_delvxeta");
        double *__inl17_delvxzeta = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_delvxzeta, (size_t)((numElem)) * sizeof(double), "__inl17_delvxzeta");
        double *__inl17_rho = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_rho, (size_t)((numElem)) * sizeof(double), "__inl17_rho");
        double *__inl17_qlin = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_qlin, (size_t)((numElem)) * sizeof(double), "__inl17_qlin");
        double *__inl17_qquad = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl17_qquad, (size_t)((numElem)) * sizeof(double), "__inl17_qquad");
        bool *__inl17_pos = (bool *)malloc((size_t)((numElem)) * sizeof(bool));
        __npb_alloc_check(__inl17_pos, (size_t)((numElem)) * sizeof(bool), "__inl17_pos");
        double *__inl18_compression = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_compression, (size_t)((numElem)) * sizeof(double), "__inl18_compression");
        double *__inl18_vchalf = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_vchalf, (size_t)((numElem)) * sizeof(double), "__inl18_vchalf");
        double *__inl18_compHalfStep = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_compHalfStep, (size_t)((numElem)) * sizeof(double), "__inl18_compHalfStep");
        bool *__inl18_m = (bool *)malloc((size_t)((numElem)) * sizeof(bool));
        __npb_alloc_check(__inl18_m, (size_t)((numElem)) * sizeof(bool), "__inl18_m");
        double *__inl34_e_new1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_e_new1, (size_t)((numElem)) * sizeof(double), "__inl34_e_new1");
        double *__inl34_e_new2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_e_new2, (size_t)((numElem)) * sizeof(double), "__inl34_e_new2");
        double *__inl40_bvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl40_bvc, (size_t)((numElem)) * sizeof(double), "__inl40_bvc");
        double *__inl40_p_new1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl40_p_new1, (size_t)((numElem)) * sizeof(double), "__inl40_p_new1");
        double *__inl40_p_new2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl40_p_new2, (size_t)((numElem)) * sizeof(double), "__inl40_p_new2");
        double *__inl40_p_new3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl40_p_new3, (size_t)((numElem)) * sizeof(double), "__inl40_p_new3");
        double *__inl40_p_new4 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl40_p_new4, (size_t)((numElem)) * sizeof(double), "__inl40_p_new4");
        double *__inl34_pHalfStep = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_pHalfStep, (size_t)((numElem)) * sizeof(double), "__inl34_pHalfStep");
        double *__inl34_bvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_bvc, (size_t)((numElem)) * sizeof(double), "__inl34_bvc");
        double *__inl34_pbvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_pbvc, (size_t)((numElem)) * sizeof(double), "__inl34_pbvc");
        double *__inl34_vhalf = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_vhalf, (size_t)((numElem)) * sizeof(double), "__inl34_vhalf");
        double *__inl34_ssc1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_ssc1, (size_t)((numElem)) * sizeof(double), "__inl34_ssc1");
        double *__inl34_ssc2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_ssc2, (size_t)((numElem)) * sizeof(double), "__inl34_ssc2");
        double *__inl34_q_new = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_q_new, (size_t)((numElem)) * sizeof(double), "__inl34_q_new");
        double *__inl34_e_new3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_e_new3, (size_t)((numElem)) * sizeof(double), "__inl34_e_new3");
        double *__inl34_e_new4 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_e_new4, (size_t)((numElem)) * sizeof(double), "__inl34_e_new4");
        double *__inl34_e_new5 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_e_new5, (size_t)((numElem)) * sizeof(double), "__inl34_e_new5");
        double *__inl34_e_new6 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_e_new6, (size_t)((numElem)) * sizeof(double), "__inl34_e_new6");
        double *__inl41_bvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl41_bvc, (size_t)((numElem)) * sizeof(double), "__inl41_bvc");
        double *__inl41_p_new1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl41_p_new1, (size_t)((numElem)) * sizeof(double), "__inl41_p_new1");
        double *__inl41_p_new2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl41_p_new2, (size_t)((numElem)) * sizeof(double), "__inl41_p_new2");
        double *__inl41_p_new3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl41_p_new3, (size_t)((numElem)) * sizeof(double), "__inl41_p_new3");
        double *__inl41_p_new4 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl41_p_new4, (size_t)((numElem)) * sizeof(double), "__inl41_p_new4");
        double *__inl34_p_new = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_p_new, (size_t)((numElem)) * sizeof(double), "__inl34_p_new");
        double *__inl34_ssc3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_ssc3, (size_t)((numElem)) * sizeof(double), "__inl34_ssc3");
        double *__inl34_ssc4 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_ssc4, (size_t)((numElem)) * sizeof(double), "__inl34_ssc4");
        double *__inl34_q_tilde = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_q_tilde, (size_t)((numElem)) * sizeof(double), "__inl34_q_tilde");
        double *__inl34_e_new7 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_e_new7, (size_t)((numElem)) * sizeof(double), "__inl34_e_new7");
        double *__inl34_e_new8 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_e_new8, (size_t)((numElem)) * sizeof(double), "__inl34_e_new8");
        double *__inl34_e_new9 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_e_new9, (size_t)((numElem)) * sizeof(double), "__inl34_e_new9");
        double *__inl42_bvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl42_bvc, (size_t)((numElem)) * sizeof(double), "__inl42_bvc");
        double *__inl42_p_new1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl42_p_new1, (size_t)((numElem)) * sizeof(double), "__inl42_p_new1");
        double *__inl42_p_new2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl42_p_new2, (size_t)((numElem)) * sizeof(double), "__inl42_p_new2");
        double *__inl42_p_new3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl42_p_new3, (size_t)((numElem)) * sizeof(double), "__inl42_p_new3");
        double *__inl42_p_new4 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl42_p_new4, (size_t)((numElem)) * sizeof(double), "__inl42_p_new4");
        double *__inl34_ssc5 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_ssc5, (size_t)((numElem)) * sizeof(double), "__inl34_ssc5");
        double *__inl34_ssc6 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_ssc6, (size_t)((numElem)) * sizeof(double), "__inl34_ssc6");
        double *__inl34_q_new21 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_q_new21, (size_t)((numElem)) * sizeof(double), "__inl34_q_new21");
        double *__inl34_q_new22 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl34_q_new22, (size_t)((numElem)) * sizeof(double), "__inl34_q_new22");
        double *__inl18_p_new = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_p_new, (size_t)((numElem)) * sizeof(double), "__inl18_p_new");
        double *__inl18_e_new = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_e_new, (size_t)((numElem)) * sizeof(double), "__inl18_e_new");
        double *__inl18_q_new = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_q_new, (size_t)((numElem)) * sizeof(double), "__inl18_q_new");
        double *__inl18_bvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_bvc, (size_t)((numElem)) * sizeof(double), "__inl18_bvc");
        double *__inl18_pbvc = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl18_pbvc, (size_t)((numElem)) * sizeof(double), "__inl18_pbvc");
        double *__inl35_ssc1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl35_ssc1, (size_t)((numElem)) * sizeof(double), "__inl35_ssc1");
        double *__inl35_ssc2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl35_ssc2, (size_t)((numElem)) * sizeof(double), "__inl35_ssc2");
        double *__inl13_tmpV2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl13_tmpV2, (size_t)((numElem)) * sizeof(double), "__inl13_tmpV2");
        double *__inl3_dtf1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl3_dtf1, (size_t)((numElem)) * sizeof(double), "__inl3_dtf1");
        double *__inl3_dtf2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl3_dtf2, (size_t)((numElem)) * sizeof(double), "__inl3_dtf2");
        double *__inl3_dtf4 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl3_dtf4, (size_t)((numElem)) * sizeof(double), "__inl3_dtf4");
        double *__inl3_dtf5 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl3_dtf5, (size_t)((numElem)) * sizeof(double), "__inl3_dtf5");
        double *__inl4_dtdvov1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl4_dtdvov1, (size_t)((numElem)) * sizeof(double), "__inl4_dtdvov1");
        double *__inl4_dtdvov2 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl4_dtdvov2, (size_t)((numElem)) * sizeof(double), "__inl4_dtdvov2");
        double *__inl19_xl = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl19_xl, (size_t)((numElem) * (8)) * sizeof(double), "__inl19_xl");
        double *__inl19_yl = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl19_yl, (size_t)((numElem) * (8)) * sizeof(double), "__inl19_yl");
        double *__inl19_zl = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl19_zl, (size_t)((numElem) * (8)) * sizeof(double), "__inl19_zl");
        double *__inl20_x1 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl20_x1, (size_t)((numElem) * (8)) * sizeof(double), "__inl20_x1");
        double *__inl20_y1 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl20_y1, (size_t)((numElem) * (8)) * sizeof(double), "__inl20_y1");
        double *__inl20_z1 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl20_z1, (size_t)((numElem) * (8)) * sizeof(double), "__inl20_z1");
        double *__inl38_gx = (double *)malloc((size_t)((numElem) * (8) * (6)) * sizeof(double));
        __npb_alloc_check(__inl38_gx, (size_t)((numElem) * (8) * (6)) * sizeof(double), "__inl38_gx");
        double *__inl38_gy = (double *)malloc((size_t)((numElem) * (8) * (6)) * sizeof(double));
        __npb_alloc_check(__inl38_gy, (size_t)((numElem) * (8) * (6)) * sizeof(double), "__inl38_gy");
        double *__inl38_gz = (double *)malloc((size_t)((numElem) * (8) * (6)) * sizeof(double));
        __npb_alloc_check(__inl38_gz, (size_t)((numElem) * (8) * (6)) * sizeof(double), "__inl38_gz");
        double *__inl15_xdl = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl15_xdl, (size_t)((numElem) * (8)) * sizeof(double), "__inl15_xdl");
        double *__inl15_ydl = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl15_ydl, (size_t)((numElem) * (8)) * sizeof(double), "__inl15_ydl");
        double *__inl15_zdl = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl15_zdl, (size_t)((numElem) * (8)) * sizeof(double), "__inl15_zdl");
        double *__inl16_xn = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl16_xn, (size_t)((numElem) * (8)) * sizeof(double), "__inl16_xn");
        double *__inl16_yn = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl16_yn, (size_t)((numElem) * (8)) * sizeof(double), "__inl16_yn");
        double *__inl16_zn = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl16_zn, (size_t)((numElem) * (8)) * sizeof(double), "__inl16_zn");
        double *__inl16_xv = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl16_xv, (size_t)((numElem) * (8)) * sizeof(double), "__inl16_xv");
        double *__inl16_yv = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl16_yv, (size_t)((numElem) * (8)) * sizeof(double), "__inl16_yv");
        double *__inl16_zv = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl16_zv, (size_t)((numElem) * (8)) * sizeof(double), "__inl16_zv");
        double *__inl25_out1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl25_out1, (size_t)((numElem)) * sizeof(double), "__inl25_out1");
        double *__inl26_out1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl26_out1, (size_t)((numElem)) * sizeof(double), "__inl26_out1");
        double *__inl28_out1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl28_out1, (size_t)((numElem)) * sizeof(double), "__inl28_out1");
        double *__inl29_out1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl29_out1, (size_t)((numElem)) * sizeof(double), "__inl29_out1");
        double *__inl31_out1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl31_out1, (size_t)((numElem)) * sizeof(double), "__inl31_out1");
        double *__inl32_out1 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl32_out1, (size_t)((numElem)) * sizeof(double), "__inl32_out1");
        double *__inl3_dtf3 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl3_dtf3, (size_t)((numElem)) * sizeof(double), "__inl3_dtf3");
        double *__inl39_xd1 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl39_xd1, (size_t)((numElem) * (8)) * sizeof(double), "__inl39_xd1");
        double *__inl39_yd1 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl39_yd1, (size_t)((numElem) * (8)) * sizeof(double), "__inl39_yd1");
        double *__inl39_zd1 = (double *)malloc((size_t)((numElem) * (8)) * sizeof(double));
        __npb_alloc_check(__inl39_zd1, (size_t)((numElem) * (8)) * sizeof(double), "__inl39_zd1");
        double *__inl39_volume13 = (double *)malloc((size_t)((numElem)) * sizeof(double));
        __npb_alloc_check(__inl39_volume13, (size_t)((numElem)) * sizeof(double), "__inl39_volume13");
        memset(_GAMMA, 0, (size_t)((8) * (4)) * sizeof(double));
        _GAMMA[(0)*(4) + (0)] = 1.0;
        _GAMMA[(0)*(4) + (1)] = 1.0;
        _GAMMA[(0)*(4) + (2)] = 1.0;
        _GAMMA[(0)*(4) + (3)] = -1.0;
        _GAMMA[(1)*(4) + (0)] = 1.0;
        _GAMMA[(1)*(4) + (1)] = -1.0;
        _GAMMA[(1)*(4) + (2)] = -1.0;
        _GAMMA[(1)*(4) + (3)] = 1.0;
        _GAMMA[(2)*(4) + (0)] = -1.0;
        _GAMMA[(2)*(4) + (1)] = -1.0;
        _GAMMA[(2)*(4) + (2)] = 1.0;
        _GAMMA[(2)*(4) + (3)] = -1.0;
        _GAMMA[(3)*(4) + (0)] = -1.0;
        _GAMMA[(3)*(4) + (1)] = 1.0;
        _GAMMA[(3)*(4) + (2)] = -1.0;
        _GAMMA[(3)*(4) + (3)] = 1.0;
        _GAMMA[(4)*(4) + (0)] = -1.0;
        _GAMMA[(4)*(4) + (1)] = -1.0;
        _GAMMA[(4)*(4) + (2)] = 1.0;
        _GAMMA[(4)*(4) + (3)] = 1.0;
        _GAMMA[(5)*(4) + (0)] = -1.0;
        _GAMMA[(5)*(4) + (1)] = 1.0;
        _GAMMA[(5)*(4) + (2)] = -1.0;
        _GAMMA[(5)*(4) + (3)] = -1.0;
        _GAMMA[(6)*(4) + (0)] = 1.0;
        _GAMMA[(6)*(4) + (1)] = 1.0;
        _GAMMA[(6)*(4) + (2)] = 1.0;
        _GAMMA[(6)*(4) + (3)] = 1.0;
        _GAMMA[(7)*(4) + (0)] = 1.0;
        _GAMMA[(7)*(4) + (1)] = -1.0;
        _GAMMA[(7)*(4) + (2)] = -1.0;
        _GAMMA[(7)*(4) + (3)] = -1.0;
        memset(_VOLU_PERM, 0, (size_t)((8) * (6)) * sizeof(int64_t));
        _VOLU_PERM[(0)*(6) + (0)] = 1;
        _VOLU_PERM[(0)*(6) + (1)] = 2;
        _VOLU_PERM[(0)*(6) + (2)] = 3;
        _VOLU_PERM[(0)*(6) + (3)] = 4;
        _VOLU_PERM[(0)*(6) + (4)] = 5;
        _VOLU_PERM[(0)*(6) + (5)] = 7;
        _VOLU_PERM[(1)*(6) + (0)] = 2;
        _VOLU_PERM[(1)*(6) + (1)] = 3;
        _VOLU_PERM[(1)*(6) + (2)] = 0;
        _VOLU_PERM[(1)*(6) + (3)] = 5;
        _VOLU_PERM[(1)*(6) + (4)] = 6;
        _VOLU_PERM[(1)*(6) + (5)] = 4;
        _VOLU_PERM[(2)*(6) + (0)] = 3;
        _VOLU_PERM[(2)*(6) + (1)] = 0;
        _VOLU_PERM[(2)*(6) + (2)] = 1;
        _VOLU_PERM[(2)*(6) + (3)] = 6;
        _VOLU_PERM[(2)*(6) + (4)] = 7;
        _VOLU_PERM[(2)*(6) + (5)] = 5;
        _VOLU_PERM[(3)*(6) + (0)] = 0;
        _VOLU_PERM[(3)*(6) + (1)] = 1;
        _VOLU_PERM[(3)*(6) + (2)] = 2;
        _VOLU_PERM[(3)*(6) + (3)] = 7;
        _VOLU_PERM[(3)*(6) + (4)] = 4;
        _VOLU_PERM[(3)*(6) + (5)] = 6;
        _VOLU_PERM[(4)*(6) + (0)] = 7;
        _VOLU_PERM[(4)*(6) + (1)] = 6;
        _VOLU_PERM[(4)*(6) + (2)] = 5;
        _VOLU_PERM[(4)*(6) + (3)] = 0;
        _VOLU_PERM[(4)*(6) + (4)] = 3;
        _VOLU_PERM[(4)*(6) + (5)] = 1;
        _VOLU_PERM[(5)*(6) + (0)] = 4;
        _VOLU_PERM[(5)*(6) + (1)] = 7;
        _VOLU_PERM[(5)*(6) + (2)] = 6;
        _VOLU_PERM[(5)*(6) + (3)] = 1;
        _VOLU_PERM[(5)*(6) + (4)] = 0;
        _VOLU_PERM[(5)*(6) + (5)] = 2;
        _VOLU_PERM[(6)*(6) + (0)] = 5;
        _VOLU_PERM[(6)*(6) + (1)] = 4;
        _VOLU_PERM[(6)*(6) + (2)] = 7;
        _VOLU_PERM[(6)*(6) + (3)] = 2;
        _VOLU_PERM[(6)*(6) + (4)] = 1;
        _VOLU_PERM[(6)*(6) + (5)] = 3;
        _VOLU_PERM[(7)*(6) + (0)] = 6;
        _VOLU_PERM[(7)*(6) + (1)] = 5;
        _VOLU_PERM[(7)*(6) + (2)] = 4;
        _VOLU_PERM[(7)*(6) + (3)] = 3;
        _VOLU_PERM[(7)*(6) + (4)] = 2;
        _VOLU_PERM[(7)*(6) + (5)] = 0;
        deltatime = 1e-07;
        time = 0.0;
        cycle = 0;
        dtcourant = 1e+20;
        dthydro = 1e+20;
        for (int64_t _ = 0; _ < ((int64_t)(nsteps)); ++_) {
          targetdt = (0.01 - time);
          if (((-1e-07 <= 0.0) && (cycle != 0))) {
            olddt = deltatime;
            gnewdt = 1e+20;
            if ((dtcourant < gnewdt)) {
              gnewdt = (dtcourant / 2.0);
            }
            if ((dthydro < gnewdt)) {
              gnewdt = (dthydro * (2.0 / 3.0));
            }
            newdt = gnewdt;
            ratio = (newdt / olddt);
            if ((ratio >= 1.0)) {
              if ((ratio < 1.1)) {
                newdt = olddt;
              }
              else if ((ratio > 1.2)) {
                newdt = (olddt * 1.2);
              }
            }
            if ((newdt > 0.01)) {
              newdt = 0.01;
            }
            deltatime = newdt;
          }
          if (((targetdt > deltatime) && (targetdt < ((4.0 * deltatime) / 3.0)))) {
            targetdt = ((2.0 * deltatime) / 3.0);
          }
          if ((targetdt < deltatime)) {
            deltatime = targetdt;
          }
          time = (time + deltatime);
          cycle = (cycle + 1);
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            fx[__w0] = 0.0;
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            fy[__w0] = 0.0;
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            fz[__w0] = 0.0;
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl14_sig[__w0] = ((-p[__w0]) - q[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl19_xl[(__w0)*(8) + (__w1)] = x[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl19_yl[(__w0)*(8) + (__w1)] = y[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl19_zl[(__w0)*(8) + (__w1)] = z[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_fjxxi[__w0] = (0.125 * ((((__inl19_xl[(__w0)*(8) + (6)] - __inl19_xl[(__w0)*(8) + (0)]) + (__inl19_xl[(__w0)*(8) + (5)] - __inl19_xl[(__w0)*(8) + (3)])) - (__inl19_xl[(__w0)*(8) + (7)] - __inl19_xl[(__w0)*(8) + (1)])) - (__inl19_xl[(__w0)*(8) + (4)] - __inl19_xl[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_fjxet[__w0] = (0.125 * ((((__inl19_xl[(__w0)*(8) + (6)] - __inl19_xl[(__w0)*(8) + (0)]) - (__inl19_xl[(__w0)*(8) + (5)] - __inl19_xl[(__w0)*(8) + (3)])) + (__inl19_xl[(__w0)*(8) + (7)] - __inl19_xl[(__w0)*(8) + (1)])) - (__inl19_xl[(__w0)*(8) + (4)] - __inl19_xl[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_fjxze[__w0] = (0.125 * ((((__inl19_xl[(__w0)*(8) + (6)] - __inl19_xl[(__w0)*(8) + (0)]) + (__inl19_xl[(__w0)*(8) + (5)] - __inl19_xl[(__w0)*(8) + (3)])) + (__inl19_xl[(__w0)*(8) + (7)] - __inl19_xl[(__w0)*(8) + (1)])) + (__inl19_xl[(__w0)*(8) + (4)] - __inl19_xl[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_fjyxi[__w0] = (0.125 * ((((__inl19_yl[(__w0)*(8) + (6)] - __inl19_yl[(__w0)*(8) + (0)]) + (__inl19_yl[(__w0)*(8) + (5)] - __inl19_yl[(__w0)*(8) + (3)])) - (__inl19_yl[(__w0)*(8) + (7)] - __inl19_yl[(__w0)*(8) + (1)])) - (__inl19_yl[(__w0)*(8) + (4)] - __inl19_yl[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_fjyet[__w0] = (0.125 * ((((__inl19_yl[(__w0)*(8) + (6)] - __inl19_yl[(__w0)*(8) + (0)]) - (__inl19_yl[(__w0)*(8) + (5)] - __inl19_yl[(__w0)*(8) + (3)])) + (__inl19_yl[(__w0)*(8) + (7)] - __inl19_yl[(__w0)*(8) + (1)])) - (__inl19_yl[(__w0)*(8) + (4)] - __inl19_yl[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_fjyze[__w0] = (0.125 * ((((__inl19_yl[(__w0)*(8) + (6)] - __inl19_yl[(__w0)*(8) + (0)]) + (__inl19_yl[(__w0)*(8) + (5)] - __inl19_yl[(__w0)*(8) + (3)])) + (__inl19_yl[(__w0)*(8) + (7)] - __inl19_yl[(__w0)*(8) + (1)])) + (__inl19_yl[(__w0)*(8) + (4)] - __inl19_yl[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_fjzxi[__w0] = (0.125 * ((((__inl19_zl[(__w0)*(8) + (6)] - __inl19_zl[(__w0)*(8) + (0)]) + (__inl19_zl[(__w0)*(8) + (5)] - __inl19_zl[(__w0)*(8) + (3)])) - (__inl19_zl[(__w0)*(8) + (7)] - __inl19_zl[(__w0)*(8) + (1)])) - (__inl19_zl[(__w0)*(8) + (4)] - __inl19_zl[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_fjzet[__w0] = (0.125 * ((((__inl19_zl[(__w0)*(8) + (6)] - __inl19_zl[(__w0)*(8) + (0)]) - (__inl19_zl[(__w0)*(8) + (5)] - __inl19_zl[(__w0)*(8) + (3)])) + (__inl19_zl[(__w0)*(8) + (7)] - __inl19_zl[(__w0)*(8) + (1)])) - (__inl19_zl[(__w0)*(8) + (4)] - __inl19_zl[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_fjzze[__w0] = (0.125 * ((((__inl19_zl[(__w0)*(8) + (6)] - __inl19_zl[(__w0)*(8) + (0)]) + (__inl19_zl[(__w0)*(8) + (5)] - __inl19_zl[(__w0)*(8) + (3)])) + (__inl19_zl[(__w0)*(8) + (7)] - __inl19_zl[(__w0)*(8) + (1)])) + (__inl19_zl[(__w0)*(8) + (4)] - __inl19_zl[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_cjxxi[__w0] = ((__inl36_fjyet[__w0] * __inl36_fjzze[__w0]) - (__inl36_fjzet[__w0] * __inl36_fjyze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_cjxet[__w0] = ((-(__inl36_fjyxi[__w0] * __inl36_fjzze[__w0])) + (__inl36_fjzxi[__w0] * __inl36_fjyze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_cjxze[__w0] = ((__inl36_fjyxi[__w0] * __inl36_fjzet[__w0]) - (__inl36_fjzxi[__w0] * __inl36_fjyet[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_cjyxi[__w0] = ((-(__inl36_fjxet[__w0] * __inl36_fjzze[__w0])) + (__inl36_fjzet[__w0] * __inl36_fjxze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_cjyet[__w0] = ((__inl36_fjxxi[__w0] * __inl36_fjzze[__w0]) - (__inl36_fjzxi[__w0] * __inl36_fjxze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_cjyze[__w0] = ((-(__inl36_fjxxi[__w0] * __inl36_fjzet[__w0])) + (__inl36_fjzxi[__w0] * __inl36_fjxet[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_cjzxi[__w0] = ((__inl36_fjxet[__w0] * __inl36_fjyze[__w0]) - (__inl36_fjyet[__w0] * __inl36_fjxze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_cjzet[__w0] = ((-(__inl36_fjxxi[__w0] * __inl36_fjyze[__w0])) + (__inl36_fjyxi[__w0] * __inl36_fjxze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_cjzze[__w0] = ((__inl36_fjxxi[__w0] * __inl36_fjyet[__w0]) - (__inl36_fjyxi[__w0] * __inl36_fjxet[__w0]));
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (0))*(3) + (0)] = (((-__inl36_cjxxi[si0]) - __inl36_cjxet[si0]) - __inl36_cjxze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (1))*(3) + (0)] = ((__inl36_cjxxi[si0] - __inl36_cjxet[si0]) - __inl36_cjxze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (2))*(3) + (0)] = ((__inl36_cjxxi[si0] + __inl36_cjxet[si0]) - __inl36_cjxze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (3))*(3) + (0)] = (((-__inl36_cjxxi[si0]) + __inl36_cjxet[si0]) - __inl36_cjxze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (4))*(3) + (0)] = (-__inl36_b[((si0)*(8) + (2))*(3) + (0)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (5))*(3) + (0)] = (-__inl36_b[((si0)*(8) + (3))*(3) + (0)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (6))*(3) + (0)] = (-__inl36_b[((si0)*(8) + (0))*(3) + (0)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (7))*(3) + (0)] = (-__inl36_b[((si0)*(8) + (1))*(3) + (0)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (0))*(3) + (1)] = (((-__inl36_cjyxi[si0]) - __inl36_cjyet[si0]) - __inl36_cjyze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (1))*(3) + (1)] = ((__inl36_cjyxi[si0] - __inl36_cjyet[si0]) - __inl36_cjyze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (2))*(3) + (1)] = ((__inl36_cjyxi[si0] + __inl36_cjyet[si0]) - __inl36_cjyze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (3))*(3) + (1)] = (((-__inl36_cjyxi[si0]) + __inl36_cjyet[si0]) - __inl36_cjyze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (4))*(3) + (1)] = (-__inl36_b[((si0)*(8) + (2))*(3) + (1)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (5))*(3) + (1)] = (-__inl36_b[((si0)*(8) + (3))*(3) + (1)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (6))*(3) + (1)] = (-__inl36_b[((si0)*(8) + (0))*(3) + (1)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (7))*(3) + (1)] = (-__inl36_b[((si0)*(8) + (1))*(3) + (1)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (0))*(3) + (2)] = (((-__inl36_cjzxi[si0]) - __inl36_cjzet[si0]) - __inl36_cjzze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (1))*(3) + (2)] = ((__inl36_cjzxi[si0] - __inl36_cjzet[si0]) - __inl36_cjzze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (2))*(3) + (2)] = ((__inl36_cjzxi[si0] + __inl36_cjzet[si0]) - __inl36_cjzze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (3))*(3) + (2)] = (((-__inl36_cjzxi[si0]) + __inl36_cjzet[si0]) - __inl36_cjzze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (4))*(3) + (2)] = (-__inl36_b[((si0)*(8) + (2))*(3) + (2)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (5))*(3) + (2)] = (-__inl36_b[((si0)*(8) + (3))*(3) + (2)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (6))*(3) + (2)] = (-__inl36_b[((si0)*(8) + (0))*(3) + (2)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl36_b[((si0)*(8) + (7))*(3) + (2)] = (-__inl36_b[((si0)*(8) + (1))*(3) + (2)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl36_volume[__w0] = (8.0 * (((__inl36_fjxet[__w0] * __inl36_cjxet[__w0]) + (__inl36_fjyet[__w0] * __inl36_cjyet[__w0])) + (__inl36_fjzet[__w0] * __inl36_cjzet[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
                __inl19__[((__w0)*(8) + (__w1))*(3) + (__w2)] = __inl36_b[((__w0)*(8) + (__w1))*(3) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl19_determ[__w0] = __inl36_volume[__w0];
          }
          memset(__inl37_pf, 0, (size_t)((numElem) * (8) * (3)) * sizeof(double));
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl43_bX0[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (3)] + __inl19_xl[(__w0)*(8) + (2)]) - __inl19_xl[(__w0)*(8) + (1)]) - __inl19_xl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl43_bY0[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (3)] + __inl19_yl[(__w0)*(8) + (2)]) - __inl19_yl[(__w0)*(8) + (1)]) - __inl19_yl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl43_bZ0[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (3)] + __inl19_zl[(__w0)*(8) + (2)]) - __inl19_zl[(__w0)*(8) + (1)]) - __inl19_zl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl43_bX1[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (2)] + __inl19_xl[(__w0)*(8) + (1)]) - __inl19_xl[(__w0)*(8) + (3)]) - __inl19_xl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl43_bY1[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (2)] + __inl19_yl[(__w0)*(8) + (1)]) - __inl19_yl[(__w0)*(8) + (3)]) - __inl19_yl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl43_bZ1[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (2)] + __inl19_zl[(__w0)*(8) + (1)]) - __inl19_zl[(__w0)*(8) + (3)]) - __inl19_zl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl43_areaX[__w0] = (0.25 * ((__inl43_bY0[__w0] * __inl43_bZ1[__w0]) - (__inl43_bZ0[__w0] * __inl43_bY1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl43_areaY[__w0] = (0.25 * ((__inl43_bZ0[__w0] * __inl43_bX1[__w0]) - (__inl43_bX0[__w0] * __inl43_bZ1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl43_areaZ[__w0] = (0.25 * ((__inl43_bX0[__w0] * __inl43_bY1[__w0]) - (__inl43_bY0[__w0] * __inl43_bX1[__w0])));
          }
          __inl43_corners[0] = 0;
          __inl43_corners[1] = 1;
          __inl43_corners[2] = 2;
          __inl43_corners[3] = 3;
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg0[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl43_corners[__sc0]))*(3) + (0)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl43_corners[__sc0]))*(3) + (0)] = (__scg0[(__scs0)*(4) + (__sc0)] + __inl43_areaX[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg1[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl43_corners[__sc0]))*(3) + (1)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl43_corners[__sc0]))*(3) + (1)] = (__scg1[(__scs0)*(4) + (__sc0)] + __inl43_areaY[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg2[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl43_corners[__sc0]))*(3) + (2)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl43_corners[__sc0]))*(3) + (2)] = (__scg2[(__scs0)*(4) + (__sc0)] + __inl43_areaZ[__scs0]);
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl44_bX0[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (1)] + __inl19_xl[(__w0)*(8) + (5)]) - __inl19_xl[(__w0)*(8) + (4)]) - __inl19_xl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl44_bY0[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (1)] + __inl19_yl[(__w0)*(8) + (5)]) - __inl19_yl[(__w0)*(8) + (4)]) - __inl19_yl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl44_bZ0[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (1)] + __inl19_zl[(__w0)*(8) + (5)]) - __inl19_zl[(__w0)*(8) + (4)]) - __inl19_zl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl44_bX1[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (5)] + __inl19_xl[(__w0)*(8) + (4)]) - __inl19_xl[(__w0)*(8) + (1)]) - __inl19_xl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl44_bY1[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (5)] + __inl19_yl[(__w0)*(8) + (4)]) - __inl19_yl[(__w0)*(8) + (1)]) - __inl19_yl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl44_bZ1[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (5)] + __inl19_zl[(__w0)*(8) + (4)]) - __inl19_zl[(__w0)*(8) + (1)]) - __inl19_zl[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl44_areaX[__w0] = (0.25 * ((__inl44_bY0[__w0] * __inl44_bZ1[__w0]) - (__inl44_bZ0[__w0] * __inl44_bY1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl44_areaY[__w0] = (0.25 * ((__inl44_bZ0[__w0] * __inl44_bX1[__w0]) - (__inl44_bX0[__w0] * __inl44_bZ1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl44_areaZ[__w0] = (0.25 * ((__inl44_bX0[__w0] * __inl44_bY1[__w0]) - (__inl44_bY0[__w0] * __inl44_bX1[__w0])));
          }
          __inl44_corners[0] = 0;
          __inl44_corners[1] = 4;
          __inl44_corners[2] = 5;
          __inl44_corners[3] = 1;
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg3[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl44_corners[__sc0]))*(3) + (0)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl44_corners[__sc0]))*(3) + (0)] = (__scg3[(__scs0)*(4) + (__sc0)] + __inl44_areaX[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg4[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl44_corners[__sc0]))*(3) + (1)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl44_corners[__sc0]))*(3) + (1)] = (__scg4[(__scs0)*(4) + (__sc0)] + __inl44_areaY[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg5[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl44_corners[__sc0]))*(3) + (2)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl44_corners[__sc0]))*(3) + (2)] = (__scg5[(__scs0)*(4) + (__sc0)] + __inl44_areaZ[__scs0]);
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl45_bX0[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (2)] + __inl19_xl[(__w0)*(8) + (6)]) - __inl19_xl[(__w0)*(8) + (5)]) - __inl19_xl[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl45_bY0[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (2)] + __inl19_yl[(__w0)*(8) + (6)]) - __inl19_yl[(__w0)*(8) + (5)]) - __inl19_yl[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl45_bZ0[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (2)] + __inl19_zl[(__w0)*(8) + (6)]) - __inl19_zl[(__w0)*(8) + (5)]) - __inl19_zl[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl45_bX1[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (6)] + __inl19_xl[(__w0)*(8) + (5)]) - __inl19_xl[(__w0)*(8) + (2)]) - __inl19_xl[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl45_bY1[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (6)] + __inl19_yl[(__w0)*(8) + (5)]) - __inl19_yl[(__w0)*(8) + (2)]) - __inl19_yl[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl45_bZ1[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (6)] + __inl19_zl[(__w0)*(8) + (5)]) - __inl19_zl[(__w0)*(8) + (2)]) - __inl19_zl[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl45_areaX[__w0] = (0.25 * ((__inl45_bY0[__w0] * __inl45_bZ1[__w0]) - (__inl45_bZ0[__w0] * __inl45_bY1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl45_areaY[__w0] = (0.25 * ((__inl45_bZ0[__w0] * __inl45_bX1[__w0]) - (__inl45_bX0[__w0] * __inl45_bZ1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl45_areaZ[__w0] = (0.25 * ((__inl45_bX0[__w0] * __inl45_bY1[__w0]) - (__inl45_bY0[__w0] * __inl45_bX1[__w0])));
          }
          __inl45_corners[0] = 1;
          __inl45_corners[1] = 5;
          __inl45_corners[2] = 6;
          __inl45_corners[3] = 2;
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg6[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl45_corners[__sc0]))*(3) + (0)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl45_corners[__sc0]))*(3) + (0)] = (__scg6[(__scs0)*(4) + (__sc0)] + __inl45_areaX[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg7[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl45_corners[__sc0]))*(3) + (1)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl45_corners[__sc0]))*(3) + (1)] = (__scg7[(__scs0)*(4) + (__sc0)] + __inl45_areaY[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg8[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl45_corners[__sc0]))*(3) + (2)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl45_corners[__sc0]))*(3) + (2)] = (__scg8[(__scs0)*(4) + (__sc0)] + __inl45_areaZ[__scs0]);
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl46_bX0[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (3)] + __inl19_xl[(__w0)*(8) + (7)]) - __inl19_xl[(__w0)*(8) + (6)]) - __inl19_xl[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl46_bY0[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (3)] + __inl19_yl[(__w0)*(8) + (7)]) - __inl19_yl[(__w0)*(8) + (6)]) - __inl19_yl[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl46_bZ0[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (3)] + __inl19_zl[(__w0)*(8) + (7)]) - __inl19_zl[(__w0)*(8) + (6)]) - __inl19_zl[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl46_bX1[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (7)] + __inl19_xl[(__w0)*(8) + (6)]) - __inl19_xl[(__w0)*(8) + (3)]) - __inl19_xl[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl46_bY1[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (7)] + __inl19_yl[(__w0)*(8) + (6)]) - __inl19_yl[(__w0)*(8) + (3)]) - __inl19_yl[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl46_bZ1[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (7)] + __inl19_zl[(__w0)*(8) + (6)]) - __inl19_zl[(__w0)*(8) + (3)]) - __inl19_zl[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl46_areaX[__w0] = (0.25 * ((__inl46_bY0[__w0] * __inl46_bZ1[__w0]) - (__inl46_bZ0[__w0] * __inl46_bY1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl46_areaY[__w0] = (0.25 * ((__inl46_bZ0[__w0] * __inl46_bX1[__w0]) - (__inl46_bX0[__w0] * __inl46_bZ1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl46_areaZ[__w0] = (0.25 * ((__inl46_bX0[__w0] * __inl46_bY1[__w0]) - (__inl46_bY0[__w0] * __inl46_bX1[__w0])));
          }
          __inl46_corners[0] = 2;
          __inl46_corners[1] = 6;
          __inl46_corners[2] = 7;
          __inl46_corners[3] = 3;
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg9[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl46_corners[__sc0]))*(3) + (0)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl46_corners[__sc0]))*(3) + (0)] = (__scg9[(__scs0)*(4) + (__sc0)] + __inl46_areaX[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg10[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl46_corners[__sc0]))*(3) + (1)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl46_corners[__sc0]))*(3) + (1)] = (__scg10[(__scs0)*(4) + (__sc0)] + __inl46_areaY[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg11[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl46_corners[__sc0]))*(3) + (2)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl46_corners[__sc0]))*(3) + (2)] = (__scg11[(__scs0)*(4) + (__sc0)] + __inl46_areaZ[__scs0]);
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl47_bX0[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (0)] + __inl19_xl[(__w0)*(8) + (4)]) - __inl19_xl[(__w0)*(8) + (7)]) - __inl19_xl[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl47_bY0[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (0)] + __inl19_yl[(__w0)*(8) + (4)]) - __inl19_yl[(__w0)*(8) + (7)]) - __inl19_yl[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl47_bZ0[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (0)] + __inl19_zl[(__w0)*(8) + (4)]) - __inl19_zl[(__w0)*(8) + (7)]) - __inl19_zl[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl47_bX1[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (4)] + __inl19_xl[(__w0)*(8) + (7)]) - __inl19_xl[(__w0)*(8) + (0)]) - __inl19_xl[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl47_bY1[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (4)] + __inl19_yl[(__w0)*(8) + (7)]) - __inl19_yl[(__w0)*(8) + (0)]) - __inl19_yl[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl47_bZ1[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (4)] + __inl19_zl[(__w0)*(8) + (7)]) - __inl19_zl[(__w0)*(8) + (0)]) - __inl19_zl[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl47_areaX[__w0] = (0.25 * ((__inl47_bY0[__w0] * __inl47_bZ1[__w0]) - (__inl47_bZ0[__w0] * __inl47_bY1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl47_areaY[__w0] = (0.25 * ((__inl47_bZ0[__w0] * __inl47_bX1[__w0]) - (__inl47_bX0[__w0] * __inl47_bZ1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl47_areaZ[__w0] = (0.25 * ((__inl47_bX0[__w0] * __inl47_bY1[__w0]) - (__inl47_bY0[__w0] * __inl47_bX1[__w0])));
          }
          __inl47_corners[0] = 3;
          __inl47_corners[1] = 7;
          __inl47_corners[2] = 4;
          __inl47_corners[3] = 0;
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg12[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl47_corners[__sc0]))*(3) + (0)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl47_corners[__sc0]))*(3) + (0)] = (__scg12[(__scs0)*(4) + (__sc0)] + __inl47_areaX[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg13[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl47_corners[__sc0]))*(3) + (1)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl47_corners[__sc0]))*(3) + (1)] = (__scg13[(__scs0)*(4) + (__sc0)] + __inl47_areaY[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg14[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl47_corners[__sc0]))*(3) + (2)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl47_corners[__sc0]))*(3) + (2)] = (__scg14[(__scs0)*(4) + (__sc0)] + __inl47_areaZ[__scs0]);
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl48_bX0[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (5)] + __inl19_xl[(__w0)*(8) + (6)]) - __inl19_xl[(__w0)*(8) + (7)]) - __inl19_xl[(__w0)*(8) + (4)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl48_bY0[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (5)] + __inl19_yl[(__w0)*(8) + (6)]) - __inl19_yl[(__w0)*(8) + (7)]) - __inl19_yl[(__w0)*(8) + (4)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl48_bZ0[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (5)] + __inl19_zl[(__w0)*(8) + (6)]) - __inl19_zl[(__w0)*(8) + (7)]) - __inl19_zl[(__w0)*(8) + (4)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl48_bX1[__w0] = (0.5 * (((__inl19_xl[(__w0)*(8) + (6)] + __inl19_xl[(__w0)*(8) + (7)]) - __inl19_xl[(__w0)*(8) + (5)]) - __inl19_xl[(__w0)*(8) + (4)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl48_bY1[__w0] = (0.5 * (((__inl19_yl[(__w0)*(8) + (6)] + __inl19_yl[(__w0)*(8) + (7)]) - __inl19_yl[(__w0)*(8) + (5)]) - __inl19_yl[(__w0)*(8) + (4)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl48_bZ1[__w0] = (0.5 * (((__inl19_zl[(__w0)*(8) + (6)] + __inl19_zl[(__w0)*(8) + (7)]) - __inl19_zl[(__w0)*(8) + (5)]) - __inl19_zl[(__w0)*(8) + (4)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl48_areaX[__w0] = (0.25 * ((__inl48_bY0[__w0] * __inl48_bZ1[__w0]) - (__inl48_bZ0[__w0] * __inl48_bY1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl48_areaY[__w0] = (0.25 * ((__inl48_bZ0[__w0] * __inl48_bX1[__w0]) - (__inl48_bX0[__w0] * __inl48_bZ1[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl48_areaZ[__w0] = (0.25 * ((__inl48_bX0[__w0] * __inl48_bY1[__w0]) - (__inl48_bY0[__w0] * __inl48_bX1[__w0])));
          }
          __inl48_corners[0] = 4;
          __inl48_corners[1] = 7;
          __inl48_corners[2] = 6;
          __inl48_corners[3] = 5;
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg15[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl48_corners[__sc0]))*(3) + (0)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl48_corners[__sc0]))*(3) + (0)] = (__scg15[(__scs0)*(4) + (__sc0)] + __inl48_areaX[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg16[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl48_corners[__sc0]))*(3) + (1)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl48_corners[__sc0]))*(3) + (1)] = (__scg16[(__scs0)*(4) + (__sc0)] + __inl48_areaY[__scs0]);
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __scg17[(__scs0)*(4) + (__sc0)] = __inl37_pf[((__scs0)*(8) + (__inl48_corners[__sc0]))*(3) + (2)];
            }
          }
          for (int64_t __scs0 = 0; __scs0 < numElem; ++__scs0) {
            for (int64_t __sc0 = 0; __sc0 < 4; ++__sc0) {
              __inl37_pf[((__scs0)*(8) + (__inl48_corners[__sc0]))*(3) + (2)] = (__scg17[(__scs0)*(4) + (__sc0)] + __inl48_areaZ[__scs0]);
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
                __inl19_b[((__w0)*(8) + (__w1))*(3) + (__w2)] = __inl37_pf[((__w0)*(8) + (__w1))*(3) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl19_sfx[(__w0)*(8) + (__w1)] = (-(__inl14_sig[__w0] * __inl19_b[((__w0)*(8) + (__w1))*(3) + (0)]));
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl19_sfy[(__w0)*(8) + (__w1)] = (-(__inl14_sig[__w0] * __inl19_b[((__w0)*(8) + (__w1))*(3) + (1)]));
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl19_sfz[(__w0)*(8) + (__w1)] = (-(__inl14_sig[__w0] * __inl19_b[((__w0)*(8) + (__w1))*(3) + (2)]));
            }
          }
          for (int64_t __sat1_0 = 0; __sat1_0 < numElem; ++__sat1_0) {
            for (int64_t __sat1_1 = 0; __sat1_1 < 8; ++__sat1_1) {
              fx[nodelist[(__sat1_0)*(8) + (__sat1_1)]] += __inl19_sfx[(__sat1_0)*(8) + (__sat1_1)];
            }
          }
          for (int64_t __sat2_0 = 0; __sat2_0 < numElem; ++__sat2_0) {
            for (int64_t __sat2_1 = 0; __sat2_1 < 8; ++__sat2_1) {
              fy[nodelist[(__sat2_0)*(8) + (__sat2_1)]] += __inl19_sfy[(__sat2_0)*(8) + (__sat2_1)];
            }
          }
          for (int64_t __sat3_0 = 0; __sat3_0 < numElem; ++__sat3_0) {
            for (int64_t __sat3_1 = 0; __sat3_1 < 8; ++__sat3_1) {
              fz[nodelist[(__sat3_0)*(8) + (__sat3_1)]] += __inl19_sfz[(__sat3_0)*(8) + (__sat3_1)];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl14_determ[__w0] = __inl19_determ[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl20_x1[(__w0)*(8) + (__w1)] = x[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl20_y1[(__w0)*(8) + (__w1)] = y[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl20_z1[(__w0)*(8) + (__w1)] = z[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              for (int64_t __w2 = 0; __w2 < 6; ++__w2) {
                __inl38_gx[((__w0)*(8) + (__w1))*(6) + (__w2)] = __inl20_x1[(__w0)*(8) + (_VOLU_PERM[(__w1)*(6) + (__w2)])];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              for (int64_t __w2 = 0; __w2 < 6; ++__w2) {
                __inl38_gy[((__w0)*(8) + (__w1))*(6) + (__w2)] = __inl20_y1[(__w0)*(8) + (_VOLU_PERM[(__w1)*(6) + (__w2)])];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              for (int64_t __w2 = 0; __w2 < 6; ++__w2) {
                __inl38_gz[((__w0)*(8) + (__w1))*(6) + (__w2)] = __inl20_z1[(__w0)*(8) + (_VOLU_PERM[(__w1)*(6) + (__w2)])];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl49_dvdx[(__w0)*(8) + (__w1)] = (((((((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (1)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (2)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (1)])) - ((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (1)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (1)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (2)]))) + ((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (4)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (4)]))) - ((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (4)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (4)]))) - ((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (2)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (5)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (5)]))) + ((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (5)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (2)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (5)])));
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl49_dvdy[(__w0)*(8) + (__w1)] = (((((((-(__inl38_gx[((__w0)*(8) + (__w1))*(6) + (1)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (2)])) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (1)])) + ((__inl38_gx[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (1)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (1)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (2)]))) - ((__inl38_gx[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (4)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (4)]))) + ((__inl38_gx[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (4)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (4)]))) + ((__inl38_gx[((__w0)*(8) + (__w1))*(6) + (2)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (5)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (5)]))) - ((__inl38_gx[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (5)]) * (__inl38_gz[((__w0)*(8) + (__w1))*(6) + (2)] + __inl38_gz[((__w0)*(8) + (__w1))*(6) + (5)])));
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl49_dvdz[(__w0)*(8) + (__w1)] = (((((((-(__inl38_gy[((__w0)*(8) + (__w1))*(6) + (1)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (2)])) * (__inl38_gx[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (1)])) + ((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (1)]) * (__inl38_gx[((__w0)*(8) + (__w1))*(6) + (1)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (2)]))) - ((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (4)]) * (__inl38_gx[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (4)]))) + ((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (4)]) * (__inl38_gx[((__w0)*(8) + (__w1))*(6) + (0)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (4)]))) + ((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (2)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (5)]) * (__inl38_gx[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (5)]))) - ((__inl38_gy[((__w0)*(8) + (__w1))*(6) + (3)] + __inl38_gy[((__w0)*(8) + (__w1))*(6) + (5)]) * (__inl38_gx[((__w0)*(8) + (__w1))*(6) + (2)] + __inl38_gx[((__w0)*(8) + (__w1))*(6) + (5)])));
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl20_dvdx[(__w0)*(8) + (__w1)] = (__inl49_dvdx[(__w0)*(8) + (__w1)] * 0.08333333333333333);
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl20_dvdy[(__w0)*(8) + (__w1)] = (__inl49_dvdy[(__w0)*(8) + (__w1)] * 0.08333333333333333);
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl20_dvdz[(__w0)*(8) + (__w1)] = (__inl49_dvdz[(__w0)*(8) + (__w1)] * 0.08333333333333333);
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl14_determ[__w0] = (volo[__w0] * v[__w0]);
          }
          if ((3.0 > 0.0)) {
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl39_volinv[__w0] = (1.0 / __inl14_determ[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < 8; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
                __inl39_gamma[(__w0)*(4) + (__w1)] = _GAMMA[(__w0)*(4) + (__w1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(numElem), (blasint)(4), (blasint)(8), 1.0, __inl20_x1, (blasint)(8), __inl39_gamma, (blasint)(4), 0.0, __mm1, (blasint)(4));
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
                __inl39_hourmodx[(__w0)*(4) + (__w1)] = __mm1[(__w0)*(4) + (__w1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(numElem), (blasint)(4), (blasint)(8), 1.0, __inl20_y1, (blasint)(8), __inl39_gamma, (blasint)(4), 0.0, __mm2, (blasint)(4));
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
                __inl39_hourmody[(__w0)*(4) + (__w1)] = __mm2[(__w0)*(4) + (__w1)];
              }
            }
            cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, (blasint)(numElem), (blasint)(4), (blasint)(8), 1.0, __inl20_z1, (blasint)(8), __inl39_gamma, (blasint)(4), 0.0, __mm3, (blasint)(4));
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
                __inl39_hourmodz[(__w0)*(4) + (__w1)] = __mm3[(__w0)*(4) + (__w1)];
              }
            }
            /* numpy: np.einsum('ei,ek->eik', __inl39_hourmodx, __inl20_dvdx) */
            for (int64_t __es_e = 0; __es_e < numElem; ++__es_e) {
              for (int64_t __es_i = 0; __es_i < 4; ++__es_i) {
                for (int64_t __es_k = 0; __es_k < 8; ++__es_k) {
                  __cb4[((__es_e)*(4) + (__es_i))*(8) + (__es_k)] = (__inl39_hourmodx[(__es_e)*(4) + (__es_i)] * __inl20_dvdx[(__es_e)*(8) + (__es_k)]);
                }
              }
            }
            /* numpy: np.einsum('ei,ek->eik', __inl39_hourmody, __inl20_dvdy) */
            for (int64_t __es_e = 0; __es_e < numElem; ++__es_e) {
              for (int64_t __es_i = 0; __es_i < 4; ++__es_i) {
                for (int64_t __es_k = 0; __es_k < 8; ++__es_k) {
                  __cb5[((__es_e)*(4) + (__es_i))*(8) + (__es_k)] = (__inl39_hourmody[(__es_e)*(4) + (__es_i)] * __inl20_dvdy[(__es_e)*(8) + (__es_k)]);
                }
              }
            }
            /* numpy: np.einsum('ei,ek->eik', __inl39_hourmodz, __inl20_dvdz) */
            for (int64_t __es_e = 0; __es_e < numElem; ++__es_e) {
              for (int64_t __es_i = 0; __es_i < 4; ++__es_i) {
                for (int64_t __es_k = 0; __es_k < 8; ++__es_k) {
                  __cb6[((__es_e)*(4) + (__es_i))*(8) + (__es_k)] = (__inl39_hourmodz[(__es_e)*(4) + (__es_i)] * __inl20_dvdz[(__es_e)*(8) + (__es_k)]);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
                for (int64_t __w2 = 0; __w2 < 8; ++__w2) {
                  __inl39_term[((__w0)*(4) + (__w1))*(8) + (__w2)] = ((__cb4[((__w0)*(4) + (__w1))*(8) + (__w2)] + __cb5[((__w0)*(4) + (__w1))*(8) + (__w2)]) + __cb6[((__w0)*(4) + (__w1))*(8) + (__w2)]);
                }
              }
            }
            /* numpy: np.transpose(__inl39_gamma) */
            for (int64_t __t0 = 0; __t0 < 8; ++__t0) {
              for (int64_t __t1 = 0; __t1 < 4; ++__t1) {
                __cb7[(__t1)*(8) + (__t0)] = __inl39_gamma[(__t0)*(4) + (__t1)];
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
                for (int64_t __w2 = 0; __w2 < 8; ++__w2) {
                  __inl39_hourgam[((__w0)*(4) + (__w1))*(8) + (__w2)] = (__cb7[(__w1)*(8) + (__w2)] - (__inl39_volinv[__w0] * __inl39_term[((__w0)*(4) + (__w1))*(8) + (__w2)]));
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl39_volume13[__w0] = cbrt(__inl14_determ[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl39_coefficient[__w0] = (((((-3.0) * 0.01) * ss[__w0]) * elemMass[__w0]) / __inl39_volume13[__w0]);
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
                __inl39_xd1[(__w0)*(8) + (__w1)] = xd[nodelist[(__w0)*(8) + (__w1)]];
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
                __inl39_yd1[(__w0)*(8) + (__w1)] = yd[nodelist[(__w0)*(8) + (__w1)]];
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
                __inl39_zd1[(__w0)*(8) + (__w1)] = zd[nodelist[(__w0)*(8) + (__w1)]];
              }
            }
            /* numpy: np.einsum('eik,ek->ei', __inl39_hourgam, __inl39_xd1) */
            for (int64_t __es_e = 0; __es_e < numElem; ++__es_e) {
              for (int64_t __es_i = 0; __es_i < 4; ++__es_i) {
                __cb8[(__es_e)*(4) + (__es_i)] = 0.0;
                for (int64_t __es_k = 0; __es_k < 8; ++__es_k) {
                  __cb8[(__es_e)*(4) + (__es_i)] += (__inl39_hourgam[((__es_e)*(4) + (__es_i))*(8) + (__es_k)] * __inl39_xd1[(__es_e)*(8) + (__es_k)]);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
                __inl39___inl1_hxx[(__w0)*(4) + (__w1)] = __cb8[(__w0)*(4) + (__w1)];
              }
            }
            /* numpy: np.einsum('ei,eik->ek', __inl39___inl1_hxx, __inl39_hourgam) */
            for (int64_t __es_e = 0; __es_e < numElem; ++__es_e) {
              for (int64_t __es_k = 0; __es_k < 8; ++__es_k) {
                __cb9[(__es_e)*(8) + (__es_k)] = 0.0;
                for (int64_t __es_i = 0; __es_i < 4; ++__es_i) {
                  __cb9[(__es_e)*(8) + (__es_k)] += (__inl39___inl1_hxx[(__es_e)*(4) + (__es_i)] * __inl39_hourgam[((__es_e)*(4) + (__es_i))*(8) + (__es_k)]);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
                __inl39_hgfx[(__w0)*(8) + (__w1)] = (__inl39_coefficient[__w0] * __cb9[(__w0)*(8) + (__w1)]);
              }
            }
            /* numpy: np.einsum('eik,ek->ei', __inl39_hourgam, __inl39_yd1) */
            for (int64_t __es_e = 0; __es_e < numElem; ++__es_e) {
              for (int64_t __es_i = 0; __es_i < 4; ++__es_i) {
                __cb10[(__es_e)*(4) + (__es_i)] = 0.0;
                for (int64_t __es_k = 0; __es_k < 8; ++__es_k) {
                  __cb10[(__es_e)*(4) + (__es_i)] += (__inl39_hourgam[((__es_e)*(4) + (__es_i))*(8) + (__es_k)] * __inl39_yd1[(__es_e)*(8) + (__es_k)]);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
                __inl39___inl2_hxx[(__w0)*(4) + (__w1)] = __cb10[(__w0)*(4) + (__w1)];
              }
            }
            /* numpy: np.einsum('ei,eik->ek', __inl39___inl2_hxx, __inl39_hourgam) */
            for (int64_t __es_e = 0; __es_e < numElem; ++__es_e) {
              for (int64_t __es_k = 0; __es_k < 8; ++__es_k) {
                __cb11[(__es_e)*(8) + (__es_k)] = 0.0;
                for (int64_t __es_i = 0; __es_i < 4; ++__es_i) {
                  __cb11[(__es_e)*(8) + (__es_k)] += (__inl39___inl2_hxx[(__es_e)*(4) + (__es_i)] * __inl39_hourgam[((__es_e)*(4) + (__es_i))*(8) + (__es_k)]);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
                __inl39_hgfy[(__w0)*(8) + (__w1)] = (__inl39_coefficient[__w0] * __cb11[(__w0)*(8) + (__w1)]);
              }
            }
            /* numpy: np.einsum('eik,ek->ei', __inl39_hourgam, __inl39_zd1) */
            for (int64_t __es_e = 0; __es_e < numElem; ++__es_e) {
              for (int64_t __es_i = 0; __es_i < 4; ++__es_i) {
                __cb12[(__es_e)*(4) + (__es_i)] = 0.0;
                for (int64_t __es_k = 0; __es_k < 8; ++__es_k) {
                  __cb12[(__es_e)*(4) + (__es_i)] += (__inl39_hourgam[((__es_e)*(4) + (__es_i))*(8) + (__es_k)] * __inl39_zd1[(__es_e)*(8) + (__es_k)]);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
                __inl39___inl3_hxx[(__w0)*(4) + (__w1)] = __cb12[(__w0)*(4) + (__w1)];
              }
            }
            /* numpy: np.einsum('ei,eik->ek', __inl39___inl3_hxx, __inl39_hourgam) */
            for (int64_t __es_e = 0; __es_e < numElem; ++__es_e) {
              for (int64_t __es_k = 0; __es_k < 8; ++__es_k) {
                __cb13[(__es_e)*(8) + (__es_k)] = 0.0;
                for (int64_t __es_i = 0; __es_i < 4; ++__es_i) {
                  __cb13[(__es_e)*(8) + (__es_k)] += (__inl39___inl3_hxx[(__es_e)*(4) + (__es_i)] * __inl39_hourgam[((__es_e)*(4) + (__es_i))*(8) + (__es_k)]);
                }
              }
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
                __inl39_hgfz[(__w0)*(8) + (__w1)] = (__inl39_coefficient[__w0] * __cb13[(__w0)*(8) + (__w1)]);
              }
            }
            for (int64_t __sat4_0 = 0; __sat4_0 < numElem; ++__sat4_0) {
              for (int64_t __sat4_1 = 0; __sat4_1 < 8; ++__sat4_1) {
                fx[nodelist[(__sat4_0)*(8) + (__sat4_1)]] += __inl39_hgfx[(__sat4_0)*(8) + (__sat4_1)];
              }
            }
            for (int64_t __sat5_0 = 0; __sat5_0 < numElem; ++__sat5_0) {
              for (int64_t __sat5_1 = 0; __sat5_1 < 8; ++__sat5_1) {
                fy[nodelist[(__sat5_0)*(8) + (__sat5_1)]] += __inl39_hgfy[(__sat5_0)*(8) + (__sat5_1)];
              }
            }
            for (int64_t __sat6_0 = 0; __sat6_0 < numElem; ++__sat6_0) {
              for (int64_t __sat6_1 = 0; __sat6_1 < 8; ++__sat6_1) {
                fz[nodelist[(__sat6_0)*(8) + (__sat6_1)]] += __inl39_hgfz[(__sat6_0)*(8) + (__sat6_1)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            xdd[__w0] = (fx[__w0] / nodalMass[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            ydd[__w0] = (fy[__w0] / nodalMass[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            zdd[__w0] = (fz[__w0] / nodalMass[__w0]);
          }
          for (int64_t __sc0 = 0; __sc0 < numSymm; ++__sc0) {
            xdd[symmX[__sc0]] = 0.0;
          }
          for (int64_t __sc0 = 0; __sc0 < numSymm; ++__sc0) {
            ydd[symmY[__sc0]] = 0.0;
          }
          for (int64_t __sc0 = 0; __sc0 < numSymm; ++__sc0) {
            zdd[symmZ[__sc0]] = 0.0;
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            __inl8_txd[__w0] = (xd[__w0] + (xdd[__w0] * deltatime));
          }
          /* numpy: np.where(fabs(__inl8_txd) < 1e-07, 0.0, __inl8_txd) */
          for (int64_t __r0 = 0; __r0 < numNode; ++__r0) {
            __cb14[__r0] = ((fabs(__inl8_txd[__r0]) < 1e-07) ? 0.0 : __inl8_txd[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            xd[__w0] = __cb14[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            __inl8_tyd[__w0] = (yd[__w0] + (ydd[__w0] * deltatime));
          }
          /* numpy: np.where(fabs(__inl8_tyd) < 1e-07, 0.0, __inl8_tyd) */
          for (int64_t __r0 = 0; __r0 < numNode; ++__r0) {
            __cb15[__r0] = ((fabs(__inl8_tyd[__r0]) < 1e-07) ? 0.0 : __inl8_tyd[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            yd[__w0] = __cb15[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            __inl8_tzd[__w0] = (zd[__w0] + (zdd[__w0] * deltatime));
          }
          /* numpy: np.where(fabs(__inl8_tzd) < 1e-07, 0.0, __inl8_tzd) */
          for (int64_t __r0 = 0; __r0 < numNode; ++__r0) {
            __cb16[__r0] = ((fabs(__inl8_tzd[__r0]) < 1e-07) ? 0.0 : __inl8_tzd[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            zd[__w0] = __cb16[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            x[__w0] = (x[__w0] + (xd[__w0] * deltatime));
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            y[__w0] = (y[__w0] + (yd[__w0] * deltatime));
          }
          for (int64_t __w0 = 0; __w0 < numNode; ++__w0) {
            z[__w0] = (z[__w0] + (zd[__w0] * deltatime));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __cb17[(__w0)*(8) + (__w1)] = x[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          /* numpy: np.copy(__cb17) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            for (int64_t __r1 = 0; __r1 < 8; ++__r1) {
              __cb18[(__r0)*(8) + (__r1)] = __cb17[(__r0)*(8) + (__r1)];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl15_xl1[(__w0)*(8) + (__w1)] = __cb18[(__w0)*(8) + (__w1)];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __cb19[(__w0)*(8) + (__w1)] = y[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          /* numpy: np.copy(__cb19) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            for (int64_t __r1 = 0; __r1 < 8; ++__r1) {
              __cb20[(__r0)*(8) + (__r1)] = __cb19[(__r0)*(8) + (__r1)];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl15_yl1[(__w0)*(8) + (__w1)] = __cb20[(__w0)*(8) + (__w1)];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __cb21[(__w0)*(8) + (__w1)] = z[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          /* numpy: np.copy(__cb21) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            for (int64_t __r1 = 0; __r1 < 8; ++__r1) {
              __cb22[(__r0)*(8) + (__r1)] = __cb21[(__r0)*(8) + (__r1)];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl15_zl1[(__w0)*(8) + (__w1)] = __cb22[(__w0)*(8) + (__w1)];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx61[__w0] = (__inl15_xl1[(__w0)*(8) + (6)] - __inl15_xl1[(__w0)*(8) + (1)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy61[__w0] = (__inl15_yl1[(__w0)*(8) + (6)] - __inl15_yl1[(__w0)*(8) + (1)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz61[__w0] = (__inl15_zl1[(__w0)*(8) + (6)] - __inl15_zl1[(__w0)*(8) + (1)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx70[__w0] = (__inl15_xl1[(__w0)*(8) + (7)] - __inl15_xl1[(__w0)*(8) + (0)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy70[__w0] = (__inl15_yl1[(__w0)*(8) + (7)] - __inl15_yl1[(__w0)*(8) + (0)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz70[__w0] = (__inl15_zl1[(__w0)*(8) + (7)] - __inl15_zl1[(__w0)*(8) + (0)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx63[__w0] = (__inl15_xl1[(__w0)*(8) + (6)] - __inl15_xl1[(__w0)*(8) + (3)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy63[__w0] = (__inl15_yl1[(__w0)*(8) + (6)] - __inl15_yl1[(__w0)*(8) + (3)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz63[__w0] = (__inl15_zl1[(__w0)*(8) + (6)] - __inl15_zl1[(__w0)*(8) + (3)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx20[__w0] = (__inl15_xl1[(__w0)*(8) + (2)] - __inl15_xl1[(__w0)*(8) + (0)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy20[__w0] = (__inl15_yl1[(__w0)*(8) + (2)] - __inl15_yl1[(__w0)*(8) + (0)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz20[__w0] = (__inl15_zl1[(__w0)*(8) + (2)] - __inl15_zl1[(__w0)*(8) + (0)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx50[__w0] = (__inl15_xl1[(__w0)*(8) + (5)] - __inl15_xl1[(__w0)*(8) + (0)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy50[__w0] = (__inl15_yl1[(__w0)*(8) + (5)] - __inl15_yl1[(__w0)*(8) + (0)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz50[__w0] = (__inl15_zl1[(__w0)*(8) + (5)] - __inl15_zl1[(__w0)*(8) + (0)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx64[__w0] = (__inl15_xl1[(__w0)*(8) + (6)] - __inl15_xl1[(__w0)*(8) + (4)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy64[__w0] = (__inl15_yl1[(__w0)*(8) + (6)] - __inl15_yl1[(__w0)*(8) + (4)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz64[__w0] = (__inl15_zl1[(__w0)*(8) + (6)] - __inl15_zl1[(__w0)*(8) + (4)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx31[__w0] = (__inl15_xl1[(__w0)*(8) + (3)] - __inl15_xl1[(__w0)*(8) + (1)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy31[__w0] = (__inl15_yl1[(__w0)*(8) + (3)] - __inl15_yl1[(__w0)*(8) + (1)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz31[__w0] = (__inl15_zl1[(__w0)*(8) + (3)] - __inl15_zl1[(__w0)*(8) + (1)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx72[__w0] = (__inl15_xl1[(__w0)*(8) + (7)] - __inl15_xl1[(__w0)*(8) + (2)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy72[__w0] = (__inl15_yl1[(__w0)*(8) + (7)] - __inl15_yl1[(__w0)*(8) + (2)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz72[__w0] = (__inl15_zl1[(__w0)*(8) + (7)] - __inl15_zl1[(__w0)*(8) + (2)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx43[__w0] = (__inl15_xl1[(__w0)*(8) + (4)] - __inl15_xl1[(__w0)*(8) + (3)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy43[__w0] = (__inl15_yl1[(__w0)*(8) + (4)] - __inl15_yl1[(__w0)*(8) + (3)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz43[__w0] = (__inl15_zl1[(__w0)*(8) + (4)] - __inl15_zl1[(__w0)*(8) + (3)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx57[__w0] = (__inl15_xl1[(__w0)*(8) + (5)] - __inl15_xl1[(__w0)*(8) + (7)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy57[__w0] = (__inl15_yl1[(__w0)*(8) + (5)] - __inl15_yl1[(__w0)*(8) + (7)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz57[__w0] = (__inl15_zl1[(__w0)*(8) + (5)] - __inl15_zl1[(__w0)*(8) + (7)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx14[__w0] = (__inl15_xl1[(__w0)*(8) + (1)] - __inl15_xl1[(__w0)*(8) + (4)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy14[__w0] = (__inl15_yl1[(__w0)*(8) + (1)] - __inl15_yl1[(__w0)*(8) + (4)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz14[__w0] = (__inl15_zl1[(__w0)*(8) + (1)] - __inl15_zl1[(__w0)*(8) + (4)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dx25[__w0] = (__inl15_xl1[(__w0)*(8) + (2)] - __inl15_xl1[(__w0)*(8) + (5)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dy25[__w0] = (__inl15_yl1[(__w0)*(8) + (2)] - __inl15_yl1[(__w0)*(8) + (5)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_dz25[__w0] = (__inl15_zl1[(__w0)*(8) + (2)] - __inl15_zl1[(__w0)*(8) + (5)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl21_vol[__w0] = ((((((__inl21_dx31[__w0] + __inl21_dx72[__w0]) * ((__inl21_dy63[__w0] * __inl21_dz20[__w0]) - (__inl21_dy20[__w0] * __inl21_dz63[__w0]))) + ((__inl21_dy31[__w0] + __inl21_dy72[__w0]) * ((__inl21_dx20[__w0] * __inl21_dz63[__w0]) - (__inl21_dx63[__w0] * __inl21_dz20[__w0])))) + ((__inl21_dz31[__w0] + __inl21_dz72[__w0]) * ((__inl21_dx63[__w0] * __inl21_dy20[__w0]) - (__inl21_dx20[__w0] * __inl21_dy63[__w0])))) + ((((__inl21_dx43[__w0] + __inl21_dx57[__w0]) * ((__inl21_dy64[__w0] * __inl21_dz70[__w0]) - (__inl21_dy70[__w0] * __inl21_dz64[__w0]))) + ((__inl21_dy43[__w0] + __inl21_dy57[__w0]) * ((__inl21_dx70[__w0] * __inl21_dz64[__w0]) - (__inl21_dx64[__w0] * __inl21_dz70[__w0])))) + ((__inl21_dz43[__w0] + __inl21_dz57[__w0]) * ((__inl21_dx64[__w0] * __inl21_dy70[__w0]) - (__inl21_dx70[__w0] * __inl21_dy64[__w0]))))) + ((((__inl21_dx14[__w0] + __inl21_dx25[__w0]) * ((__inl21_dy61[__w0] * __inl21_dz50[__w0]) - (__inl21_dy50[__w0] * __inl21_dz61[__w0]))) + ((__inl21_dy14[__w0] + __inl21_dy25[__w0]) * ((__inl21_dx50[__w0] * __inl21_dz61[__w0]) - (__inl21_dx61[__w0] * __inl21_dz50[__w0])))) + ((__inl21_dz14[__w0] + __inl21_dz25[__w0]) * ((__inl21_dx61[__w0] * __inl21_dy50[__w0]) - (__inl21_dx50[__w0] * __inl21_dy61[__w0])))));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl15_volume[__w0] = (__inl21_vol[__w0] * 0.08333333333333333);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl15_relvol[__w0] = (__inl15_volume[__w0] / volo[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            vnew[__w0] = __inl15_relvol[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            delv[__w0] = (__inl15_relvol[__w0] - v[__w0]);
          }
          memset(__inl22_charl, 0, (size_t)((numElem)) * sizeof(double));
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fx[__w0] = ((__inl15_xl1[(__w0)*(8) + (2)] - __inl15_xl1[(__w0)*(8) + (0)]) - (__inl15_xl1[(__w0)*(8) + (3)] - __inl15_xl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fy[__w0] = ((__inl15_yl1[(__w0)*(8) + (2)] - __inl15_yl1[(__w0)*(8) + (0)]) - (__inl15_yl1[(__w0)*(8) + (3)] - __inl15_yl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fz[__w0] = ((__inl15_zl1[(__w0)*(8) + (2)] - __inl15_zl1[(__w0)*(8) + (0)]) - (__inl15_zl1[(__w0)*(8) + (3)] - __inl15_zl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gx[__w0] = ((__inl15_xl1[(__w0)*(8) + (2)] - __inl15_xl1[(__w0)*(8) + (0)]) + (__inl15_xl1[(__w0)*(8) + (3)] - __inl15_xl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gy[__w0] = ((__inl15_yl1[(__w0)*(8) + (2)] - __inl15_yl1[(__w0)*(8) + (0)]) + (__inl15_yl1[(__w0)*(8) + (3)] - __inl15_yl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gz[__w0] = ((__inl15_zl1[(__w0)*(8) + (2)] - __inl15_zl1[(__w0)*(8) + (0)]) + (__inl15_zl1[(__w0)*(8) + (3)] - __inl15_zl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_ar[__w0] = (((((__inl22___inl1_fx[__w0] * __inl22___inl1_fx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_fy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_fz[__w0])) * (((__inl22___inl1_gx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_gy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_gz[__w0] * __inl22___inl1_gz[__w0]))) - ((((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0])) * (((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0]))));
          }
          /* numpy: np.maximum(__inl22_ar, __inl22_charl) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb23[__r0] = max(__inl22_ar[__r0], __inl22_charl[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_charl[__w0] = __cb23[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fx[__w0] = ((__inl15_xl1[(__w0)*(8) + (6)] - __inl15_xl1[(__w0)*(8) + (4)]) - (__inl15_xl1[(__w0)*(8) + (7)] - __inl15_xl1[(__w0)*(8) + (5)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fy[__w0] = ((__inl15_yl1[(__w0)*(8) + (6)] - __inl15_yl1[(__w0)*(8) + (4)]) - (__inl15_yl1[(__w0)*(8) + (7)] - __inl15_yl1[(__w0)*(8) + (5)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fz[__w0] = ((__inl15_zl1[(__w0)*(8) + (6)] - __inl15_zl1[(__w0)*(8) + (4)]) - (__inl15_zl1[(__w0)*(8) + (7)] - __inl15_zl1[(__w0)*(8) + (5)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gx[__w0] = ((__inl15_xl1[(__w0)*(8) + (6)] - __inl15_xl1[(__w0)*(8) + (4)]) + (__inl15_xl1[(__w0)*(8) + (7)] - __inl15_xl1[(__w0)*(8) + (5)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gy[__w0] = ((__inl15_yl1[(__w0)*(8) + (6)] - __inl15_yl1[(__w0)*(8) + (4)]) + (__inl15_yl1[(__w0)*(8) + (7)] - __inl15_yl1[(__w0)*(8) + (5)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gz[__w0] = ((__inl15_zl1[(__w0)*(8) + (6)] - __inl15_zl1[(__w0)*(8) + (4)]) + (__inl15_zl1[(__w0)*(8) + (7)] - __inl15_zl1[(__w0)*(8) + (5)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_ar[__w0] = (((((__inl22___inl1_fx[__w0] * __inl22___inl1_fx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_fy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_fz[__w0])) * (((__inl22___inl1_gx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_gy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_gz[__w0] * __inl22___inl1_gz[__w0]))) - ((((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0])) * (((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0]))));
          }
          /* numpy: np.maximum(__inl22_ar, __inl22_charl) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb24[__r0] = max(__inl22_ar[__r0], __inl22_charl[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_charl[__w0] = __cb24[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fx[__w0] = ((__inl15_xl1[(__w0)*(8) + (5)] - __inl15_xl1[(__w0)*(8) + (0)]) - (__inl15_xl1[(__w0)*(8) + (4)] - __inl15_xl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fy[__w0] = ((__inl15_yl1[(__w0)*(8) + (5)] - __inl15_yl1[(__w0)*(8) + (0)]) - (__inl15_yl1[(__w0)*(8) + (4)] - __inl15_yl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fz[__w0] = ((__inl15_zl1[(__w0)*(8) + (5)] - __inl15_zl1[(__w0)*(8) + (0)]) - (__inl15_zl1[(__w0)*(8) + (4)] - __inl15_zl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gx[__w0] = ((__inl15_xl1[(__w0)*(8) + (5)] - __inl15_xl1[(__w0)*(8) + (0)]) + (__inl15_xl1[(__w0)*(8) + (4)] - __inl15_xl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gy[__w0] = ((__inl15_yl1[(__w0)*(8) + (5)] - __inl15_yl1[(__w0)*(8) + (0)]) + (__inl15_yl1[(__w0)*(8) + (4)] - __inl15_yl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gz[__w0] = ((__inl15_zl1[(__w0)*(8) + (5)] - __inl15_zl1[(__w0)*(8) + (0)]) + (__inl15_zl1[(__w0)*(8) + (4)] - __inl15_zl1[(__w0)*(8) + (1)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_ar[__w0] = (((((__inl22___inl1_fx[__w0] * __inl22___inl1_fx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_fy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_fz[__w0])) * (((__inl22___inl1_gx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_gy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_gz[__w0] * __inl22___inl1_gz[__w0]))) - ((((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0])) * (((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0]))));
          }
          /* numpy: np.maximum(__inl22_ar, __inl22_charl) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb25[__r0] = max(__inl22_ar[__r0], __inl22_charl[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_charl[__w0] = __cb25[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fx[__w0] = ((__inl15_xl1[(__w0)*(8) + (6)] - __inl15_xl1[(__w0)*(8) + (1)]) - (__inl15_xl1[(__w0)*(8) + (5)] - __inl15_xl1[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fy[__w0] = ((__inl15_yl1[(__w0)*(8) + (6)] - __inl15_yl1[(__w0)*(8) + (1)]) - (__inl15_yl1[(__w0)*(8) + (5)] - __inl15_yl1[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fz[__w0] = ((__inl15_zl1[(__w0)*(8) + (6)] - __inl15_zl1[(__w0)*(8) + (1)]) - (__inl15_zl1[(__w0)*(8) + (5)] - __inl15_zl1[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gx[__w0] = ((__inl15_xl1[(__w0)*(8) + (6)] - __inl15_xl1[(__w0)*(8) + (1)]) + (__inl15_xl1[(__w0)*(8) + (5)] - __inl15_xl1[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gy[__w0] = ((__inl15_yl1[(__w0)*(8) + (6)] - __inl15_yl1[(__w0)*(8) + (1)]) + (__inl15_yl1[(__w0)*(8) + (5)] - __inl15_yl1[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gz[__w0] = ((__inl15_zl1[(__w0)*(8) + (6)] - __inl15_zl1[(__w0)*(8) + (1)]) + (__inl15_zl1[(__w0)*(8) + (5)] - __inl15_zl1[(__w0)*(8) + (2)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_ar[__w0] = (((((__inl22___inl1_fx[__w0] * __inl22___inl1_fx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_fy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_fz[__w0])) * (((__inl22___inl1_gx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_gy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_gz[__w0] * __inl22___inl1_gz[__w0]))) - ((((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0])) * (((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0]))));
          }
          /* numpy: np.maximum(__inl22_ar, __inl22_charl) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb26[__r0] = max(__inl22_ar[__r0], __inl22_charl[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_charl[__w0] = __cb26[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fx[__w0] = ((__inl15_xl1[(__w0)*(8) + (7)] - __inl15_xl1[(__w0)*(8) + (2)]) - (__inl15_xl1[(__w0)*(8) + (6)] - __inl15_xl1[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fy[__w0] = ((__inl15_yl1[(__w0)*(8) + (7)] - __inl15_yl1[(__w0)*(8) + (2)]) - (__inl15_yl1[(__w0)*(8) + (6)] - __inl15_yl1[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fz[__w0] = ((__inl15_zl1[(__w0)*(8) + (7)] - __inl15_zl1[(__w0)*(8) + (2)]) - (__inl15_zl1[(__w0)*(8) + (6)] - __inl15_zl1[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gx[__w0] = ((__inl15_xl1[(__w0)*(8) + (7)] - __inl15_xl1[(__w0)*(8) + (2)]) + (__inl15_xl1[(__w0)*(8) + (6)] - __inl15_xl1[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gy[__w0] = ((__inl15_yl1[(__w0)*(8) + (7)] - __inl15_yl1[(__w0)*(8) + (2)]) + (__inl15_yl1[(__w0)*(8) + (6)] - __inl15_yl1[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gz[__w0] = ((__inl15_zl1[(__w0)*(8) + (7)] - __inl15_zl1[(__w0)*(8) + (2)]) + (__inl15_zl1[(__w0)*(8) + (6)] - __inl15_zl1[(__w0)*(8) + (3)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_ar[__w0] = (((((__inl22___inl1_fx[__w0] * __inl22___inl1_fx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_fy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_fz[__w0])) * (((__inl22___inl1_gx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_gy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_gz[__w0] * __inl22___inl1_gz[__w0]))) - ((((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0])) * (((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0]))));
          }
          /* numpy: np.maximum(__inl22_ar, __inl22_charl) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb27[__r0] = max(__inl22_ar[__r0], __inl22_charl[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_charl[__w0] = __cb27[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fx[__w0] = ((__inl15_xl1[(__w0)*(8) + (4)] - __inl15_xl1[(__w0)*(8) + (3)]) - (__inl15_xl1[(__w0)*(8) + (7)] - __inl15_xl1[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fy[__w0] = ((__inl15_yl1[(__w0)*(8) + (4)] - __inl15_yl1[(__w0)*(8) + (3)]) - (__inl15_yl1[(__w0)*(8) + (7)] - __inl15_yl1[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_fz[__w0] = ((__inl15_zl1[(__w0)*(8) + (4)] - __inl15_zl1[(__w0)*(8) + (3)]) - (__inl15_zl1[(__w0)*(8) + (7)] - __inl15_zl1[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gx[__w0] = ((__inl15_xl1[(__w0)*(8) + (4)] - __inl15_xl1[(__w0)*(8) + (3)]) + (__inl15_xl1[(__w0)*(8) + (7)] - __inl15_xl1[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gy[__w0] = ((__inl15_yl1[(__w0)*(8) + (4)] - __inl15_yl1[(__w0)*(8) + (3)]) + (__inl15_yl1[(__w0)*(8) + (7)] - __inl15_yl1[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22___inl1_gz[__w0] = ((__inl15_zl1[(__w0)*(8) + (4)] - __inl15_zl1[(__w0)*(8) + (3)]) + (__inl15_zl1[(__w0)*(8) + (7)] - __inl15_zl1[(__w0)*(8) + (0)]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_ar[__w0] = (((((__inl22___inl1_fx[__w0] * __inl22___inl1_fx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_fy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_fz[__w0])) * (((__inl22___inl1_gx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_gy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_gz[__w0] * __inl22___inl1_gz[__w0]))) - ((((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0])) * (((__inl22___inl1_fx[__w0] * __inl22___inl1_gx[__w0]) + (__inl22___inl1_fy[__w0] * __inl22___inl1_gy[__w0])) + (__inl22___inl1_fz[__w0] * __inl22___inl1_gz[__w0]))));
          }
          /* numpy: np.maximum(__inl22_ar, __inl22_charl) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb28[__r0] = max(__inl22_ar[__r0], __inl22_charl[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl22_charl[__w0] = __cb28[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            arealg[__w0] = ((4.0 * __inl15_volume[__w0]) / sqrt(__inl22_charl[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl15_xdl[(__w0)*(8) + (__w1)] = xd[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl15_ydl[(__w0)*(8) + (__w1)] = yd[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl15_zdl[(__w0)*(8) + (__w1)] = zd[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          __inl15_dt2 = (0.5 * deltatime);
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl15_xl2[(__w0)*(8) + (__w1)] = (__inl15_xl1[(__w0)*(8) + (__w1)] - (__inl15_dt2 * __inl15_xdl[(__w0)*(8) + (__w1)]));
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl15_yl2[(__w0)*(8) + (__w1)] = (__inl15_yl1[(__w0)*(8) + (__w1)] - (__inl15_dt2 * __inl15_ydl[(__w0)*(8) + (__w1)]));
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl15_zl2[(__w0)*(8) + (__w1)] = (__inl15_zl1[(__w0)*(8) + (__w1)] - (__inl15_dt2 * __inl15_zdl[(__w0)*(8) + (__w1)]));
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_fjxxi[__w0] = (0.125 * ((((__inl15_xl2[(__w0)*(8) + (6)] - __inl15_xl2[(__w0)*(8) + (0)]) + (__inl15_xl2[(__w0)*(8) + (5)] - __inl15_xl2[(__w0)*(8) + (3)])) - (__inl15_xl2[(__w0)*(8) + (7)] - __inl15_xl2[(__w0)*(8) + (1)])) - (__inl15_xl2[(__w0)*(8) + (4)] - __inl15_xl2[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_fjxet[__w0] = (0.125 * ((((__inl15_xl2[(__w0)*(8) + (6)] - __inl15_xl2[(__w0)*(8) + (0)]) - (__inl15_xl2[(__w0)*(8) + (5)] - __inl15_xl2[(__w0)*(8) + (3)])) + (__inl15_xl2[(__w0)*(8) + (7)] - __inl15_xl2[(__w0)*(8) + (1)])) - (__inl15_xl2[(__w0)*(8) + (4)] - __inl15_xl2[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_fjxze[__w0] = (0.125 * ((((__inl15_xl2[(__w0)*(8) + (6)] - __inl15_xl2[(__w0)*(8) + (0)]) + (__inl15_xl2[(__w0)*(8) + (5)] - __inl15_xl2[(__w0)*(8) + (3)])) + (__inl15_xl2[(__w0)*(8) + (7)] - __inl15_xl2[(__w0)*(8) + (1)])) + (__inl15_xl2[(__w0)*(8) + (4)] - __inl15_xl2[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_fjyxi[__w0] = (0.125 * ((((__inl15_yl2[(__w0)*(8) + (6)] - __inl15_yl2[(__w0)*(8) + (0)]) + (__inl15_yl2[(__w0)*(8) + (5)] - __inl15_yl2[(__w0)*(8) + (3)])) - (__inl15_yl2[(__w0)*(8) + (7)] - __inl15_yl2[(__w0)*(8) + (1)])) - (__inl15_yl2[(__w0)*(8) + (4)] - __inl15_yl2[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_fjyet[__w0] = (0.125 * ((((__inl15_yl2[(__w0)*(8) + (6)] - __inl15_yl2[(__w0)*(8) + (0)]) - (__inl15_yl2[(__w0)*(8) + (5)] - __inl15_yl2[(__w0)*(8) + (3)])) + (__inl15_yl2[(__w0)*(8) + (7)] - __inl15_yl2[(__w0)*(8) + (1)])) - (__inl15_yl2[(__w0)*(8) + (4)] - __inl15_yl2[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_fjyze[__w0] = (0.125 * ((((__inl15_yl2[(__w0)*(8) + (6)] - __inl15_yl2[(__w0)*(8) + (0)]) + (__inl15_yl2[(__w0)*(8) + (5)] - __inl15_yl2[(__w0)*(8) + (3)])) + (__inl15_yl2[(__w0)*(8) + (7)] - __inl15_yl2[(__w0)*(8) + (1)])) + (__inl15_yl2[(__w0)*(8) + (4)] - __inl15_yl2[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_fjzxi[__w0] = (0.125 * ((((__inl15_zl2[(__w0)*(8) + (6)] - __inl15_zl2[(__w0)*(8) + (0)]) + (__inl15_zl2[(__w0)*(8) + (5)] - __inl15_zl2[(__w0)*(8) + (3)])) - (__inl15_zl2[(__w0)*(8) + (7)] - __inl15_zl2[(__w0)*(8) + (1)])) - (__inl15_zl2[(__w0)*(8) + (4)] - __inl15_zl2[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_fjzet[__w0] = (0.125 * ((((__inl15_zl2[(__w0)*(8) + (6)] - __inl15_zl2[(__w0)*(8) + (0)]) - (__inl15_zl2[(__w0)*(8) + (5)] - __inl15_zl2[(__w0)*(8) + (3)])) + (__inl15_zl2[(__w0)*(8) + (7)] - __inl15_zl2[(__w0)*(8) + (1)])) - (__inl15_zl2[(__w0)*(8) + (4)] - __inl15_zl2[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_fjzze[__w0] = (0.125 * ((((__inl15_zl2[(__w0)*(8) + (6)] - __inl15_zl2[(__w0)*(8) + (0)]) + (__inl15_zl2[(__w0)*(8) + (5)] - __inl15_zl2[(__w0)*(8) + (3)])) + (__inl15_zl2[(__w0)*(8) + (7)] - __inl15_zl2[(__w0)*(8) + (1)])) + (__inl15_zl2[(__w0)*(8) + (4)] - __inl15_zl2[(__w0)*(8) + (2)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_cjxxi[__w0] = ((__inl23_fjyet[__w0] * __inl23_fjzze[__w0]) - (__inl23_fjzet[__w0] * __inl23_fjyze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_cjxet[__w0] = ((-(__inl23_fjyxi[__w0] * __inl23_fjzze[__w0])) + (__inl23_fjzxi[__w0] * __inl23_fjyze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_cjxze[__w0] = ((__inl23_fjyxi[__w0] * __inl23_fjzet[__w0]) - (__inl23_fjzxi[__w0] * __inl23_fjyet[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_cjyxi[__w0] = ((-(__inl23_fjxet[__w0] * __inl23_fjzze[__w0])) + (__inl23_fjzet[__w0] * __inl23_fjxze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_cjyet[__w0] = ((__inl23_fjxxi[__w0] * __inl23_fjzze[__w0]) - (__inl23_fjzxi[__w0] * __inl23_fjxze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_cjyze[__w0] = ((-(__inl23_fjxxi[__w0] * __inl23_fjzet[__w0])) + (__inl23_fjzxi[__w0] * __inl23_fjxet[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_cjzxi[__w0] = ((__inl23_fjxet[__w0] * __inl23_fjyze[__w0]) - (__inl23_fjyet[__w0] * __inl23_fjxze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_cjzet[__w0] = ((-(__inl23_fjxxi[__w0] * __inl23_fjyze[__w0])) + (__inl23_fjyxi[__w0] * __inl23_fjxze[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_cjzze[__w0] = ((__inl23_fjxxi[__w0] * __inl23_fjyet[__w0]) - (__inl23_fjyxi[__w0] * __inl23_fjxet[__w0]));
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (0))*(3) + (0)] = (((-__inl23_cjxxi[si0]) - __inl23_cjxet[si0]) - __inl23_cjxze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (1))*(3) + (0)] = ((__inl23_cjxxi[si0] - __inl23_cjxet[si0]) - __inl23_cjxze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (2))*(3) + (0)] = ((__inl23_cjxxi[si0] + __inl23_cjxet[si0]) - __inl23_cjxze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (3))*(3) + (0)] = (((-__inl23_cjxxi[si0]) + __inl23_cjxet[si0]) - __inl23_cjxze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (4))*(3) + (0)] = (-__inl23_b[((si0)*(8) + (2))*(3) + (0)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (5))*(3) + (0)] = (-__inl23_b[((si0)*(8) + (3))*(3) + (0)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (6))*(3) + (0)] = (-__inl23_b[((si0)*(8) + (0))*(3) + (0)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (7))*(3) + (0)] = (-__inl23_b[((si0)*(8) + (1))*(3) + (0)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (0))*(3) + (1)] = (((-__inl23_cjyxi[si0]) - __inl23_cjyet[si0]) - __inl23_cjyze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (1))*(3) + (1)] = ((__inl23_cjyxi[si0] - __inl23_cjyet[si0]) - __inl23_cjyze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (2))*(3) + (1)] = ((__inl23_cjyxi[si0] + __inl23_cjyet[si0]) - __inl23_cjyze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (3))*(3) + (1)] = (((-__inl23_cjyxi[si0]) + __inl23_cjyet[si0]) - __inl23_cjyze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (4))*(3) + (1)] = (-__inl23_b[((si0)*(8) + (2))*(3) + (1)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (5))*(3) + (1)] = (-__inl23_b[((si0)*(8) + (3))*(3) + (1)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (6))*(3) + (1)] = (-__inl23_b[((si0)*(8) + (0))*(3) + (1)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (7))*(3) + (1)] = (-__inl23_b[((si0)*(8) + (1))*(3) + (1)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (0))*(3) + (2)] = (((-__inl23_cjzxi[si0]) - __inl23_cjzet[si0]) - __inl23_cjzze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (1))*(3) + (2)] = ((__inl23_cjzxi[si0] - __inl23_cjzet[si0]) - __inl23_cjzze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (2))*(3) + (2)] = ((__inl23_cjzxi[si0] + __inl23_cjzet[si0]) - __inl23_cjzze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (3))*(3) + (2)] = (((-__inl23_cjzxi[si0]) + __inl23_cjzet[si0]) - __inl23_cjzze[si0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (4))*(3) + (2)] = (-__inl23_b[((si0)*(8) + (2))*(3) + (2)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (5))*(3) + (2)] = (-__inl23_b[((si0)*(8) + (3))*(3) + (2)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (6))*(3) + (2)] = (-__inl23_b[((si0)*(8) + (0))*(3) + (2)]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl23_b[((si0)*(8) + (7))*(3) + (2)] = (-__inl23_b[((si0)*(8) + (1))*(3) + (2)]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl23_volume[__w0] = (8.0 * (((__inl23_fjxet[__w0] * __inl23_cjxet[__w0]) + (__inl23_fjyet[__w0] * __inl23_cjyet[__w0])) + (__inl23_fjzet[__w0] * __inl23_cjzet[__w0])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
                __inl15_b[((__w0)*(8) + (__w1))*(3) + (__w2)] = __inl23_b[((__w0)*(8) + (__w1))*(3) + (__w2)];
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl15_detJ[__w0] = __inl23_volume[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl24_inv[__w0] = (1.0 / __inl15_detJ[__w0]);
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl24_d[(si0)*(6) + (0)] = (__inl24_inv[si0] * ((((__inl15_b[((si0)*(8) + (0))*(3) + (0)] * (__inl15_xdl[(si0)*(8) + (0)] - __inl15_xdl[(si0)*(8) + (6)])) + (__inl15_b[((si0)*(8) + (1))*(3) + (0)] * (__inl15_xdl[(si0)*(8) + (1)] - __inl15_xdl[(si0)*(8) + (7)]))) + (__inl15_b[((si0)*(8) + (2))*(3) + (0)] * (__inl15_xdl[(si0)*(8) + (2)] - __inl15_xdl[(si0)*(8) + (4)]))) + (__inl15_b[((si0)*(8) + (3))*(3) + (0)] * (__inl15_xdl[(si0)*(8) + (3)] - __inl15_xdl[(si0)*(8) + (5)]))));
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl24_d[(si0)*(6) + (1)] = (__inl24_inv[si0] * ((((__inl15_b[((si0)*(8) + (0))*(3) + (1)] * (__inl15_ydl[(si0)*(8) + (0)] - __inl15_ydl[(si0)*(8) + (6)])) + (__inl15_b[((si0)*(8) + (1))*(3) + (1)] * (__inl15_ydl[(si0)*(8) + (1)] - __inl15_ydl[(si0)*(8) + (7)]))) + (__inl15_b[((si0)*(8) + (2))*(3) + (1)] * (__inl15_ydl[(si0)*(8) + (2)] - __inl15_ydl[(si0)*(8) + (4)]))) + (__inl15_b[((si0)*(8) + (3))*(3) + (1)] * (__inl15_ydl[(si0)*(8) + (3)] - __inl15_ydl[(si0)*(8) + (5)]))));
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl24_d[(si0)*(6) + (2)] = (__inl24_inv[si0] * ((((__inl15_b[((si0)*(8) + (0))*(3) + (2)] * (__inl15_zdl[(si0)*(8) + (0)] - __inl15_zdl[(si0)*(8) + (6)])) + (__inl15_b[((si0)*(8) + (1))*(3) + (2)] * (__inl15_zdl[(si0)*(8) + (1)] - __inl15_zdl[(si0)*(8) + (7)]))) + (__inl15_b[((si0)*(8) + (2))*(3) + (2)] * (__inl15_zdl[(si0)*(8) + (2)] - __inl15_zdl[(si0)*(8) + (4)]))) + (__inl15_b[((si0)*(8) + (3))*(3) + (2)] * (__inl15_zdl[(si0)*(8) + (3)] - __inl15_zdl[(si0)*(8) + (5)]))));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl24_dyddx[__w0] = (__inl24_inv[__w0] * ((((__inl15_b[((__w0)*(8) + (0))*(3) + (0)] * (__inl15_ydl[(__w0)*(8) + (0)] - __inl15_ydl[(__w0)*(8) + (6)])) + (__inl15_b[((__w0)*(8) + (1))*(3) + (0)] * (__inl15_ydl[(__w0)*(8) + (1)] - __inl15_ydl[(__w0)*(8) + (7)]))) + (__inl15_b[((__w0)*(8) + (2))*(3) + (0)] * (__inl15_ydl[(__w0)*(8) + (2)] - __inl15_ydl[(__w0)*(8) + (4)]))) + (__inl15_b[((__w0)*(8) + (3))*(3) + (0)] * (__inl15_ydl[(__w0)*(8) + (3)] - __inl15_ydl[(__w0)*(8) + (5)]))));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl24_dxddy[__w0] = (__inl24_inv[__w0] * ((((__inl15_b[((__w0)*(8) + (0))*(3) + (1)] * (__inl15_xdl[(__w0)*(8) + (0)] - __inl15_xdl[(__w0)*(8) + (6)])) + (__inl15_b[((__w0)*(8) + (1))*(3) + (1)] * (__inl15_xdl[(__w0)*(8) + (1)] - __inl15_xdl[(__w0)*(8) + (7)]))) + (__inl15_b[((__w0)*(8) + (2))*(3) + (1)] * (__inl15_xdl[(__w0)*(8) + (2)] - __inl15_xdl[(__w0)*(8) + (4)]))) + (__inl15_b[((__w0)*(8) + (3))*(3) + (1)] * (__inl15_xdl[(__w0)*(8) + (3)] - __inl15_xdl[(__w0)*(8) + (5)]))));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl24_dzddx[__w0] = (__inl24_inv[__w0] * ((((__inl15_b[((__w0)*(8) + (0))*(3) + (0)] * (__inl15_zdl[(__w0)*(8) + (0)] - __inl15_zdl[(__w0)*(8) + (6)])) + (__inl15_b[((__w0)*(8) + (1))*(3) + (0)] * (__inl15_zdl[(__w0)*(8) + (1)] - __inl15_zdl[(__w0)*(8) + (7)]))) + (__inl15_b[((__w0)*(8) + (2))*(3) + (0)] * (__inl15_zdl[(__w0)*(8) + (2)] - __inl15_zdl[(__w0)*(8) + (4)]))) + (__inl15_b[((__w0)*(8) + (3))*(3) + (0)] * (__inl15_zdl[(__w0)*(8) + (3)] - __inl15_zdl[(__w0)*(8) + (5)]))));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl24_dxddz[__w0] = (__inl24_inv[__w0] * ((((__inl15_b[((__w0)*(8) + (0))*(3) + (2)] * (__inl15_xdl[(__w0)*(8) + (0)] - __inl15_xdl[(__w0)*(8) + (6)])) + (__inl15_b[((__w0)*(8) + (1))*(3) + (2)] * (__inl15_xdl[(__w0)*(8) + (1)] - __inl15_xdl[(__w0)*(8) + (7)]))) + (__inl15_b[((__w0)*(8) + (2))*(3) + (2)] * (__inl15_xdl[(__w0)*(8) + (2)] - __inl15_xdl[(__w0)*(8) + (4)]))) + (__inl15_b[((__w0)*(8) + (3))*(3) + (2)] * (__inl15_xdl[(__w0)*(8) + (3)] - __inl15_xdl[(__w0)*(8) + (5)]))));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl24_dzddy[__w0] = (__inl24_inv[__w0] * ((((__inl15_b[((__w0)*(8) + (0))*(3) + (1)] * (__inl15_zdl[(__w0)*(8) + (0)] - __inl15_zdl[(__w0)*(8) + (6)])) + (__inl15_b[((__w0)*(8) + (1))*(3) + (1)] * (__inl15_zdl[(__w0)*(8) + (1)] - __inl15_zdl[(__w0)*(8) + (7)]))) + (__inl15_b[((__w0)*(8) + (2))*(3) + (1)] * (__inl15_zdl[(__w0)*(8) + (2)] - __inl15_zdl[(__w0)*(8) + (4)]))) + (__inl15_b[((__w0)*(8) + (3))*(3) + (1)] * (__inl15_zdl[(__w0)*(8) + (3)] - __inl15_zdl[(__w0)*(8) + (5)]))));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl24_dyddz[__w0] = (__inl24_inv[__w0] * ((((__inl15_b[((__w0)*(8) + (0))*(3) + (2)] * (__inl15_ydl[(__w0)*(8) + (0)] - __inl15_ydl[(__w0)*(8) + (6)])) + (__inl15_b[((__w0)*(8) + (1))*(3) + (2)] * (__inl15_ydl[(__w0)*(8) + (1)] - __inl15_ydl[(__w0)*(8) + (7)]))) + (__inl15_b[((__w0)*(8) + (2))*(3) + (2)] * (__inl15_ydl[(__w0)*(8) + (2)] - __inl15_ydl[(__w0)*(8) + (4)]))) + (__inl15_b[((__w0)*(8) + (3))*(3) + (2)] * (__inl15_ydl[(__w0)*(8) + (3)] - __inl15_ydl[(__w0)*(8) + (5)]))));
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl24_d[(si0)*(6) + (5)] = (0.5 * (__inl24_dxddy[si0] + __inl24_dyddx[si0]));
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl24_d[(si0)*(6) + (4)] = (0.5 * (__inl24_dxddz[si0] + __inl24_dzddx[si0]));
          }
          for (int64_t si0 = 0; si0 < numElem; ++si0) {
            __inl24_d[(si0)*(6) + (3)] = (0.5 * (__inl24_dzddy[si0] + __inl24_dyddz[si0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 6; ++__w1) {
              __inl15_d[(__w0)*(6) + (__w1)] = __inl24_d[(__w0)*(6) + (__w1)];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            dxx[__w0] = __inl15_d[(__w0)*(6) + (0)];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            dyy[__w0] = __inl15_d[(__w0)*(6) + (1)];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            dzz[__w0] = __inl15_d[(__w0)*(6) + (2)];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl10_vd[__w0] = ((dxx[__w0] + dyy[__w0]) + dzz[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl10_vdovthird[__w0] = (__inl10_vd[__w0] / 3.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            vdov[__w0] = __inl10_vd[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            dxx[__w0] = (dxx[__w0] - __inl10_vdovthird[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            dyy[__w0] = (dyy[__w0] - __inl10_vdovthird[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            dzz[__w0] = (dzz[__w0] - __inl10_vdovthird[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl16_xn[(__w0)*(8) + (__w1)] = x[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl16_yn[(__w0)*(8) + (__w1)] = y[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl16_zn[(__w0)*(8) + (__w1)] = z[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl16_xv[(__w0)*(8) + (__w1)] = xd[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl16_yv[(__w0)*(8) + (__w1)] = yd[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 8; ++__w1) {
              __inl16_zv[(__w0)*(8) + (__w1)] = zd[nodelist[(__w0)*(8) + (__w1)]];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_vol[__w0] = (volo[__w0] * vnew[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_norm[__w0] = (1.0 / (__inl16_vol[__w0] + 1e-36));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dxj[__w0] = ((-0.25) * ((((__inl16_xn[(__w0)*(8) + (0)] + __inl16_xn[(__w0)*(8) + (1)]) + __inl16_xn[(__w0)*(8) + (5)]) + __inl16_xn[(__w0)*(8) + (4)]) - (((__inl16_xn[(__w0)*(8) + (3)] + __inl16_xn[(__w0)*(8) + (2)]) + __inl16_xn[(__w0)*(8) + (6)]) + __inl16_xn[(__w0)*(8) + (7)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dyj[__w0] = ((-0.25) * ((((__inl16_yn[(__w0)*(8) + (0)] + __inl16_yn[(__w0)*(8) + (1)]) + __inl16_yn[(__w0)*(8) + (5)]) + __inl16_yn[(__w0)*(8) + (4)]) - (((__inl16_yn[(__w0)*(8) + (3)] + __inl16_yn[(__w0)*(8) + (2)]) + __inl16_yn[(__w0)*(8) + (6)]) + __inl16_yn[(__w0)*(8) + (7)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dzj[__w0] = ((-0.25) * ((((__inl16_zn[(__w0)*(8) + (0)] + __inl16_zn[(__w0)*(8) + (1)]) + __inl16_zn[(__w0)*(8) + (5)]) + __inl16_zn[(__w0)*(8) + (4)]) - (((__inl16_zn[(__w0)*(8) + (3)] + __inl16_zn[(__w0)*(8) + (2)]) + __inl16_zn[(__w0)*(8) + (6)]) + __inl16_zn[(__w0)*(8) + (7)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dxi[__w0] = (0.25 * ((((__inl16_xn[(__w0)*(8) + (1)] + __inl16_xn[(__w0)*(8) + (2)]) + __inl16_xn[(__w0)*(8) + (6)]) + __inl16_xn[(__w0)*(8) + (5)]) - (((__inl16_xn[(__w0)*(8) + (0)] + __inl16_xn[(__w0)*(8) + (3)]) + __inl16_xn[(__w0)*(8) + (7)]) + __inl16_xn[(__w0)*(8) + (4)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dyi[__w0] = (0.25 * ((((__inl16_yn[(__w0)*(8) + (1)] + __inl16_yn[(__w0)*(8) + (2)]) + __inl16_yn[(__w0)*(8) + (6)]) + __inl16_yn[(__w0)*(8) + (5)]) - (((__inl16_yn[(__w0)*(8) + (0)] + __inl16_yn[(__w0)*(8) + (3)]) + __inl16_yn[(__w0)*(8) + (7)]) + __inl16_yn[(__w0)*(8) + (4)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dzi[__w0] = (0.25 * ((((__inl16_zn[(__w0)*(8) + (1)] + __inl16_zn[(__w0)*(8) + (2)]) + __inl16_zn[(__w0)*(8) + (6)]) + __inl16_zn[(__w0)*(8) + (5)]) - (((__inl16_zn[(__w0)*(8) + (0)] + __inl16_zn[(__w0)*(8) + (3)]) + __inl16_zn[(__w0)*(8) + (7)]) + __inl16_zn[(__w0)*(8) + (4)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dxk[__w0] = (0.25 * ((((__inl16_xn[(__w0)*(8) + (4)] + __inl16_xn[(__w0)*(8) + (5)]) + __inl16_xn[(__w0)*(8) + (6)]) + __inl16_xn[(__w0)*(8) + (7)]) - (((__inl16_xn[(__w0)*(8) + (0)] + __inl16_xn[(__w0)*(8) + (1)]) + __inl16_xn[(__w0)*(8) + (2)]) + __inl16_xn[(__w0)*(8) + (3)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dyk[__w0] = (0.25 * ((((__inl16_yn[(__w0)*(8) + (4)] + __inl16_yn[(__w0)*(8) + (5)]) + __inl16_yn[(__w0)*(8) + (6)]) + __inl16_yn[(__w0)*(8) + (7)]) - (((__inl16_yn[(__w0)*(8) + (0)] + __inl16_yn[(__w0)*(8) + (1)]) + __inl16_yn[(__w0)*(8) + (2)]) + __inl16_yn[(__w0)*(8) + (3)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dzk[__w0] = (0.25 * ((((__inl16_zn[(__w0)*(8) + (4)] + __inl16_zn[(__w0)*(8) + (5)]) + __inl16_zn[(__w0)*(8) + (6)]) + __inl16_zn[(__w0)*(8) + (7)]) - (((__inl16_zn[(__w0)*(8) + (0)] + __inl16_zn[(__w0)*(8) + (1)]) + __inl16_zn[(__w0)*(8) + (2)]) + __inl16_zn[(__w0)*(8) + (3)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_ax1[__w0] = ((__inl16_dyi[__w0] * __inl16_dzj[__w0]) - (__inl16_dzi[__w0] * __inl16_dyj[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_ay1[__w0] = ((__inl16_dzi[__w0] * __inl16_dxj[__w0]) - (__inl16_dxi[__w0] * __inl16_dzj[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_az1[__w0] = ((__inl16_dxi[__w0] * __inl16_dyj[__w0]) - (__inl16_dyi[__w0] * __inl16_dxj[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            delx_zeta[__w0] = (__inl16_vol[__w0] / sqrt(((((__inl16_ax1[__w0] * __inl16_ax1[__w0]) + (__inl16_ay1[__w0] * __inl16_ay1[__w0])) + (__inl16_az1[__w0] * __inl16_az1[__w0])) + 1e-36)));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_axn[__w0] = (__inl16_ax1[__w0] * __inl16_norm[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_ayn[__w0] = (__inl16_ay1[__w0] * __inl16_norm[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_azn[__w0] = (__inl16_az1[__w0] * __inl16_norm[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dxv1[__w0] = (0.25 * ((((__inl16_xv[(__w0)*(8) + (4)] + __inl16_xv[(__w0)*(8) + (5)]) + __inl16_xv[(__w0)*(8) + (6)]) + __inl16_xv[(__w0)*(8) + (7)]) - (((__inl16_xv[(__w0)*(8) + (0)] + __inl16_xv[(__w0)*(8) + (1)]) + __inl16_xv[(__w0)*(8) + (2)]) + __inl16_xv[(__w0)*(8) + (3)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dyv1[__w0] = (0.25 * ((((__inl16_yv[(__w0)*(8) + (4)] + __inl16_yv[(__w0)*(8) + (5)]) + __inl16_yv[(__w0)*(8) + (6)]) + __inl16_yv[(__w0)*(8) + (7)]) - (((__inl16_yv[(__w0)*(8) + (0)] + __inl16_yv[(__w0)*(8) + (1)]) + __inl16_yv[(__w0)*(8) + (2)]) + __inl16_yv[(__w0)*(8) + (3)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dzv1[__w0] = (0.25 * ((((__inl16_zv[(__w0)*(8) + (4)] + __inl16_zv[(__w0)*(8) + (5)]) + __inl16_zv[(__w0)*(8) + (6)]) + __inl16_zv[(__w0)*(8) + (7)]) - (((__inl16_zv[(__w0)*(8) + (0)] + __inl16_zv[(__w0)*(8) + (1)]) + __inl16_zv[(__w0)*(8) + (2)]) + __inl16_zv[(__w0)*(8) + (3)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            delv_zeta[__w0] = (((__inl16_axn[__w0] * __inl16_dxv1[__w0]) + (__inl16_ayn[__w0] * __inl16_dyv1[__w0])) + (__inl16_azn[__w0] * __inl16_dzv1[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_ax2[__w0] = ((__inl16_dyj[__w0] * __inl16_dzk[__w0]) - (__inl16_dzj[__w0] * __inl16_dyk[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_ay2[__w0] = ((__inl16_dzj[__w0] * __inl16_dxk[__w0]) - (__inl16_dxj[__w0] * __inl16_dzk[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_az2[__w0] = ((__inl16_dxj[__w0] * __inl16_dyk[__w0]) - (__inl16_dyj[__w0] * __inl16_dxk[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            delx_xi[__w0] = (__inl16_vol[__w0] / sqrt(((((__inl16_ax2[__w0] * __inl16_ax2[__w0]) + (__inl16_ay2[__w0] * __inl16_ay2[__w0])) + (__inl16_az2[__w0] * __inl16_az2[__w0])) + 1e-36)));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_axn[__w0] = (__inl16_ax2[__w0] * __inl16_norm[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_ayn[__w0] = (__inl16_ay2[__w0] * __inl16_norm[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_azn[__w0] = (__inl16_az2[__w0] * __inl16_norm[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dxv2[__w0] = (0.25 * ((((__inl16_xv[(__w0)*(8) + (1)] + __inl16_xv[(__w0)*(8) + (2)]) + __inl16_xv[(__w0)*(8) + (6)]) + __inl16_xv[(__w0)*(8) + (5)]) - (((__inl16_xv[(__w0)*(8) + (0)] + __inl16_xv[(__w0)*(8) + (3)]) + __inl16_xv[(__w0)*(8) + (7)]) + __inl16_xv[(__w0)*(8) + (4)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dyv2[__w0] = (0.25 * ((((__inl16_yv[(__w0)*(8) + (1)] + __inl16_yv[(__w0)*(8) + (2)]) + __inl16_yv[(__w0)*(8) + (6)]) + __inl16_yv[(__w0)*(8) + (5)]) - (((__inl16_yv[(__w0)*(8) + (0)] + __inl16_yv[(__w0)*(8) + (3)]) + __inl16_yv[(__w0)*(8) + (7)]) + __inl16_yv[(__w0)*(8) + (4)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dzv2[__w0] = (0.25 * ((((__inl16_zv[(__w0)*(8) + (1)] + __inl16_zv[(__w0)*(8) + (2)]) + __inl16_zv[(__w0)*(8) + (6)]) + __inl16_zv[(__w0)*(8) + (5)]) - (((__inl16_zv[(__w0)*(8) + (0)] + __inl16_zv[(__w0)*(8) + (3)]) + __inl16_zv[(__w0)*(8) + (7)]) + __inl16_zv[(__w0)*(8) + (4)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            delv_xi[__w0] = (((__inl16_axn[__w0] * __inl16_dxv2[__w0]) + (__inl16_ayn[__w0] * __inl16_dyv2[__w0])) + (__inl16_azn[__w0] * __inl16_dzv2[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_ax3[__w0] = ((__inl16_dyk[__w0] * __inl16_dzi[__w0]) - (__inl16_dzk[__w0] * __inl16_dyi[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_ay3[__w0] = ((__inl16_dzk[__w0] * __inl16_dxi[__w0]) - (__inl16_dxk[__w0] * __inl16_dzi[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_az3[__w0] = ((__inl16_dxk[__w0] * __inl16_dyi[__w0]) - (__inl16_dyk[__w0] * __inl16_dxi[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            delx_eta[__w0] = (__inl16_vol[__w0] / sqrt(((((__inl16_ax3[__w0] * __inl16_ax3[__w0]) + (__inl16_ay3[__w0] * __inl16_ay3[__w0])) + (__inl16_az3[__w0] * __inl16_az3[__w0])) + 1e-36)));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_axn[__w0] = (__inl16_ax3[__w0] * __inl16_norm[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_ayn[__w0] = (__inl16_ay3[__w0] * __inl16_norm[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_azn[__w0] = (__inl16_az3[__w0] * __inl16_norm[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dxv3[__w0] = ((-0.25) * ((((__inl16_xv[(__w0)*(8) + (0)] + __inl16_xv[(__w0)*(8) + (1)]) + __inl16_xv[(__w0)*(8) + (5)]) + __inl16_xv[(__w0)*(8) + (4)]) - (((__inl16_xv[(__w0)*(8) + (3)] + __inl16_xv[(__w0)*(8) + (2)]) + __inl16_xv[(__w0)*(8) + (6)]) + __inl16_xv[(__w0)*(8) + (7)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dyv3[__w0] = ((-0.25) * ((((__inl16_yv[(__w0)*(8) + (0)] + __inl16_yv[(__w0)*(8) + (1)]) + __inl16_yv[(__w0)*(8) + (5)]) + __inl16_yv[(__w0)*(8) + (4)]) - (((__inl16_yv[(__w0)*(8) + (3)] + __inl16_yv[(__w0)*(8) + (2)]) + __inl16_yv[(__w0)*(8) + (6)]) + __inl16_yv[(__w0)*(8) + (7)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl16_dzv3[__w0] = ((-0.25) * ((((__inl16_zv[(__w0)*(8) + (0)] + __inl16_zv[(__w0)*(8) + (1)]) + __inl16_zv[(__w0)*(8) + (5)]) + __inl16_zv[(__w0)*(8) + (4)]) - (((__inl16_zv[(__w0)*(8) + (3)] + __inl16_zv[(__w0)*(8) + (2)]) + __inl16_zv[(__w0)*(8) + (6)]) + __inl16_zv[(__w0)*(8) + (7)])));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            delv_eta[__w0] = (((__inl16_axn[__w0] * __inl16_dxv3[__w0]) + (__inl16_ayn[__w0] * __inl16_dyv3[__w0])) + (__inl16_azn[__w0] * __inl16_dzv3[__w0]));
          }
          /* numpy: np.arange(numElem, dtype=np.intp) */
          for (int64_t __i = 0; __i < numElem; ++__i) {
            __cb29[__i] = __i;
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_ielem[__w0] = __cb29[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_norm1[__w0] = (1.0 / (delv_xi[__w0] + 1e-36));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl25_sel[__w0] = (elemBC[__w0] & 3);
          }
          /* numpy: np.clip(lxim, 0, numElem - 1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb30[__r0] = min((numElem - 1), max(0, lxim[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl25_neigh_safe[__w0] = __cb30[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl25_out1[__w0] = delv_xi[__inl25_neigh_safe[__w0]];
          }
          /* numpy: np.where(__inl25_sel == 1, delv_xi[__inl17_ielem], __inl25_out1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb31[__r0] = ((__inl25_sel[__r0] == 1) ? delv_xi[__inl17_ielem[__r0]] : __inl25_out1[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl25_out2[__w0] = __cb31[__w0];
          }
          /* numpy: np.where(__inl25_sel == 2, 0.0, __inl25_out2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb32[__r0] = ((__inl25_sel[__r0] == 2) ? 0.0 : __inl25_out2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl25_out3[__w0] = __cb32[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_dm1[__w0] = __inl25_out3[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl26_sel[__w0] = (elemBC[__w0] & 12);
          }
          /* numpy: np.clip(lxip, 0, numElem - 1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb33[__r0] = min((numElem - 1), max(0, lxip[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl26_neigh_safe[__w0] = __cb33[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl26_out1[__w0] = delv_xi[__inl26_neigh_safe[__w0]];
          }
          /* numpy: np.where(__inl26_sel == 4, delv_xi[__inl17_ielem], __inl26_out1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb34[__r0] = ((__inl26_sel[__r0] == 4) ? delv_xi[__inl17_ielem[__r0]] : __inl26_out1[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl26_out2[__w0] = __cb34[__w0];
          }
          /* numpy: np.where(__inl26_sel == 8, 0.0, __inl26_out2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb35[__r0] = ((__inl26_sel[__r0] == 8) ? 0.0 : __inl26_out2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl26_out3[__w0] = __cb35[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_dp1[__w0] = __inl26_out3[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl27_delvm1[__w0] = (__inl17_dm1[__w0] * __inl17_norm1[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl27_delvp1[__w0] = (__inl17_dp1[__w0] * __inl17_norm1[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl27_phi1[__w0] = (0.5 * (__inl27_delvm1[__w0] + __inl27_delvp1[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl27_delvm2[__w0] = (__inl27_delvm1[__w0] * 2.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl27_delvp2[__w0] = (__inl27_delvp1[__w0] * 2.0);
          }
          /* numpy: np.minimum(__inl27_phi1, __inl27_delvm2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb36[__r0] = min(__inl27_phi1[__r0], __inl27_delvm2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl27_phi2[__w0] = __cb36[__w0];
          }
          /* numpy: np.minimum(__inl27_phi2, __inl27_delvp2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb37[__r0] = min(__inl27_phi2[__r0], __inl27_delvp2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl27_phi3[__w0] = __cb37[__w0];
          }
          /* numpy: np.where(__inl27_phi3 < 0.0, 0.0, __inl27_phi3) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb38[__r0] = ((__inl27_phi3[__r0] < 0.0) ? 0.0 : __inl27_phi3[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl27_phi4[__w0] = __cb38[__w0];
          }
          /* numpy: np.where(__inl27_phi4 > __inl17_maxslope, __inl17_maxslope, __inl27_phi4) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb39[__r0] = ((__inl27_phi4[__r0] > 1.0) ? 1.0 : __inl27_phi4[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl27_phi5[__w0] = __cb39[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_phixi[__w0] = __inl27_phi5[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_norm2[__w0] = (1.0 / (delv_eta[__w0] + 1e-36));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl28_sel[__w0] = (elemBC[__w0] & 48);
          }
          /* numpy: np.clip(letam, 0, numElem - 1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb40[__r0] = min((numElem - 1), max(0, letam[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl28_neigh_safe[__w0] = __cb40[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl28_out1[__w0] = delv_eta[__inl28_neigh_safe[__w0]];
          }
          /* numpy: np.where(__inl28_sel == 16, delv_eta[__inl17_ielem], __inl28_out1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb41[__r0] = ((__inl28_sel[__r0] == 16) ? delv_eta[__inl17_ielem[__r0]] : __inl28_out1[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl28_out2[__w0] = __cb41[__w0];
          }
          /* numpy: np.where(__inl28_sel == 32, 0.0, __inl28_out2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb42[__r0] = ((__inl28_sel[__r0] == 32) ? 0.0 : __inl28_out2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl28_out3[__w0] = __cb42[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_dm2[__w0] = __inl28_out3[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl29_sel[__w0] = (elemBC[__w0] & 192);
          }
          /* numpy: np.clip(letap, 0, numElem - 1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb43[__r0] = min((numElem - 1), max(0, letap[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl29_neigh_safe[__w0] = __cb43[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl29_out1[__w0] = delv_eta[__inl29_neigh_safe[__w0]];
          }
          /* numpy: np.where(__inl29_sel == 64, delv_eta[__inl17_ielem], __inl29_out1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb44[__r0] = ((__inl29_sel[__r0] == 64) ? delv_eta[__inl17_ielem[__r0]] : __inl29_out1[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl29_out2[__w0] = __cb44[__w0];
          }
          /* numpy: np.where(__inl29_sel == 128, 0.0, __inl29_out2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb45[__r0] = ((__inl29_sel[__r0] == 128) ? 0.0 : __inl29_out2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl29_out3[__w0] = __cb45[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_dp2[__w0] = __inl29_out3[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl30_delvm1[__w0] = (__inl17_dm2[__w0] * __inl17_norm2[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl30_delvp1[__w0] = (__inl17_dp2[__w0] * __inl17_norm2[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl30_phi1[__w0] = (0.5 * (__inl30_delvm1[__w0] + __inl30_delvp1[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl30_delvm2[__w0] = (__inl30_delvm1[__w0] * 2.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl30_delvp2[__w0] = (__inl30_delvp1[__w0] * 2.0);
          }
          /* numpy: np.minimum(__inl30_phi1, __inl30_delvm2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb46[__r0] = min(__inl30_phi1[__r0], __inl30_delvm2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl30_phi2[__w0] = __cb46[__w0];
          }
          /* numpy: np.minimum(__inl30_phi2, __inl30_delvp2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb47[__r0] = min(__inl30_phi2[__r0], __inl30_delvp2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl30_phi3[__w0] = __cb47[__w0];
          }
          /* numpy: np.where(__inl30_phi3 < 0.0, 0.0, __inl30_phi3) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb48[__r0] = ((__inl30_phi3[__r0] < 0.0) ? 0.0 : __inl30_phi3[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl30_phi4[__w0] = __cb48[__w0];
          }
          /* numpy: np.where(__inl30_phi4 > __inl17_maxslope, __inl17_maxslope, __inl30_phi4) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb49[__r0] = ((__inl30_phi4[__r0] > 1.0) ? 1.0 : __inl30_phi4[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl30_phi5[__w0] = __cb49[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_phieta[__w0] = __inl30_phi5[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_norm3[__w0] = (1.0 / (delv_zeta[__w0] + 1e-36));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl31_sel[__w0] = (elemBC[__w0] & 768);
          }
          /* numpy: np.clip(lzetam, 0, numElem - 1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb50[__r0] = min((numElem - 1), max(0, lzetam[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl31_neigh_safe[__w0] = __cb50[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl31_out1[__w0] = delv_zeta[__inl31_neigh_safe[__w0]];
          }
          /* numpy: np.where(__inl31_sel == 256, delv_zeta[__inl17_ielem], __inl31_out1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb51[__r0] = ((__inl31_sel[__r0] == 256) ? delv_zeta[__inl17_ielem[__r0]] : __inl31_out1[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl31_out2[__w0] = __cb51[__w0];
          }
          /* numpy: np.where(__inl31_sel == 512, 0.0, __inl31_out2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb52[__r0] = ((__inl31_sel[__r0] == 512) ? 0.0 : __inl31_out2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl31_out3[__w0] = __cb52[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_dm3[__w0] = __inl31_out3[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl32_sel[__w0] = (elemBC[__w0] & 3072);
          }
          /* numpy: np.clip(lzetap, 0, numElem - 1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb53[__r0] = min((numElem - 1), max(0, lzetap[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl32_neigh_safe[__w0] = __cb53[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl32_out1[__w0] = delv_zeta[__inl32_neigh_safe[__w0]];
          }
          /* numpy: np.where(__inl32_sel == 1024, delv_zeta[__inl17_ielem], __inl32_out1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb54[__r0] = ((__inl32_sel[__r0] == 1024) ? delv_zeta[__inl17_ielem[__r0]] : __inl32_out1[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl32_out2[__w0] = __cb54[__w0];
          }
          /* numpy: np.where(__inl32_sel == 2048, 0.0, __inl32_out2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb55[__r0] = ((__inl32_sel[__r0] == 2048) ? 0.0 : __inl32_out2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl32_out3[__w0] = __cb55[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_dp3[__w0] = __inl32_out3[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl33_delvm1[__w0] = (__inl17_dm3[__w0] * __inl17_norm3[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl33_delvp1[__w0] = (__inl17_dp3[__w0] * __inl17_norm3[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl33_phi1[__w0] = (0.5 * (__inl33_delvm1[__w0] + __inl33_delvp1[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl33_delvm2[__w0] = (__inl33_delvm1[__w0] * 2.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl33_delvp2[__w0] = (__inl33_delvp1[__w0] * 2.0);
          }
          /* numpy: np.minimum(__inl33_phi1, __inl33_delvm2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb56[__r0] = min(__inl33_phi1[__r0], __inl33_delvm2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl33_phi2[__w0] = __cb56[__w0];
          }
          /* numpy: np.minimum(__inl33_phi2, __inl33_delvp2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb57[__r0] = min(__inl33_phi2[__r0], __inl33_delvp2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl33_phi3[__w0] = __cb57[__w0];
          }
          /* numpy: np.where(__inl33_phi3 < 0.0, 0.0, __inl33_phi3) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb58[__r0] = ((__inl33_phi3[__r0] < 0.0) ? 0.0 : __inl33_phi3[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl33_phi4[__w0] = __cb58[__w0];
          }
          /* numpy: np.where(__inl33_phi4 > __inl17_maxslope, __inl17_maxslope, __inl33_phi4) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb59[__r0] = ((__inl33_phi4[__r0] > 1.0) ? 1.0 : __inl33_phi4[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl33_phi5[__w0] = __cb59[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_phizeta[__w0] = __inl33_phi5[__w0];
          }
          /* numpy: np.minimum(delv_xi * delx_xi, 0.0) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb60[__r0] = min((delv_xi[__r0] * delx_xi[__r0]), 0.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_delvxxi[__w0] = __cb60[__w0];
          }
          /* numpy: np.minimum(delv_eta * delx_eta, 0.0) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb61[__r0] = min((delv_eta[__r0] * delx_eta[__r0]), 0.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_delvxeta[__w0] = __cb61[__w0];
          }
          /* numpy: np.minimum(delv_zeta * delx_zeta, 0.0) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb62[__r0] = min((delv_zeta[__r0] * delx_zeta[__r0]), 0.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_delvxzeta[__w0] = __cb62[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_rho[__w0] = (elemMass[__w0] / (volo[__w0] * vnew[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_qlin[__w0] = (((-0.5) * __inl17_rho[__w0]) * (((__inl17_delvxxi[__w0] * (1.0 - __inl17_phixi[__w0])) + (__inl17_delvxeta[__w0] * (1.0 - __inl17_phieta[__w0]))) + (__inl17_delvxzeta[__w0] * (1.0 - __inl17_phizeta[__w0]))));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_qquad[__w0] = ((0.6666666666666666 * __inl17_rho[__w0]) * ((((__inl17_delvxxi[__w0] * __inl17_delvxxi[__w0]) * (1.0 - (__inl17_phixi[__w0] * __inl17_phixi[__w0]))) + ((__inl17_delvxeta[__w0] * __inl17_delvxeta[__w0]) * (1.0 - (__inl17_phieta[__w0] * __inl17_phieta[__w0])))) + ((__inl17_delvxzeta[__w0] * __inl17_delvxzeta[__w0]) * (1.0 - (__inl17_phizeta[__w0] * __inl17_phizeta[__w0])))));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl17_pos[__w0] = (vdov[__w0] > 0.0);
          }
          /* numpy: np.where(__inl17_pos, 0.0, __inl17_qlin) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb63[__r0] = (__inl17_pos[__r0] ? 0.0 : __inl17_qlin[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            ql[__w0] = __cb63[__w0];
          }
          /* numpy: np.where(__inl17_pos, 0.0, __inl17_qquad) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb64[__r0] = (__inl17_pos[__r0] ? 0.0 : __inl17_qquad[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            qq[__w0] = __cb64[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl12_vnewc[__w0] = vnew[__w0];
          }
          if ((1e-09 != 0.0)) {
            /* numpy: np.where(__inl12_vnewc < __inl12_eosvmin, __inl12_eosvmin, __inl12_vnewc) */
            for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
              __cb65[__r0] = ((__inl12_vnewc[__r0] < 1e-09) ? 1e-09 : __inl12_vnewc[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl12_vnewc[__w0] = __cb65[__w0];
            }
          }
          if ((1000000000.0 != 0.0)) {
            /* numpy: np.where(__inl12_vnewc > __inl12_eosvmax, __inl12_eosvmax, __inl12_vnewc) */
            for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
              __cb66[__r0] = ((__inl12_vnewc[__r0] > 1000000000.0) ? 1000000000.0 : __inl12_vnewc[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl12_vnewc[__w0] = __cb66[__w0];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl12_vc[__w0] = v[__w0];
          }
          if ((1e-09 != 0.0)) {
            /* numpy: np.where(__inl12_vc < __inl12_eosvmin, __inl12_eosvmin, __inl12_vc) */
            for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
              __cb67[__r0] = ((__inl12_vc[__r0] < 1e-09) ? 1e-09 : __inl12_vc[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl12_vc[__w0] = __cb67[__w0];
            }
          }
          if ((1000000000.0 != 0.0)) {
            /* numpy: np.where(__inl12_vc > __inl12_eosvmax, __inl12_eosvmax, __inl12_vc) */
            for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
              __cb68[__r0] = ((__inl12_vc[__r0] > 1000000000.0) ? 1000000000.0 : __inl12_vc[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl12_vc[__w0] = __cb68[__w0];
            }
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_e_old[__w0] = e[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_delvc[__w0] = delv[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_p_old[__w0] = p[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_q_old[__w0] = q[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_qqc[__w0] = qq[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_qlc[__w0] = ql[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_compression[__w0] = ((1.0 / __inl12_vnewc[__w0]) - 1.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_vchalf[__w0] = (__inl12_vnewc[__w0] - (__inl18_delvc[__w0] * 0.5));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_compHalfStep[__w0] = ((1.0 / __inl18_vchalf[__w0]) - 1.0);
          }
          if ((1e-09 != 0.0)) {
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl18_m[__w0] = (__inl12_vnewc[__w0] <= 1e-09);
            }
            /* numpy: np.where(__inl18_m, __inl18_compression, __inl18_compHalfStep) */
            for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
              __cb69[__r0] = (__inl18_m[__r0] ? __inl18_compression[__r0] : __inl18_compHalfStep[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl18_compHalfStep[__w0] = __cb69[__w0];
            }
          }
          if ((1000000000.0 != 0.0)) {
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl18_m[__w0] = (__inl12_vnewc[__w0] >= 1000000000.0);
            }
            /* numpy: np.where(__inl18_m, 0.0, __inl18_p_old) */
            for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
              __cb70[__r0] = (__inl18_m[__r0] ? 0.0 : __inl18_p_old[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl18_p_old[__w0] = __cb70[__w0];
            }
            /* numpy: np.where(__inl18_m, 0.0, __inl18_compression) */
            for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
              __cb71[__r0] = (__inl18_m[__r0] ? 0.0 : __inl18_compression[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl18_compression[__w0] = __cb71[__w0];
            }
            /* numpy: np.where(__inl18_m, 0.0, __inl18_compHalfStep) */
            for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
              __cb72[__r0] = (__inl18_m[__r0] ? 0.0 : __inl18_compHalfStep[__r0]);
            }
            for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
              __inl18_compHalfStep[__w0] = __cb72[__w0];
            }
          }
          memset(__inl18_work, 0, (size_t)((numElem)) * sizeof(double));
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_e_new1[__w0] = ((__inl18_e_old[__w0] - ((0.5 * __inl18_delvc[__w0]) * (__inl18_p_old[__w0] + __inl18_q_old[__w0]))) + (0.5 * __inl18_work[__w0]));
          }
          /* numpy: np.maximum(__inl34_e_new1, __inl34_emin) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb73[__r0] = max(__inl34_e_new1[__r0], -1000000000000000.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_e_new2[__w0] = __cb73[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl40_bvc[__w0] = ((2.0 / 3.0) * (__inl18_compHalfStep[__w0] + 1.0));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl40_pbvc[__w0] = (2.0 / 3.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl40_p_new1[__w0] = (__inl40_bvc[__w0] * __inl34_e_new2[__w0]);
          }
          /* numpy: np.where(fabs(__inl40_p_new1) < 1e-07, 0.0, __inl40_p_new1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb74[__r0] = ((fabs(__inl40_p_new1[__r0]) < 1e-07) ? 0.0 : __inl40_p_new1[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl40_p_new2[__w0] = __cb74[__w0];
          }
          /* numpy: np.where(__inl12_vnewc >= 1000000000.0, 0.0, __inl40_p_new2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb75[__r0] = ((__inl12_vnewc[__r0] >= 1000000000.0) ? 0.0 : __inl40_p_new2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl40_p_new3[__w0] = __cb75[__w0];
          }
          /* numpy: np.where(__inl40_p_new3 < 0.0, 0.0, __inl40_p_new3) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb76[__r0] = ((__inl40_p_new3[__r0] < 0.0) ? 0.0 : __inl40_p_new3[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl40_p_new4[__w0] = __cb76[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_pHalfStep[__w0] = __inl40_p_new4[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_bvc[__w0] = __inl40_bvc[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_pbvc[__w0] = __inl40_pbvc[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_vhalf[__w0] = (1.0 / (1.0 + __inl18_compHalfStep[__w0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_ssc1[__w0] = (((__inl34_pbvc[__w0] * __inl34_e_new2[__w0]) + (((__inl34_vhalf[__w0] * __inl34_vhalf[__w0]) * __inl34_bvc[__w0]) * __inl34_pHalfStep[__w0])) / 1.0);
          }
          /* numpy: np.where(__inl34_ssc1 <= 1.11111e-37, 1.0, __inl34_ssc1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb77[__r0] = ((__inl34_ssc1[__r0] <= 1.11111e-37) ? 1.0 : __inl34_ssc1[__r0]);
          }
          /* numpy: np.where(__inl34_ssc1 <= 1.11111e-37, 3.33333e-19, sqrt(__cb77)) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb78[__r0] = ((__inl34_ssc1[__r0] <= 1.11111e-37) ? 3.33333e-19 : sqrt(__cb77[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_ssc2[__w0] = __cb78[__w0];
          }
          /* numpy: np.where(__inl18_delvc > 0.0, 0.0, __inl34_ssc2 * __inl18_qlc + __inl18_qqc) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb79[__r0] = ((__inl18_delvc[__r0] > 0.0) ? 0.0 : ((__inl34_ssc2[__r0] * __inl18_qlc[__r0]) + __inl18_qqc[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_q_new[__w0] = __cb79[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_e_new3[__w0] = (__inl34_e_new2[__w0] + ((0.5 * __inl18_delvc[__w0]) * ((3.0 * (__inl18_p_old[__w0] + __inl18_q_old[__w0])) - (4.0 * (__inl34_pHalfStep[__w0] + __inl34_q_new[__w0])))));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_e_new4[__w0] = (__inl34_e_new3[__w0] + (0.5 * __inl18_work[__w0]));
          }
          /* numpy: np.where(fabs(__inl34_e_new4) < 1e-07, 0.0, __inl34_e_new4) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb80[__r0] = ((fabs(__inl34_e_new4[__r0]) < 1e-07) ? 0.0 : __inl34_e_new4[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_e_new5[__w0] = __cb80[__w0];
          }
          /* numpy: np.maximum(__inl34_e_new5, __inl34_emin) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb81[__r0] = max(__inl34_e_new5[__r0], -1000000000000000.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_e_new6[__w0] = __cb81[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl41_bvc[__w0] = ((2.0 / 3.0) * (__inl18_compression[__w0] + 1.0));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl41_pbvc[__w0] = (2.0 / 3.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl41_p_new1[__w0] = (__inl41_bvc[__w0] * __inl34_e_new6[__w0]);
          }
          /* numpy: np.where(fabs(__inl41_p_new1) < 1e-07, 0.0, __inl41_p_new1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb82[__r0] = ((fabs(__inl41_p_new1[__r0]) < 1e-07) ? 0.0 : __inl41_p_new1[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl41_p_new2[__w0] = __cb82[__w0];
          }
          /* numpy: np.where(__inl12_vnewc >= 1000000000.0, 0.0, __inl41_p_new2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb83[__r0] = ((__inl12_vnewc[__r0] >= 1000000000.0) ? 0.0 : __inl41_p_new2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl41_p_new3[__w0] = __cb83[__w0];
          }
          /* numpy: np.where(__inl41_p_new3 < 0.0, 0.0, __inl41_p_new3) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb84[__r0] = ((__inl41_p_new3[__r0] < 0.0) ? 0.0 : __inl41_p_new3[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl41_p_new4[__w0] = __cb84[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_p_new[__w0] = __inl41_p_new4[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_bvc[__w0] = __inl41_bvc[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_pbvc[__w0] = __inl41_pbvc[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_ssc3[__w0] = (((__inl34_pbvc[__w0] * __inl34_e_new6[__w0]) + (((__inl12_vnewc[__w0] * __inl12_vnewc[__w0]) * __inl34_bvc[__w0]) * __inl34_p_new[__w0])) / 1.0);
          }
          /* numpy: np.where(__inl34_ssc3 <= 1.11111e-37, 1.0, __inl34_ssc3) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb85[__r0] = ((__inl34_ssc3[__r0] <= 1.11111e-37) ? 1.0 : __inl34_ssc3[__r0]);
          }
          /* numpy: np.where(__inl34_ssc3 <= 1.11111e-37, 3.33333e-19, sqrt(__cb85)) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb86[__r0] = ((__inl34_ssc3[__r0] <= 1.11111e-37) ? 3.33333e-19 : sqrt(__cb85[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_ssc4[__w0] = __cb86[__w0];
          }
          /* numpy: np.where(__inl18_delvc > 0.0, 0.0, __inl34_ssc4 * __inl18_qlc + __inl18_qqc) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb87[__r0] = ((__inl18_delvc[__r0] > 0.0) ? 0.0 : ((__inl34_ssc4[__r0] * __inl18_qlc[__r0]) + __inl18_qqc[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_q_tilde[__w0] = __cb87[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_e_new7[__w0] = (__inl34_e_new6[__w0] - (((((7.0 * (__inl18_p_old[__w0] + __inl18_q_old[__w0])) - (8.0 * (__inl34_pHalfStep[__w0] + __inl34_q_new[__w0]))) + (__inl34_p_new[__w0] + __inl34_q_tilde[__w0])) * __inl18_delvc[__w0]) * 0.16666666666666666));
          }
          /* numpy: np.where(fabs(__inl34_e_new7) < 1e-07, 0.0, __inl34_e_new7) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb88[__r0] = ((fabs(__inl34_e_new7[__r0]) < 1e-07) ? 0.0 : __inl34_e_new7[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_e_new8[__w0] = __cb88[__w0];
          }
          /* numpy: np.maximum(__inl34_e_new8, __inl34_emin) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb89[__r0] = max(__inl34_e_new8[__r0], -1000000000000000.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_e_new9[__w0] = __cb89[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl42_bvc[__w0] = ((2.0 / 3.0) * (__inl18_compression[__w0] + 1.0));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl42_pbvc[__w0] = (2.0 / 3.0);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl42_p_new1[__w0] = (__inl42_bvc[__w0] * __inl34_e_new9[__w0]);
          }
          /* numpy: np.where(fabs(__inl42_p_new1) < 1e-07, 0.0, __inl42_p_new1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb90[__r0] = ((fabs(__inl42_p_new1[__r0]) < 1e-07) ? 0.0 : __inl42_p_new1[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl42_p_new2[__w0] = __cb90[__w0];
          }
          /* numpy: np.where(__inl12_vnewc >= 1000000000.0, 0.0, __inl42_p_new2) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb91[__r0] = ((__inl12_vnewc[__r0] >= 1000000000.0) ? 0.0 : __inl42_p_new2[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl42_p_new3[__w0] = __cb91[__w0];
          }
          /* numpy: np.where(__inl42_p_new3 < 0.0, 0.0, __inl42_p_new3) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb92[__r0] = ((__inl42_p_new3[__r0] < 0.0) ? 0.0 : __inl42_p_new3[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl42_p_new4[__w0] = __cb92[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_p_new[__w0] = __inl42_p_new4[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_bvc[__w0] = __inl42_bvc[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_pbvc[__w0] = __inl42_pbvc[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_ssc5[__w0] = (((__inl34_pbvc[__w0] * __inl34_e_new9[__w0]) + (((__inl12_vnewc[__w0] * __inl12_vnewc[__w0]) * __inl34_bvc[__w0]) * __inl34_p_new[__w0])) / 1.0);
          }
          /* numpy: np.where(__inl34_ssc5 <= 1.11111e-37, 1.0, __inl34_ssc5) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb93[__r0] = ((__inl34_ssc5[__r0] <= 1.11111e-37) ? 1.0 : __inl34_ssc5[__r0]);
          }
          /* numpy: np.where(__inl34_ssc5 <= 1.11111e-37, 3.33333e-19, sqrt(__cb93)) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb94[__r0] = ((__inl34_ssc5[__r0] <= 1.11111e-37) ? 3.33333e-19 : sqrt(__cb93[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_ssc6[__w0] = __cb94[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_q_new21[__w0] = ((__inl34_ssc6[__w0] * __inl18_qlc[__w0]) + __inl18_qqc[__w0]);
          }
          /* numpy: np.where(fabs(__inl34_q_new21) < 1e-07, 0.0, __inl34_q_new21) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb95[__r0] = ((fabs(__inl34_q_new21[__r0]) < 1e-07) ? 0.0 : __inl34_q_new21[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_q_new22[__w0] = __cb95[__w0];
          }
          /* numpy: np.where(__inl18_delvc <= 0.0, __inl34_q_new22, __inl34_q_new) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb96[__r0] = ((__inl18_delvc[__r0] <= 0.0) ? __inl34_q_new22[__r0] : __inl34_q_new[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl34_q_new[__w0] = __cb96[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_p_new[__w0] = __inl34_p_new[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_e_new[__w0] = __inl34_e_new9[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_q_new[__w0] = __inl34_q_new[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_bvc[__w0] = __inl34_bvc[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl18_pbvc[__w0] = __inl34_pbvc[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            p[__w0] = __inl18_p_new[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            e[__w0] = __inl18_e_new[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            q[__w0] = __inl18_q_new[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl35_ssc1[__w0] = (((__inl18_pbvc[__w0] * __inl18_e_new[__w0]) + (((__inl12_vnewc[__w0] * __inl12_vnewc[__w0]) * __inl18_bvc[__w0]) * __inl18_p_new[__w0])) / 1.0);
          }
          /* numpy: np.where(__inl35_ssc1 <= 1.11111e-37, 1.0, __inl35_ssc1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb97[__r0] = ((__inl35_ssc1[__r0] <= 1.11111e-37) ? 1.0 : __inl35_ssc1[__r0]);
          }
          /* numpy: np.where(__inl35_ssc1 <= 1.11111e-37, 3.33333e-19, sqrt(__cb97)) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb98[__r0] = ((__inl35_ssc1[__r0] <= 1.11111e-37) ? 3.33333e-19 : sqrt(__cb97[__r0]));
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl35_ssc2[__w0] = __cb98[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            ss[__w0] = __inl35_ssc2[__w0];
          }
          /* numpy: np.where(np.abs(vnew - 1.0) < 1e-10, 1.0, vnew) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb99[__r0] = ((fabs((vnew[__r0] - 1.0)) < 1e-10) ? 1.0 : vnew[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl13_tmpV2[__w0] = __cb99[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            v[__w0] = __inl13_tmpV2[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl3_dtf1[__w0] = (ss[__w0] * ss[__w0]);
          }
          /* numpy: np.where(vdov < 0.0, __inl3_dtf1 + __inl3_qqc2 * arealg * arealg * vdov * vdov, __inl3_dtf1) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb100[__r0] = ((vdov[__r0] < 0.0) ? (__inl3_dtf1[__r0] + ((((((64.0 * 2.0) * 2.0) * arealg[__r0]) * arealg[__r0]) * vdov[__r0]) * vdov[__r0])) : __inl3_dtf1[__r0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl3_dtf2[__w0] = __cb100[__w0];
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl3_dtf3[__w0] = sqrt(__inl3_dtf2[__w0]);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl3_dtf4[__w0] = (arealg[__w0] / __inl3_dtf3[__w0]);
          }
          /* numpy: np.where(vdov != 0.0, __inl3_dtf4, 1e+20) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb101[__r0] = ((vdov[__r0] != 0.0) ? __inl3_dtf4[__r0] : 1e+20);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl3_dtf5[__w0] = __cb101[__w0];
          }
          /* numpy: np.min(__inl3_dtf5) */
          __cb102 = __inl3_dtf5[0];
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb102 = (((__inl3_dtf5[__r0] < __cb102) || (__inl3_dtf5[__r0] != __inl3_dtf5[__r0])) ? __inl3_dtf5[__r0] : __cb102);
          }
          __inl3_cand = __cb102;
          dtcourant = ((__inl3_cand < 1e+20) ? __inl3_cand : 1e+20);
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl4_dtdvov1[__w0] = (0.1 / (fabs(vdov[__w0]) + 1e-20));
          }
          /* numpy: np.where(vdov != 0.0, __inl4_dtdvov1, 1e+20) */
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb103[__r0] = ((vdov[__r0] != 0.0) ? __inl4_dtdvov1[__r0] : 1e+20);
          }
          for (int64_t __w0 = 0; __w0 < numElem; ++__w0) {
            __inl4_dtdvov2[__w0] = __cb103[__w0];
          }
          /* numpy: np.min(__inl4_dtdvov2) */
          __cb104 = __inl4_dtdvov2[0];
          for (int64_t __r0 = 0; __r0 < numElem; ++__r0) {
            __cb104 = (((__inl4_dtdvov2[__r0] < __cb104) || (__inl4_dtdvov2[__r0] != __inl4_dtdvov2[__r0])) ? __inl4_dtdvov2[__r0] : __cb104);
          }
          __inl4_cand = __cb104;
          dthydro = ((__inl4_cand < 1e+20) ? __inl4_cand : 1e+20);
        }
        free(__inl36_b);
        free(__inl37_pf);
        free(__inl22_charl);
        free(__inl23_b);
        free(__inl24_d);
        free(__inl12_vnewc);
        free(__inl12_vc);
        free(__inl18_e_old);
        free(__inl18_delvc);
        free(__inl18_p_old);
        free(__inl18_q_old);
        free(__inl18_qqc);
        free(__inl18_qlc);
        free(__inl18_work);
        free(__inl40_pbvc);
        free(__inl41_pbvc);
        free(__inl42_pbvc);
        free(__mm1);
        free(__mm2);
        free(__mm3);
        free(__cb4);
        free(__cb5);
        free(__cb6);
        free(__cb8);
        free(__cb9);
        free(__cb10);
        free(__cb11);
        free(__cb12);
        free(__cb13);
        free(__cb14);
        free(__cb15);
        free(__cb16);
        free(__cb17);
        free(__cb18);
        free(__cb19);
        free(__cb20);
        free(__cb21);
        free(__cb22);
        free(__cb23);
        free(__cb24);
        free(__cb25);
        free(__cb26);
        free(__cb27);
        free(__cb28);
        free(__cb29);
        free(__cb30);
        free(__cb31);
        free(__cb32);
        free(__cb33);
        free(__cb34);
        free(__cb35);
        free(__cb36);
        free(__cb37);
        free(__cb38);
        free(__cb39);
        free(__cb40);
        free(__cb41);
        free(__cb42);
        free(__cb43);
        free(__cb44);
        free(__cb45);
        free(__cb46);
        free(__cb47);
        free(__cb48);
        free(__cb49);
        free(__cb50);
        free(__cb51);
        free(__cb52);
        free(__cb53);
        free(__cb54);
        free(__cb55);
        free(__cb56);
        free(__cb57);
        free(__cb58);
        free(__cb59);
        free(__cb60);
        free(__cb61);
        free(__cb62);
        free(__cb63);
        free(__cb64);
        free(__cb65);
        free(__cb66);
        free(__cb67);
        free(__cb68);
        free(__cb69);
        free(__cb70);
        free(__cb71);
        free(__cb72);
        free(__cb73);
        free(__cb74);
        free(__cb75);
        free(__cb76);
        free(__cb77);
        free(__cb78);
        free(__cb79);
        free(__cb80);
        free(__cb81);
        free(__cb82);
        free(__cb83);
        free(__cb84);
        free(__cb85);
        free(__cb86);
        free(__cb87);
        free(__cb88);
        free(__cb89);
        free(__cb90);
        free(__cb91);
        free(__cb92);
        free(__cb93);
        free(__cb94);
        free(__cb95);
        free(__cb96);
        free(__cb97);
        free(__cb98);
        free(__cb99);
        free(__cb100);
        free(__cb101);
        free(__cb103);
        free(__inl14_sig);
        free(__inl36_fjxxi);
        free(__inl36_fjxet);
        free(__inl36_fjxze);
        free(__inl36_fjyxi);
        free(__inl36_fjyet);
        free(__inl36_fjyze);
        free(__inl36_fjzxi);
        free(__inl36_fjzet);
        free(__inl36_fjzze);
        free(__inl36_cjxxi);
        free(__inl36_cjxet);
        free(__inl36_cjxze);
        free(__inl36_cjyxi);
        free(__inl36_cjyet);
        free(__inl36_cjyze);
        free(__inl36_cjzxi);
        free(__inl36_cjzet);
        free(__inl36_cjzze);
        free(__inl36_volume);
        free(__inl19__);
        free(__inl19_determ);
        free(__inl43_bX0);
        free(__inl43_bY0);
        free(__inl43_bZ0);
        free(__inl43_bX1);
        free(__inl43_bY1);
        free(__inl43_bZ1);
        free(__inl43_areaX);
        free(__inl43_areaY);
        free(__inl43_areaZ);
        free(__scg0);
        free(__scg1);
        free(__scg2);
        free(__inl44_bX0);
        free(__inl44_bY0);
        free(__inl44_bZ0);
        free(__inl44_bX1);
        free(__inl44_bY1);
        free(__inl44_bZ1);
        free(__inl44_areaX);
        free(__inl44_areaY);
        free(__inl44_areaZ);
        free(__scg3);
        free(__scg4);
        free(__scg5);
        free(__inl45_bX0);
        free(__inl45_bY0);
        free(__inl45_bZ0);
        free(__inl45_bX1);
        free(__inl45_bY1);
        free(__inl45_bZ1);
        free(__inl45_areaX);
        free(__inl45_areaY);
        free(__inl45_areaZ);
        free(__scg6);
        free(__scg7);
        free(__scg8);
        free(__inl46_bX0);
        free(__inl46_bY0);
        free(__inl46_bZ0);
        free(__inl46_bX1);
        free(__inl46_bY1);
        free(__inl46_bZ1);
        free(__inl46_areaX);
        free(__inl46_areaY);
        free(__inl46_areaZ);
        free(__scg9);
        free(__scg10);
        free(__scg11);
        free(__inl47_bX0);
        free(__inl47_bY0);
        free(__inl47_bZ0);
        free(__inl47_bX1);
        free(__inl47_bY1);
        free(__inl47_bZ1);
        free(__inl47_areaX);
        free(__inl47_areaY);
        free(__inl47_areaZ);
        free(__scg12);
        free(__scg13);
        free(__scg14);
        free(__inl48_bX0);
        free(__inl48_bY0);
        free(__inl48_bZ0);
        free(__inl48_bX1);
        free(__inl48_bY1);
        free(__inl48_bZ1);
        free(__inl48_areaX);
        free(__inl48_areaY);
        free(__inl48_areaZ);
        free(__scg15);
        free(__scg16);
        free(__scg17);
        free(__inl19_b);
        free(__inl19_sfx);
        free(__inl19_sfy);
        free(__inl19_sfz);
        free(__inl14_determ);
        free(__inl49_dvdx);
        free(__inl49_dvdy);
        free(__inl49_dvdz);
        free(__inl20_dvdx);
        free(__inl20_dvdy);
        free(__inl20_dvdz);
        free(__inl39_volinv);
        free(__inl39_hourmodx);
        free(__inl39_hourmody);
        free(__inl39_hourmodz);
        free(__inl39_term);
        free(__inl39_hourgam);
        free(__inl39_coefficient);
        free(__inl39___inl1_hxx);
        free(__inl39_hgfx);
        free(__inl39___inl2_hxx);
        free(__inl39_hgfy);
        free(__inl39___inl3_hxx);
        free(__inl39_hgfz);
        free(__inl8_txd);
        free(__inl8_tyd);
        free(__inl8_tzd);
        free(__inl15_xl1);
        free(__inl15_yl1);
        free(__inl15_zl1);
        free(__inl21_dx61);
        free(__inl21_dy61);
        free(__inl21_dz61);
        free(__inl21_dx70);
        free(__inl21_dy70);
        free(__inl21_dz70);
        free(__inl21_dx63);
        free(__inl21_dy63);
        free(__inl21_dz63);
        free(__inl21_dx20);
        free(__inl21_dy20);
        free(__inl21_dz20);
        free(__inl21_dx50);
        free(__inl21_dy50);
        free(__inl21_dz50);
        free(__inl21_dx64);
        free(__inl21_dy64);
        free(__inl21_dz64);
        free(__inl21_dx31);
        free(__inl21_dy31);
        free(__inl21_dz31);
        free(__inl21_dx72);
        free(__inl21_dy72);
        free(__inl21_dz72);
        free(__inl21_dx43);
        free(__inl21_dy43);
        free(__inl21_dz43);
        free(__inl21_dx57);
        free(__inl21_dy57);
        free(__inl21_dz57);
        free(__inl21_dx14);
        free(__inl21_dy14);
        free(__inl21_dz14);
        free(__inl21_dx25);
        free(__inl21_dy25);
        free(__inl21_dz25);
        free(__inl21_vol);
        free(__inl15_volume);
        free(__inl15_relvol);
        free(__inl22___inl1_fx);
        free(__inl22___inl1_fy);
        free(__inl22___inl1_fz);
        free(__inl22___inl1_gx);
        free(__inl22___inl1_gy);
        free(__inl22___inl1_gz);
        free(__inl22_ar);
        free(__inl15_xl2);
        free(__inl15_yl2);
        free(__inl15_zl2);
        free(__inl23_fjxxi);
        free(__inl23_fjxet);
        free(__inl23_fjxze);
        free(__inl23_fjyxi);
        free(__inl23_fjyet);
        free(__inl23_fjyze);
        free(__inl23_fjzxi);
        free(__inl23_fjzet);
        free(__inl23_fjzze);
        free(__inl23_cjxxi);
        free(__inl23_cjxet);
        free(__inl23_cjxze);
        free(__inl23_cjyxi);
        free(__inl23_cjyet);
        free(__inl23_cjyze);
        free(__inl23_cjzxi);
        free(__inl23_cjzet);
        free(__inl23_cjzze);
        free(__inl23_volume);
        free(__inl15_b);
        free(__inl15_detJ);
        free(__inl24_inv);
        free(__inl24_dyddx);
        free(__inl24_dxddy);
        free(__inl24_dzddx);
        free(__inl24_dxddz);
        free(__inl24_dzddy);
        free(__inl24_dyddz);
        free(__inl15_d);
        free(__inl10_vd);
        free(__inl10_vdovthird);
        free(__inl16_vol);
        free(__inl16_norm);
        free(__inl16_dxj);
        free(__inl16_dyj);
        free(__inl16_dzj);
        free(__inl16_dxi);
        free(__inl16_dyi);
        free(__inl16_dzi);
        free(__inl16_dxk);
        free(__inl16_dyk);
        free(__inl16_dzk);
        free(__inl16_ax1);
        free(__inl16_ay1);
        free(__inl16_az1);
        free(__inl16_axn);
        free(__inl16_ayn);
        free(__inl16_azn);
        free(__inl16_dxv1);
        free(__inl16_dyv1);
        free(__inl16_dzv1);
        free(__inl16_ax2);
        free(__inl16_ay2);
        free(__inl16_az2);
        free(__inl16_dxv2);
        free(__inl16_dyv2);
        free(__inl16_dzv2);
        free(__inl16_ax3);
        free(__inl16_ay3);
        free(__inl16_az3);
        free(__inl16_dxv3);
        free(__inl16_dyv3);
        free(__inl16_dzv3);
        free(__inl17_ielem);
        free(__inl17_norm1);
        free(__inl25_sel);
        free(__inl25_neigh_safe);
        free(__inl25_out2);
        free(__inl25_out3);
        free(__inl17_dm1);
        free(__inl26_sel);
        free(__inl26_neigh_safe);
        free(__inl26_out2);
        free(__inl26_out3);
        free(__inl17_dp1);
        free(__inl27_delvm1);
        free(__inl27_delvp1);
        free(__inl27_phi1);
        free(__inl27_delvm2);
        free(__inl27_delvp2);
        free(__inl27_phi2);
        free(__inl27_phi3);
        free(__inl27_phi4);
        free(__inl27_phi5);
        free(__inl17_phixi);
        free(__inl17_norm2);
        free(__inl28_sel);
        free(__inl28_neigh_safe);
        free(__inl28_out2);
        free(__inl28_out3);
        free(__inl17_dm2);
        free(__inl29_sel);
        free(__inl29_neigh_safe);
        free(__inl29_out2);
        free(__inl29_out3);
        free(__inl17_dp2);
        free(__inl30_delvm1);
        free(__inl30_delvp1);
        free(__inl30_phi1);
        free(__inl30_delvm2);
        free(__inl30_delvp2);
        free(__inl30_phi2);
        free(__inl30_phi3);
        free(__inl30_phi4);
        free(__inl30_phi5);
        free(__inl17_phieta);
        free(__inl17_norm3);
        free(__inl31_sel);
        free(__inl31_neigh_safe);
        free(__inl31_out2);
        free(__inl31_out3);
        free(__inl17_dm3);
        free(__inl32_sel);
        free(__inl32_neigh_safe);
        free(__inl32_out2);
        free(__inl32_out3);
        free(__inl17_dp3);
        free(__inl33_delvm1);
        free(__inl33_delvp1);
        free(__inl33_phi1);
        free(__inl33_delvm2);
        free(__inl33_delvp2);
        free(__inl33_phi2);
        free(__inl33_phi3);
        free(__inl33_phi4);
        free(__inl33_phi5);
        free(__inl17_phizeta);
        free(__inl17_delvxxi);
        free(__inl17_delvxeta);
        free(__inl17_delvxzeta);
        free(__inl17_rho);
        free(__inl17_qlin);
        free(__inl17_qquad);
        free(__inl17_pos);
        free(__inl18_compression);
        free(__inl18_vchalf);
        free(__inl18_compHalfStep);
        free(__inl18_m);
        free(__inl34_e_new1);
        free(__inl34_e_new2);
        free(__inl40_bvc);
        free(__inl40_p_new1);
        free(__inl40_p_new2);
        free(__inl40_p_new3);
        free(__inl40_p_new4);
        free(__inl34_pHalfStep);
        free(__inl34_bvc);
        free(__inl34_pbvc);
        free(__inl34_vhalf);
        free(__inl34_ssc1);
        free(__inl34_ssc2);
        free(__inl34_q_new);
        free(__inl34_e_new3);
        free(__inl34_e_new4);
        free(__inl34_e_new5);
        free(__inl34_e_new6);
        free(__inl41_bvc);
        free(__inl41_p_new1);
        free(__inl41_p_new2);
        free(__inl41_p_new3);
        free(__inl41_p_new4);
        free(__inl34_p_new);
        free(__inl34_ssc3);
        free(__inl34_ssc4);
        free(__inl34_q_tilde);
        free(__inl34_e_new7);
        free(__inl34_e_new8);
        free(__inl34_e_new9);
        free(__inl42_bvc);
        free(__inl42_p_new1);
        free(__inl42_p_new2);
        free(__inl42_p_new3);
        free(__inl42_p_new4);
        free(__inl34_ssc5);
        free(__inl34_ssc6);
        free(__inl34_q_new21);
        free(__inl34_q_new22);
        free(__inl18_p_new);
        free(__inl18_e_new);
        free(__inl18_q_new);
        free(__inl18_bvc);
        free(__inl18_pbvc);
        free(__inl35_ssc1);
        free(__inl35_ssc2);
        free(__inl13_tmpV2);
        free(__inl3_dtf1);
        free(__inl3_dtf2);
        free(__inl3_dtf4);
        free(__inl3_dtf5);
        free(__inl4_dtdvov1);
        free(__inl4_dtdvov2);
        free(__inl19_xl);
        free(__inl19_yl);
        free(__inl19_zl);
        free(__inl20_x1);
        free(__inl20_y1);
        free(__inl20_z1);
        free(__inl38_gx);
        free(__inl38_gy);
        free(__inl38_gz);
        free(__inl15_xdl);
        free(__inl15_ydl);
        free(__inl15_zdl);
        free(__inl16_xn);
        free(__inl16_yn);
        free(__inl16_zn);
        free(__inl16_xv);
        free(__inl16_yv);
        free(__inl16_zv);
        free(__inl25_out1);
        free(__inl26_out1);
        free(__inl28_out1);
        free(__inl29_out1);
        free(__inl31_out1);
        free(__inl32_out1);
        free(__inl3_dtf3);
        free(__inl39_xd1);
        free(__inl39_yd1);
        free(__inl39_zd1);
        free(__inl39_volume13);
}
