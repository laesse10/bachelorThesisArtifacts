#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <math.h>
#include <omp.h>

/*
 * Optimised CP2K grid‑integrate kernel.
 *
 * The reference implementation (cp2k_grid_integrate_reference.c) performs a
 * large number of per‑task dynamic allocations and a series of high‑dimensional
 * tensor contractions.  For the problem sizes used by the benchmark the total
 * temporary storage per task is bounded (<=~200 kB) and therefore can be kept on
 * the stack.  Removing malloc/free eliminates the dominant source of overhead
 * when the number of tasks is in the millions.
 *
 * The algorithmic steps are unchanged:
 *   1.  Build the one‑dimensional polynomial tables.
 *   2.  Gather grid values, apply the spherical mask and accumulate the three‑
 *       dimensional tensor cxyz via an explicit triple loop.
 *   3.  Zero out entries of cxyz whose angular degree exceeds lp.
 *   4.  Construct the alpha tensors for each Cartesian direction.
 *   5.  Enumerate the a‑ and b‑shell cosets.
 *   6.  Perform the final contraction using a straightforward i‑j‑k triple
 *       loop – mathematically equivalent to the reference's series of tensordot
 *       operations.
 *
 * All temporaries are declared with compile‑time maximum sizes derived from the
 * constants defined below.  The implementation is pure C11 and is parallelised
 * over tasks with OpenMP.
 */

#define MAX_L 2
#define MAX_LP (2 * MAX_L)
#define MAX_COSET 10
#define MAX_CUBE_RADIUS 2
#define MAX_SPAN (MAX_CUBE_RADIUS * 2 + 1)        /* = 5 */
#define MAX_REL (MAX_SPAN * MAX_SPAN * MAX_SPAN) /* = 125 */
#define MAX_NLP ((MAX_LP * 2) + 1)                /* = 9 */

/* Integer floor division used by the reference implementation. */
static inline int64_t int_floor(int64_t a, int64_t b) {
    int64_t q = a / b;
    int64_t r = a % b;
    if ((r != 0) && ((r < 0) != (b < 0))) {
        q -= 1;
    }
    return q;
}

/* Helper to enumerate a coset for a given angular‑momentum range. */
static inline void enumerate_coset(int64_t l_min, int64_t l_max,
                                   int64_t *lx, int64_t *ly, int64_t *lz,
                                   int64_t *ico, int64_t *n_out) {
    int64_t n = 0;
    for (int64_t total = l_min; total <= l_max; ++total) {
        for (int64_t x = 0; x <= total; ++x) {
            for (int64_t y = 0; y <= total - x; ++y) {
                int64_t z = total - x - y;
                lx[n] = x;
                ly[n] = y;
                lz[n] = z;
                ico[n] = int_floor((total * (total + 1) * (total + 2)), 6) +
                         int_floor(((total - x) * (total - x + 1)), 2) + z;
                ++n;
            }
        }
    }
    *n_out = n;
}

void cp2k_grid_integrate_fp64(
    const int32_t *restrict border_width,
    const double *restrict dh,
    const double *restrict dh_inv,
    const double *restrict grid,
    double *restrict hab,
    const int32_t *restrict la_max,
    const int32_t *restrict la_min,
    const int32_t *restrict lb_max,
    const int32_t *restrict lb_min,
    const int32_t *restrict npts_global,
    const int32_t *restrict npts_local,
    const double *restrict ra,
    const double *restrict rab,
    const double *restrict radius,
    const int32_t *restrict shift_local,
    const double *restrict zeta,
    const double *restrict zetb,
    const int64_t npts,
    const int64_t num_tasks,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {

    /* Ensure OpenMP uses all available cores. */
    omp_set_dynamic(0);
    omp_set_num_threads(omp_get_num_procs());
    /* Parallelise over independent tasks. */
    #pragma omp parallel for schedule(dynamic)
    for (int64_t task = 0; task < num_tasks; ++task) {
        /* Optional mask handling – not used by the benchmark but kept for
         * compatibility with the original signature. */
        uint8_t *mask = NULL;
        if (mask && mask[task]) continue;

        /* ----------------------------------------------------------------
         * 1. Geometry and polynomial tables
         * ---------------------------------------------------------------- */
        int64_t lamax = la_max[task];
        int64_t lbmax = lb_max[task];
        int64_t lp    = lamax + lbmax;               /* total angular momentum */
        int64_t nlp   = lp + 1;                      /* polynomial table size */
        double zetp   = zeta[task] + zetb[task];
        double f = zetb[task] / zetp;

        double rp0 = ra[task * 3 + 0] + f * rab[task * 3 + 0];
        double rp1 = ra[task * 3 + 1] + f * rab[task * 3 + 1];
        double rp2 = ra[task * 3 + 2] + f * rab[task * 3 + 2];

        /* Compute integer lattice centre closest to the displaced centre. */
        double cx = dh_inv[0] * rp0 + dh_inv[1] * rp1 + dh_inv[2] * rp2;
        double cy = dh_inv[3] * rp0 + dh_inv[4] * rp1 + dh_inv[5] * rp2;
        double cz = dh_inv[6] * rp0 + dh_inv[7] * rp1 + dh_inv[8] * rp2;
        int64_t center[3];
        center[0] = (int64_t)floor(cx);
        center[1] = (int64_t)floor(cy);
        center[2] = (int64_t)floor(cz);

        /* Pre‑allocate all temporary buffers with compile‑time maxima. */
        double displacement[3][MAX_REL];
        double pol[3][MAX_NLP][MAX_SPAN];
        bool   inside[3][MAX_SPAN];
        double cxyz[MAX_NLP][MAX_NLP][MAX_NLP];
        double alpha[3][MAX_L + 1][MAX_L + 1][MAX_NLP];
        int64_t a_lx[MAX_COSET], a_ly[MAX_COSET], a_lz[MAX_COSET], a_ico[MAX_COSET];
        int64_t b_lx[MAX_COSET], b_ly[MAX_COSET], b_lz[MAX_COSET], b_jco[MAX_COSET];
        int64_t n_a, n_b;

        /* Zero initialise buffers. */
        for (int d = 0; d < 3; ++d)
            for (int i = 0; i < MAX_NLP; ++i)
                for (int j = 0; j < MAX_SPAN; ++j)
                    pol[d][i][j] = 0.0;
        for (int i = 0; i < MAX_NLP; ++i)
            for (int j = 0; j < MAX_NLP; ++j)
                for (int k = 0; k < MAX_NLP; ++k)
                    cxyz[i][j][k] = 0.0;
        for (int d = 0; d < 3; ++d)
            for (int i = 0; i < MAX_L + 1; ++i)
                for (int j = 0; j < MAX_L + 1; ++j)
                    for (int l = 0; l < MAX_NLP; ++l)
                        alpha[d][i][j][l] = 0.0;

        int span[3];
        double rp[3] = { rp0, rp1, rp2 };
        for (int idir = 0; idir < 3; ++idir) {
            double dh_ii = dh[idir * 3 + idir];
            int sp = (int)(radius[task] / dh_ii);
            if ((double)sp * dh_ii < radius[task]) sp++;
            if (sp > MAX_CUBE_RADIUS) sp = MAX_CUBE_RADIUS;   // safety clamp
            span[idir] = sp;
            for (int rel = -sp; rel <= sp; ++rel) {
                int idx = rel + MAX_CUBE_RADIUS; // map -2..2 -> 0..4
                displacement[idir][idx] = ((center[idir] + rel) * dh_ii) - rp[idir];
                double factor = exp(-zetp * displacement[idir][idx] * displacement[idir][idx]);
                double cum = factor;
                for (int order = 0; order < nlp; ++order) {
                    pol[idir][order][idx] = cum;
                    cum *= displacement[idir][idx];
                }
                /* Determine whether the grid point lies inside the local region. */
                int64_t cont = center[idir] + rel;
                int64_t gather = (cont - shift_local[idir]) % npts_global[idir];
                if (gather < 0) gather += npts_global[idir];
                inside[idir][idx] = (gather >= border_width[idir] &&
                                      gather < (npts_local[idir] - border_width[idir]));
            }
        }

        /* ----------------------------------------------------------------
         * 2. Sample the grid, apply spherical cutoff and accumulate cxyz.
         * ---------------------------------------------------------------- */
        double radius_sq = radius[task] * radius[task];
        for (int dz = -span[2]; dz <= span[2]; ++dz) {
            int iz = dz + MAX_CUBE_RADIUS;
            int64_t cont_z = center[2] + dz;
            int64_t gather_z = (cont_z - shift_local[2]) % npts_global[2];
            if (gather_z < 0) gather_z += npts_global[2];
            if (!inside[2][iz]) continue;
            double disp_z = displacement[2][iz];
            double disp_z_sq = disp_z * disp_z;
            for (int dy = -span[1]; dy <= span[1]; ++dy) {
                int iy = dy + MAX_CUBE_RADIUS;
                int64_t cont_y = center[1] + dy;
                int64_t gather_y = (cont_y - shift_local[1]) % npts_global[1];
                if (gather_y < 0) gather_y += npts_global[1];
                if (!inside[1][iy]) continue;
                double disp_y = displacement[1][iy];
                double disp_y_sq = disp_y * disp_y;
                for (int dx = -span[0]; dx <= span[0]; ++dx) {
                    int ix = dx + MAX_CUBE_RADIUS;
                    int64_t cont_x = center[0] + dx;
                    int64_t gather_x = (cont_x - shift_local[0]) % npts_global[0];
                    if (gather_x < 0) gather_x += npts_global[0];
                    if (!inside[0][ix]) continue;

                    double disp_x = displacement[0][ix];
                    double off_sq = disp_x * disp_x + disp_y_sq + disp_z_sq;
                    if (off_sq > radius_sq) continue;

                    double w = grid[gather_z * npts * npts + gather_y * npts + gather_x];
                    for (int i = 0; i < nlp; ++i) {
                        double pz = pol[2][i][iz];
                        for (int j = 0; j < nlp; ++j) {
                            double py = pol[1][j][iy];
                            for (int k = 0; k < nlp; ++k) {
                                double px = pol[0][k][ix];
                                cxyz[i][j][k] += w * pz * py * px;
                            }
                        }
                    }
                }
            }
        }

        /* ----------------------------------------------------------------
         * 3. Zero out cxyz entries whose total angular degree exceeds lp.
         * ---------------------------------------------------------------- */
        for (int i = 0; i < nlp; ++i) {
            for (int j = 0; j < nlp; ++j) {
                for (int k = 0; k < nlp; ++k) {
                    if (i + j + k > lp) cxyz[i][j][k] = 0.0;
                }
            }
        }

        /* ----------------------------------------------------------------
         * 4. Build the alpha tensors.
         * ---------------------------------------------------------------- */
        for (int idir = 0; idir < 3; ++idir) {
            double drpa = rp[idir] - ra[task * 3 + idir];
            double drpb = rp[idir] - (ra[task * 3 + idir] + rab[task * 3 + idir]);
            for (int lxa = 0; lxa <= la_max[task]; ++lxa) {
                for (int lxb = 0; lxb <= lb_max[task]; ++lxb) {
                    double binom_k = 1.0;   // binomial(lxa, k)
                    double a_pow = 1.0;      // drpa^k
                    for (int k = 0; k <= lxa; ++k) {
                        double binom_l = 1.0; // binomial(lxb, l)
                        double b_pow = 1.0;    // drpb^l
                        for (int l = 0; l <= lxb; ++l) {
                            int ls = (lxa - l) + lxb - k;
                            alpha[idir][lxb][lxa][ls] += binom_k * binom_l * a_pow * b_pow;
                            if (l < lxb) {
                                binom_l *= ((double)(lxb - l)) / ((double)(l + 1));
                            }
                            b_pow *= drpb;
                        }
                        if (k < lxa) {
                            binom_k *= ((double)(lxa - k)) / ((double)(k + 1));
                        }
                        a_pow *= drpa;
                    }
                }
            }
        }

        /* ----------------------------------------------------------------
         * 5. Enumerate cosets for shells a (la) and b (lb).
         * ---------------------------------------------------------------- */
        enumerate_coset(la_min[task], la_max[task], a_lx, a_ly, a_lz, a_ico, &n_a);
        enumerate_coset(lb_min[task], lb_max[task], b_lx, b_ly, b_lz, b_jco, &n_b);

        /* ----------------------------------------------------------------
         * 6. Final contraction – direct triple loop.
         * ---------------------------------------------------------------- */
        double f_factor = f; // just to keep naming consistent with reference
        double prefac = exp(-zeta[task] * f_factor *
                             (rab[task * 3 + 0] * rab[task * 3 + 0] +
                              rab[task * 3 + 1] * rab[task * 3 + 1] +
                              rab[task * 3 + 2] * rab[task * 3 + 2]));

        for (int64_t a_idx = 0; a_idx < n_a; ++a_idx) {
            for (int64_t b_idx = 0; b_idx < n_b; ++b_idx) {
                double acc = 0.0;
                for (int i = 0; i < nlp; ++i) {
                    double a_coeff = alpha[0][b_lx[b_idx]][a_lx[a_idx]][i];
                    for (int j = 0; j < nlp; ++j) {
                        double b_coeff = alpha[1][b_ly[b_idx]][a_ly[a_idx]][j];
                        for (int k = 0; k < nlp; ++k) {
                            double c_coeff = alpha[2][b_lz[b_idx]][a_lz[a_idx]][k];
                            double val = cxyz[i][j][k];
                            if (val != 0.0) {
                                acc += val * a_coeff * b_coeff * c_coeff;
                            }
                        }
                    }
                }
                hab[task * 100 + b_jco[b_idx] * 10 + a_ico[a_idx]] += prefac * acc;
            }
        }
    }
}
