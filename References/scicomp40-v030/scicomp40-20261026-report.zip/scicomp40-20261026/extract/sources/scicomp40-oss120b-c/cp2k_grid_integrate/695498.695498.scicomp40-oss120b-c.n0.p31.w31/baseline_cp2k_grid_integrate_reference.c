// hpcagent_bench-autogen -- generated from cp2k_grid_integrate_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

void cp2k_grid_integrate_fp64(const int32_t *restrict border_width, const double *restrict dh, const double *restrict dh_inv, const double *restrict grid, double *restrict hab, const int32_t *restrict la_max, const int32_t *restrict la_min, const int32_t *restrict lb_max, const int32_t *restrict lb_min, const int32_t *restrict npts_global, const int32_t *restrict npts_local, const double *restrict ra, const double *restrict rab, const double *restrict radius, const int32_t *restrict shift_local, const double *restrict zeta, const double *restrict zetb, const int64_t npts, const int64_t num_tasks, uint8_t *restrict workspace, const int64_t workspace_size) {
        int64_t nlp;
        double rab2;
        double rp0;
        double rp1;
        double rp2;
        double center0_value;
        double center1_value;
        double center2_value;
        int64_t span0;
        int64_t span1;
        int64_t span2;
        int64_t __inl1_n;
        int64_t n_a;
        int64_t __inl2_n;
        int64_t n_b;
        int64_t nrel;
        int64_t center;
        int64_t span;
        double product_center;
        double drpa;
        double drpb;
        double binomial_k_lxa;
        double a_power;
        int64_t __inl1_z;
        int64_t __inl2_z;
        double binomial_l_lxb;
        double b_power;
        int64_t ls;
        double pol_x[(5) * (5)];
        memset(pol_x, 0, (size_t)((5) * (5)) * sizeof(double));
        double pol_y[(5) * (5)];
        memset(pol_y, 0, (size_t)((5) * (5)) * sizeof(double));
        double pol_z[(5) * (5)];
        memset(pol_z, 0, (size_t)((5) * (5)) * sizeof(double));
        double alpha[(3) * (3) * (3) * (5)];
        memset(alpha, 0, (size_t)((3) * (3) * (3) * (5)) * sizeof(double));
        double cxyz[(5) * (5) * (5)];
        memset(cxyz, 0, (size_t)((5) * (5) * (5)) * sizeof(double));
        int64_t __inl1_lx[(10)];
        memset(__inl1_lx, 0, (size_t)((10)) * sizeof(int64_t));
        int64_t __inl1_ly[(10)];
        memset(__inl1_ly, 0, (size_t)((10)) * sizeof(int64_t));
        int64_t __inl1_lz[(10)];
        memset(__inl1_lz, 0, (size_t)((10)) * sizeof(int64_t));
        int64_t __inl1_ico[(10)];
        memset(__inl1_ico, 0, (size_t)((10)) * sizeof(int64_t));
        int64_t __inl2_lx[(10)];
        memset(__inl2_lx, 0, (size_t)((10)) * sizeof(int64_t));
        int64_t __inl2_ly[(10)];
        memset(__inl2_ly, 0, (size_t)((10)) * sizeof(int64_t));
        int64_t __inl2_lz[(10)];
        memset(__inl2_lz, 0, (size_t)((10)) * sizeof(int64_t));
        int64_t __inl2_ico[(10)];
        memset(__inl2_ico, 0, (size_t)((10)) * sizeof(int64_t));
        int64_t a_lx[(10)];
        int64_t a_ly[(10)];
        int64_t a_lz[(10)];
        int64_t a_ico[(10)];
        int64_t b_lx[(10)];
        int64_t b_ly[(10)];
        int64_t b_lz[(10)];
        int64_t b_jco[(10)];
        double *seed = NULL;
        int64_t *__cb1 = NULL;
        int64_t *__cb3 = NULL;
        int64_t *__cb4 = NULL;
        int64_t *__cb5 = NULL;
        double *__cb6 = NULL;
        double *__cb7 = NULL;
        int64_t *__cb8 = NULL;
        int64_t *__cb9 = NULL;
        int64_t *__cb10 = NULL;
        double *__cb11 = NULL;
        int64_t *__cb12 = NULL;
        int64_t *__cb13 = NULL;
        int64_t *__cb14 = NULL;
        int64_t *__cb15 = NULL;
        double *__cb16 = NULL;
        double *__cb17 = NULL;
        double *__cb18 = NULL;
        double *__cb19 = NULL;
        double *scan = NULL;
        double *__td_op1 = NULL;
        double *__td_op2 = NULL;
        double *__td_op3 = NULL;
        int64_t *rel = NULL;
        double *displacement = NULL;
        int64_t *rel_x = NULL;
        int64_t *rel_y = NULL;
        int64_t *rel_z = NULL;
        int64_t *cont_x = NULL;
        int64_t *cont_y = NULL;
        int64_t *cont_z = NULL;
        int64_t *gather_x = NULL;
        int64_t *gather_y = NULL;
        int64_t *gather_z = NULL;
        bool *inside_x = NULL;
        bool *inside_y = NULL;
        bool *inside_z = NULL;
        double *dx = NULL;
        double *dy = NULL;
        double *dz = NULL;
        double *offset = NULL;
        bool *keep = NULL;
        double *weights = NULL;
        double *contribution = NULL;
        int64_t *degree = NULL;
        double *gated = NULL;
        double *contracted = NULL;
        double *contracted__v1 = NULL;
        double *contracted__v2 = NULL;
        double *pz = NULL;
        double *py = NULL;
        double *px = NULL;
        int64_t *deg_z = NULL;
        int64_t *deg_y = NULL;
        int64_t *deg_x = NULL;
        int64_t *zi = NULL;
        int64_t *yi = NULL;
        int64_t *xi = NULL;
        int64_t *si = NULL;
        double *values = NULL;
        for (int64_t task = 0; task < num_tasks; ++task) {
          nlp = ((((int64_t)(((int64_t)(la_max[task])))) + ((int64_t)(((int64_t)(lb_max[task]))))) + 1);
          memset(pol_x, 0, (size_t)((5) * (5)) * sizeof(double));
          memset(pol_y, 0, (size_t)((5) * (5)) * sizeof(double));
          memset(pol_z, 0, (size_t)((5) * (5)) * sizeof(double));
          memset(alpha, 0, (size_t)((3) * (3) * (3) * (5)) * sizeof(double));
          memset(cxyz, 0, (size_t)((5) * (5) * (5)) * sizeof(double));
          rab2 = (((rab[(task)*(3) + (0)] * rab[(task)*(3) + (0)]) + (rab[(task)*(3) + (1)] * rab[(task)*(3) + (1)])) + (rab[(task)*(3) + (2)] * rab[(task)*(3) + (2)]));
          rp0 = (ra[(task)*(3) + (0)] + ((zetb[task] / (zeta[task] + zetb[task])) * rab[(task)*(3) + (0)]));
          rp1 = (ra[(task)*(3) + (1)] + ((zetb[task] / (zeta[task] + zetb[task])) * rab[(task)*(3) + (1)]));
          rp2 = (ra[(task)*(3) + (2)] + ((zetb[task] / (zeta[task] + zetb[task])) * rab[(task)*(3) + (2)]));
          center0_value = (((dh_inv[(0)*(3) + (0)] * rp0) + (dh_inv[(1)*(3) + (0)] * rp1)) + (dh_inv[(2)*(3) + (0)] * rp2));
          center1_value = (((dh_inv[(0)*(3) + (1)] * rp0) + (dh_inv[(1)*(3) + (1)] * rp1)) + (dh_inv[(2)*(3) + (1)] * rp2));
          center2_value = (((dh_inv[(0)*(3) + (2)] * rp0) + (dh_inv[(1)*(3) + (2)] * rp1)) + (dh_inv[(2)*(3) + (2)] * rp2));
          span0 = ((int64_t)((radius[task] / dh[(0)*(3) + (0)])));
          span1 = ((int64_t)((radius[task] / dh[(1)*(3) + (1)])));
          span2 = ((int64_t)((radius[task] / dh[(2)*(3) + (2)])));
          if (((span0 * dh[(0)*(3) + (0)]) < radius[task])) {
            span0 += 1;
          }
          if (((span1 * dh[(1)*(3) + (1)]) < radius[task])) {
            span1 += 1;
          }
          if (((span2 * dh[(2)*(3) + (2)]) < radius[task])) {
            span2 += 1;
          }
          for (int64_t idir = 0; idir < 3; ++idir) {
            if ((idir == 0)) {
              center = ((int64_t)(floor(center0_value)));
              span = span0;
              product_center = rp0;
            }
            else if ((idir == 1)) {
              center = ((int64_t)(floor(center1_value)));
              span = span1;
              product_center = rp1;
            }
            else {
              center = ((int64_t)(floor(center2_value)));
              span = span2;
              product_center = rp2;
            }
            nrel = ((2 * span) + 1);
            free(__cb1);
            __cb1 = (int64_t *)malloc((size_t)((((2 * span) + 1))) * sizeof(int64_t));
            __npb_alloc_check(__cb1, (size_t)((((2 * span) + 1))) * sizeof(int64_t), "__cb1");
            /* numpy: np.arange(-span, span + 1) */
            for (int64_t __i = 0; __i < ((span + 1) - (-span)); ++__i) {
              __cb1[__i] = ((-span) + __i);
            }
            free(rel);
            rel = (int64_t *)malloc((size_t)((((span + 1) - (-span)))) * sizeof(int64_t));
            __npb_alloc_check(rel, (size_t)((((span + 1) - (-span)))) * sizeof(int64_t), "rel");
            for (int64_t __w0 = 0; __w0 < ((span + 1) - (-span)); ++__w0) {
              rel[__w0] = __cb1[__w0];
            }
            free(displacement);
            displacement = (double *)malloc((size_t)((((span + 1) - (-span)))) * sizeof(double));
            __npb_alloc_check(displacement, (size_t)((((span + 1) - (-span)))) * sizeof(double), "displacement");
            for (int64_t __w0 = 0; __w0 < ((span + 1) - (-span)); ++__w0) {
              displacement[__w0] = (((center + rel[__w0]) * dh[(idir)*(3) + (idir)]) - product_center);
            }
            free(seed);
            seed = (double *)malloc((size_t)((nlp) * (nrel)) * sizeof(double));
            __npb_alloc_check(seed, (size_t)((nlp) * (nrel)) * sizeof(double), "seed");
            for (int64_t si1 = 0; si1 < nrel; ++si1) {
              seed[(0)*(nrel) + (si1)] = exp((((-(zeta[task] + zetb[task])) * displacement[si1]) * displacement[si1]));
            }
            for (int64_t si0 = 1; si0 < nlp; ++si0) {
              for (int64_t si1 = 0; si1 < nrel; ++si1) {
                seed[(si0)*(nrel) + (si1)] = displacement[si1];
              }
            }
            free(scan);
            scan = (double *)malloc((size_t)((nlp) * (nrel)) * sizeof(double));
            __npb_alloc_check(scan, (size_t)((nlp) * (nrel)) * sizeof(double), "scan");
            /* numpy: np.cumprod(seed, axis=0) */
            for (int64_t __cs1 = 0; __cs1 < nrel; ++__cs1) {
              scan[(0)*(nrel) + (__cs1)] = seed[(0)*(nrel) + (__cs1)];
              for (int64_t __cs0 = 1; __cs0 < nlp; ++__cs0) {
                scan[(__cs0)*(nrel) + (__cs1)] = (scan[((__cs0 - 1))*(nrel) + (__cs1)] * seed[(__cs0)*(nrel) + (__cs1)]);
              }
            }
            if ((idir == 0)) {
              for (int64_t __scs0 = 0; __scs0 < nlp; ++__scs0) {
                for (int64_t __sc0 = 0; __sc0 < ((span + 1) - (-span)); ++__sc0) {
                  pol_x[(__scs0)*(5) + ((rel[__sc0] + 2))] = scan[(__scs0)*(nrel) + (__sc0)];
                }
              }
            }
            else if ((idir == 1)) {
              for (int64_t __scs0 = 0; __scs0 < nlp; ++__scs0) {
                for (int64_t __sc0 = 0; __sc0 < ((span + 1) - (-span)); ++__sc0) {
                  pol_y[(__scs0)*(5) + ((rel[__sc0] + 2))] = scan[(__scs0)*(nrel) + (__sc0)];
                }
              }
            }
            else {
              for (int64_t __scs0 = 0; __scs0 < nlp; ++__scs0) {
                for (int64_t __sc0 = 0; __sc0 < ((span + 1) - (-span)); ++__sc0) {
                  pol_z[(__scs0)*(5) + ((rel[__sc0] + 2))] = scan[(__scs0)*(nrel) + (__sc0)];
                }
              }
            }
          }
          free(__cb3);
          __cb3 = (int64_t *)malloc((size_t)((((2 * span0) + 1))) * sizeof(int64_t));
          __npb_alloc_check(__cb3, (size_t)((((2 * span0) + 1))) * sizeof(int64_t), "__cb3");
          /* numpy: np.arange(-span0, span0 + 1) */
          for (int64_t __i = 0; __i < ((span0 + 1) - (-span0)); ++__i) {
            __cb3[__i] = ((-span0) + __i);
          }
          free(rel_x);
          rel_x = (int64_t *)malloc((size_t)((((span0 + 1) - (-span0)))) * sizeof(int64_t));
          __npb_alloc_check(rel_x, (size_t)((((span0 + 1) - (-span0)))) * sizeof(int64_t), "rel_x");
          for (int64_t __w0 = 0; __w0 < ((span0 + 1) - (-span0)); ++__w0) {
            rel_x[__w0] = __cb3[__w0];
          }
          free(__cb4);
          __cb4 = (int64_t *)malloc((size_t)((((2 * span1) + 1))) * sizeof(int64_t));
          __npb_alloc_check(__cb4, (size_t)((((2 * span1) + 1))) * sizeof(int64_t), "__cb4");
          /* numpy: np.arange(-span1, span1 + 1) */
          for (int64_t __i = 0; __i < ((span1 + 1) - (-span1)); ++__i) {
            __cb4[__i] = ((-span1) + __i);
          }
          free(rel_y);
          rel_y = (int64_t *)malloc((size_t)((((span1 + 1) - (-span1)))) * sizeof(int64_t));
          __npb_alloc_check(rel_y, (size_t)((((span1 + 1) - (-span1)))) * sizeof(int64_t), "rel_y");
          for (int64_t __w0 = 0; __w0 < ((span1 + 1) - (-span1)); ++__w0) {
            rel_y[__w0] = __cb4[__w0];
          }
          free(__cb5);
          __cb5 = (int64_t *)malloc((size_t)((((2 * span2) + 1))) * sizeof(int64_t));
          __npb_alloc_check(__cb5, (size_t)((((2 * span2) + 1))) * sizeof(int64_t), "__cb5");
          /* numpy: np.arange(-span2, span2 + 1) */
          for (int64_t __i = 0; __i < ((span2 + 1) - (-span2)); ++__i) {
            __cb5[__i] = ((-span2) + __i);
          }
          free(rel_z);
          rel_z = (int64_t *)malloc((size_t)((((span2 + 1) - (-span2)))) * sizeof(int64_t));
          __npb_alloc_check(rel_z, (size_t)((((span2 + 1) - (-span2)))) * sizeof(int64_t), "rel_z");
          for (int64_t __w0 = 0; __w0 < ((span2 + 1) - (-span2)); ++__w0) {
            rel_z[__w0] = __cb5[__w0];
          }
          free(cont_x);
          cont_x = (int64_t *)malloc((size_t)((((span0 + 1) - (-span0)))) * sizeof(int64_t));
          __npb_alloc_check(cont_x, (size_t)((((span0 + 1) - (-span0)))) * sizeof(int64_t), "cont_x");
          for (int64_t __w0 = 0; __w0 < ((span0 + 1) - (-span0)); ++__w0) {
            cont_x[__w0] = (((int64_t)(floor(center0_value))) + rel_x[__w0]);
          }
          free(cont_y);
          cont_y = (int64_t *)malloc((size_t)((((span1 + 1) - (-span1)))) * sizeof(int64_t));
          __npb_alloc_check(cont_y, (size_t)((((span1 + 1) - (-span1)))) * sizeof(int64_t), "cont_y");
          for (int64_t __w0 = 0; __w0 < ((span1 + 1) - (-span1)); ++__w0) {
            cont_y[__w0] = (((int64_t)(floor(center1_value))) + rel_y[__w0]);
          }
          free(cont_z);
          cont_z = (int64_t *)malloc((size_t)((((span2 + 1) - (-span2)))) * sizeof(int64_t));
          __npb_alloc_check(cont_z, (size_t)((((span2 + 1) - (-span2)))) * sizeof(int64_t), "cont_z");
          for (int64_t __w0 = 0; __w0 < ((span2 + 1) - (-span2)); ++__w0) {
            cont_z[__w0] = (((int64_t)(floor(center2_value))) + rel_z[__w0]);
          }
          free(gather_x);
          gather_x = (int64_t *)malloc((size_t)((((span0 + 1) - (-span0)))) * sizeof(int64_t));
          __npb_alloc_check(gather_x, (size_t)((((span0 + 1) - (-span0)))) * sizeof(int64_t), "gather_x");
          for (int64_t __w0 = 0; __w0 < ((span0 + 1) - (-span0)); ++__w0) {
            gather_x[__w0] = python_mod((cont_x[__w0] - ((int64_t)(((int64_t)(shift_local[0]))))), ((int64_t)(((int64_t)(npts_global[0])))));
          }
          free(gather_y);
          gather_y = (int64_t *)malloc((size_t)((((span1 + 1) - (-span1)))) * sizeof(int64_t));
          __npb_alloc_check(gather_y, (size_t)((((span1 + 1) - (-span1)))) * sizeof(int64_t), "gather_y");
          for (int64_t __w0 = 0; __w0 < ((span1 + 1) - (-span1)); ++__w0) {
            gather_y[__w0] = python_mod((cont_y[__w0] - ((int64_t)(((int64_t)(shift_local[1]))))), ((int64_t)(((int64_t)(npts_global[1])))));
          }
          free(gather_z);
          gather_z = (int64_t *)malloc((size_t)((((span2 + 1) - (-span2)))) * sizeof(int64_t));
          __npb_alloc_check(gather_z, (size_t)((((span2 + 1) - (-span2)))) * sizeof(int64_t), "gather_z");
          for (int64_t __w0 = 0; __w0 < ((span2 + 1) - (-span2)); ++__w0) {
            gather_z[__w0] = python_mod((cont_z[__w0] - ((int64_t)(((int64_t)(shift_local[2]))))), ((int64_t)(((int64_t)(npts_global[2])))));
          }
          free(inside_x);
          inside_x = (bool *)malloc((size_t)((((span0 + 1) - (-span0)))) * sizeof(bool));
          __npb_alloc_check(inside_x, (size_t)((((span0 + 1) - (-span0)))) * sizeof(bool), "inside_x");
          for (int64_t __w0 = 0; __w0 < ((span0 + 1) - (-span0)); ++__w0) {
            inside_x[__w0] = ((gather_x[__w0] >= ((int64_t)(((int64_t)(border_width[0]))))) & (gather_x[__w0] < ((int64_t)(((int32_t)((((int64_t)(npts_local[0])) - ((int64_t)(border_width[0])))))))));
          }
          free(inside_y);
          inside_y = (bool *)malloc((size_t)((((span1 + 1) - (-span1)))) * sizeof(bool));
          __npb_alloc_check(inside_y, (size_t)((((span1 + 1) - (-span1)))) * sizeof(bool), "inside_y");
          for (int64_t __w0 = 0; __w0 < ((span1 + 1) - (-span1)); ++__w0) {
            inside_y[__w0] = ((gather_y[__w0] >= ((int64_t)(((int64_t)(border_width[1]))))) & (gather_y[__w0] < ((int64_t)(((int32_t)((((int64_t)(npts_local[1])) - ((int64_t)(border_width[1])))))))));
          }
          free(inside_z);
          inside_z = (bool *)malloc((size_t)((((span2 + 1) - (-span2)))) * sizeof(bool));
          __npb_alloc_check(inside_z, (size_t)((((span2 + 1) - (-span2)))) * sizeof(bool), "inside_z");
          for (int64_t __w0 = 0; __w0 < ((span2 + 1) - (-span2)); ++__w0) {
            inside_z[__w0] = ((gather_z[__w0] >= ((int64_t)(((int64_t)(border_width[2]))))) & (gather_z[__w0] < ((int64_t)(((int32_t)((((int64_t)(npts_local[2])) - ((int64_t)(border_width[2])))))))));
          }
          free(dx);
          dx = (double *)malloc((size_t)((((span0 + 1) - (-span0)))) * sizeof(double));
          __npb_alloc_check(dx, (size_t)((((span0 + 1) - (-span0)))) * sizeof(double), "dx");
          for (int64_t __w0 = 0; __w0 < ((span0 + 1) - (-span0)); ++__w0) {
            dx[__w0] = ((cont_x[__w0] * dh[(0)*(3) + (0)]) - rp0);
          }
          free(dy);
          dy = (double *)malloc((size_t)((((span1 + 1) - (-span1)))) * sizeof(double));
          __npb_alloc_check(dy, (size_t)((((span1 + 1) - (-span1)))) * sizeof(double), "dy");
          for (int64_t __w0 = 0; __w0 < ((span1 + 1) - (-span1)); ++__w0) {
            dy[__w0] = ((cont_y[__w0] * dh[(1)*(3) + (1)]) - rp1);
          }
          free(dz);
          dz = (double *)malloc((size_t)((((span2 + 1) - (-span2)))) * sizeof(double));
          __npb_alloc_check(dz, (size_t)((((span2 + 1) - (-span2)))) * sizeof(double), "dz");
          for (int64_t __w0 = 0; __w0 < ((span2 + 1) - (-span2)); ++__w0) {
            dz[__w0] = ((cont_z[__w0] * dh[(2)*(3) + (2)]) - rp2);
          }
          free(values);
          values = (double *)malloc((size_t)((((span2 + 1) - (-span2))) * (((span1 + 1) - (-span1))) * (((span0 + 1) - (-span0)))) * sizeof(double));
          __npb_alloc_check(values, (size_t)((((span2 + 1) - (-span2))) * (((span1 + 1) - (-span1))) * (((span0 + 1) - (-span0)))) * sizeof(double), "values");
          for (int64_t __w0 = 0; __w0 < ((span2 + 1) - (-span2)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((span1 + 1) - (-span1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < ((span0 + 1) - (-span0)); ++__w2) {
                values[((__w0)*(((span1 + 1) - (-span1))) + (__w1))*(((span0 + 1) - (-span0))) + (__w2)] = grid[((gather_z[__w0])*(npts) + (gather_y[__w1]))*(npts) + (gather_x[__w2])];
              }
            }
          }
          free(offset);
          offset = (double *)malloc((size_t)((((span2 + 1) - (-span2))) * (((span1 + 1) - (-span1))) * (((span0 + 1) - (-span0)))) * sizeof(double));
          __npb_alloc_check(offset, (size_t)((((span2 + 1) - (-span2))) * (((span1 + 1) - (-span1))) * (((span0 + 1) - (-span0)))) * sizeof(double), "offset");
          for (int64_t __w0 = 0; __w0 < ((span2 + 1) - (-span2)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((span1 + 1) - (-span1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < ((span0 + 1) - (-span0)); ++__w2) {
                offset[((__w0)*(((span1 + 1) - (-span1))) + (__w1))*(((span0 + 1) - (-span0))) + (__w2)] = (((dz[__w0] * dz[__w0]) + (dy[__w1] * dy[__w1])) + (dx[__w2] * dx[__w2]));
              }
            }
          }
          free(keep);
          keep = (bool *)malloc((size_t)((((span2 + 1) - (-span2))) * (((span1 + 1) - (-span1))) * (((span0 + 1) - (-span0)))) * sizeof(bool));
          __npb_alloc_check(keep, (size_t)((((span2 + 1) - (-span2))) * (((span1 + 1) - (-span1))) * (((span0 + 1) - (-span0)))) * sizeof(bool), "keep");
          for (int64_t __w0 = 0; __w0 < ((span2 + 1) - (-span2)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((span1 + 1) - (-span1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < ((span0 + 1) - (-span0)); ++__w2) {
                keep[((__w0)*(((span1 + 1) - (-span1))) + (__w1))*(((span0 + 1) - (-span0))) + (__w2)] = (((inside_z[__w0] & inside_y[__w1]) & inside_x[__w2]) & (offset[((__w0)*(((span1 + 1) - (-span1))) + (__w1))*(((span0 + 1) - (-span0))) + (__w2)] <= (radius[task] * radius[task])));
              }
            }
          }
          free(__cb6);
          __cb6 = (double *)malloc((size_t)((((2 * span2) + 1)) * (((2 * span1) + 1)) * (((2 * span0) + 1))) * sizeof(double));
          __npb_alloc_check(__cb6, (size_t)((((2 * span2) + 1)) * (((2 * span1) + 1)) * (((2 * span0) + 1))) * sizeof(double), "__cb6");
          /* numpy: np.where(keep, values, 0.0) */
          for (int64_t __r0 = 0; __r0 < ((span2 + 1) - (-span2)); ++__r0) {
            for (int64_t __r1 = 0; __r1 < ((span1 + 1) - (-span1)); ++__r1) {
              for (int64_t __r2 = 0; __r2 < ((span0 + 1) - (-span0)); ++__r2) {
                __cb6[((__r0)*(((2 * span1) + 1)) + (__r1))*(((2 * span0) + 1)) + (__r2)] = (keep[((__r0)*(((span1 + 1) - (-span1))) + (__r1))*(((span0 + 1) - (-span0))) + (__r2)] ? values[((__r0)*(((span1 + 1) - (-span1))) + (__r1))*(((span0 + 1) - (-span0))) + (__r2)] : 0.0);
              }
            }
          }
          free(weights);
          weights = (double *)malloc((size_t)((((span2 + 1) - (-span2))) * (((span1 + 1) - (-span1))) * (((span0 + 1) - (-span0)))) * sizeof(double));
          __npb_alloc_check(weights, (size_t)((((span2 + 1) - (-span2))) * (((span1 + 1) - (-span1))) * (((span0 + 1) - (-span0)))) * sizeof(double), "weights");
          for (int64_t __w0 = 0; __w0 < ((span2 + 1) - (-span2)); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((span1 + 1) - (-span1)); ++__w1) {
              for (int64_t __w2 = 0; __w2 < ((span0 + 1) - (-span0)); ++__w2) {
                weights[((__w0)*(((span1 + 1) - (-span1))) + (__w1))*(((span0 + 1) - (-span0))) + (__w2)] = __cb6[((__w0)*(((2 * span1) + 1)) + (__w1))*(((2 * span0) + 1)) + (__w2)];
              }
            }
          }
          free(pz);
          pz = (double *)malloc((size_t)((nlp) * (((2 * span2) + 1))) * sizeof(double));
          __npb_alloc_check(pz, (size_t)((nlp) * (((2 * span2) + 1))) * sizeof(double), "pz");
          for (int64_t si0 = 0; si0 < nlp; ++si0) {
            for (int64_t si1 = 0; si1 < ((2 * span2) + 1); ++si1) {
              pz[(si0)*(((2 * span2) + 1)) + (si1)] = pol_z[(si0)*(5) + ((rel_z[si1] + 2))];
            }
          }
          free(py);
          py = (double *)malloc((size_t)((nlp) * (((2 * span1) + 1))) * sizeof(double));
          __npb_alloc_check(py, (size_t)((nlp) * (((2 * span1) + 1))) * sizeof(double), "py");
          for (int64_t si0 = 0; si0 < nlp; ++si0) {
            for (int64_t si1 = 0; si1 < ((2 * span1) + 1); ++si1) {
              py[(si0)*(((2 * span1) + 1)) + (si1)] = pol_y[(si0)*(5) + ((rel_y[si1] + 2))];
            }
          }
          free(px);
          px = (double *)malloc((size_t)((nlp) * (((2 * span0) + 1))) * sizeof(double));
          __npb_alloc_check(px, (size_t)((nlp) * (((2 * span0) + 1))) * sizeof(double), "px");
          for (int64_t si0 = 0; si0 < nlp; ++si0) {
            for (int64_t si1 = 0; si1 < ((2 * span0) + 1); ++si1) {
              px[(si0)*(((2 * span0) + 1)) + (si1)] = pol_x[(si0)*(5) + ((rel_x[si1] + 2))];
            }
          }
          free(__cb7);
          __cb7 = (double *)malloc((size_t)((nlp) * (nlp) * (nlp)) * sizeof(double));
          __npb_alloc_check(__cb7, (size_t)((nlp) * (nlp) * (nlp)) * sizeof(double), "__cb7");
          /* numpy: np.einsum('kji,zk,yj,xi->zyx', weights, pz, py, px, optimize=True) */
          for (int64_t __es_z = 0; __es_z < nlp; ++__es_z) {
            for (int64_t __es_y = 0; __es_y < nlp; ++__es_y) {
              for (int64_t __es_x = 0; __es_x < nlp; ++__es_x) {
                __cb7[((__es_z)*(nlp) + (__es_y))*(nlp) + (__es_x)] = 0.0;
                for (int64_t __es_k = 0; __es_k < ((span2 + 1) - (-span2)); ++__es_k) {
                  for (int64_t __es_j = 0; __es_j < ((span1 + 1) - (-span1)); ++__es_j) {
                    for (int64_t __es_i = 0; __es_i < ((span0 + 1) - (-span0)); ++__es_i) {
                      __cb7[((__es_z)*(nlp) + (__es_y))*(nlp) + (__es_x)] += (((weights[((__es_k)*(((span1 + 1) - (-span1))) + (__es_j))*(((span0 + 1) - (-span0))) + (__es_i)] * pz[(__es_z)*(((2 * span2) + 1)) + (__es_k)]) * py[(__es_y)*(((2 * span1) + 1)) + (__es_j)]) * px[(__es_x)*(((2 * span0) + 1)) + (__es_i)]);
                    }
                  }
                }
              }
            }
          }
          free(contribution);
          contribution = (double *)malloc((size_t)((nlp) * (nlp) * (nlp)) * sizeof(double));
          __npb_alloc_check(contribution, (size_t)((nlp) * (nlp) * (nlp)) * sizeof(double), "contribution");
          for (int64_t __w0 = 0; __w0 < nlp; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nlp; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nlp; ++__w2) {
                contribution[((__w0)*(nlp) + (__w1))*(nlp) + (__w2)] = __cb7[((__w0)*(nlp) + (__w1))*(nlp) + (__w2)];
              }
            }
          }
          free(__cb8);
          __cb8 = (int64_t *)malloc((size_t)((nlp)) * sizeof(int64_t));
          __npb_alloc_check(__cb8, (size_t)((nlp)) * sizeof(int64_t), "__cb8");
          /* numpy: np.arange(nlp) */
          for (int64_t __i = 0; __i < nlp; ++__i) {
            __cb8[__i] = __i;
          }
          free(deg_z);
          deg_z = (int64_t *)malloc((size_t)((nlp) * (1) * (1)) * sizeof(int64_t));
          __npb_alloc_check(deg_z, (size_t)((nlp) * (1) * (1)) * sizeof(int64_t), "deg_z");
          for (int64_t si0 = 0; si0 < nlp; ++si0) {
            for (int64_t si1 = 0; si1 < 1; ++si1) {
              for (int64_t si2 = 0; si2 < 1; ++si2) {
                deg_z[((si0)*(1) + (si1))*(1) + (si2)] = __cb8[si0];
              }
            }
          }
          free(__cb9);
          __cb9 = (int64_t *)malloc((size_t)((nlp)) * sizeof(int64_t));
          __npb_alloc_check(__cb9, (size_t)((nlp)) * sizeof(int64_t), "__cb9");
          /* numpy: np.arange(nlp) */
          for (int64_t __i = 0; __i < nlp; ++__i) {
            __cb9[__i] = __i;
          }
          free(deg_y);
          deg_y = (int64_t *)malloc((size_t)((1) * (nlp) * (1)) * sizeof(int64_t));
          __npb_alloc_check(deg_y, (size_t)((1) * (nlp) * (1)) * sizeof(int64_t), "deg_y");
          for (int64_t si0 = 0; si0 < 1; ++si0) {
            for (int64_t si1 = 0; si1 < nlp; ++si1) {
              for (int64_t si2 = 0; si2 < 1; ++si2) {
                deg_y[((si0)*(nlp) + (si1))*(1) + (si2)] = __cb9[si1];
              }
            }
          }
          free(__cb10);
          __cb10 = (int64_t *)malloc((size_t)((nlp)) * sizeof(int64_t));
          __npb_alloc_check(__cb10, (size_t)((nlp)) * sizeof(int64_t), "__cb10");
          /* numpy: np.arange(nlp) */
          for (int64_t __i = 0; __i < nlp; ++__i) {
            __cb10[__i] = __i;
          }
          free(deg_x);
          deg_x = (int64_t *)malloc((size_t)((1) * (1) * (nlp)) * sizeof(int64_t));
          __npb_alloc_check(deg_x, (size_t)((1) * (1) * (nlp)) * sizeof(int64_t), "deg_x");
          for (int64_t si0 = 0; si0 < 1; ++si0) {
            for (int64_t si1 = 0; si1 < 1; ++si1) {
              for (int64_t si2 = 0; si2 < nlp; ++si2) {
                deg_x[((si0)*(1) + (si1))*(nlp) + (si2)] = __cb10[si2];
              }
            }
          }
          free(degree);
          degree = (int64_t *)malloc((size_t)((nlp) * (nlp) * (nlp)) * sizeof(int64_t));
          __npb_alloc_check(degree, (size_t)((nlp) * (nlp) * (nlp)) * sizeof(int64_t), "degree");
          for (int64_t __w0 = 0; __w0 < nlp; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nlp; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nlp; ++__w2) {
                degree[((__w0)*(nlp) + (__w1))*(nlp) + (__w2)] = ((deg_z[((__w0)*(1) + (0))*(1) + (0)] + deg_y[((0)*(nlp) + (__w1))*(1) + (0)]) + deg_x[((0)*(1) + (0))*(nlp) + (__w2)]);
              }
            }
          }
          free(__cb11);
          __cb11 = (double *)malloc((size_t)((nlp) * (nlp) * (nlp)) * sizeof(double));
          __npb_alloc_check(__cb11, (size_t)((nlp) * (nlp) * (nlp)) * sizeof(double), "__cb11");
          /* numpy: np.where(degree <= lp, contribution, 0.0) */
          for (int64_t __r0 = 0; __r0 < nlp; ++__r0) {
            for (int64_t __r1 = 0; __r1 < nlp; ++__r1) {
              for (int64_t __r2 = 0; __r2 < nlp; ++__r2) {
                __cb11[((__r0)*(nlp) + (__r1))*(nlp) + (__r2)] = ((degree[((__r0)*(nlp) + (__r1))*(nlp) + (__r2)] <= (((int64_t)(((int64_t)(la_max[task])))) + ((int64_t)(((int64_t)(lb_max[task])))))) ? contribution[((__r0)*(nlp) + (__r1))*(nlp) + (__r2)] : 0.0);
              }
            }
          }
          for (int64_t si0 = 0; si0 < nlp; ++si0) {
            for (int64_t si1 = 0; si1 < nlp; ++si1) {
              for (int64_t si2 = 0; si2 < nlp; ++si2) {
                cxyz[((si0)*(5) + (si1))*(5) + (si2)] = __cb11[((si0)*(nlp) + (si1))*(nlp) + (si2)];
              }
            }
          }
          for (int64_t idir = 0; idir < 3; ++idir) {
            if ((idir == 0)) {
              drpa = (rp0 - ra[(task)*(3) + (0)]);
              drpb = (rp0 - (ra[(task)*(3) + (0)] + rab[(task)*(3) + (0)]));
            }
            else if ((idir == 1)) {
              drpa = (rp1 - ra[(task)*(3) + (1)]);
              drpb = (rp1 - (ra[(task)*(3) + (1)] + rab[(task)*(3) + (1)]));
            }
            else {
              drpa = (rp2 - ra[(task)*(3) + (2)]);
              drpb = (rp2 - (ra[(task)*(3) + (2)] + rab[(task)*(3) + (2)]));
            }
            for (int64_t lxa = 0; lxa < (((int64_t)(((int64_t)(la_max[task])))) + 1); ++lxa) {
              for (int64_t lxb = 0; lxb < (((int64_t)(((int64_t)(lb_max[task])))) + 1); ++lxb) {
                binomial_k_lxa = 1.0;
                a_power = 1.0;
                for (int64_t k = 0; k < (lxa + 1); ++k) {
                  binomial_l_lxb = 1.0;
                  b_power = 1.0;
                  for (int64_t l = 0; l < (lxb + 1); ++l) {
                    ls = (((lxa - l) + lxb) - k);
                    alpha[(((idir)*(3) + (lxb))*(3) + (lxa))*(5) + (ls)] += (((binomial_k_lxa * binomial_l_lxb) * a_power) * b_power);
                    binomial_l_lxb *= (((double)((lxb - l))) / ((double)((l + 1))));
                    b_power *= drpb;
                  }
                  binomial_k_lxa *= (((double)((lxa - k))) / ((double)((k + 1))));
                  a_power *= drpa;
                }
              }
            }
          }
          memset(__inl1_lx, 0, (size_t)((10)) * sizeof(int64_t));
          memset(__inl1_ly, 0, (size_t)((10)) * sizeof(int64_t));
          memset(__inl1_lz, 0, (size_t)((10)) * sizeof(int64_t));
          memset(__inl1_ico, 0, (size_t)((10)) * sizeof(int64_t));
          __inl1_n = 0;
          for (int64_t __inl1_total = ((int64_t)(((int64_t)(la_min[task])))); __inl1_total < (((int64_t)(((int64_t)(la_max[task])))) + 1); ++__inl1_total) {
            for (int64_t __inl1_x = 0; __inl1_x < (__inl1_total + 1); ++__inl1_x) {
              for (int64_t __inl1_y = 0; __inl1_y < ((__inl1_total - __inl1_x) + 1); ++__inl1_y) {
                __inl1_z = ((__inl1_total - __inl1_x) - __inl1_y);
                __inl1_lx[__inl1_n] = __inl1_x;
                __inl1_ly[__inl1_n] = __inl1_y;
                __inl1_lz[__inl1_n] = __inl1_z;
                __inl1_ico[__inl1_n] = ((int_floor(((__inl1_total * (__inl1_total + 1)) * (__inl1_total + 2)), 6) + int_floor(((__inl1_total - __inl1_x) * ((__inl1_total - __inl1_x) + 1)), 2)) + __inl1_z);
                __inl1_n += 1;
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < 10; ++__w0) {
            a_lx[__w0] = __inl1_lx[__w0];
          }
          for (int64_t __w0 = 0; __w0 < 10; ++__w0) {
            a_ly[__w0] = __inl1_ly[__w0];
          }
          for (int64_t __w0 = 0; __w0 < 10; ++__w0) {
            a_lz[__w0] = __inl1_lz[__w0];
          }
          for (int64_t __w0 = 0; __w0 < 10; ++__w0) {
            a_ico[__w0] = __inl1_ico[__w0];
          }
          n_a = __inl1_n;
          memset(__inl2_lx, 0, (size_t)((10)) * sizeof(int64_t));
          memset(__inl2_ly, 0, (size_t)((10)) * sizeof(int64_t));
          memset(__inl2_lz, 0, (size_t)((10)) * sizeof(int64_t));
          memset(__inl2_ico, 0, (size_t)((10)) * sizeof(int64_t));
          __inl2_n = 0;
          for (int64_t __inl2_total = ((int64_t)(((int64_t)(lb_min[task])))); __inl2_total < (((int64_t)(((int64_t)(lb_max[task])))) + 1); ++__inl2_total) {
            for (int64_t __inl2_x = 0; __inl2_x < (__inl2_total + 1); ++__inl2_x) {
              for (int64_t __inl2_y = 0; __inl2_y < ((__inl2_total - __inl2_x) + 1); ++__inl2_y) {
                __inl2_z = ((__inl2_total - __inl2_x) - __inl2_y);
                __inl2_lx[__inl2_n] = __inl2_x;
                __inl2_ly[__inl2_n] = __inl2_y;
                __inl2_lz[__inl2_n] = __inl2_z;
                __inl2_ico[__inl2_n] = ((int_floor(((__inl2_total * (__inl2_total + 1)) * (__inl2_total + 2)), 6) + int_floor(((__inl2_total - __inl2_x) * ((__inl2_total - __inl2_x) + 1)), 2)) + __inl2_z);
                __inl2_n += 1;
              }
            }
          }
          for (int64_t __w0 = 0; __w0 < 10; ++__w0) {
            b_lx[__w0] = __inl2_lx[__w0];
          }
          for (int64_t __w0 = 0; __w0 < 10; ++__w0) {
            b_ly[__w0] = __inl2_ly[__w0];
          }
          for (int64_t __w0 = 0; __w0 < 10; ++__w0) {
            b_lz[__w0] = __inl2_lz[__w0];
          }
          for (int64_t __w0 = 0; __w0 < 10; ++__w0) {
            b_jco[__w0] = __inl2_ico[__w0];
          }
          n_b = __inl2_n;
          free(__cb12);
          __cb12 = (int64_t *)malloc((size_t)((nlp)) * sizeof(int64_t));
          __npb_alloc_check(__cb12, (size_t)((nlp)) * sizeof(int64_t), "__cb12");
          /* numpy: np.arange(nlp) */
          for (int64_t __i = 0; __i < nlp; ++__i) {
            __cb12[__i] = __i;
          }
          free(zi);
          zi = (int64_t *)malloc((size_t)((nlp) * (1) * (1)) * sizeof(int64_t));
          __npb_alloc_check(zi, (size_t)((nlp) * (1) * (1)) * sizeof(int64_t), "zi");
          for (int64_t si0 = 0; si0 < nlp; ++si0) {
            for (int64_t si1 = 0; si1 < 1; ++si1) {
              for (int64_t si2 = 0; si2 < 1; ++si2) {
                zi[((si0)*(1) + (si1))*(1) + (si2)] = __cb12[si0];
              }
            }
          }
          free(__cb13);
          __cb13 = (int64_t *)malloc((size_t)((nlp)) * sizeof(int64_t));
          __npb_alloc_check(__cb13, (size_t)((nlp)) * sizeof(int64_t), "__cb13");
          /* numpy: np.arange(nlp) */
          for (int64_t __i = 0; __i < nlp; ++__i) {
            __cb13[__i] = __i;
          }
          free(yi);
          yi = (int64_t *)malloc((size_t)((1) * (nlp) * (1)) * sizeof(int64_t));
          __npb_alloc_check(yi, (size_t)((1) * (nlp) * (1)) * sizeof(int64_t), "yi");
          for (int64_t si0 = 0; si0 < 1; ++si0) {
            for (int64_t si1 = 0; si1 < nlp; ++si1) {
              for (int64_t si2 = 0; si2 < 1; ++si2) {
                yi[((si0)*(nlp) + (si1))*(1) + (si2)] = __cb13[si1];
              }
            }
          }
          free(__cb14);
          __cb14 = (int64_t *)malloc((size_t)((nlp)) * sizeof(int64_t));
          __npb_alloc_check(__cb14, (size_t)((nlp)) * sizeof(int64_t), "__cb14");
          /* numpy: np.arange(nlp) */
          for (int64_t __i = 0; __i < nlp; ++__i) {
            __cb14[__i] = __i;
          }
          free(xi);
          xi = (int64_t *)malloc((size_t)((1) * (1) * (nlp)) * sizeof(int64_t));
          __npb_alloc_check(xi, (size_t)((1) * (1) * (nlp)) * sizeof(int64_t), "xi");
          for (int64_t si0 = 0; si0 < 1; ++si0) {
            for (int64_t si1 = 0; si1 < 1; ++si1) {
              for (int64_t si2 = 0; si2 < nlp; ++si2) {
                xi[((si0)*(1) + (si1))*(nlp) + (si2)] = __cb14[si2];
              }
            }
          }
          free(__cb15);
          __cb15 = (int64_t *)malloc((size_t)((nlp)) * sizeof(int64_t));
          __npb_alloc_check(__cb15, (size_t)((nlp)) * sizeof(int64_t), "__cb15");
          /* numpy: np.arange(nlp) */
          for (int64_t __i = 0; __i < nlp; ++__i) {
            __cb15[__i] = __i;
          }
          free(si);
          si = (int64_t *)malloc((size_t)((nlp) * (1) * (1) * (1)) * sizeof(int64_t));
          __npb_alloc_check(si, (size_t)((nlp) * (1) * (1) * (1)) * sizeof(int64_t), "si");
          for (int64_t si0 = 0; si0 < nlp; ++si0) {
            for (int64_t si1 = 0; si1 < 1; ++si1) {
              for (int64_t si2 = 0; si2 < 1; ++si2) {
                for (int64_t si3 = 0; si3 < 1; ++si3) {
                  si[(((si0)*(1) + (si1))*(1) + (si2))*(1) + (si3)] = __cb15[si0];
                }
              }
            }
          }
          free(__cb16);
          __cb16 = (double *)malloc((size_t)((nlp) * (nlp) * (nlp) * (nlp)) * sizeof(double));
          __npb_alloc_check(__cb16, (size_t)((nlp) * (nlp) * (nlp) * (nlp)) * sizeof(double), "__cb16");
          /* numpy: np.where((zi <= si) & (yi + xi <= lp - si), cxyz[:nlp, :nlp, :nlp], 0.0) */
          for (int64_t __r0 = 0; __r0 < nlp; ++__r0) {
            for (int64_t __r1 = 0; __r1 < nlp; ++__r1) {
              for (int64_t __r2 = 0; __r2 < nlp; ++__r2) {
                for (int64_t __r3 = 0; __r3 < nlp; ++__r3) {
                  __cb16[(((__r0)*(nlp) + (__r1))*(nlp) + (__r2))*(nlp) + (__r3)] = (((zi[((__r1)*(1) + (0))*(1) + (0)] <= si[(((__r0)*(1) + (0))*(1) + (0))*(1) + (0)]) & ((yi[((0)*(nlp) + (__r2))*(1) + (0)] + xi[((0)*(1) + (0))*(nlp) + (__r3)]) <= ((((int64_t)(((int64_t)(la_max[task])))) + ((int64_t)(((int64_t)(lb_max[task]))))) - si[(((__r0)*(1) + (0))*(1) + (0))*(1) + (0)]))) ? cxyz[((__r1)*(5) + (__r2))*(5) + (__r3)] : 0.0);
                }
              }
            }
          }
          free(gated);
          gated = (double *)malloc((size_t)((nlp) * (nlp) * (nlp) * (nlp)) * sizeof(double));
          __npb_alloc_check(gated, (size_t)((nlp) * (nlp) * (nlp) * (nlp)) * sizeof(double), "gated");
          for (int64_t __w0 = 0; __w0 < nlp; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nlp; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nlp; ++__w2) {
                for (int64_t __w3 = 0; __w3 < nlp; ++__w3) {
                  gated[(((__w0)*(nlp) + (__w1))*(nlp) + (__w2))*(nlp) + (__w3)] = __cb16[(((__w0)*(nlp) + (__w1))*(nlp) + (__w2))*(nlp) + (__w3)];
                }
              }
            }
          }
          free(__cb17);
          __cb17 = (double *)malloc((size_t)((nlp) * (nlp) * (nlp) * (3) * (3)) * sizeof(double));
          __npb_alloc_check(__cb17, (size_t)((nlp) * (nlp) * (nlp) * (3) * (3)) * sizeof(double), "__cb17");
          free(__td_op1);
          __td_op1 = (double *)malloc((size_t)((3) * (3) * (nlp)) * sizeof(double));
          __npb_alloc_check(__td_op1, (size_t)((3) * (3) * (nlp)) * sizeof(double), "__td_op1");
          /* numpy: np.tensordot(gated, alpha[0, :, :, :nlp], axes=([3], [2])) */
          for (int64_t __td_c0 = 0; __td_c0 < 3; ++__td_c0) {
            for (int64_t __td_c1 = 0; __td_c1 < 3; ++__td_c1) {
              for (int64_t __td_c2 = 0; __td_c2 < nlp; ++__td_c2) {
                __td_op1[((__td_c0)*(3) + (__td_c1))*(nlp) + (__td_c2)] = alpha[(((0)*(3) + (__td_c0))*(3) + (__td_c1))*(5) + (__td_c2)];
              }
            }
          }
          for (int64_t __es_a = 0; __es_a < nlp; ++__es_a) {
            for (int64_t __es_b = 0; __es_b < nlp; ++__es_b) {
              for (int64_t __es_c = 0; __es_c < nlp; ++__es_c) {
                for (int64_t __es_e = 0; __es_e < 3; ++__es_e) {
                  for (int64_t __es_f = 0; __es_f < 3; ++__es_f) {
                    __cb17[((((__es_a)*(nlp) + (__es_b))*(nlp) + (__es_c))*(3) + (__es_e))*(3) + (__es_f)] = 0.0;
                    for (int64_t __es_d = 0; __es_d < nlp; ++__es_d) {
                      __cb17[((((__es_a)*(nlp) + (__es_b))*(nlp) + (__es_c))*(3) + (__es_e))*(3) + (__es_f)] += (gated[(((__es_a)*(nlp) + (__es_b))*(nlp) + (__es_c))*(nlp) + (__es_d)] * __td_op1[((__es_e)*(3) + (__es_f))*(nlp) + (__es_d)]);
                    }
                  }
                }
              }
            }
          }
          free(contracted);
          contracted = (double *)malloc((size_t)((nlp) * (nlp) * (nlp) * (3) * (3)) * sizeof(double));
          __npb_alloc_check(contracted, (size_t)((nlp) * (nlp) * (nlp) * (3) * (3)) * sizeof(double), "contracted");
          for (int64_t __w0 = 0; __w0 < nlp; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nlp; ++__w1) {
              for (int64_t __w2 = 0; __w2 < nlp; ++__w2) {
                for (int64_t __w3 = 0; __w3 < 3; ++__w3) {
                  for (int64_t __w4 = 0; __w4 < 3; ++__w4) {
                    contracted[((((__w0)*(nlp) + (__w1))*(nlp) + (__w2))*(3) + (__w3))*(3) + (__w4)] = __cb17[((((__w0)*(nlp) + (__w1))*(nlp) + (__w2))*(3) + (__w3))*(3) + (__w4)];
                  }
                }
              }
            }
          }
          free(__cb18);
          __cb18 = (double *)malloc((size_t)((nlp) * (nlp) * (3) * (3) * (3) * (3)) * sizeof(double));
          __npb_alloc_check(__cb18, (size_t)((nlp) * (nlp) * (3) * (3) * (3) * (3)) * sizeof(double), "__cb18");
          free(__td_op2);
          __td_op2 = (double *)malloc((size_t)((3) * (3) * (nlp)) * sizeof(double));
          __npb_alloc_check(__td_op2, (size_t)((3) * (3) * (nlp)) * sizeof(double), "__td_op2");
          /* numpy: np.tensordot(contracted, alpha[1, :, :, :nlp], axes=([2], [2])) */
          for (int64_t __td_c0 = 0; __td_c0 < 3; ++__td_c0) {
            for (int64_t __td_c1 = 0; __td_c1 < 3; ++__td_c1) {
              for (int64_t __td_c2 = 0; __td_c2 < nlp; ++__td_c2) {
                __td_op2[((__td_c0)*(3) + (__td_c1))*(nlp) + (__td_c2)] = alpha[(((1)*(3) + (__td_c0))*(3) + (__td_c1))*(5) + (__td_c2)];
              }
            }
          }
          for (int64_t __es_a = 0; __es_a < nlp; ++__es_a) {
            for (int64_t __es_b = 0; __es_b < nlp; ++__es_b) {
              for (int64_t __es_d = 0; __es_d < 3; ++__es_d) {
                for (int64_t __es_e = 0; __es_e < 3; ++__es_e) {
                  for (int64_t __es_f = 0; __es_f < 3; ++__es_f) {
                    for (int64_t __es_g = 0; __es_g < 3; ++__es_g) {
                      __cb18[(((((__es_a)*(nlp) + (__es_b))*(3) + (__es_d))*(3) + (__es_e))*(3) + (__es_f))*(3) + (__es_g)] = 0.0;
                      for (int64_t __es_c = 0; __es_c < nlp; ++__es_c) {
                        __cb18[(((((__es_a)*(nlp) + (__es_b))*(3) + (__es_d))*(3) + (__es_e))*(3) + (__es_f))*(3) + (__es_g)] += (contracted[((((__es_a)*(nlp) + (__es_b))*(nlp) + (__es_c))*(3) + (__es_d))*(3) + (__es_e)] * __td_op2[((__es_f)*(3) + (__es_g))*(nlp) + (__es_c)]);
                      }
                    }
                  }
                }
              }
            }
          }
          free(contracted__v1);
          contracted__v1 = (double *)malloc((size_t)((nlp) * (nlp) * (3) * (3) * (3) * (3)) * sizeof(double));
          __npb_alloc_check(contracted__v1, (size_t)((nlp) * (nlp) * (3) * (3) * (3) * (3)) * sizeof(double), "contracted__v1");
          for (int64_t __w0 = 0; __w0 < nlp; ++__w0) {
            for (int64_t __w1 = 0; __w1 < nlp; ++__w1) {
              for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
                for (int64_t __w3 = 0; __w3 < 3; ++__w3) {
                  for (int64_t __w4 = 0; __w4 < 3; ++__w4) {
                    for (int64_t __w5 = 0; __w5 < 3; ++__w5) {
                      contracted__v1[(((((__w0)*(nlp) + (__w1))*(3) + (__w2))*(3) + (__w3))*(3) + (__w4))*(3) + (__w5)] = __cb18[(((((__w0)*(nlp) + (__w1))*(3) + (__w2))*(3) + (__w3))*(3) + (__w4))*(3) + (__w5)];
                    }
                  }
                }
              }
            }
          }
          free(__cb19);
          __cb19 = (double *)malloc((size_t)((nlp) * (3) * (3) * (3) * (3) * (3) * (3)) * sizeof(double));
          __npb_alloc_check(__cb19, (size_t)((nlp) * (3) * (3) * (3) * (3) * (3) * (3)) * sizeof(double), "__cb19");
          free(__td_op3);
          __td_op3 = (double *)malloc((size_t)((3) * (3) * (nlp)) * sizeof(double));
          __npb_alloc_check(__td_op3, (size_t)((3) * (3) * (nlp)) * sizeof(double), "__td_op3");
          /* numpy: np.tensordot(contracted__v1, alpha[2, :, :, :nlp], axes=([1], [2])) */
          for (int64_t __td_c0 = 0; __td_c0 < 3; ++__td_c0) {
            for (int64_t __td_c1 = 0; __td_c1 < 3; ++__td_c1) {
              for (int64_t __td_c2 = 0; __td_c2 < nlp; ++__td_c2) {
                __td_op3[((__td_c0)*(3) + (__td_c1))*(nlp) + (__td_c2)] = alpha[(((2)*(3) + (__td_c0))*(3) + (__td_c1))*(5) + (__td_c2)];
              }
            }
          }
          for (int64_t __es_a = 0; __es_a < nlp; ++__es_a) {
            for (int64_t __es_c = 0; __es_c < 3; ++__es_c) {
              for (int64_t __es_d = 0; __es_d < 3; ++__es_d) {
                for (int64_t __es_e = 0; __es_e < 3; ++__es_e) {
                  for (int64_t __es_f = 0; __es_f < 3; ++__es_f) {
                    for (int64_t __es_g = 0; __es_g < 3; ++__es_g) {
                      for (int64_t __es_h = 0; __es_h < 3; ++__es_h) {
                        __cb19[((((((__es_a)*(3) + (__es_c))*(3) + (__es_d))*(3) + (__es_e))*(3) + (__es_f))*(3) + (__es_g))*(3) + (__es_h)] = 0.0;
                        for (int64_t __es_b = 0; __es_b < nlp; ++__es_b) {
                          __cb19[((((((__es_a)*(3) + (__es_c))*(3) + (__es_d))*(3) + (__es_e))*(3) + (__es_f))*(3) + (__es_g))*(3) + (__es_h)] += (contracted__v1[(((((__es_a)*(nlp) + (__es_b))*(3) + (__es_c))*(3) + (__es_d))*(3) + (__es_e))*(3) + (__es_f)] * __td_op3[((__es_g)*(3) + (__es_h))*(nlp) + (__es_b)]);
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          free(contracted__v2);
          contracted__v2 = (double *)malloc((size_t)((nlp) * (3) * (3) * (3) * (3) * (3) * (3)) * sizeof(double));
          __npb_alloc_check(contracted__v2, (size_t)((nlp) * (3) * (3) * (3) * (3) * (3) * (3)) * sizeof(double), "contracted__v2");
          for (int64_t __w0 = 0; __w0 < nlp; ++__w0) {
            for (int64_t __w1 = 0; __w1 < 3; ++__w1) {
              for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
                for (int64_t __w3 = 0; __w3 < 3; ++__w3) {
                  for (int64_t __w4 = 0; __w4 < 3; ++__w4) {
                    for (int64_t __w5 = 0; __w5 < 3; ++__w5) {
                      for (int64_t __w6 = 0; __w6 < 3; ++__w6) {
                        contracted__v2[((((((__w0)*(3) + (__w1))*(3) + (__w2))*(3) + (__w3))*(3) + (__w4))*(3) + (__w5))*(3) + (__w6)] = __cb19[((((((__w0)*(3) + (__w1))*(3) + (__w2))*(3) + (__w3))*(3) + (__w4))*(3) + (__w5))*(3) + (__w6)];
                      }
                    }
                  }
                }
              }
            }
          }
          for (int64_t ia = 0; ia < n_a; ++ia) {
            for (int64_t ib = 0; ib < n_b; ++ib) {
              hab[((task)*(10) + (b_jco[ib]))*(10) + (a_ico[ia])] += (exp((((-zeta[task]) * (zetb[task] / (zeta[task] + zetb[task]))) * rab2)) * contracted__v2[(((((((a_lz[ia] + b_lz[ib]))*(3) + (b_lx[ib]))*(3) + (a_lx[ia]))*(3) + (b_ly[ib]))*(3) + (a_ly[ia]))*(3) + (b_lz[ib]))*(3) + (a_lz[ia])]);
            }
          }
        }
        free(seed);
        free(__cb1);
        free(__cb3);
        free(__cb4);
        free(__cb5);
        free(__cb6);
        free(__cb7);
        free(__cb8);
        free(__cb9);
        free(__cb10);
        free(__cb11);
        free(__cb12);
        free(__cb13);
        free(__cb14);
        free(__cb15);
        free(__cb16);
        free(__cb17);
        free(__cb18);
        free(__cb19);
        free(scan);
        free(__td_op1);
        free(__td_op2);
        free(__td_op3);
        free(rel);
        free(displacement);
        free(rel_x);
        free(rel_y);
        free(rel_z);
        free(cont_x);
        free(cont_y);
        free(cont_z);
        free(gather_x);
        free(gather_y);
        free(gather_z);
        free(inside_x);
        free(inside_y);
        free(inside_z);
        free(dx);
        free(dy);
        free(dz);
        free(offset);
        free(keep);
        free(weights);
        free(contribution);
        free(degree);
        free(gated);
        free(contracted);
        free(contracted__v1);
        free(contracted__v2);
        free(pz);
        free(py);
        free(px);
        free(deg_z);
        free(deg_y);
        free(deg_x);
        free(zi);
        free(yi);
        free(xi);
        free(si);
        free(values);
}
