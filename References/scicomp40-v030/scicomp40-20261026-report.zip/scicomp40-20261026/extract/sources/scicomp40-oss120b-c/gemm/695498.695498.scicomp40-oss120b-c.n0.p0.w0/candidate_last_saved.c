#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <cblas.h>

void gemm_fp64(
    const double *restrict A,
    const double *restrict B,
    double *restrict C,
    const int64_t NI,
    const int64_t NJ,
    const int64_t NK,
    const double alpha,
    const double beta,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    (void)workspace; // unused
    (void)workspace_size; // unused
    // Use OpenBLAS (cblas) for matrix multiplication.
    // C = alpha * A * B + beta * C; row-major layout.
    // Ensure dimensions fit into int for BLAS.
    cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                (int)NI, (int)NJ, (int)NK,
                alpha, A, (int)NK,
                B, (int)NJ,
                beta, C, (int)NJ);
}

