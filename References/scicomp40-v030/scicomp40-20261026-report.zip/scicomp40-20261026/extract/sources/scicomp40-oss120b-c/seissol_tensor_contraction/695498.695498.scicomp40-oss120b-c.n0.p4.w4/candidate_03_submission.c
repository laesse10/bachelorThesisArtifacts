#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <stdio.h>
#include <complex.h>
#ifdef I
#undef I
#endif

/* Optimized tensor contraction for seissol. */

void seissol_tensor_contraction_fp64(const double *restrict I,
                                     double *restrict Q,
                                     const double *restrict kDivM,
                                     const double *restrict star,
                                     const int64_t batch,
                                     uint8_t *restrict workspace,
                                     const int64_t workspace_size)
{
    const int64_t nb = 84;
    const int64_t dim9 = 9;
    (void)workspace; // unused parameter to keep signature compatible
    (void)workspace_size;
        double *R = (double *)malloc((size_t)nb * dim9 * sizeof(double));
        if (R == NULL) {
            fprintf(stderr, "out of memory: %zu bytes for temporary buffer\\n", (size_t)nb * dim9 * sizeof(double));
            abort();
        }
                for (int64_t b = 0; b < batch; ++b) {
            const double *I_b = I + b * nb * dim9;
            double *Q_b = Q + b * nb * dim9;
            for (int d = 0; d < 3; ++d) {
                const double *star_d = star + d * dim9 * dim9;
                // R = I_b * star_d -> (nb x 9) = (nb x 9) * (9 x 9)
                // Compute R = I_b * star_d (nb x 9)
                for (int i = 0; i < nb; ++i) {
                    const double *I_row = I_b + i * dim9;
                    double *R_row = R + i * dim9;
                    for (int j = 0; j < dim9; ++j) {
                        double sum = 0.0;
                        for (int q = 0; q < dim9; ++q) {
                            sum += I_row[q] * star_d[q * dim9 + j];
                        }
                        R_row[j] = sum;
                    }
                }
                const double *K_d = kDivM + d * nb * nb;
                // Q_b += K_d * R -> (nb x 9) += (nb x nb) * (nb x 9)
                // Accumulate Q_b += K_d * R
                for (int i = 0; i < nb; ++i) {
                    double *Q_row = Q_b + i * dim9;
                    for (int k = 0; k < nb; ++k) {
                        double K_ik = K_d[i * nb + k];
                        const double *R_row = R + k * dim9;
                        for (int j = 0; j < dim9; ++j) {
                            Q_row[j] += K_ik * R_row[j];
                        }
                    }
                }
            }
        }
        free(R);
}
