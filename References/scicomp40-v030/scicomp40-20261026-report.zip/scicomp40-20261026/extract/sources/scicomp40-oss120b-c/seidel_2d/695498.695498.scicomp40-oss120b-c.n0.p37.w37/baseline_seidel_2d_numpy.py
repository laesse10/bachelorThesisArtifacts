# Adapted from PolyBench/C 4.2.1 (github.com/MatthiasJReisinger/PolyBenchC-4.2.1),
# permissive license (Ohio State University). Reimplemented in NumPy as the
# HPCAgent-Bench correctness reference.


def kernel(TSTEPS, N, A):

    for t in range(TSTEPS):
        for i in range(1, N - 1):
            A[i, 1:-1] += (
                A[i - 1, :-2] + A[i - 1, 1:-1] + A[i - 1, 2:] + A[i, 2:] + A[i + 1, :-2] + A[i + 1, 1:-1] + A[i + 1, 2:]
            )
            for j in range(1, N - 1):
                A[i, j] += A[i, j - 1]
                A[i, j] /= 9.0
