#include <stdint.h>
#include <stddef.h>
#include <math.h>
#include <omp.h>

// Optimized implementation of the 2D Seidel stencil.
// The signature must match that in signature.json.
void seidel_2d_fp64(double *restrict A, const int64_t N, const int64_t TSTEPS,
                    uint8_t *restrict workspace, const int64_t workspace_size) {
    // The workspace arguments are unused in this kernel.
    const int64_t n = N;
    double *restrict a = (double * __restrict__) __builtin_assume_aligned(A, 64);
    // Outer time-step loop.
    for (int64_t t = 0; t < TSTEPS; ++t) {
        // Iterate over interior rows.
        for (int64_t i = 1; i < n - 1; ++i) {
            double *restrict cur = a + i * n;        // current row
            double *restrict up  = a + (i - 1) * n;  // row above
            double *restrict down = a + (i + 1) * n; // row below
            // Combined phase: compute neighbor sum, add to element, and apply prefix-like update.
            double left = cur[0];
            for (int64_t j = 1; j < n - 1; ++j) {
                double s = up[j - 1];
                s += up[j];
                s += up[j + 1];
                s += cur[j + 1];
                s += down[j - 1];
                s += down[j];
                s += down[j + 1];
                double val = cur[j] + s;
                val = (val + left) / 9.0;
                cur[j] = val;
                left = val;
            }
        }
    }
    // Suppress unused parameter warnings.
    (void)workspace;
    (void)workspace_size;
}
