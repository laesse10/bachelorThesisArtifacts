#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

/*
 * Optimized implementation of lavamd_fp64.
 * Computes forces from neighbor particles using an exponential kernel.
 * The algorithm mirrors the reference implementation but eliminates temporary
 * allocations and combines the computation into a tightly‑nested loop, enabling
 * better cache utilization and vectorization. Parallelism is introduced over the
 * outer box loop using OpenMP.
 */
void lavamd_fp64(
    const int32_t *restrict box_offsets,
    double *restrict fv,
    const int32_t *restrict neighbor_counts,
    const int32_t *restrict neighbor_list,
    const double *restrict qv,
    const double *restrict rv,
    const double alpha,
    const int64_t max_neighbors,
    const int64_t n_boxes,
    const int64_t particles_per_box,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    const double a2 = (2.0 * alpha) * alpha;

    /* Parallelize over boxes. Each box works on a distinct range of the
     * fv array, so no race conditions arise.
     */
    #pragma omp parallel for schedule(static)
    for (int64_t l = 0; l < n_boxes; ++l) {
        const int64_t first_i = (int64_t)box_offsets[l];
        const int64_t last_i = first_i + particles_per_box;
        const int64_t count = (int64_t)neighbor_counts[l];
        /* Process each particle i in the current box. */
        for (int64_t i = first_i; i < last_i; ++i) {
            const double *restrict rv_i = &rv[i * 4];
            const double rv_i0 = rv_i[0];
            const double rv_i1 = rv_i[1];
            const double rv_i2 = rv_i[2];
            const double rv_i3 = rv_i[3];
            double acc0 = 0.0, acc1 = 0.0, acc2 = 0.0, acc3 = 0.0;

            /* Loop over self + neighbor boxes. */
            for (int64_t nb = 0; nb <= count; ++nb) {
                int64_t neighbor_box = (nb == 0) ? l : (int64_t)neighbor_list[l * max_neighbors + (nb - 1)];
                const int64_t first_j = (int64_t)box_offsets[neighbor_box];
                const int64_t last_j = first_j + particles_per_box;
                for (int64_t j = first_j; j < last_j; ++j) {
                    const double *restrict rv_j = &rv[j * 4];
                    const double qv_j = qv[j];

                    /* Compute the scalar r2 term as in the reference. */
                    const double r2 = (rv_i0 + rv_j[0]) -
                                      (rv_i1 * rv_j[1] + rv_i2 * rv_j[2] + rv_i3 * rv_j[3]);
                    const double u2 = a2 * r2;
                    const double vij = exp(-u2);
                    const double fs = 2.0 * vij;

                    const double dx = rv_i1 - rv_j[1];
                    const double dy = rv_i2 - rv_j[2];
                    const double dz = rv_i3 - rv_j[3];

                    acc0 += qv_j * vij;
                    acc1 += qv_j * fs * dx;
                    acc2 += qv_j * fs * dy;
                    acc3 += qv_j * fs * dz;
                }
            }
            const int64_t out_idx = i * 4;
            fv[out_idx + 0] += acc0;
            fv[out_idx + 1] += acc1;
            fv[out_idx + 2] += acc2;
            fv[out_idx + 3] += acc3;
        }
    }
    /* workspace is currently unused – it is provided for compatibility with the
     * benchmark harness.
     */
    (void)workspace;
    (void)workspace_size;
}

