// hpcagent_bench-autogen -- generated from lavamd_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

void lavamd_fp64(const int32_t *restrict box_offsets, double *restrict fv, const int32_t *restrict neighbor_counts, const int32_t *restrict neighbor_list, const double *restrict qv, const double *restrict rv, const double alpha, const int64_t max_neighbors, const int64_t n_boxes, const int64_t particles_per_box, uint8_t *restrict workspace, const int64_t workspace_size) {
        double a2;
        int64_t first_i;
        int64_t last_i;
        int64_t count;
        int64_t *__cb1 = (int64_t *)malloc((size_t)((particles_per_box)) * sizeof(int64_t));
        __npb_alloc_check(__cb1, (size_t)((particles_per_box)) * sizeof(int64_t), "__cb1");
        int64_t *within_box = (int64_t *)malloc((size_t)((particles_per_box)) * sizeof(int64_t));
        __npb_alloc_check(within_box, (size_t)((particles_per_box)) * sizeof(int64_t), "within_box");
        int64_t *pointers = NULL;
        double *__cb2 = NULL;
        double *__cb3 = NULL;
        double *__cb4 = NULL;
        double *__cb5 = NULL;
        double *__cb6 = NULL;
        int64_t *neighbor_offsets = NULL;
        int64_t *bj = NULL;
        double *r2 = NULL;
        double *u2 = NULL;
        double *fs = NULL;
        double *dx = NULL;
        double *dy = NULL;
        double *dz = NULL;
        double *term0 = NULL;
        double *term1 = NULL;
        double *term2 = NULL;
        double *term3 = NULL;
        int64_t *first_j = NULL;
        double *rv_i = NULL;
        double *rv_j = NULL;
        double *qv_j = NULL;
        double *vij = NULL;
        a2 = ((2.0 * alpha) * alpha);
        /* numpy: np.arange(particles_per_box, dtype=np.int64) */
        for (int64_t __i = 0; __i < particles_per_box; ++__i) {
          __cb1[__i] = __i;
        }
        for (int64_t __w0 = 0; __w0 < particles_per_box; ++__w0) {
          within_box[__w0] = __cb1[__w0];
        }
        for (int64_t l = 0; l < n_boxes; ++l) {
          first_i = ((int64_t)(((int64_t)(box_offsets[l]))));
          last_i = (first_i + particles_per_box);
          count = ((int64_t)(((int64_t)(neighbor_counts[l]))));
          free(pointers);
          pointers = (int64_t *)malloc((size_t)(((1 + count))) * sizeof(int64_t));
          __npb_alloc_check(pointers, (size_t)(((1 + count))) * sizeof(int64_t), "pointers");
          pointers[0] = l;
          for (int64_t si0 = 1; si0 < (1 + count); ++si0) {
            pointers[si0] = ((int64_t)(neighbor_list[(l)*(max_neighbors) + ((si0 - 1))]));
          }
          free(first_j);
          first_j = (int64_t *)malloc((size_t)(((1 + count))) * sizeof(int64_t));
          __npb_alloc_check(first_j, (size_t)(((1 + count))) * sizeof(int64_t), "first_j");
          for (int64_t __w0 = 0; __w0 < (1 + count); ++__w0) {
            first_j[__w0] = ((int64_t)(((int64_t)(box_offsets[pointers[__w0]]))));
          }
          free(neighbor_offsets);
          neighbor_offsets = (int64_t *)malloc((size_t)(((1 + count)) * (particles_per_box)) * sizeof(int64_t));
          __npb_alloc_check(neighbor_offsets, (size_t)(((1 + count)) * (particles_per_box)) * sizeof(int64_t), "neighbor_offsets");
          for (int64_t __w0 = 0; __w0 < (1 + count); ++__w0) {
            for (int64_t __w1 = 0; __w1 < particles_per_box; ++__w1) {
              neighbor_offsets[(__w0)*(particles_per_box) + (__w1)] = (first_j[__w0] + within_box[__w1]);
            }
          }
          free(__cb2);
          __cb2 = (double *)malloc((size_t)((((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(__cb2, (size_t)((((1 + count) * particles_per_box))) * sizeof(double), "__cb2");
          /* numpy: np.reshape(neighbor_offsets, (-1,)) */
          for (int64_t __rs0 = 0; __rs0 < (1 + count); ++__rs0) {
            for (int64_t __rs1 = 0; __rs1 < particles_per_box; ++__rs1) {
              __cb2[((__rs0 * particles_per_box) + __rs1)] = neighbor_offsets[(__rs0)*(particles_per_box) + (__rs1)];
            }
          }
          free(bj);
          bj = (int64_t *)malloc((size_t)((((1 + count) * particles_per_box))) * sizeof(int64_t));
          __npb_alloc_check(bj, (size_t)((((1 + count) * particles_per_box))) * sizeof(int64_t), "bj");
          for (int64_t __w0 = 0; __w0 < ((1 + count) * particles_per_box); ++__w0) {
            bj[__w0] = __cb2[__w0];
          }
          free(rv_i);
          rv_i = (double *)malloc((size_t)(((last_i - first_i)) * (4)) * sizeof(double));
          __npb_alloc_check(rv_i, (size_t)(((last_i - first_i)) * (4)) * sizeof(double), "rv_i");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
              rv_i[(__w0)*(4) + (__w1)] = rv[((__w0 + (first_i - 0)))*(4) + (__w1)];
            }
          }
          free(rv_j);
          rv_j = (double *)malloc((size_t)((((1 + count) * particles_per_box)) * (4)) * sizeof(double));
          __npb_alloc_check(rv_j, (size_t)((((1 + count) * particles_per_box)) * (4)) * sizeof(double), "rv_j");
          for (int64_t __w0 = 0; __w0 < ((1 + count) * particles_per_box); ++__w0) {
            for (int64_t __w1 = 0; __w1 < 4; ++__w1) {
              rv_j[(__w0)*(4) + (__w1)] = rv[(bj[__w0])*(4) + (__w1)];
            }
          }
          free(qv_j);
          qv_j = (double *)malloc((size_t)((((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(qv_j, (size_t)((((1 + count) * particles_per_box))) * sizeof(double), "qv_j");
          for (int64_t __w0 = 0; __w0 < ((1 + count) * particles_per_box); ++__w0) {
            qv_j[__w0] = qv[bj[__w0]];
          }
          free(r2);
          r2 = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(r2, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "r2");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              r2[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = ((rv_i[(__w0)*(4) + (0)] + rv_j[(__w1)*(4) + (0)]) - (((rv_i[(__w0)*(4) + (1)] * rv_j[(__w1)*(4) + (1)]) + (rv_i[(__w0)*(4) + (2)] * rv_j[(__w1)*(4) + (2)])) + (rv_i[(__w0)*(4) + (3)] * rv_j[(__w1)*(4) + (3)])));
            }
          }
          free(u2);
          u2 = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(u2, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "u2");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              u2[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = (a2 * r2[(__w0)*(((1 + count) * particles_per_box)) + (__w1)]);
            }
          }
          free(vij);
          vij = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(vij, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "vij");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              vij[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = exp((-u2[(__w0)*(((1 + count) * particles_per_box)) + (__w1)]));
            }
          }
          free(fs);
          fs = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(fs, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "fs");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              fs[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = (2.0 * vij[(__w0)*(((1 + count) * particles_per_box)) + (__w1)]);
            }
          }
          free(dx);
          dx = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(dx, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "dx");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              dx[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = (rv_i[(__w0)*(4) + (1)] - rv_j[(__w1)*(4) + (1)]);
            }
          }
          free(dy);
          dy = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(dy, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "dy");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              dy[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = (rv_i[(__w0)*(4) + (2)] - rv_j[(__w1)*(4) + (2)]);
            }
          }
          free(dz);
          dz = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(dz, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "dz");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              dz[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = (rv_i[(__w0)*(4) + (3)] - rv_j[(__w1)*(4) + (3)]);
            }
          }
          free(term0);
          term0 = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(term0, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "term0");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              term0[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = (qv_j[__w1] * vij[(__w0)*(((1 + count) * particles_per_box)) + (__w1)]);
            }
          }
          free(term1);
          term1 = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(term1, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "term1");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              term1[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = ((qv_j[__w1] * fs[(__w0)*(((1 + count) * particles_per_box)) + (__w1)]) * dx[(__w0)*(((1 + count) * particles_per_box)) + (__w1)]);
            }
          }
          free(term2);
          term2 = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(term2, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "term2");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              term2[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = ((qv_j[__w1] * fs[(__w0)*(((1 + count) * particles_per_box)) + (__w1)]) * dy[(__w0)*(((1 + count) * particles_per_box)) + (__w1)]);
            }
          }
          free(term3);
          term3 = (double *)malloc((size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double));
          __npb_alloc_check(term3, (size_t)(((last_i - first_i)) * (((1 + count) * particles_per_box))) * sizeof(double), "term3");
          for (int64_t __w0 = 0; __w0 < (last_i - first_i); ++__w0) {
            for (int64_t __w1 = 0; __w1 < ((1 + count) * particles_per_box); ++__w1) {
              term3[(__w0)*(((1 + count) * particles_per_box)) + (__w1)] = ((qv_j[__w1] * fs[(__w0)*(((1 + count) * particles_per_box)) + (__w1)]) * dz[(__w0)*(((1 + count) * particles_per_box)) + (__w1)]);
            }
          }
          free(__cb3);
          __cb3 = (double *)malloc((size_t)(((last_i - first_i))) * sizeof(double));
          __npb_alloc_check(__cb3, (size_t)(((last_i - first_i))) * sizeof(double), "__cb3");
          /* numpy: np.sum(term0, axis=1) */
          for (int64_t __ax0 = 0; __ax0 < (last_i - first_i); ++__ax0) {
            __cb3[__ax0] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < ((1 + count) * particles_per_box); ++__rd0) {
              __cb3[__ax0] = (__cb3[__ax0] + term0[(__ax0)*(((1 + count) * particles_per_box)) + (__rd0)]);
            }
          }
          for (int64_t si0 = first_i; si0 < last_i; ++si0) {
            fv[(si0)*(4) + (0)] += __cb3[(si0 - first_i)];
          }
          free(__cb4);
          __cb4 = (double *)malloc((size_t)(((last_i - first_i))) * sizeof(double));
          __npb_alloc_check(__cb4, (size_t)(((last_i - first_i))) * sizeof(double), "__cb4");
          /* numpy: np.sum(term1, axis=1) */
          for (int64_t __ax0 = 0; __ax0 < (last_i - first_i); ++__ax0) {
            __cb4[__ax0] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < ((1 + count) * particles_per_box); ++__rd0) {
              __cb4[__ax0] = (__cb4[__ax0] + term1[(__ax0)*(((1 + count) * particles_per_box)) + (__rd0)]);
            }
          }
          for (int64_t si0 = first_i; si0 < last_i; ++si0) {
            fv[(si0)*(4) + (1)] += __cb4[(si0 - first_i)];
          }
          free(__cb5);
          __cb5 = (double *)malloc((size_t)(((last_i - first_i))) * sizeof(double));
          __npb_alloc_check(__cb5, (size_t)(((last_i - first_i))) * sizeof(double), "__cb5");
          /* numpy: np.sum(term2, axis=1) */
          for (int64_t __ax0 = 0; __ax0 < (last_i - first_i); ++__ax0) {
            __cb5[__ax0] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < ((1 + count) * particles_per_box); ++__rd0) {
              __cb5[__ax0] = (__cb5[__ax0] + term2[(__ax0)*(((1 + count) * particles_per_box)) + (__rd0)]);
            }
          }
          for (int64_t si0 = first_i; si0 < last_i; ++si0) {
            fv[(si0)*(4) + (2)] += __cb5[(si0 - first_i)];
          }
          free(__cb6);
          __cb6 = (double *)malloc((size_t)(((last_i - first_i))) * sizeof(double));
          __npb_alloc_check(__cb6, (size_t)(((last_i - first_i))) * sizeof(double), "__cb6");
          /* numpy: np.sum(term3, axis=1) */
          for (int64_t __ax0 = 0; __ax0 < (last_i - first_i); ++__ax0) {
            __cb6[__ax0] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < ((1 + count) * particles_per_box); ++__rd0) {
              __cb6[__ax0] = (__cb6[__ax0] + term3[(__ax0)*(((1 + count) * particles_per_box)) + (__rd0)]);
            }
          }
          for (int64_t si0 = first_i; si0 < last_i; ++si0) {
            fv[(si0)*(4) + (3)] += __cb6[(si0 - first_i)];
          }
        }
        free(__cb1);
        free(within_box);
        free(pointers);
        free(__cb2);
        free(__cb3);
        free(__cb4);
        free(__cb5);
        free(__cb6);
        free(neighbor_offsets);
        free(bj);
        free(r2);
        free(u2);
        free(fs);
        free(dx);
        free(dy);
        free(dz);
        free(term0);
        free(term1);
        free(term2);
        free(term3);
        free(first_j);
        free(rv_i);
        free(rv_j);
        free(qv_j);
        free(vij);
}
