// Optimized GEM kernel implementation
// Computes screened Coulomb (Yukawa) potential phi_i = sum_j q_j * exp(-kappa * r_ij) / (diel * r_ij)
// where r_ij = sqrt((pos_i - apos_j)^2) for each point i and each atom j.
// This implementation uses direct nested loops with OpenMP parallelism and avoids temporary allocations.
#include <stddef.h>
#include <stdint.h>
#include <math.h>
#include <omp.h>

void gem_fp64(const double *restrict apos,
               const double *restrict charge,
               double *restrict phi,
               const double *restrict pos,
               const double diel,
               const double kappa,
               const int64_t natoms,
               const int64_t npoints,
               uint8_t *restrict workspace,
               const int64_t workspace_size) {
    // Parallelize over evaluation points. Each phi[i] is independent.
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < npoints; ++i) {
        // Load point coordinates once.
        const double xi = pos[i * 3];
        const double yi = pos[i * 3 + 1];
        const double zi = pos[i * 3 + 2];
        double sum = 0.0;
        for (int64_t j = 0; j < natoms; ++j) {
            // Distance vector components.
            const double dx = xi - apos[j * 3];
            const double dy = yi - apos[j * 3 + 1];
            const double dz = zi - apos[j * 3 + 2];
            const double r2 = dx * dx + dy * dy + dz * dz;
            const double r = sqrt(r2);
            // Potential contribution for this atom.
            // Handle potential zero distance (r == 0) - follows reference behaviour (inf).
            const double term = charge[j] * exp(-kappa * r) / (diel * r);
            sum += term;
        }
        phi[i] = sum;
    }
    // workspace and workspace_size are unused but kept for API compatibility.
    (void)workspace;
    (void)workspace_size;
}
