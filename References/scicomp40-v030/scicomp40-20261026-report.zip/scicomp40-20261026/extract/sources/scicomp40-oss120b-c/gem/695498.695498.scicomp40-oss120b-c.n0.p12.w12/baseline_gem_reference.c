// hpcagent_bench-autogen -- generated from gem_numpy.py; edit the numpy reference and regenerate, or delete this line to keep local edits as a hand override.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#ifndef NPB_HD
#if defined(__HIPCC__) || defined(__CUDACC__)
#define NPB_HD __host__ __device__
#else
#define NPB_HD
#endif
#endif
/* ``z.conjugate()`` -- named helper so the C and C++ preludes
 * offer the same spelling. C has the standard one: ``conj``
 * from <complex.h>. The C++ prelude, which has no <complex.h>,
 * writes its own. */
static inline NPB_HD double _Complex __npb_conj(double _Complex z) {
    return conj(z);
}
/* A refused ``malloc`` (an armed ``RLIMIT_DATA`` cap, an exhausted node) aborts naming the
 * array and byte count instead of surfacing as a SIGSEGV at the first write. A function, so
 * the kernel body stays free of control flow pet / pluto would have to model. */
static inline void __npb_alloc_check(const void *p, size_t nbytes, const char *name) {
    if (p == NULL && nbytes != 0) {
        fprintf(stderr, "out of memory: %zu bytes for %s\n", nbytes, name);
        abort();
    }
}
/* M_PI / M_E etc. are POSIX/GNU extensions -- ensure they
 * are defined even on strict-C builds (glibc 2.27+ /
 * BSDs / MSVC). */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
/* ``<complex.h>`` defines ``I`` as the imaginary unit;
 * undef it so user variable names like ``I`` (mandelbrot
 * boolean mask) don''t collide. Complex literals continue
 * to use the portable ``_Complex_I`` form. */
#ifdef I
#undef I
#endif
/* ``max``/``min`` PROPAGATE NaN (a NaN in EITHER operand yields NaN):
 * these serve the elementwise ``np.maximum``/``np.minimum`` broadcast
 * and the ``np.maximum.at`` / ``np.minimum.at`` scatter folds, which
 * follow numpy (propagate), not Python's builtin max (which drops a NaN
 * second operand). ``(a)+(b)`` is NaN whenever either operand is; for
 * finite operands the ternary picks the larger/smaller -- identical to
 * a plain comparison, so the 3-way builtin max (needleman_wunsch, always
 * finite) is unchanged. For integer operands the NaN test is dead. */
#ifndef min
#define min(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) < (a)) ? (b) : (a)))
#endif
#ifndef max
#define max(a, b) ((((a) != (a)) || ((b) != (b))) ? ((a) + (b)) : (((b) > (a)) ? (b) : (a)))
#endif
/* Elementwise ``np.maximum``/``np.minimum`` lower to ``fmax``/``fmin``;
 * libm ``fmax``/``fmin`` SUPPRESS NaN (return the non-NaN operand) but
 * numpy PROPAGATES it. These single-evaluation helpers return NaN when
 * either operand is NaN, else the larger/smaller.
 * Integer operands take the INTEGER form, dispatched on the promoted operand
 * type exactly as int_floor is: routing them through the double helper rounds
 * every value above 2**53 to the nearest representable double, so
 * min(2**53 + 1, 2**53 + 2) returned 2**53 -- a value neither operand had. */
static inline NPB_HD double __npb_fmax_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a > b ? a : b);
}
static inline NPB_HD double __npb_fmin_f(double a, double b) {
    return (a != a) ? a : (b != b) ? b : (a < b ? a : b);
}
static inline NPB_HD int64_t __npb_fmax_i(int64_t a, int64_t b) { return a > b ? a : b; }
static inline NPB_HD int64_t __npb_fmin_i(int64_t a, int64_t b) { return a < b ? a : b; }
static inline NPB_HD uint64_t __npb_fmax_u(uint64_t a, uint64_t b) { return a > b ? a : b; }
static inline NPB_HD uint64_t __npb_fmin_u(uint64_t a, uint64_t b) { return a < b ? a : b; }
/* ``np.sign``: numpy ``sign(nan) == nan`` and ``sign(0) == 0``. The
 * naive ``(x>0)-(x<0)`` gives 0 for NaN and evaluates ``x`` twice. */
static inline NPB_HD double __npb_sign(double x) {
    return x != x ? x : (double)((x > 0) - (x < 0));
}
/* Python ``//`` floors toward -inf; C ``/`` truncates toward zero. Integer and
 * floating operands need different corrections, so the division helpers dispatch
 * on the PROMOTED OPERAND TYPE -- the emitter never has to infer the dtype from
 * the source AST (guessing it wrong silently truncated instead of flooring).
 * _Generic's controlling expression is unevaluated and each argument is spelled
 * once, so operands with side effects are evaluated exactly once. */
static inline NPB_HD int64_t __npb_floordiv_i(int64_t a, int64_t b) {
    return a / b - ((a % b != 0) && ((a < 0) ^ (b < 0)));
}
static inline NPB_HD double __npb_floordiv_f(double a, double b) { return floor(a / b); }
/* Unsigned operands need their own form: floor == truncate for them, and routing
 * them through the SIGNED helper reinterprets any value above INT64_MAX as
 * negative ((2**63 + 5) // 2 came back negative). */
static inline NPB_HD uint64_t __npb_floordiv_u(uint64_t a, uint64_t b) { return a / b; }
static inline NPB_HD uint64_t __npb_ceildiv_u(uint64_t a, uint64_t b) { return a / b + (a % b != 0); }
static inline NPB_HD uint64_t __npb_mod_u(uint64_t a, uint64_t b) { return a % b; }
/* _Float16 is NOT promoted by GCC in arithmetic, so `_Float16 + _Float16` has type
 * _Float16 and fell to `default:` -- the INTEGER helper. 0.5 // 0.25 became
 * int_floor(0, 0) and died with SIGFPE. Spelled as a macro because the association
 * only exists where the type does. */
#if defined(__FLT16_MANT_DIG__)
#define __NPB_F16_ASSOC(fn) _Float16: fn,
#else
#define __NPB_F16_ASSOC(fn)
#endif
#define __NPB_UNSIGNED_ASSOC(fn) \
    unsigned int: fn, unsigned long: fn, unsigned long long: fn,
/* min/max dispatch (declared above): integer operands stay exact, floating ones
 * propagate NaN. Spelled here because the type associations are. */
#define __npb_fmin(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmin_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmin_u) \
    float: __npb_fmin_f, double: __npb_fmin_f, long double: __npb_fmin_f, \
    default: __npb_fmin_i)((a), (b))
#define __npb_fmax(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_fmax_f) \
    __NPB_UNSIGNED_ASSOC(__npb_fmax_u) \
    float: __npb_fmax_f, double: __npb_fmax_f, long double: __npb_fmax_f, \
    default: __npb_fmax_i)((a), (b))
#ifndef int_floor
#define int_floor(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_floordiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_floordiv_u) \
    float: __npb_floordiv_f, double: __npb_floordiv_f, long double: __npb_floordiv_f, \
    default: __npb_floordiv_i)((a), (b))
#endif
/* Ceil-division counterpart (toward +inf), exact for both signs -- unlike the
 * ``(a + b - 1) / b`` idiom, which is correct only for a positive divisor and
 * overflows near the integer maximum. */
static inline NPB_HD int64_t __npb_ceildiv_i(int64_t a, int64_t b) {
    return a / b + ((a % b != 0) && ((a < 0) == (b < 0)));
}
static inline NPB_HD double __npb_ceildiv_f(double a, double b) { return ceil(a / b); }
#ifndef int_ceil
#define int_ceil(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(__npb_ceildiv_f) \
    __NPB_UNSIGNED_ASSOC(__npb_ceildiv_u) \
    float: __npb_ceildiv_f, double: __npb_ceildiv_f, long double: __npb_ceildiv_f, \
    default: __npb_ceildiv_i)((a), (b))
#endif
/* pet's named quasi-affine builtins (POLYCC-008); guarded because polycc prepends
 * its own #define floord/ceild, which would expand these declarators (POLYCC-004). */
#ifndef floord
static inline NPB_HD int64_t floord(int64_t a, int64_t b) {
    return __npb_floordiv_i(a, b);
}
#endif
#ifndef ceild
static inline NPB_HD int64_t ceild(int64_t a, int64_t b) {
    return __npb_ceildiv_i(a, b);
}
#endif
/* Python ``%`` returns sign of divisor; C returns sign of dividend. Same
 * type-dispatch as int_floor: integer operands use the exact integer form,
 * floating operands numpy's npy_remainder (see python_fmod). */
static inline NPB_HD int64_t __npb_mod_i(int64_t a, int64_t b) { return (a % b + b) % b; }
/* Floating-point ``%``: numpy's floored modulo takes the sign of the
 * divisor, which integer ``python_mod`` cannot express on doubles.
 * Mirrors numpy ``npy_remainder`` (fmod + sign-of-divisor fixup). */
static inline NPB_HD double python_fmod(double a, double b) {
    double m = fmod(a, b);
    if (m != 0.0 && ((b < 0.0) != (m < 0.0))) m += b;
    return m;
}
#ifndef python_mod
#define python_mod(a, b) _Generic((a) + (b), \
    __NPB_F16_ASSOC(python_fmod) \
    __NPB_UNSIGNED_ASSOC(__npb_mod_u) \
    float: python_fmod, double: python_fmod, long double: python_fmod, \
    default: __npb_mod_i)((a), (b))
#endif
/* Integer power for VLA shape bounds like ``R ** K``. */
static inline NPB_HD int64_t __npb_int_pow(int64_t base, int64_t exp) {
    int64_t result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

void gem_fp64(const double *restrict apos, const double *restrict charge, double *restrict phi, const double *restrict pos, const double diel, const double kappa, const int64_t natoms, const int64_t npoints, uint8_t *restrict workspace, const int64_t workspace_size) {
        int64_t nblocks;
        int64_t tail;
        int64_t start;
        int64_t stop;
        double *__cb1 = NULL;
        double *__cb2 = NULL;
        double *__cb3 = NULL;
        double *__cb4 = NULL;
        double *__cb5 = NULL;
        double *__cb6 = NULL;
        double *__cb7 = NULL;
        double *__cb8 = NULL;
        double *d = NULL;
        double *d__v1 = NULL;
        double *r__v1 = NULL;
        double *r = NULL;
        nblocks = int_floor(npoints, 1024);
        for (int64_t block = 0; block < nblocks; ++block) {
          start = (block * 1024);
          stop = (start + 1024);
          free(d);
          d = (double *)malloc((size_t)(((stop - start)) * (natoms) * (3)) * sizeof(double));
          __npb_alloc_check(d, (size_t)(((stop - start)) * (natoms) * (3)) * sizeof(double), "d");
          for (int64_t __w0 = 0; __w0 < (stop - start); ++__w0) {
            for (int64_t __w1 = 0; __w1 < natoms; ++__w1) {
              for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
                d[((__w0)*(natoms) + (__w1))*(3) + (__w2)] = (pos[((__w0 + (start - 0)))*(3) + (__w2)] - apos[(__w1)*(3) + (__w2)]);
              }
            }
          }
          free(__cb1);
          __cb1 = (double *)malloc((size_t)(((stop - start)) * (natoms) * (3)) * sizeof(double));
          __npb_alloc_check(__cb1, (size_t)(((stop - start)) * (natoms) * (3)) * sizeof(double), "__cb1");
          for (int64_t __w0 = 0; __w0 < (stop - start); ++__w0) {
            for (int64_t __w1 = 0; __w1 < natoms; ++__w1) {
              for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
                __cb1[((__w0)*(natoms) + (__w1))*(3) + (__w2)] = (d[((__w0)*(natoms) + (__w1))*(3) + (__w2)] * d[((__w0)*(natoms) + (__w1))*(3) + (__w2)]);
              }
            }
          }
          free(__cb2);
          __cb2 = (double *)malloc((size_t)(((stop - start)) * (natoms)) * sizeof(double));
          __npb_alloc_check(__cb2, (size_t)(((stop - start)) * (natoms)) * sizeof(double), "__cb2");
          /* numpy: np.sum(__cb1, axis=2) */
          for (int64_t __ax0 = 0; __ax0 < (stop - start); ++__ax0) {
            for (int64_t __ax1 = 0; __ax1 < natoms; ++__ax1) {
              __cb2[(__ax0)*(natoms) + (__ax1)] = 0.0;
              for (int64_t __rd0 = 0; __rd0 < 3; ++__rd0) {
                __cb2[(__ax0)*(natoms) + (__ax1)] = (__cb2[(__ax0)*(natoms) + (__ax1)] + __cb1[((__ax0)*(natoms) + (__ax1))*(3) + (__rd0)]);
              }
            }
          }
          free(r);
          r = (double *)malloc((size_t)(((stop - start)) * (natoms)) * sizeof(double));
          __npb_alloc_check(r, (size_t)(((stop - start)) * (natoms)) * sizeof(double), "r");
          for (int64_t __w0 = 0; __w0 < (stop - start); ++__w0) {
            for (int64_t __w1 = 0; __w1 < natoms; ++__w1) {
              r[(__w0)*(natoms) + (__w1)] = sqrt(__cb2[(__w0)*(natoms) + (__w1)]);
            }
          }
          free(__cb3);
          __cb3 = (double *)malloc((size_t)(((stop - start)) * (natoms)) * sizeof(double));
          __npb_alloc_check(__cb3, (size_t)(((stop - start)) * (natoms)) * sizeof(double), "__cb3");
          for (int64_t si0 = 0; si0 < (stop - start); ++si0) {
            for (int64_t si1 = 0; si1 < natoms; ++si1) {
              __cb3[(si0)*(natoms) + (si1)] = ((charge[si1] * exp(((-kappa) * r[(si0)*(natoms) + (si1)]))) / (diel * r[(si0)*(natoms) + (si1)]));
            }
          }
          free(__cb4);
          __cb4 = (double *)malloc((size_t)(((stop - start))) * sizeof(double));
          __npb_alloc_check(__cb4, (size_t)(((stop - start))) * sizeof(double), "__cb4");
          /* numpy: np.sum(__cb3, axis=1) */
          for (int64_t __ax0 = 0; __ax0 < (stop - start); ++__ax0) {
            __cb4[__ax0] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < natoms; ++__rd0) {
              __cb4[__ax0] = (__cb4[__ax0] + __cb3[(__ax0)*(natoms) + (__rd0)]);
            }
          }
          for (int64_t si0 = start; si0 < stop; ++si0) {
            phi[si0] = __cb4[(si0 - start)];
          }
        }
        tail = (nblocks * 1024);
        free(d__v1);
        d__v1 = (double *)malloc((size_t)(((npoints - tail)) * (natoms) * (3)) * sizeof(double));
        __npb_alloc_check(d__v1, (size_t)(((npoints - tail)) * (natoms) * (3)) * sizeof(double), "d__v1");
        for (int64_t __w0 = 0; __w0 < (npoints - tail); ++__w0) {
          for (int64_t __w1 = 0; __w1 < natoms; ++__w1) {
            for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
              d__v1[((__w0)*(natoms) + (__w1))*(3) + (__w2)] = (pos[((__w0 + (tail - 0)))*(3) + (__w2)] - apos[(__w1)*(3) + (__w2)]);
            }
          }
        }
        free(__cb5);
        __cb5 = (double *)malloc((size_t)(((npoints - tail)) * (natoms) * (3)) * sizeof(double));
        __npb_alloc_check(__cb5, (size_t)(((npoints - tail)) * (natoms) * (3)) * sizeof(double), "__cb5");
        for (int64_t __w0 = 0; __w0 < (npoints - tail); ++__w0) {
          for (int64_t __w1 = 0; __w1 < natoms; ++__w1) {
            for (int64_t __w2 = 0; __w2 < 3; ++__w2) {
              __cb5[((__w0)*(natoms) + (__w1))*(3) + (__w2)] = (d__v1[((__w0)*(natoms) + (__w1))*(3) + (__w2)] * d__v1[((__w0)*(natoms) + (__w1))*(3) + (__w2)]);
            }
          }
        }
        free(__cb6);
        __cb6 = (double *)malloc((size_t)(((npoints - tail)) * (natoms)) * sizeof(double));
        __npb_alloc_check(__cb6, (size_t)(((npoints - tail)) * (natoms)) * sizeof(double), "__cb6");
        /* numpy: np.sum(__cb5, axis=2) */
        for (int64_t __ax0 = 0; __ax0 < (npoints - tail); ++__ax0) {
          for (int64_t __ax1 = 0; __ax1 < natoms; ++__ax1) {
            __cb6[(__ax0)*(natoms) + (__ax1)] = 0.0;
            for (int64_t __rd0 = 0; __rd0 < 3; ++__rd0) {
              __cb6[(__ax0)*(natoms) + (__ax1)] = (__cb6[(__ax0)*(natoms) + (__ax1)] + __cb5[((__ax0)*(natoms) + (__ax1))*(3) + (__rd0)]);
            }
          }
        }
        free(r__v1);
        r__v1 = (double *)malloc((size_t)(((npoints - tail)) * (natoms)) * sizeof(double));
        __npb_alloc_check(r__v1, (size_t)(((npoints - tail)) * (natoms)) * sizeof(double), "r__v1");
        for (int64_t __w0 = 0; __w0 < (npoints - tail); ++__w0) {
          for (int64_t __w1 = 0; __w1 < natoms; ++__w1) {
            r__v1[(__w0)*(natoms) + (__w1)] = sqrt(__cb6[(__w0)*(natoms) + (__w1)]);
          }
        }
        free(__cb7);
        __cb7 = (double *)malloc((size_t)(((npoints - tail)) * (natoms)) * sizeof(double));
        __npb_alloc_check(__cb7, (size_t)(((npoints - tail)) * (natoms)) * sizeof(double), "__cb7");
        for (int64_t si0 = 0; si0 < (npoints - tail); ++si0) {
          for (int64_t si1 = 0; si1 < natoms; ++si1) {
            __cb7[(si0)*(natoms) + (si1)] = ((charge[si1] * exp(((-kappa) * r__v1[(si0)*(natoms) + (si1)]))) / (diel * r__v1[(si0)*(natoms) + (si1)]));
          }
        }
        free(__cb8);
        __cb8 = (double *)malloc((size_t)(((npoints - tail))) * sizeof(double));
        __npb_alloc_check(__cb8, (size_t)(((npoints - tail))) * sizeof(double), "__cb8");
        /* numpy: np.sum(__cb7, axis=1) */
        for (int64_t __ax0 = 0; __ax0 < (npoints - tail); ++__ax0) {
          __cb8[__ax0] = 0.0;
          for (int64_t __rd0 = 0; __rd0 < natoms; ++__rd0) {
            __cb8[__ax0] = (__cb8[__ax0] + __cb7[(__ax0)*(natoms) + (__rd0)]);
          }
        }
        for (int64_t si0 = tail; si0 < npoints; ++si0) {
          phi[si0] = __cb8[(si0 - tail)];
        }
        free(__cb1);
        free(__cb2);
        free(__cb3);
        free(__cb4);
        free(__cb5);
        free(__cb6);
        free(__cb7);
        free(__cb8);
        free(d);
        free(d__v1);
        free(r__v1);
        free(r);
}
