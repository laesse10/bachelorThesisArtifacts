// Optimized seissol_batched_gemm kernel exploiting star matrix sparsity and eliminating temporary allocation.
// License: GPL-3.0-or-later (same as reference)

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <omp.h>

// The kernel signature as defined in signature.json
void seissol_batched_gemm_fp64(const double *restrict I,
                               double *restrict Q,
                               const double *restrict star,
                               const int64_t batch,
                               uint8_t *restrict workspace,
                               const int64_t workspace_size) {
    // Number of basis functions per element (constant for this kernel)
    const int64_t nb = 84;
    // Load all 24 non-zero star entries into registers (thread-local)
    // Column 0 (j=0): rows 6,7,8
    const double s6_0 = star[6 * 9 + 0];
    const double s7_0 = star[7 * 9 + 0];
    const double s8_0 = star[8 * 9 + 0];
    // Column 1 (j=1): rows 6,7,8
    const double s6_1 = star[6 * 9 + 1];
    const double s7_1 = star[7 * 9 + 1];
    const double s8_1 = star[8 * 9 + 1];
    // Column 2 (j=2): rows 6,7,8
    const double s6_2 = star[6 * 9 + 2];
    const double s7_2 = star[7 * 9 + 2];
    const double s8_2 = star[8 * 9 + 2];
    // Column 3 (j=3): rows 6,7
    const double s6_3 = star[6 * 9 + 3];
    const double s7_3 = star[7 * 9 + 3];
    // Column 4 (j=4): rows 7,8
    const double s7_4 = star[7 * 9 + 4];
    const double s8_4 = star[8 * 9 + 4];
    // Column 5 (j=5): rows 6,8
    const double s6_5 = star[6 * 9 + 5];
    const double s8_5 = star[8 * 9 + 5];
    // Column 6 (j=6): rows 0,3,5
    const double s0_6 = star[0 * 9 + 6];
    const double s3_6 = star[3 * 9 + 6];
    const double s5_6 = star[5 * 9 + 6];
    // Column 7 (j=7): rows 1,3,4
    const double s1_7 = star[1 * 9 + 7];
    const double s3_7 = star[3 * 9 + 7];
    const double s4_7 = star[4 * 9 + 7];
    // Column 8 (j=8): rows 2,4,5
    const double s2_8 = star[2 * 9 + 8];
    const double s4_8 = star[4 * 9 + 8];
    const double s5_8 = star[5 * 9 + 8];

    // Parallelize over the batch dimension. Each iteration works on a contiguous chunk of memory.
    #pragma omp parallel for schedule(static)
    for (int64_t b = 0; b < batch; ++b) {
        const double *I_batch = I + b * nb * 9;
        double *Q_batch = Q + b * nb * 9;
        // Loop over the Nb basis functions.
        for (int64_t i = 0; i < nb; ++i) {
            const double *I_vec = I_batch + i * 9;
            double *Q_vec = Q_batch + i * 9;
            // Load the 9 components of I for readability.
            const double i0 = I_vec[0];
            const double i1 = I_vec[1];
            const double i2 = I_vec[2];
            const double i3 = I_vec[3];
            const double i4 = I_vec[4];
            const double i5 = I_vec[5];
            const double i6 = I_vec[6];
            const double i7 = I_vec[7];
            const double i8 = I_vec[8];
            // Compute Q += I @ star using the sparsity pattern.
            Q_vec[0] += i6 * s6_0 + i7 * s7_0 + i8 * s8_0;
            Q_vec[1] += i6 * s6_1 + i7 * s7_1 + i8 * s8_1;
            Q_vec[2] += i6 * s6_2 + i7 * s7_2 + i8 * s8_2;
            Q_vec[3] += i6 * s6_3 + i7 * s7_3;
            Q_vec[4] += i7 * s7_4 + i8 * s8_4;
            Q_vec[5] += i6 * s6_5 + i8 * s8_5;
            Q_vec[6] += i0 * s0_6 + i3 * s3_6 + i5 * s5_6;
            Q_vec[7] += i1 * s1_7 + i3 * s3_7 + i4 * s4_7;
            Q_vec[8] += i2 * s2_8 + i4 * s4_8 + i5 * s5_8;
        }
    }
    // workspace and workspace_size are unused – the kernel does not need temporary storage.
    (void)workspace;
    (void)workspace_size;
}

