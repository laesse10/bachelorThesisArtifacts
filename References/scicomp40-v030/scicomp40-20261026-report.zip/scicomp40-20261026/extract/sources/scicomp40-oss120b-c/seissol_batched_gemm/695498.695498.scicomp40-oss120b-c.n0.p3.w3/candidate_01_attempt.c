#include <stdint.h>
void seissol_batched_gemm_fp64(const double *restrict I,
                               double *restrict Q,
                               const double *restrict star,
                               const int64_t batch,
                               uint8_t *restrict workspace,
                               const int64_t workspace_size) {
    (void)I; (void)Q; (void)star; (void)batch; (void)workspace; (void)workspace_size;
}
