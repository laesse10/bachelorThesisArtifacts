// SeisSol ADER-DG element-local "star" update: Q[b] += I[b] @ star.
//
// star is the shared 9x9 elastic flux Jacobian with the real SeisSol
// sparsity: 24 nonzero entries in two coupling blocks.  The fast path
// hardwires that pattern (verified at runtime against the actual star
// values) and processes each 9-wide row with 256-bit vector ops:
//
//   Group A = j0..3 : live l's 6,7,8           -> 3 ymm FMA
//   Group B = j4..7 : live l's 0,1,3,4,5,6,7,8 -> 8 ymm FMA
//   j8 scalar       : live l's 2,4,5           -> 3 scalar FMA
//
// i.e. 14 FMA + 8 broadcasts + 18 mem ops per row: about 8-11 cycles/row,
// well under the ~15 cycles/row the memory stream allows per thread, so
// the kernel is memory-bandwidth bound (read I, read Q, write Q, once).
//
// Per-column terms stay in ascending input-index order, the same order as
// the dense reference: zero entries inside a group add +/-0.0 exactly as
// the reference does, and the running sum can never be -0.0 because it
// starts at +0.0 -- hence bit-identical results for all finite inputs.
// Any star that does not match the expected zero pattern falls back to a
// generic loop that sums the actually-nonzero terms in the same order.
//
// Parallelism: raw pthreads, one worker per allowed CPU, contiguous
// element ranges (streaming access), small explicit stacks.

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <pthread.h>
#include <immintrin.h>

#define NB 84
#define NQ 9

// canonical 24 nonzero positions (row l, col j)
static const int NZ_L[24] = {6,7,8,6,7,8,6,7,8,6,7,7,8,6,8,0,3,5,1,3,4,2,4,5};
static const int NZ_J[24] = {0,0,0,1,1,1,2,2,2,3,3,4,4,5,5,6,6,6,7,7,7,8,8,8};

static const double *g_I;
static double *g_Q;
static int g_fast;

// constants shared by workers (fast path)
static __m256d SA6, SA7, SA8, SB0, SB1, SB3, SB4, SB5, SB6, SB7, SB8;
static double s28, s48, s58;
// generic path tables
static int g_jl[9][9];
static double g_sv[9][9];
static int g_cnt[9];

static void fast_range(const double *I, double *Q, int64_t b0, int64_t b1)
{
    for (int64_t b = b0; b < b1; ++b) {
        const double *Ib = I + b * (int64_t)(NB * NQ);
        double *Qb = Q + b * (int64_t)(NB * NQ);
        for (int i = 0; i < NB; i++) {
            const double *ir = Ib + (int64_t)i * NQ;
            double *qr = Qb + (int64_t)i * NQ;

            double i0 = ir[0], i1 = ir[1], i2 = ir[2], i3 = ir[3];
            double i4 = ir[4], i5 = ir[5], i6 = ir[6], i7 = ir[7], i8 = ir[8];

            __m256d b_i0 = _mm256_set1_pd(i0);
            __m256d b_i1 = _mm256_set1_pd(i1);
            __m256d b_i3 = _mm256_set1_pd(i3);
            __m256d b_i4 = _mm256_set1_pd(i4);
            __m256d b_i5 = _mm256_set1_pd(i5);
            __m256d b_i6 = _mm256_set1_pd(i6);
            __m256d b_i7 = _mm256_set1_pd(i7);
            __m256d b_i8 = _mm256_set1_pd(i8);

            __m256d tA = _mm256_mul_pd(b_i6, SA6);
            tA = _mm256_fmadd_pd(b_i7, SA7, tA);
            tA = _mm256_fmadd_pd(b_i8, SA8, tA);

            __m256d tB = _mm256_mul_pd(b_i0, SB0);
            tB = _mm256_fmadd_pd(b_i1, SB1, tB);
            tB = _mm256_fmadd_pd(b_i3, SB3, tB);
            tB = _mm256_fmadd_pd(b_i4, SB4, tB);
            tB = _mm256_fmadd_pd(b_i5, SB5, tB);
            tB = _mm256_fmadd_pd(b_i6, SB6, tB);
            tB = _mm256_fmadd_pd(b_i7, SB7, tB);
            tB = _mm256_fmadd_pd(b_i8, SB8, tB);

            double t8 = i2 * s28;
            t8 = fma(i4, s48, t8);
            t8 = fma(i5, s58, t8);

            __m256d qlo = _mm256_loadu_pd(qr);
            __m256d qhi = _mm256_loadu_pd(qr + 4);
            double q8 = qr[8];
            _mm256_storeu_pd(qr, _mm256_add_pd(qlo, tA));
            _mm256_storeu_pd(qr + 4, _mm256_add_pd(qhi, tB));
            qr[8] = q8 + t8;
        }
    }
}

static void gen_range(const double *I, double *Q, int64_t b0, int64_t b1)
{
    for (int64_t b = b0; b < b1; ++b) {
        const double *Ib = I + b * (int64_t)(NB * NQ);
        double *Qb = Q + b * (int64_t)(NB * NQ);
        for (int i = 0; i < NB; i++) {
            const double *ir = Ib + (int64_t)i * NQ;
            double *qr = Qb + (int64_t)i * NQ;
            double t[NQ] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
            for (int l = 0; l < NQ; l++) {
                double a = ir[l];
                const int n = g_cnt[l];
                for (int k = 0; k < n; k++)
                    t[g_jl[l][k]] = fma(a, g_sv[l][k], t[g_jl[l][k]]);
            }
            qr[0] += t[0]; qr[1] += t[1]; qr[2] += t[2];
            qr[3] += t[3]; qr[4] += t[4]; qr[5] += t[5];
            qr[6] += t[6]; qr[7] += t[7]; qr[8] += t[8];
        }
    }
}

typedef struct { int64_t b0, b1; } warg_t;

static void *worker(void *arg)
{
    warg_t *w = (warg_t *)arg;
    if (g_fast) fast_range(g_I, g_Q, w->b0, w->b1);
    else gen_range(g_I, g_Q, w->b0, w->b1);
    return 0;
}

void seissol_batched_gemm_fp64(
    const double *restrict I,
    double *restrict Q,
    const double *restrict star,
    const int64_t batch,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;

    // ---- verify the expected zero pattern (57 positions must be exactly 0)
    int in_pat[NQ * NQ];
    memset(in_pat, 0, sizeof in_pat);
    for (int k = 0; k < 24; k++) in_pat[NZ_L[k] * NQ + NZ_J[k]] = 1;
    g_fast = 1;
    for (int l = 0; l < NQ && g_fast; l++)
        for (int j = 0; j < NQ && g_fast; j++)
            if (!in_pat[l * NQ + j] && star[l * NQ + j] != 0.0) g_fast = 0;

    if (g_fast) {
        SA6 = _mm256_setr_pd(star[6 * 9 + 0], star[6 * 9 + 1], star[6 * 9 + 2], star[6 * 9 + 3]);
        SA7 = _mm256_setr_pd(star[7 * 9 + 0], star[7 * 9 + 1], star[7 * 9 + 2], star[7 * 9 + 3]);
        SA8 = _mm256_setr_pd(star[8 * 9 + 0], star[8 * 9 + 1], star[8 * 9 + 2], star[8 * 9 + 3]);
        SB0 = _mm256_setr_pd(0.0, 0.0, star[0 * 9 + 6], 0.0);
        SB1 = _mm256_setr_pd(0.0, 0.0, 0.0, star[1 * 9 + 7]);
        SB3 = _mm256_setr_pd(0.0, 0.0, star[3 * 9 + 6], star[3 * 9 + 7]);
        SB4 = _mm256_setr_pd(0.0, 0.0, 0.0, star[4 * 9 + 7]);
        SB5 = _mm256_setr_pd(0.0, 0.0, star[5 * 9 + 6], 0.0);
        SB6 = _mm256_setr_pd(star[6 * 9 + 4], star[6 * 9 + 5], 0.0, 0.0);
        SB7 = _mm256_setr_pd(star[7 * 9 + 4], star[7 * 9 + 5], 0.0, 0.0);
        SB8 = _mm256_setr_pd(star[8 * 9 + 4], star[8 * 9 + 5], 0.0, 0.0);
        s28 = star[2 * 9 + 8]; s48 = star[4 * 9 + 8]; s58 = star[5 * 9 + 8];
    } else {
        for (int l = 0; l < NQ; l++) {
            g_cnt[l] = 0;
            for (int j = 0; j < NQ; j++)
                if (star[l * NQ + j] != 0.0) {
                    g_sv[l][g_cnt[l]] = star[l * NQ + j];
                    g_jl[l][g_cnt[l]] = j;
                    g_cnt[l]++;
                }
        }
    }

    // ---- count allowed CPUs from /proc/self/status (Cpus_allowed_list)
    int ncpu = 0;
    {
        FILE *f = fopen("/proc/self/status", "r");
        if (f) {
            char line[256];
            while (fgets(line, sizeof line, f)) {
                char buf[220];
                if (sscanf(line, "Cpus_allowed_list: %219s", buf) == 1) {
                    for (char *tok = strtok(buf, ","); tok; tok = strtok(NULL, ",")) {
                        int a = atoi(tok);
                        char *dash = strchr(tok, '-');
                        if (dash) {
                            int b = atoi(dash + 1);
                            for (int c = a; c <= b && ncpu < 64; c++) ncpu++;
                        } else {
                            if (ncpu < 64) ncpu++;
                        }
                    }
                    break;
                }
            }
            fclose(f);
        }
    }
    if (ncpu <= 0) ncpu = 5;
    if (ncpu > 32) ncpu = 32;
    const char *env = getenv("SEISSOL_NTHREADS");
    if (env) { int e = atoi(env); if (e >= 1 && e <= ncpu) ncpu = e; }

    g_I = I;
    g_Q = Q;

    // small batches or few CPUs: just run inline
    if (ncpu == 1 || batch < 4096) {
        if (g_fast) fast_range(I, Q, 0, batch);
        else gen_range(I, Q, 0, batch);
        return;
    }

    // threads: one per allowed CPU (the scheduler spreads them over the
    // allowed set), contiguous split of [0, batch) for streaming locality
    static warg_t warg[32];
    static pthread_t tid[32];
    int n = ncpu;
    int64_t per = batch / n, rem = batch % n;
    int64_t off = 0;
    for (int t = 0; t < n; t++) {
        int64_t cnt = per + (t < rem ? 1 : 0);
        warg[t].b0 = off;
        warg[t].b1 = off + cnt;
        off += cnt;
        pthread_attr_t at;
        pthread_attr_init(&at);
        pthread_attr_setstacksize(&at, 16 * 1024 * 1024);
        if (pthread_create(&tid[t], &at, worker, &warg[t]) == 0)
            continue;
        // thread creation failed: run this range inline (correctness first)
        if (g_fast) fast_range(I, Q, warg[t].b0, warg[t].b1);
        else gen_range(I, Q, warg[t].b0, warg[t].b1);
        tid[t] = 0;
        pthread_attr_destroy(&at);
    }
    for (int t = 0; t < n; t++)
        if (tid[t] != 0) pthread_join(tid[t], NULL);
}
