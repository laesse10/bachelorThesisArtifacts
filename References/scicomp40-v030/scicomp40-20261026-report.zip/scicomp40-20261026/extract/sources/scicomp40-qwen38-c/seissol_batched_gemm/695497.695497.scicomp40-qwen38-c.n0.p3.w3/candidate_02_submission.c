// SeisSol ADER-DG element-local "star" update: Q[b] += I[b] @ star.
//   I, Q : (batch, 84, 9) fp64, row-major
//   star : (9, 9) fp64, shared across the batch, elastic flux Jacobian
//          (24 structurally nonzero entries, pattern fixed).
//
// The right operand is tiny and shared, so this is a tall-skinny,
// memory-bound batched GEMM: read I, read Q, write Q, once.  The star
// sparsity is taken from the actual star values at runtime (entries
// that are exactly +0.0 contribute nothing for finite operands), and
// per-output sums are accumulated in ascending input-index order, so
// the result is bit-identical to the dense reference for all finite
// inputs (skipping a zero term adds nothing, and the running sum can
// never be -0.0 because it starts at +0.0).

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define NB 84
#define NQ 9

void seissol_batched_gemm_fp64(
    const double *restrict I,
    double *restrict Q,
    const double *restrict star,
    const int64_t batch,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;

    // Which (l -> j) products are live, in l-ascending order per j.
    int jl[9][9];
    double sv[9][9];
    int cnt[9];
    for (int l = 0; l < NQ; l++) {
        cnt[l] = 0;
        for (int j = 0; j < NQ; j++) {
            double s = star[l * NQ + j];
            if (s != 0.0) {
                sv[l][cnt[l]] = s;
                jl[l][cnt[l]] = j;
                cnt[l]++;
            }
        }
    }

    #pragma omp parallel for schedule(static)
    for (int64_t b = 0; b < batch; ++b) {
        const double *Ib = I + b * (int64_t)(NB * NQ);
        double *Qb = Q + b * (int64_t)(NB * NQ);
        for (int i = 0; i < NB; i++) {
            const double *ir = Ib + (int64_t)i * NQ;
            double *qr = Qb + (int64_t)i * NQ;
            double t[NQ] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
            for (int l = 0; l < NQ; l++) {
                double a = ir[l];
                const int n = cnt[l];
                for (int k = 0; k < n; k++)
                    t[jl[l][k]] = fma(a, sv[l][k], t[jl[l][k]]);
            }
            qr[0] += t[0]; qr[1] += t[1]; qr[2] += t[2];
            qr[3] += t[3]; qr[4] += t[4]; qr[5] += t[5];
            qr[6] += t[6]; qr[7] += t[7]; qr[8] += t[8];
        }
    }
}
