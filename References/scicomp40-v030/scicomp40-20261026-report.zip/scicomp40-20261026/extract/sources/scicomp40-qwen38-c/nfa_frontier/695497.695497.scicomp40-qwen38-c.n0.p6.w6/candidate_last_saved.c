// Optimized nfa_frontier: transposed (t outer, components inner) simulation with
// per-component memo tables of (frontier_bits, symbol) -> transition.
//
// Fast path requires every component width <= 64 (u64 bitset frontier) and
// T <= 1e8 (so per-state activation counts fit in int32); otherwise a parallel
// generic implementation with the reference's exact semantics is used.
//
// Per component one cycle (match + children + starts) is a pure function of
// (frontier_bits, sym); only the per-cycle eod flag (newline / last symbol)
// changes which start bits are ORed in afterwards.  Frontier patterns recur
// densely (a few dozen distinct keys per component), so per component we keep
// in a 64B hot region:
//   line 0: A0 | bits | key0 | key1           (all 16B sector pairs)
//   line 1: (nb0,cnt)0 | (nb0,cnt)1           two 24->16B mini slots
//   the mini slots are a self-organizing direct-mapped cache (slot = key
//   parity, replaced on conflict): the two hottest keys settle there.
// plus a 256-entry (128 sets x 2 ways) cold table, 32B entries
// {key, nb0, cnt, mb} for all the other keys.
// Occurrences are tallied into entry counts and folded into the activation
// and report counters once at the end, so the hot loop has no scattered
// writes except the mini/cold count.
#define _POSIX_C_SOURCE 199309L
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#ifndef NFA_PROFILE
#define NFA_PROFILE 0
#endif
#if NFA_PROFILE
#define NFA_HIT(n) ((n)++)
#define NFA_MISS(n) ((n)++)
#else
#define NFA_HIT(n) (0)
#define NFA_MISS(n) (0)
#endif

#define NFA_COLD_SLOTS 256u
#define NFA_MAXW 64u
#define NFA_EMPTY_KEY UINT64_MAX

uint64_t nfa_dbg_hits = 0, nfa_dbg_misses = 0;

typedef struct {
    uint64_t key;   /* (bits<<8)|sym, or NFA_EMPTY_KEY */
    uint64_t nb0;   /* children bits of this key */
    uint64_t cnt;
    uint64_t mb;    /* matched bits */
} NfaCold;                            /* 32 bytes */

typedef struct {
    /* hot 64 bytes, touched every step: 4 x 16B sector pairs */
    uint64_t A0;        /* all-input start bits          (sector 0a) */
    uint64_t bits;      /* current frontier bits         (sector 0b) */
    uint64_t mkey[2];   /* mini slot keys                (sector 1)  */
    uint64_t mnb0[2];   /* mini slot children bits       (sector 2a) */
    uint64_t mcnt[2];   /* mini slot occurrence counts   (sector 2b) */
    /* cold */
    uint64_t A1;        /* all start bits (A0 | sod) */
    int64_t base;
    int64_t width;
    uint64_t R;         /* report state bits */
    int64_t rep;
    int32_t *acc;       /* [width] local activation counters */
    uint64_t *succ;     /* [width] successor bits per state */
    NfaCold cold[NFA_COLD_SLOTS];    /* 128 sets x 2 ways, one 64B line per set */
} NfaComp;

static inline uint32_t nfa_set(uint64_t bits, uint64_t sym) {
    return (uint32_t)((((bits * 0x9E3779B97F4A7C15ull) >> 56) ^ sym) & (NFA_COLD_SLOTS / 2u - 1u));
}
static inline uint32_t nfa_set_key(uint64_t key) {
    return nfa_set(key >> 8, key & 255ull);
}

/* mini slot for a key: self-organizing direct-mapped, slot = set parity. */
static inline void nfa_mini_put(NfaComp *cc, uint64_t key, uint64_t nb0) {
    unsigned slot = nfa_set(key >> 8, key & 255ull) & 1u;
    cc->mkey[slot] = key;
    cc->mnb0[slot] = nb0;
    cc->mcnt[slot] = 0;
}

/* one full transition step for a key absent from both tables.
   Updates the component's acc/rep; returns children bits nb0. */
static inline uint64_t nfa_step_full(
    NfaComp *cc, uint64_t bits, uint64_t sym,
    const uint8_t *restrict symbol_cols)
{
    uint64_t mb = 0, f = bits;
    int64_t base = cc->base;
    while (f) {
        int r = __builtin_ctzll(f);
        f &= f - 1;
        if (symbol_cols[(base + r) * 256 + sym]) mb |= 1ull << r;
    }
    uint64_t nb0 = 0, m = mb;
    int32_t *acc = cc->acc;
    uint64_t *succ = cc->succ;
    while (m) {
        int r = __builtin_ctzll(m);
        m &= m - 1;
        acc[r] += 1;
        nb0 |= succ[r];
    }
    cc->rep += (int64_t)__builtin_popcountll(mb & cc->R);

    uint64_t key = (bits << 8) | sym;
    NfaCold *e = &cc->cold[nfa_set(bits, sym) * 2u];
    if (e->key == NFA_EMPTY_KEY) {
        e->key = key; e->cnt = 0; e->nb0 = nb0; e->mb = mb;
    } else if (e[1].key == NFA_EMPTY_KEY) {
        e[1].key = key; e[1].cnt = 0; e[1].nb0 = nb0; e[1].mb = mb;
    }
    nfa_mini_put(cc, key, nb0);
    return nb0;
}

/* one memo step for component cc, given symbol sym; the start bits ORed in
   afterwards are SA (A0 normally, A1 on a record boundary). */
#define NFA_STEP(cc, SA) do {                                                       \
        NfaComp *_cc = (cc);                                                         \
        uint64_t _b = _cc->bits;                                                     \
        uint64_t _key = (_b << 8) | sym;                                             \
        if (_cc->mkey[0] == _key) {                                                  \
            _cc->mcnt[0] += 1;                                                       \
            _b = _cc->mnb0[0];                                                       \
            (void)NFA_HIT(nfa_hits_local);                                           \
        } else if (_cc->mkey[1] == _key) {                                           \
            _cc->mcnt[1] += 1;                                                       \
            _b = _cc->mnb0[1];                                                       \
            (void)NFA_HIT(nfa_hits_local);                                           \
        } else {                                                                     \
            NfaCold *_ce = &_cc->cold[nfa_set(_b, sym) * 2u];                        \
            if (_ce->key == _key) {                                                  \
                _ce->cnt += 1;                                                       \
                _b = _ce->nb0;                                                       \
                nfa_mini_put(_cc, _key, _b);                                         \
                (void)NFA_HIT(nfa_hits_local);                                       \
            } else if (_ce[1].key == _key) {                                         \
                _ce[1].cnt += 1;                                                     \
                _b = _ce[1].nb0;                                                     \
                nfa_mini_put(_cc, _key, _b);                                         \
                (void)NFA_HIT(nfa_hits_local);                                       \
            } else {                                                                 \
                _b = nfa_step_full(_cc, _b, sym, symbol_cols);                       \
                (void)NFA_MISS(nfa_misses_local);                                    \
            }                                                                        \
        }                                                                            \
        _cc->bits = _b | (SA);                                                       \
    } while (0)

/* generic fallback: reference semantics, parallel over components */
static void nfa_frontier_generic(
    int64_t *restrict activation_counts, const int64_t *restrict col_idx,
    const int64_t *restrict comp_ptr, const uint8_t *restrict is_report,
    int64_t *restrict report_counts, const int64_t *restrict row_ptr,
    const int64_t *restrict start_idx, const int64_t *restrict start_ptr,
    const uint8_t *restrict start_sod, const int64_t *restrict stream,
    const uint8_t *restrict symbol_cols,
    const int64_t C, const int64_t NS, const int64_t T, uint8_t *scratch)
{
    int64_t *enabled = (int64_t *)scratch;
    int64_t *frontier = enabled + NS;
    int64_t *matched = frontier + NS;
    uint8_t *s8 = (uint8_t *)(matched + NS);
    #pragma omp parallel for schedule(static)
    for (int64_t t = 0; t < T; ++t) s8[t] = (uint8_t)stream[t];
    #pragma omp parallel for schedule(dynamic, 64)
    for (int64_t c = 0; c < C; ++c) {
        int64_t base = comp_ptr[c];
        int64_t n_front = 0, reports = 0;
        for (int64_t k = start_ptr[c]; k < start_ptr[c + 1]; ++k) {
            int64_t s = start_idx[k];
            if (enabled[s] == 0) { enabled[s] = 1; frontier[base + n_front++] = s; }
        }
        for (int64_t t = 0; t < T; ++t) {
            uint8_t sym = s8[t];
            int64_t eod = (t == T - 1) || (sym == 10);
            int64_t n_match = 0;
            for (int64_t k = 0; k < n_front; ++k) {
                int64_t s = frontier[base + k];
                if (symbol_cols[s * 256 + sym]) {
                    matched[base + n_match++] = s;
                    activation_counts[s] += 1;
                    if (is_report[s]) reports += 1;
                }
                enabled[s] = 0;
            }
            n_front = 0;
            for (int64_t k = 0; k < n_match; ++k) {
                int64_t s = matched[base + k];
                for (int64_t e = row_ptr[s]; e < row_ptr[s + 1]; ++e) {
                    int64_t child = col_idx[e];
                    if (enabled[child] == 0) { enabled[child] = 1; frontier[base + n_front++] = child; }
                }
            }
            for (int64_t k = start_ptr[c]; k < start_ptr[c + 1]; ++k) {
                if (start_sod[k] == 0 || eod) {
                    int64_t s = start_idx[k];
                    if (enabled[s] == 0) { enabled[s] = 1; frontier[base + n_front++] = s; }
                }
            }
        }
        report_counts[c] = reports;
    }
}

void nfa_frontier_fp64(
    int64_t *restrict activation_counts,
    const int64_t *restrict col_idx,
    const int64_t *restrict comp_ptr,
    const uint8_t *restrict is_report,
    int64_t *restrict report_counts,
    const int64_t *restrict row_ptr,
    const int64_t *restrict start_idx,
    const int64_t *restrict start_ptr,
    const uint8_t *restrict start_sod,
    const int64_t *restrict stream,
    const uint8_t *restrict symbol_cols,
    const int64_t C,
    const int64_t NE,
    const int64_t NS,
    const int64_t NSTART,
    const int64_t T,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)NE; (void)NSTART;
    nfa_dbg_hits = nfa_dbg_misses = 0;
    if (C <= 0) return;
    if (T <= 0) {
        #pragma omp parallel for schedule(static)
        for (int64_t c = 0; c < C; ++c) report_counts[c] = 0;
        return;
    }

    /* fast path requires every component width <= 64 and counts that fit int32 */
    bool fast = (T <= 100000000);
    for (int64_t c = 0; c < C && fast; ++c) {
        if (comp_ptr[c + 1] - comp_ptr[c] > (int64_t)NFA_MAXW) fast = false;
    }
    if (!fast) {
        int64_t need = 3 * NS * 8 + T + 64;
        bool ows = (workspace && workspace_size >= need);
        uint8_t *scratch = ows ? workspace : (uint8_t *)malloc((size_t)need);
        if (!scratch) abort();
        memset(scratch, 0, (size_t)3 * NS * 8);
        nfa_frontier_generic(activation_counts, col_idx, comp_ptr, is_report,
                             report_counts, row_ptr, start_idx, start_ptr,
                             start_sod, stream, symbol_cols, C, NS, T, scratch);
        if (!ows) free(scratch);
        return;
    }

    const size_t stream8_sz = (size_t)T;
    const size_t comp_stride = (sizeof(NfaComp) + 63) / 64 * 64;
    const size_t aux_sz = (size_t)C * (NFA_MAXW * 8 + NFA_MAXW * 4);
    const size_t total = 64 + stream8_sz + C * comp_stride + aux_sz;
    uint8_t *ws = workspace;
    bool own = false;
    if (!ws || (int64_t)workspace_size < (int64_t)total) {
        ws = (uint8_t *)malloc(total);
        if (!ws) abort();
        own = true;
    }
    ws = (uint8_t *)(((uintptr_t)ws + 63) & ~(uintptr_t)63);
    uint8_t *stream8 = ws + 64;
    NfaComp *comps = (NfaComp *)(ws + 64 + stream8_sz);
    uint8_t *aux = (uint8_t *)(comps + C);

    int nt = omp_get_max_threads();
    if (nt > C) nt = (int)C;
    if (nt > 512) nt = 512;
    if (nt < 1) nt = 1;
    omp_set_num_threads(nt);

    #pragma omp parallel for schedule(static)
    for (int64_t t = 0; t < T; ++t) stream8[t] = (uint8_t)stream[t];

    #pragma omp parallel for schedule(static)
    for (int64_t c = 0; c < C; ++c) {
        NfaComp *cc = &comps[c];
        cc->base = comp_ptr[c];
        cc->width = comp_ptr[c + 1] - comp_ptr[c];
        cc->succ = (uint64_t *)(aux + (size_t)c * (NFA_MAXW * 12));
        cc->acc = (int32_t *)(cc->succ + NFA_MAXW);
        uint64_t A0 = 0, A1 = 0, R = 0;
        for (int64_t k = start_ptr[c]; k < start_ptr[c + 1]; ++k) {
            int64_t r = start_idx[k] - cc->base;
            A1 |= 1ull << r;
            if (start_sod[k] == 0) A0 |= 1ull << r;
        }
        for (int64_t r = 0; r < cc->width; ++r) {
            if (is_report[cc->base + r]) R |= 1ull << r;
            uint64_t sb = 0;
            int64_t s = cc->base + r;
            for (int64_t e = row_ptr[s]; e < row_ptr[s + 1]; ++e)
                sb |= 1ull << (int)(col_idx[e] - cc->base);
            cc->succ[r] = sb;
        }
        cc->A0 = A0;
        cc->A1 = A1;
        cc->R = R;
        cc->rep = 0;
        cc->bits = A1;   /* all starts enabled before the first symbol */
        cc->mkey[0] = NFA_EMPTY_KEY; cc->mnb0[0] = 0; cc->mcnt[0] = 0;
        cc->mkey[1] = NFA_EMPTY_KEY; cc->mnb0[1] = 0; cc->mcnt[1] = 0;
        for (unsigned i = 0; i < NFA_COLD_SLOTS; ++i) cc->cold[i].key = NFA_EMPTY_KEY;
        memset(cc->acc, 0, (size_t)cc->width * sizeof(int32_t));
    }

    #pragma omp parallel
    {
        int tid = omp_get_thread_num();
        int nthreads = omp_get_num_threads();
        int64_t t0 = (C * (int64_t)tid) / nthreads;
        int64_t t1 = (C * (int64_t)(tid + 1)) / nthreads;
        NfaComp *cs = &comps[t0];
        NfaComp *ce = cs + (t1 - t0);

        const uint8_t *s8 = stream8;
        int64_t tlim = T - 1;
        uint64_t nfa_hits_local = 0, nfa_misses_local = 0;

        for (int64_t t = 0; t < tlim; ++t) {
            uint64_t sym = s8[t];
            if (sym == 10u) {
                for (NfaComp *cc = cs; cc < ce; ++cc) NFA_STEP(cc, cc->A1);
            } else {
                for (NfaComp *cc = cs; cc < ce; ++cc) NFA_STEP(cc, cc->A0);
            }
        }
        /* final symbol: eod forced */
        {
            uint64_t sym = s8[tlim];
            for (NfaComp *cc = cs; cc < ce; ++cc) NFA_STEP(cc, cc->A1);
        }
        nfa_dbg_hits += nfa_hits_local;
        nfa_dbg_misses += nfa_misses_local;
    }

    /* write report_counts and flush acc (deterministic per-component owners) */
    #pragma omp parallel for schedule(static)
    for (int64_t c = 0; c < C; ++c) {
        NfaComp *cc = &comps[c];
        int64_t rep_total = cc->rep;
        for (unsigned i = 0; i < NFA_COLD_SLOTS; ++i) {
            NfaCold *e = &cc->cold[i];
            if (e->key == NFA_EMPTY_KEY) continue;
            int64_t cnt = (int64_t)e->cnt;
            if (!cnt) continue;
            rep_total += (int64_t)__builtin_popcountll(e->mb & cc->R) * cnt;
            uint64_t m = e->mb;
            while (m) {
                int r = __builtin_ctzll(m);
                cc->acc[r] += (int32_t)cnt;
                m &= m - 1;
            }
        }
        for (unsigned i = 0; i < 2; ++i) {
            uint64_t key = cc->mkey[i];
            if (key == NFA_EMPTY_KEY) continue;
            int64_t cnt = (int64_t)cc->mcnt[i];
            if (!cnt) continue;
            NfaCold *e = &cc->cold[nfa_set_key(key) * 2u];
            if (e->key != key) e = &e[1];
            rep_total += (int64_t)__builtin_popcountll(e->mb & cc->R) * cnt;
            uint64_t m = e->mb;
            while (m) {
                int r = __builtin_ctzll(m);
                cc->acc[r] += (int32_t)cnt;
                m &= m - 1;
            }
        }
        report_counts[c] = rep_total;
        for (int64_t r = 0; r < cc->width; ++r) {
            int64_t v = cc->acc[r];
            if (v) activation_counts[cc->base + r] += v;
        }
    }

    if (own) free(ws);
}
