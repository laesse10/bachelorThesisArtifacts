#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define NHALO 3
#define P1 0.5833333333333334
#define P2 (-0.08333333333333333)
#define C1 (-0.14285714285714285)
#define C2 0.7857142857142857
#define C3 0.35714285714285715
#define STEP 0.01

/* PPM volume-mean edge value: al = P1*(q[j-1]+q[j]) + P2*(q[j-2]+q[j+1]) */
static inline double al_gen(double qm2, double qm1, double q0, double qp1) {
    return P1 * (qm1 + q0) + P2 * (qm2 + qp1);
}

/* PPM flux, numpy order of ops; m5: sign test bl*br<0, else general limiter */
static inline double ppm_flux(double alm1, double al0, double alp1, double qi, double qim1, double c, int m5) {
    double bl   = al0 - qi;
    double br   = alp1 - qi;
    double b0   = bl + br;
    double blm1 = alm1 - qim1;
    double brm1 = al0 - qim1;
    double b0m1 = blm1 + brm1;
    double mask;
    if (m5)
        mask = ((bl * br < 0.0) | (blm1 * brm1 < 0.0)) ? 1.0 : 0.0;
    else
        mask = ((3.0 * fabs(b0) < fabs(bl - br)) | (3.0 * fabs(b0m1) < fabs(blm1 - brm1))) ? 1.0 : 0.0;
    if (c > 0.0)
        return qim1 + (1.0 - c) * (brm1 - c * b0m1) * mask;
    return qi + (1.0 + c) * (bl + c * b0) * mask;
}

/* grid_type<3 special edge values */
static inline double al_ja(double qm2, double qm1, double q0) {
    return (C1 * qm2 + C2 * qm1) + C3 * q0;
}
static inline double al_jb(double gm2, double gm1, double g0, double gp1,
                           double qm2, double qm1, double q0, double qp1) {
    double left  = ((2.0 * gm1 + gm2) * qm1 - gm1 * qm2) / (gm2 + gm1);
    double right = ((2.0 * g0 + gp1) * q0 - g0 * qp1) / (g0 + gp1);
    return 0.5 * (left + right);
}
static inline double al_jc(double qm1, double q0, double qp1) {
    return (C3 * qm1 + C2 * q0) + C1 * qp1;
}

/* cubed-sphere corner copies (in place) -- exact tables from the reference */
static void corners_x(double *f, int64_t nx, int64_t ny, int64_t nk) {
    for (int64_t k = 0; k < nk; k++) {
        int dr, dc;
        for (dr = 0; dr < 3; dr++)
            for (dc = 0; dc < 3; dc++)
                f[(dr * ny + dc) * nk + k] = f[(dc * ny + (5 - dr)) * nk + k];
        for (dr = 0; dr < 3; dr++)
            for (dc = 0; dc < 3; dc++)
                f[(dr * ny + (ny - 4 + dc)) * nk + k] = f[((2 - dc) * ny + (ny - 7 + dr)) * nk + k];
        for (dr = 0; dr < 3; dr++)
            for (dc = 0; dc < 3; dc++)
                f[((nx - 4 + dr) * ny + dc) * nk + k] = f[((nx - 2 - dc) * ny + (3 + dr)) * nk + k];
        for (dr = 0; dr < 3; dr++)
            for (dc = 0; dc < 3; dc++)
                f[((nx - 4 + dr) * ny + (ny - 4 + dc)) * nk + k] = f[((nx - 4 + dc) * ny + (ny - 5 - dr)) * nk + k];
    }
}

static void corners_y(double *f, int64_t nx, int64_t ny, int64_t nk) {
    for (int64_t k = 0; k < nk; k++) {
        int dr, dc;
        for (dr = 0; dr < 3; dr++)
            for (dc = 0; dc < 3; dc++)
                f[(dr * ny + dc) * nk + k] = f[((5 - dc) * ny + dr) * nk + k];
        for (dr = 0; dr < 3; dr++)
            for (dc = 0; dc < 3; dc++)
                f[((nx - 4 + dr) * ny + dc) * nk + k] = f[((nx - 7 + dc) * ny + (2 - dr)) * nk + k];
        for (dr = 0; dr < 3; dr++)
            for (dc = 0; dc < 3; dc++)
                f[(dr * ny + (ny - 4 + dc)) * nk + k] = f[((3 + dc) * ny + (ny - 2 - dr)) * nk + k];
        for (dr = 0; dr < 3; dr++)
            for (dc = 0; dc < 3; dc++)
                f[((nx - 4 + dr) * ny + (ny - 4 + dc)) * nk + k] = f[((nx - 5 - dc) * ny + (ny - 4 + dr)) * nk + k];
    }
}

/* ------------------------------------------------------------------ */
/* phase Y1 (i-row): y-PPM flux f[j] on q for j in [3, nj+3]           */
/*   stores qyadv[i,j]=f[j] for i in [3, ni+2]                         */
/*   stores qadv_y[i,j-1] = (q[j-1]*A + yf[j-1]*f[j-1] - yf[j]*f[j])  */
/*                             / (A + yf[j-1] - yf[j])  for j-1 in [3,nj+2] */
/* state at step j: window q[j-2..j+3], al[j-1..j+1], f[j-1], f[j]     */
/* ------------------------------------------------------------------ */
static void phase_y1_row(const double *restrict q, const double *restrict cry,
                         const double *restrict dya, const double *restrict area,
                         const double *restrict yuf, double *restrict qadv_y,
                         double *restrict qyadv,
                         int64_t i, int64_t ny, int64_t nk, int64_t ni, int64_t nj,
                         int gt3, int m5in) {
    const double *qrow   = q    + i * ny * nk;
    const double *cryrow = cry  + i * ny * nk;
    const double *dyarow = dya  + i * ny * nk;
    const double *arow   = area + i * ny * nk;
    const double *yufrow = yuf  + i * ny * nk;
    double *qadvrow  = qadv_y  + i * ny * nk;
    double *qyadvrow = qyadv   + i * ny * nk;
    int64_t jmax = nj + 3;
    int store_qyadv = (i >= 3) & (i <= ni + 2);
    int64_t kbase;

    for (kbase = 0; kbase < nk; kbase += 8) {
        int kn = (int)(nk - kbase);
        if (kn > 8) kn = 8;
        double qm2[8], qm1[8], q0[8], q1[8], q2[8], q3[8];
        double alm1[8], al0[8], alp1[8];
        double fcur[8], fprev[8];
        int l;
        for (l = 0; l < kn; l++) {
            int64_t k = kbase + l;
            double qm3 = qrow[0 * nk + k];  /* q[0]: only for al[2] */
            qm2[l] = qrow[1 * nk + k]; qm1[l] = qrow[2 * nk + k]; q0[l] = qrow[3 * nk + k];
            q1[l]  = qrow[4 * nk + k]; q2[l] = qrow[5 * nk + k]; q3[l] = qrow[6 * nk + k];
            alm1[l] = gt3 ? al_ja(qm3, qm2[l], qm1[l]) : al_gen(qm3, qm2[l], qm1[l], q0[l]);
            if (gt3)
                al0[l] = al_jb(dyarow[1 * nk + k], dyarow[2 * nk + k],
                               dyarow[3 * nk + k], dyarow[4 * nk + k],
                               qm2[l], qm1[l], q0[l], q1[l]);
            else
                al0[l] = al_gen(qm2[l], qm1[l], q0[l], q1[l]);
            alp1[l] = gt3 ? al_jc(qm1[l], q0[l], q1[l]) : al_gen(qm1[l], q0[l], q1[l], q2[l]);
            fcur[l]  = ppm_flux(alm1[l], al0[l], alp1[l], q0[l], qm1[l], cryrow[3 * nk + k], m5in);
            fprev[l] = fcur[l];
        }
        for (int64_t j = 3; j <= jmax; j++) {
            for (l = 0; l < kn; l++) {
                int64_t k = kbase + l;
                if (store_qyadv) qyadvrow[j * nk + k] = fcur[l];
                if (j > 3) {
                    double aa = arow[(j - 1) * nk + k];
                    double y0 = yufrow[(j - 1) * nk + k];
                    double y1 = yufrow[j * nk + k];
                    qadvrow[(j - 1) * nk + k] =
                        (qm1[l] * aa + y0 * fprev[l] - y1 * fcur[l]) / (aa + y0 - y1);
                }
            }
            if (j < jmax) {
                for (l = 0; l < kn; l++) {
                    int64_t k = kbase + l;
                    double q4 = qrow[(j + 3) * nk + k];
                    double nal;
                    if (gt3) {
                        int64_t kk = j + 2;
                        if (kk == nj + 2)
                            nal = al_ja(q0[l], q1[l], q2[l]);
                        else if (kk == nj + 3)
                            nal = al_jb(dyarow[(j + 1) * nk + k], dyarow[(j + 2) * nk + k],
                                        dyarow[(j + 3) * nk + k], dyarow[(j + 4) * nk + k],
                                        q0[l], q1[l], q2[l], q3[l]);
                        else
                            nal = al_jc(q1[l], q2[l], q3[l]);
                    } else
                        nal = al_gen(q0[l], q1[l], q2[l], q3[l]);
                    double fnext = ppm_flux(al0[l], alp1[l], nal, q1[l], q0[l],
                                            cryrow[(j + 1) * nk + k], m5in);
                    qm2[l] = qm1[l]; qm1[l] = q0[l]; q0[l] = q1[l];
                    q1[l] = q2[l]; q2[l] = q3[l]; q3[l] = q4;
                    alm1[l] = al0[l]; al0[l] = alp1[l]; alp1[l] = nal;
                    fprev[l] = fcur[l]; fcur[l] = fnext;
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/* phase X (j-col, i-stream):                                          */
/*   fxc = x-PPM flux on q (m5in)  for i in [3, ni+3]                  */
/*   fx2 = x-PPM flux on qadv_y (m5out) for i in [3, ni+3]             */
/*   qadv_x[i-1] = (q[i-1]*A + xf[i-1]*fxc[i-1] - xf[i]*fxc[i])/(..)   */
/*       for i-1 in [3, ni+2]                                          */
/*   q_x_flux[i] = 0.5*(fx2[i]+fxc[i])*xuf[i]  (j in [3, nj+2])        */
/* state at step i: windows q[i-2..i+3], y[i-2..i+3],                  */
/*                  alx[i-1..i+1], al2[i-1..i+1], fxc[i-1], fxc[i], fx2[i] */
/* ------------------------------------------------------------------ */
static void phase_x_col(const double *restrict q, const double *restrict crx,
                        const double *restrict dxa, const double *restrict area,
                        const double *restrict xuf, const double *restrict qadv_y,
                        double *restrict qadv_x, double *restrict q_x_flux,
                        int64_t j, int64_t ny, int64_t nk, int64_t ni, int64_t nj,
                        int gt3, int m5in, int m5out) {
    const int64_t is = ny * nk;                 /* stride between i rows */
    const double *qrow   = q    + j * nk;
    const double *crxrow = crx  + j * nk;
    const double *dxarow = dxa  + j * nk;
    const double *arow   = area + j * nk;
    const double *xufrow = xuf  + j * nk;
    const double *yrow   = qadv_y + j * nk;
    double *qadvxrow = qadv_x  + j * nk;
    double *qxfrow   = q_x_flux + j * nk;
    int64_t imax = ni + 3;
    int write_xflux = (j >= 3) & (j <= nj + 2);
    int64_t kbase;

    for (kbase = 0; kbase < nk; kbase += 8) {
        int kn = (int)(nk - kbase);
        if (kn > 8) kn = 8;
        double qm2[8], qm1[8], q0[8], q1[8], q2[8], q3[8];
        double ym2[8], ym1[8], y0[8], y1[8], y2[8], y3[8];
        double alxm1[8], alx0[8], alxp1[8];
        double al2m1[8], al20[8], al2p1[8];
        double fxc[8], fxcprev[8], fx2[8];
        int l;
        for (l = 0; l < kn; l++) {
            int64_t k = kbase + l;
            double qm3 = qrow[0 * is + k], ym3 = yrow[0 * is + k];
            qm2[l] = qrow[1 * is + k]; qm1[l] = qrow[2 * is + k]; q0[l] = qrow[3 * is + k];
            q1[l]  = qrow[4 * is + k]; q2[l] = qrow[5 * is + k]; q3[l] = qrow[6 * is + k];
            ym2[l] = yrow[1 * is + k]; ym1[l] = yrow[2 * is + k]; y0[l] = yrow[3 * is + k];
            y1[l]  = yrow[4 * is + k]; y2[l] = yrow[5 * is + k]; y3[l] = yrow[6 * is + k];
            alxm1[l] = gt3 ? al_ja(qm3, qm2[l], qm1[l]) : al_gen(qm3, qm2[l], qm1[l], q0[l]);
            if (gt3)
                alx0[l] = al_jb(dxarow[1 * is + k], dxarow[2 * is + k],
                                dxarow[3 * is + k], dxarow[4 * is + k],
                                qm2[l], qm1[l], q0[l], q1[l]);
            else
                alx0[l] = al_gen(qm2[l], qm1[l], q0[l], q1[l]);
            alxp1[l] = gt3 ? al_jc(qm1[l], q0[l], q1[l]) : al_gen(qm1[l], q0[l], q1[l], q2[l]);
            al2m1[l] = gt3 ? al_ja(ym3, ym2[l], ym1[l]) : al_gen(ym3, ym2[l], ym1[l], y0[l]);
            if (gt3)
                al20[l] = al_jb(dxarow[1 * is + k], dxarow[2 * is + k],
                                dxarow[3 * is + k], dxarow[4 * is + k],
                                ym2[l], ym1[l], y0[l], y1[l]);
            else
                al20[l] = al_gen(ym2[l], ym1[l], y0[l], y1[l]);
            al2p1[l] = gt3 ? al_jc(ym1[l], y0[l], y1[l]) : al_gen(ym1[l], y0[l], y1[l], y2[l]);
            fxc[l]     = ppm_flux(alxm1[l], alx0[l], alxp1[l], q0[l], qm1[l], crxrow[3 * is + k], m5in);
            fxcprev[l] = fxc[l];
            fx2[l]     = ppm_flux(al2m1[l], al20[l], al2p1[l], y0[l], ym1[l], crxrow[3 * is + k], m5out);
        }
        for (int64_t i = 3; i <= imax; i++) {
            for (l = 0; l < kn; l++) {
                int64_t k = kbase + l;
                if (i > 3) {
                    double aa = arow[(i - 1) * is + k];
                    double x0 = xufrow[(i - 1) * is + k];
                    double x1 = xufrow[i * is + k];
                    qadvxrow[(i - 1) * is + k] =
                        (qm1[l] * aa + x0 * fxcprev[l] - x1 * fxc[l]) / (aa + x0 - x1);
                }
                if (write_xflux && i <= ni + 2)
                    qxfrow[i * is + k] = 0.5 * (fx2[l] + fxc[l]) * xufrow[i * is + k];
            }
            if (i < imax) {
                for (l = 0; l < kn; l++) {
                    int64_t k = kbase + l;
                    double q4 = qrow[(i + 3) * is + k];
                    double y4 = yrow[(i + 3) * is + k];
                    double nalx, nal2;
                    if (gt3) {
                        int64_t kk = i + 2;
                        if (kk == ni + 2) {
                            nalx = al_ja(q0[l], q1[l], q2[l]);
                            nal2 = al_ja(y0[l], y1[l], y2[l]);
                        } else if (kk == ni + 3) {
                            nalx = al_jb(dxarow[(i + 1) * is + k], dxarow[(i + 2) * is + k],
                                         dxarow[(i + 3) * is + k], dxarow[(i + 4) * is + k],
                                         q0[l], q1[l], q2[l], q3[l]);
                            nal2 = al_jb(dxarow[(i + 1) * is + k], dxarow[(i + 2) * is + k],
                                         dxarow[(i + 3) * is + k], dxarow[(i + 4) * is + k],
                                         y0[l], y1[l], y2[l], y3[l]);
                        } else {
                            nalx = al_jc(q1[l], q2[l], q3[l]);
                            nal2 = al_jc(y1[l], y2[l], y3[l]);
                        }
                    } else {
                        nalx = al_gen(q0[l], q1[l], q2[l], q3[l]);
                        nal2 = al_gen(y0[l], y1[l], y2[l], y3[l]);
                    }
                    double c = crxrow[(i + 1) * is + k];
                    double fxcnext = ppm_flux(alx0[l], alxp1[l], nalx, q1[l], q0[l], c, m5in);
                    double fx2next = ppm_flux(al20[l], al2p1[l], nal2, y1[l], y0[l], c, m5out);
                    qm2[l] = qm1[l]; qm1[l] = q0[l]; q0[l] = q1[l];
                    q1[l] = q2[l]; q2[l] = q3[l]; q3[l] = q4;
                    ym2[l] = ym1[l]; ym1[l] = y0[l]; y0[l] = y1[l];
                    y1[l] = y2[l]; y2[l] = y3[l]; y3[l] = y4;
                    alxm1[l] = alx0[l]; alx0[l] = alxp1[l]; alxp1[l] = nalx;
                    al2m1[l] = al20[l]; al20[l] = al2p1[l]; al2p1[l] = nal2;
                    fxcprev[l] = fxc[l]; fxc[l] = fxcnext;
                    fx2[l] = fx2next;
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/* phase Y2 (i-row, interior i in [3, ni+2], j-stream):                */
/*   fx3 = y-PPM flux on qadv_x (m5out) for j in [3, nj+3]             */
/*   yf  = 0.5*(fx3[j]+qyadv[j])*yuf[j]                                */
/*   q[i,j-1] -= (0.01*((qxf[i+1,j-1]-qxf[i,j-1])+yf[j])-yf[j-1])/area */
/*   q_y_flux[i,j] = yf  (last step only)                              */
/* ------------------------------------------------------------------ */
static void phase_y2_row(double *restrict q, const double *restrict cry,
                         const double *restrict dya, const double *restrict area,
                         const double *restrict yuf, const double *restrict qadv_x,
                         const double *restrict qyadv, const double *restrict q_x_flux,
                         double *restrict q_y_flux,
                         int64_t i, int64_t ny, int64_t nk, int64_t nj,
                         int gt3, int m5out, int last_step) {
    const double *xrow   = qadv_x  + i * ny * nk;
    const double *cryrow = cry     + i * ny * nk;
    const double *dyarow = dya     + i * ny * nk;
    const double *arow   = area    + i * ny * nk;
    const double *yufrow = yuf     + i * ny * nk;
    const double *qyrow  = qyadv   + i * ny * nk;
    const double *qxfrow = q_x_flux + i * ny * nk;
    const double *qxfrow1 = q_x_flux + (i + 1) * ny * nk;
    double *qrow   = q  + i * ny * nk;
    double *qyfrow = q_y_flux + i * ny * nk;
    int64_t jmax = nj + 3;
    int64_t kbase;

    for (kbase = 0; kbase < nk; kbase += 8) {
        int kn = (int)(nk - kbase);
        if (kn > 8) kn = 8;
        double xm2[8], xm1[8], x0[8], x1[8], x2[8], x3[8];
        double alm1[8], al0[8], alp1[8];
        double fcur[8];
        double yfprev[8];
        int l;
        for (l = 0; l < kn; l++) {
            int64_t k = kbase + l;
            double xm3 = xrow[0 * nk + k];
            xm2[l] = xrow[1 * nk + k]; xm1[l] = xrow[2 * nk + k]; x0[l] = xrow[3 * nk + k];
            x1[l]  = xrow[4 * nk + k]; x2[l] = xrow[5 * nk + k]; x3[l] = xrow[6 * nk + k];
            alm1[l] = gt3 ? al_ja(xm3, xm2[l], xm1[l]) : al_gen(xm3, xm2[l], xm1[l], x0[l]);
            if (gt3)
                al0[l] = al_jb(dyarow[1 * nk + k], dyarow[2 * nk + k],
                               dyarow[3 * nk + k], dyarow[4 * nk + k],
                               xm2[l], xm1[l], x0[l], x1[l]);
            else
                al0[l] = al_gen(xm2[l], xm1[l], x0[l], x1[l]);
            alp1[l] = gt3 ? al_jc(xm1[l], x0[l], x1[l]) : al_gen(xm1[l], x0[l], x1[l], x2[l]);
            fcur[l]  = ppm_flux(alm1[l], al0[l], alp1[l], x0[l], xm1[l], cryrow[3 * nk + k], m5out);
            yfprev[l] = 0.5 * (fcur[l] + qyrow[3 * nk + k]) * yufrow[3 * nk + k];
        }
        for (int64_t j = 3; j <= jmax; j++) {
            for (l = 0; l < kn; l++) {
                int64_t k = kbase + l;
                double yfcur = 0.5 * (fcur[l] + qyrow[j * nk + k]) * yufrow[j * nk + k];
                if (j > 3) {
                    double xfl0 = qxfrow[(j - 1) * nk + k];
                    double xfl1 = qxfrow1[(j - 1) * nk + k];
                    double aa = arow[(j - 1) * nk + k];
                    double div = ((xfl1 - xfl0) + yfcur) - yfprev[l];
                    qrow[(j - 1) * nk + k] -= (STEP * div) / aa;
                }
                if (last_step) qyfrow[j * nk + k] = yfcur;
            }
            if (j < jmax) {
                for (l = 0; l < kn; l++) {
                    int64_t k = kbase + l;
                    double x4 = xrow[(j + 3) * nk + k];
                    double nal;
                    if (gt3) {
                        int64_t kk = j + 2;
                        if (kk == nj + 2)
                            nal = al_ja(x0[l], x1[l], x2[l]);
                        else if (kk == nj + 3)
                            nal = al_jb(dyarow[(j + 1) * nk + k], dyarow[(j + 2) * nk + k],
                                        dyarow[(j + 3) * nk + k], dyarow[(j + 4) * nk + k],
                                        x0[l], x1[l], x2[l], x3[l]);
                        else
                            nal = al_jc(x1[l], x2[l], x3[l]);
                    } else
                        nal = al_gen(x0[l], x1[l], x2[l], x3[l]);
                    double fnext = ppm_flux(al0[l], alp1[l], nal, x1[l], x0[l],
                                            cryrow[(j + 1) * nk + k], m5out);
                    xm2[l] = xm1[l]; xm1[l] = x0[l]; x0[l] = x1[l];
                    x1[l] = x2[l]; x2[l] = x3[l]; x3[l] = x4;
                    alm1[l] = al0[l]; al0[l] = alp1[l]; alp1[l] = nal;
                    fcur[l] = fnext;
                    yfprev[l] = 0.5 * (fnext + qyrow[(j + 1) * nk + k]) * yufrow[(j + 1) * nk + k];
                }
            }
        }
    }
}

void fv3_dycore_fp64(
    const double *restrict area, const double *restrict crx, const double *restrict cry,
    const double *restrict dxa, const double *restrict dya,
    double *restrict q, double *restrict q_x_flux, double *restrict q_y_flux,
    const double *restrict x_area_flux, const double *restrict y_area_flux,
    const int64_t grid_type, const int64_t hord, const int64_t ni, const int64_t nj,
    const int64_t nk, const int64_t nsteps,
    uint8_t *restrict workspace, const int64_t workspace_size) {
    int64_t nx = ni + 6, ny = nj + 6;
    int64_t ord_inner = (hord == 10) ? 8 : hord;
    int m5in = (llabs(ord_inner) == 5) != 0;
    int m5out = (llabs(hord) == 5) != 0;
    int gt3 = (grid_type < 3);
    size_t fsize = (size_t)nx * (size_t)ny * (size_t)nk;
    double *qadv_y = (double *)workspace;
    double *qyadv  = (double *)(workspace + fsize * sizeof(double));
    double *qadv_x = (double *)(workspace + 2 * fsize * sizeof(double));

    for (int64_t step = 0; step < nsteps; step++) {
        int last_step = (step == nsteps - 1);
        corners_y(q, nx, ny, nk);
#pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < nx; i++)
            phase_y1_row(q, cry, dya, area, y_area_flux, qadv_y, qyadv,
                         i, ny, nk, ni, nj, gt3, m5in);
        corners_x(q, nx, ny, nk);
#pragma omp parallel for schedule(static)
        for (int64_t j = 0; j < ny; j++)
            phase_x_col(q, crx, dxa, area, x_area_flux, qadv_y, qadv_x, q_x_flux,
                        j, ny, nk, ni, nj, gt3, m5in, m5out);
#pragma omp parallel for schedule(static)
        for (int64_t i = 3; i <= ni + 2; i++)
            phase_y2_row(q, cry, dya, area, y_area_flux, qadv_x, qyadv,
                         q_x_flux, q_y_flux, i, ny, nk, nj, gt3, m5out, last_step);
    }
    (void)workspace_size;
}
