/* BOUT++ Arakawa Poisson bracket [f,g] with nsteps advection.
 * Optimized C (AVX-512 + OpenMP). Semantics identical to bout_arakawa_numpy.py:
 * each step: result = B(f)  (bracket of the whole current f), then
 *            f[1:NX-1,:,:] += STEP * result[1:NX-1,:,:].
 *
 * Technique: parallel over y-slices. Each slice sweeps x with three rotating
 * line buffers per array (f, g) plus three for the per-step bracket (r), so
 * every f line is read once and written once per step.  The in-place f update
 * of line jx-1 is deferred until iteration jx (after that line has been
 * consumed as the stencil's x-1 line), reproducing the reference's
 * compute-all-then-update snapshot semantics exactly.
 * z is periodic: the +/-1 neighbours come from overlapping 8-wide window loads.
 */
#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <omp.h>
#include <immintrin.h>

static const double STEP = 1.0e-3;

#if defined(__AVX512F__)
#define HAS_AVX512 1
#else
#define HAS_AVX512 0
#endif

/* midpoint line from overlapping window loads:
 * lo = v[z-1 .. z+6], hi = v[z+1 .. z+8]  ->  mid = v[z .. z+7] */
#if HAS_AVX512
static __m512d mid_view(__m512d lo, __m512d hi)
{
    static const __m512i idx = { 1, 8, 9, 10, 11, 12, 13, 14 };
    return _mm512_permutex2var_pd(lo, idx, hi);
}
#endif

/* one z point of the bracket from pre-gathered stencil values.
 * f lines: (ma,mb,mc) f[xm] at (zm,z,zp); (na,nc) f[x] at (zm,zp);
 *          (pa,pb,pc) f[xp] at (zm,z,zp).
 * g lines: (maa,mab,mac) g[xm] at (zm,z,zp); (naa,nbb,nac) g[x] at (zm,z,zp);
 *          (paa,pab,pac) g[xp] at (zm,z,zp).
 * stores r into rline[z]; if rmem != NULL also stores into rmem[z]. */
static inline void point(int64_t z, double *rline, double *rmem,
                         double ma, double mb, double mc,
                         double na, double nc,
                         double pa, double pb, double pc,
                         double maa, double mab, double mac,
                         double naa, double nbb, double nac,
                         double paa, double pab, double pac,
                         double fct)
{
    double jpp = (nc - na) * (pab - mab) - (pb - mb) * (nac - naa);
    double jpx = pab * (pc - pa) - mab * (mc - ma) - nac * (pc - mc) + nbb * (pa - ma);
    double jxp = pac * (nc - pb) - maa * (mb - na) - mac * (nc - mb) + paa * (pb - na);
    double r = ((jpp + jpx) + jxp) * fct;
    rline[z] = r;
    if (rmem != NULL)
        rmem[z] = r;
}

/* scalar z=0..7 and z=NZ-8..NZ-1 (full line if NZ < 16) */
static inline void row_ends(int64_t NZ, double *rline, double *rmem,
                            const double *fa, const double *fb, const double *fc,
                            const double *ga, const double *gb, const double *gc,
                            double fct)
{
    int64_t z;
    int64_t z0 = 0, z1 = (NZ < 16) ? NZ : 8;
    int64_t t0 = (NZ < 16) ? NZ : NZ - 8, t1 = NZ;
    for (z = z0; z < z1; ++z) {
        int64_t zm = (z == 0) ? NZ - 1 : z - 1;
        int64_t zp = (z == NZ - 1) ? 0 : z + 1;
        point(z, rline, rmem,
              fa[zm], fa[z], fa[zp], fb[zm], fb[zp], fc[zm], fc[z], fc[zp],
              ga[zm], ga[z], ga[zp], gb[zm], gb[z], gb[zp],
              gc[zm], gc[z], gc[zp], fct);
    }
    for (z = t0; z < t1; ++z) {
        int64_t zm = (z == 0) ? NZ - 1 : z - 1;
        int64_t zp = (z == NZ - 1) ? 0 : z + 1;
        point(z, rline, rmem,
              fa[zm], fa[z], fa[zp], fb[zm], fb[zp], fc[zm], fc[z], fc[zp],
              ga[zm], ga[z], ga[zp], gb[zm], gb[z], gb[zp],
              gc[zm], gc[z], gc[zp], fct);
    }
}

#if HAS_AVX512
/* vector middle: z = 8 .. NZ-9 in steps of 8 (NZ >= 16) */
static inline void row_vec(int64_t NZ, double *rline, double *rmem,
                           const double *fa, const double *fb, const double *fc,
                           const double *ga, const double *gb, const double *gc,
                           double fct)
{
    for (int64_t z = 8; z < NZ - 8; z += 8) {
        __m512d ma = _mm512_loadu_pd(fa + z - 1), mc = _mm512_loadu_pd(fa + z + 1);
        __m512d mb = mid_view(ma, mc);
        __m512d na = _mm512_loadu_pd(fb + z - 1), nc = _mm512_loadu_pd(fb + z + 1);
        __m512d pa = _mm512_loadu_pd(fc + z - 1), pc = _mm512_loadu_pd(fc + z + 1);
        __m512d pb = mid_view(pa, pc);
        __m512d maa = _mm512_loadu_pd(ga + z - 1), mac = _mm512_loadu_pd(ga + z + 1);
        __m512d mab = mid_view(maa, mac);
        __m512d naa = _mm512_loadu_pd(gb + z - 1), nac = _mm512_loadu_pd(gb + z + 1);
        __m512d nbb = mid_view(naa, nac);
        __m512d paa = _mm512_loadu_pd(gc + z - 1), pac = _mm512_loadu_pd(gc + z + 1);
        __m512d pab = mid_view(paa, pac);

        __m512d jpp = _mm512_fnmadd_pd(_mm512_sub_pd(pb, mb), _mm512_sub_pd(nac, naa),
                                       _mm512_mul_pd(_mm512_sub_pd(nc, na),
                                                     _mm512_sub_pd(pab, mab)));
        __m512d jpx = _mm512_fmadd_pd(nbb, _mm512_sub_pd(pa, ma),
                     _mm512_fnmadd_pd(nac, _mm512_sub_pd(pc, mc),
                      _mm512_fnmadd_pd(mab, _mm512_sub_pd(mc, ma),
                       _mm512_mul_pd(pab, _mm512_sub_pd(pc, pa)))));
        __m512d jxp = _mm512_fmadd_pd(paa, _mm512_sub_pd(pb, na),
                     _mm512_fnmadd_pd(mac, _mm512_sub_pd(nc, mb),
                      _mm512_fnmadd_pd(maa, _mm512_sub_pd(mb, na),
                       _mm512_mul_pd(pac, _mm512_sub_pd(nc, pb)))));

        __m512d r = _mm512_mul_pd(_mm512_add_pd(_mm512_add_pd(jpp, jpx), jxp),
                                  _mm512_set1_pd(fct));
        _mm512_store_pd(rline + z, r);
        if (rmem != NULL)
            _mm512_storeu_pd(rmem + z, r);
    }
}
#endif

static inline void load_line(double *restrict dst, const double *restrict src, int64_t NZ)
{
    int64_t n8 = (NZ >= 8) ? NZ - 7 : 0;
    for (int64_t z = 0; z < n8; z += 8)
#if HAS_AVX512
        _mm512_store_pd(dst + z, _mm512_loadu_pd(src + z));
#else
    {
        double v[8];
        for (int k = 0; k < 8; ++k)
            v[k] = src[z + k];
        for (int k = 0; k < 8; ++k)
            dst[z + k] = v[k];
    }
#endif
    for (int64_t z = n8; z < NZ; ++z)
        dst[z] = src[z];
}

/* fa[z] += STEP * ra[z] on z = 0..NZ-1 (scratch lines are 64B aligned) */
static inline void apply_step(double *fa, const double *ra, int64_t NZ)
{
    int64_t n8 = (NZ >= 8) ? NZ - 7 : 0;
    for (int64_t z = 0; z < n8; z += 8)
#if HAS_AVX512
        _mm512_store_pd(fa + z, _mm512_fmadd_pd(_mm512_set1_pd(STEP),
                                                _mm512_load_pd(ra + z),
                                                _mm512_load_pd(fa + z)));
#else
    {
        for (int k = 0; k < 8; ++k)
            fa[z + k] = fma(STEP, ra[z + k], fa[z + k]);
    }
#endif
    for (int64_t z = n8; z < NZ; ++z)
        fa[z] = fma(STEP, ra[z], fa[z]);
}

/* scratch line -> memory line (scratch source is 64B aligned) */
static inline void store_line(double *restrict dst, const double *restrict src, int64_t NZ)
{
    int64_t n8 = (NZ >= 8) ? NZ - 7 : 0;
    for (int64_t z = 0; z < n8; z += 8)
#if HAS_AVX512
        _mm512_storeu_pd(dst + z, _mm512_load_pd(src + z));
#else
    {
        for (int k = 0; k < 8; ++k)
            dst[z + k] = src[z + k];
    }
#endif
    for (int64_t z = n8; z < NZ; ++z)
        dst[z] = src[z];
}

void bout_arakawa_fp64(const double *restrict dx, const double *restrict dz,
                       double *restrict f, const double *restrict g,
                       double *restrict result, const int64_t NX, const int64_t NY,
                       const int64_t NZ, const int64_t nsteps, uint8_t *restrict workspace,
                       const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    if (NX < 3 || NY < 1 || NZ < 2 || nsteps <= 0)
        return;

    const int64_t lp = (NZ + 7) & ~7LL;
    const int64_t per = 9 * lp; /* fa fb fc ga gb gc ra rb rc */
    const int nt = omp_get_max_threads();
    double *scratch = (double *)aligned_alloc(64, (size_t)nt * per * sizeof(double) + 64);
    if (!scratch)
        return;

    for (int64_t step = 0; step < nsteps; ++step) {
        const int final_step = (step == nsteps - 1);
#pragma omp parallel for schedule(dynamic, 1)
        for (int64_t jy = 0; jy < NY; ++jy) {
            const int tid = omp_get_thread_num();
            double *fa = scratch + (size_t)tid * per;
            double *fb = fa + lp, *fc = fa + 2 * lp;
            double *ga = fa + 3 * lp, *gb = fa + 4 * lp, *gc = fa + 5 * lp;
            double *ra = fa + 6 * lp, *rb = fa + 7 * lp, *rc = fa + 8 * lp;
            const size_t stride = (size_t)NY * (size_t)NZ;

            load_line(fa, f + (size_t)jy * NZ, NZ);
            load_line(fb, f + (size_t)NY * NZ + (size_t)jy * NZ, NZ);
            load_line(fc, f + (size_t)(2 * NY) * NZ + (size_t)jy * NZ, NZ);
            load_line(ga, g + (size_t)jy * NZ, NZ);
            load_line(gb, g + (size_t)NY * NZ + (size_t)jy * NZ, NZ);
            load_line(gc, g + (size_t)(2 * NY) * NZ + (size_t)jy * NZ, NZ);

            for (int64_t jx = 1; jx <= NX - 2; ++jx) {
                double fct = 1.0 / (12.0 * dz[jx * NY + jy] * dx[jx * NY + jy]);
                double *rmem = final_step ? result + ((size_t)jx * NY + (size_t)jy) * NZ : (double *)0;

#if HAS_AVX512
                if (NZ >= 16) {
                    row_ends(NZ, rb, rmem, fa, fb, fc, ga, gb, gc, fct);
                    row_vec(NZ, rb, rmem, fa, fb, fc, ga, gb, gc, fct);
                } else
                    row_ends(NZ, rb, rmem, fa, fb, fc, ga, gb, gc, fct);
#else
                row_ends(NZ, rb, rmem, fa, fb, fc, ga, gb, gc, fct);
#endif

                if (jx >= 2) {
                    apply_step(fa, ra, NZ);
                    store_line(f + ((size_t)(jx - 1) * NY + (size_t)jy) * NZ, fa, NZ);
                }
                if (jx < NX - 2) {
                    double *t = fa;
                    fa = fb;
                    fb = fc;
                    fc = t;
                    load_line(fc, f + (size_t)(jx + 2) * stride, NZ);
                    t = ga;
                    ga = gb;
                    gb = gc;
                    gc = t;
                    load_line(gc, g + (size_t)(jx + 2) * stride, NZ);
                    t = ra;
                    ra = rb;
                    rb = rc;
                    rc = t;
                }
            }
            /* last interior line: fb = f[NX-2], rb = r[NX-2] */
            apply_step(fb, rb, NZ);
            store_line(f + ((size_t)(NX - 2) * NY + (size_t)jy) * NZ, fb, NZ);
        }
    }
    free(scratch);
}
