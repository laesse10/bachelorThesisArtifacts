#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <immintrin.h>
#include <omp.h>

void cp2k_grid_integrate_fp64(
    const int32_t *restrict border_width,
    const double *restrict dh,
    const double *restrict dh_inv,
    const double *restrict grid,
    double *restrict hab,
    const int32_t *restrict la_max,
    const int32_t *restrict la_min,
    const int32_t *restrict lb_max,
    const int32_t *restrict lb_min,
    const int32_t *restrict npts_global,
    const int32_t *restrict npts_local,
    const double *restrict ra,
    const double *restrict rab,
    const double *restrict radius,
    const int32_t *restrict shift_local,
    const double *restrict zeta,
    const double *restrict zetb,
    const int64_t npts,
    const int64_t num_tasks,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    const int N = (int)npts;
    const int64_t NN = (int64_t)N * (int64_t)N;
    const int bw0 = border_width[0], bw1 = border_width[1], bw2 = border_width[2];
    const int nl0 = npts_local[0] - bw0, nl1 = npts_local[1] - bw1, nl2 = npts_local[2] - bw2;
    const int ng0 = npts_global[0], ng1 = npts_global[1], ng2 = npts_global[2];
    const int sh0 = shift_local[0], sh1 = shift_local[1], sh2 = shift_local[2];

    #pragma omp parallel for schedule(static, 256)
    for (int64_t task = 0; task < num_tasks; ++task) {
        const double zt  = zeta[task];
        const double zbt = zetb[task];
        const double r0  = radius[task];
        const int lamax  = la_max[task];
        const int lamina = la_min[task];
        const int lbmax  = lb_max[task];
        const int lbin   = lb_min[task];
        const int lp     = lamax + lbmax;
        const int nlp    = lp + 1;

        const double rab0 = rab[3*task+0], rab1 = rab[3*task+1], rab2c = rab[3*task+2];
        const double ra0  = ra[3*task+0],  ra1  = ra[3*task+1],  ra2  = ra[3*task+2];

        const double rab2 = (rab0*rab0) + (rab1*rab1) + (rab2c*rab2c);
        const double f    = zbt / (zt + zbt);
        const double pre  = exp((-zt) * f * rab2);
        const double rp0  = ra0 + f*rab0;
        const double rp1  = ra1 + f*rab1;
        const double rp2  = ra2 + f*rab2c;
        const double zetp = zt + zbt;

        const double cv0 = ((dh_inv[0]*rp0) + (dh_inv[3]*rp1)) + (dh_inv[6]*rp2);
        const double cv1 = ((dh_inv[1]*rp0) + (dh_inv[4]*rp1)) + (dh_inv[7]*rp2);
        const double cv2 = ((dh_inv[2]*rp0) + (dh_inv[5]*rp1)) + (dh_inv[8]*rp2);
        const int c0 = (int)floor(cv0), c1 = (int)floor(cv1), c2 = (int)floor(cv2);
        double *hrow = hab + task*100;
        #pragma GCC ivdep
        for (int i = 0; i < 100; i += 4)
            _mm256_storeu_pd(hrow + i, _mm256_setzero_pd());

        const double drx = dh[0], dry = dh[4], drz = dh[8];
        int s0 = (int)(r0 / drx); if ((double)s0 * drx < r0) s0++;
        int s1 = (int)(r0 / dry); if ((double)s1 * dry < r0) s1++;
        int s2 = (int)(r0 / drz); if ((double)s2 * drz < r0) s2++;
        const int nrx = 2*s0+1, nry = 2*s1+1, nrz = 2*s2+1;

        double PX[25] = {0}, PY[25] = {0}, PZ[25] = {0};
        {
            double d[5], cur[5];
            for (int r = 0; r < nrx; r++) d[r] = (double)(c0 - s0 + r) * drx - rp0;
            for (int r = 0; r < nrx; r++) cur[r] = exp((-zetp) * d[r] * d[r]);
            for (int p = 0; p < nlp; p++) {
                for (int r = 0; r < nrx; r++) PX[p*5 + r] = cur[r];
                for (int r = 0; r < nrx; r++) cur[r] = cur[r] * d[r];
            }
        }
        {
            double d[5], cur[5];
            for (int r = 0; r < nry; r++) d[r] = (double)(c1 - s1 + r) * dry - rp1;
            for (int r = 0; r < nry; r++) cur[r] = exp((-zetp) * d[r] * d[r]);
            for (int p = 0; p < nlp; p++) {
                for (int r = 0; r < nry; r++) PY[p*5 + r] = cur[r];
                for (int r = 0; r < nry; r++) cur[r] = cur[r] * d[r];
            }
        }
        {
            double d[5], cur[5];
            for (int r = 0; r < nrz; r++) d[r] = (double)(c2 - s2 + r) * drz - rp2;
            for (int r = 0; r < nrz; r++) cur[r] = exp((-zetp) * d[r] * d[r]);
            for (int p = 0; p < nlp; p++) {
                for (int r = 0; r < nrz; r++) PZ[p*5 + r] = cur[r];
                for (int r = 0; r < nrz; r++) cur[r] = cur[r] * d[r];
            }
        }

        int kxm[5], kym[5], kzm[5];
        double dxv[5], dyv[5], dzv[5];
        int64_t gzb[5], gyb[5], gxb[5];
        {
            int g = (c0 - s0 - sh0) % ng0; if (g < 0) g += ng0;
            for (int r = 0; r < nrx; r++) {
                const int cont = c0 - s0 + r;
                kxm[r] = (g >= bw0 && g < nl0);
                dxv[r] = (double)cont * drx - rp0;
                gxb[r] = (int64_t)g;
                if (++g == ng0) g = 0;
            }
            g = (c1 - s1 - sh1) % ng1; if (g < 0) g += ng1;
            for (int r = 0; r < nry; r++) {
                const int cont = c1 - s1 + r;
                kym[r] = (g >= bw1 && g < nl1);
                dyv[r] = (double)cont * dry - rp1;
                gyb[r] = (int64_t)g * N;
                if (++g == ng1) g = 0;
            }
            g = (c2 - s2 - sh2) % ng2; if (g < 0) g += ng2;
            for (int r = 0; r < nrz; r++) {
                const int cont = c2 - s2 + r;
                kzm[r] = (g >= bw2 && g < nl2);
                dzv[r] = (double)cont * drz - rp2;
                gzb[r] = (int64_t)g * NN;
                if (++g == ng2) g = 0;
            }
        }

        double W[5][5][5];
        const double r2 = r0 * r0;
        for (int kz = 0; kz < nrz; kz++) {
            const double dza = dzv[kz]*dzv[kz];
            for (int kj = 0; kj < nry; kj++) {
                const double zy = dza + dyv[kj]*dyv[kj];
                const int64_t base = gzb[kz] + gyb[kj];
                for (int ki = 0; ki < nrx; ki++) {
                    const double o = zy + dxv[ki]*dxv[ki];
                    W[kz][kj][ki] = (kzm[kz] & kym[kj] & kxm[ki] & (o <= r2)) ? grid[base + gxb[ki]] : 0.0;
                }
            }
        }

        double C[5][5][5];
        if (nrx == 5) {
            /* C[z][y][x] = sum_{kz,kj} PZ[z][kz]*PY[y][kj]*D[kz][kj][x],
               D[kz][kj][x] = dot_i W[kz][kj][i] * PX[x][i]  (x degree, i rel) */
            double D[5][5][5];
            /* column i of PX over degrees 0..3 (lanes = degree) */
            const __m256d px0 = _mm256_set_pd(PX[15], PX[10], PX[5], PX[0]);
            const __m256d px1 = _mm256_set_pd(PX[16], PX[11], PX[6], PX[1]);
            const __m256d px2 = _mm256_set_pd(PX[17], PX[12], PX[7], PX[2]);
            const __m256d px3 = _mm256_set_pd(PX[18], PX[13], PX[8], PX[3]);
            const __m256d px4 = _mm256_set_pd(PX[19], PX[14], PX[9], PX[4]);
            for (int kz = 0; kz < nrz; kz++) {
                for (int kj = 0; kj < nry; kj++) {
                    const double *w = &W[kz][kj][0];
                    __m256d d = _mm256_fmadd_pd(_mm256_set1_pd(w[0]), px0, _mm256_setzero_pd());
                    d = _mm256_fmadd_pd(_mm256_set1_pd(w[1]), px1, d);
                    d = _mm256_fmadd_pd(_mm256_set1_pd(w[2]), px2, d);
                    d = _mm256_fmadd_pd(_mm256_set1_pd(w[3]), px3, d);
                    d = _mm256_fmadd_pd(_mm256_set1_pd(w[4]), px4, d);
                    _mm256_storeu_pd(&D[kz][kj][0], d);
                    if (nlp == 5)
                        D[kz][kj][4] = (((w[0]*PX[20] + w[1]*PX[21]) + (w[2]*PX[22] + w[3]*PX[23])) + w[4]*PX[24]);
                }
            }
            for (int z = 0; z < nlp; z++) {
                for (int y = 0; y < nlp; y++) {
                    __m256d c = _mm256_setzero_pd();
                    double cs = 0.0;
                    for (int kz = 0; kz < nrz; kz++) {
                        for (int kj = 0; kj < nry; kj++) {
                            const double m = PZ[z*5+kz] * PY[y*5+kj];
                            c = _mm256_fmadd_pd(_mm256_set1_pd(m), _mm256_loadu_pd(&D[kz][kj][0]), c);
                            if (nlp == 5) cs += m * D[kz][kj][4];
                        }
                    }
                    _mm256_storeu_pd(&C[z][y][0], c);
                    if (nlp == 5) C[z][y][4] = cs;
                }
            }
        } else {
            for (int z = 0; z < nlp; z++)
            for (int y = 0; y < nlp; y++)
            for (int x = 0; x < nlp; x++) {
                double acc = 0.0;
                for (int kz = 0; kz < nrz; kz++)
                for (int kj = 0; kj < nry; kj++) {
                    const double m = PZ[z*5+kz] * PY[y*5+kj];
                    for (int ki = 0; ki < nrx; ki++)
                        acc += W[kz][kj][ki] * m * PX[x*5+ki];
                }
                C[z][y][x] = acc;
            }
        }

        double alphaX[45], alphaY[45], alphaZ[45];
        memset(alphaX, 0, sizeof alphaX);
        memset(alphaY, 0, sizeof alphaY);
        memset(alphaZ, 0, sizeof alphaZ);
        {
            const double dpa[3] = { rp0 - ra0, rp1 - ra1, rp2 - ra2 };
            const double dpb[3] = { rp0 - (ra0 + rab0), rp1 - (ra1 + rab1), rp2 - (ra2 + rab2c) };
            static const double RR[3][3] = {{0.0, 0.0, 0.0}, {1.0, 0.0, 0.0}, {2.0, 0.5, 0.0}};
            for (int idir = 0; idir < 3; idir++) {
                double *A = idir == 0 ? alphaX : (idir == 1 ? alphaY : alphaZ);
                const double a = dpa[idir], b = dpb[idir];
                for (int lxa = 0; lxa <= lamax; lxa++) {
                    for (int lxb = 0; lxb <= lbmax; lxb++) {
                        double bk = 1.0, ap = 1.0;
                        for (int k = 0; k <= lxa; k++) {
                            double bl = 1.0, bp = 1.0;
                            for (int l = 0; l <= lxb; l++) {
                                const int ls = (lxa - l) + lxb - k;
                                A[lxb*15 + lxa*5 + ls] += (bk * bl) * ap * bp;
                                bl = bl * RR[lxb][l];
                                bp = bp * b;
                            }
                            bk = bk * RR[lxa][k];
                            ap = ap * a;
                        }
                    }
                }
            }
        }

        int a_lx[10], a_ly[10], a_lz[10], a_ico[10], n_a = 0;
        for (int t = lamina; t <= lamax; t++)
            for (int x = 0; x <= t; x++)
                for (int y = 0; y <= t - x; y++) {
                    a_lx[n_a] = x; a_ly[n_a] = y; a_lz[n_a] = t - x - y;
                    a_ico[n_a] = t*(t+1)*(t+2)/6 + (t-x)*(t-x+1)/2 + (t - x - y);
                    n_a++;
                }
        int b_lx[10], b_ly[10], b_lz[10], b_ico[10], n_b = 0;
        for (int t = lbin; t <= lbmax; t++)
            for (int x = 0; x <= t; x++)
                for (int y = 0; y <= t - x; y++) {
                    b_lx[n_b] = x; b_ly[n_b] = y; b_lz[n_b] = t - x - y;
                    b_ico[n_b] = t*(t+1)*(t+2)/6 + (t-x)*(t-x+1)/2 + (t - x - y);
                    n_b++;
                }

        for (int ia = 0; ia < n_a; ia++) {
            for (int ib = 0; ib < n_b; ib++) {
                const int s = a_lz[ia] + b_lz[ib];
                double acc = 0.0;
                const double *ax = &alphaX[b_lx[ib]*15 + a_lx[ia]*5];
                const double *ay = &alphaY[b_ly[ib]*15 + a_ly[ia]*5];
                const double *az = &alphaZ[b_lz[ib]*15 + a_lz[ia]*5];
                for (int z = 0; z <= s; z++) {
                    const double a2 = az[z];
                    if (a2 == 0.0) continue;
                    for (int x = 0; x < nlp; x++) {
                        const double a0 = ax[x];
                        if (a0 == 0.0) continue;
                        const int ym = lp - s - x;
                        for (int y = 0; y <= ym && y < nlp; y++) {
                            const double a1 = ay[y];
                            if (a1 != 0.0)
                                acc += C[z][y][x] * (a0 * a1) * a2;
                        }
                    }
                }
                hrow[b_ico[ib]*10 + a_ico[ia]] = pre * acc;
            }
        }
    }
}
