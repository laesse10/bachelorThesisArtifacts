/* minife: nsteps implicit backward-Euler diffusion steps, each one a CG solve of
 * A x_{n+1} = x_n (or input b for the first step), where A = I + a weighted graph
 * Laplacian of a structured 3D grid (27-point stencil, unit row sums, CSR layout).
 *
 * The algorithm follows the reference exactly (same operations, same per-row
 * accumulation order, same CG stopping rule). Speedups come from:
 *  - no per-iteration allocation (the reference mallocs/frees scratch per matvec),
 *  - OpenMP parallelism: every row's output depends only on its own row's slots,
 *    so the matvec (and all elementwise kernels) is partitioned without any
 *    cross-thread addition; dot products use a fixed chunk split with an ordered
 *    combine, so results are reproducible for any thread count,
 *  - structure-aware matvec: cols[] is verified once to be the standard
 *    27-neighbor pattern; on the interior rows the column indices are then
 *    implicit (row + fixed offset) and 8 consecutive rows of a grid line are
 *    processed with one 216-slot stream and independent accumulator chains, so
 *    the 8-byte-per-nnz cols array is never read in the hot path. If the
 *    structure differs, a plain CSR matvec is used instead.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define MINIFE_MAX_ITER 100
#define MINIFE_TOL 1.0e-10

static void *mk_malloc(size_t n) {
    void *p = malloc(n ? n : 1);
    if (!p) { fprintf(stderr, "minife: out of memory\n"); exit(1); }
    return p;
}

/* Verify cols[] is exactly the structured 27-neighbor pattern for every row.
 * O(nnz) reads of cols once; on success the hot matvec never needs cols again. */
static int check_structure(const int64_t *restrict cols, const int64_t *restrict ro,
                           int64_t nrows, int64_t nx1, int64_t ny1, int64_t nz1,
                           int64_t plane) {
    int ok = 1;
    #pragma omp parallel for schedule(static) reduction(&:ok)
    for (int64_t r = 0; r < nrows; r++) {
        int64_t iz = r / plane, rem = r - iz * plane;
        int64_t iy = rem / nx1, ix = rem - iy * nx1;
        int64_t k = 0;
        int row_ok = 1;
        for (int64_t dz = -1; dz <= 1 && row_ok; dz++) {
            int64_t z = iz + dz; if (z < 0 || z >= nz1) continue;
            for (int64_t dy = -1; dy <= 1 && row_ok; dy++) {
                int64_t y = iy + dy; if (y < 0 || y >= ny1) continue;
                for (int64_t dx = -1; dx <= 1 && row_ok; dx++) {
                    int64_t xx = ix + dx; if (xx < 0 || xx >= nx1) continue;
                    if (cols[ro[r] + k] != r + dz * plane + dy * nx1 + dx) row_ok = 0;
                    k++;
                }
            }
        }
        if (ro[r + 1] - ro[r] != k) row_ok = 0;
        ok &= row_ok;
    }
    return ok;
}

/* One row in the plain CSR form (reads cols). */
static void row_csr(const int64_t *restrict ro, const int64_t *restrict cols,
                    const double *restrict values, const double *restrict x,
                    double *restrict ap, int64_t r) {
    double s = 0.0;
    const double *vv = values + ro[r];
    const int64_t *cl = cols + ro[r];
    int64_t len = ro[r + 1] - ro[r];
    for (int64_t j = 0; j < len; j++) {
        double t = vv[j] * x[cl[j]];
        s += t;
    }
    ap[r] = s;
}

/* One interior row (all 27 neighbors present, slots in (dz,dy,dx) lex order):
 * columns are row + fixed offset, so cols[] is not read. */
static void row_intra(const int64_t *restrict ro, const double *restrict values,
                      const double *restrict x, double *restrict ap, int64_t r,
                      const int64_t OFF[27]) {
    const double *vv = values + ro[r];
    const double *xx = x + r;
    double s = 0.0;
    #pragma GCC unroll 27
    for (int d = 0; d < 27; d++) {
        double t = vv[d] * xx[OFF[d]];
        s += t;
    }
    ap[r] = s;
}

/* Eight consecutive interior rows of one grid line: 216 consecutive values
 * slots, columns consecutive, independent accumulator chains per row. */
static void block8(const int64_t *restrict ro, const double *restrict values,
                   const double *restrict x, double *restrict ap, int64_t rb,
                   const int64_t OFF[27]) {
    const double *vv = values + ro[rb];
    const double *xx = x + rb;
    double s0 = 0.0, s1 = 0.0, s2 = 0.0, s3 = 0.0;
    double s4 = 0.0, s5 = 0.0, s6 = 0.0, s7 = 0.0;
    #pragma GCC unroll 27
    for (int d = 0; d < 27; d++) {
        double t0 = vv[d] * xx[OFF[d]];
        double t1 = vv[27 + d] * xx[1 + OFF[d]];
        double t2 = vv[54 + d] * xx[2 + OFF[d]];
        double t3 = vv[81 + d] * xx[3 + OFF[d]];
        double t4 = vv[108 + d] * xx[4 + OFF[d]];
        double t5 = vv[135 + d] * xx[5 + OFF[d]];
        double t6 = vv[162 + d] * xx[6 + OFF[d]];
        double t7 = vv[189 + d] * xx[7 + OFF[d]];
        s0 += t0; s1 += t1; s2 += t2; s3 += t3;
        s4 += t4; s5 += t5; s6 += t6; s7 += t7;
    }
    ap[rb] = s0; ap[rb + 1] = s1; ap[rb + 2] = s2; ap[rb + 3] = s3;
    ap[rb + 4] = s4; ap[rb + 5] = s5; ap[rb + 6] = s6; ap[rb + 7] = s7;
}

/* The mat-vec body: one grid line (iz,iy) holds nx1 consecutive rows; on
 * interior lines the nx1-2 middle rows have all 27 neighbors and uniform slot
 * stride 27, so they run through block8/row_intra with implicit column offsets;
 * boundary lines and the two edge rows of interior lines use the plain CSR
 * form. Lines are handed to the threads by equal slot-weight (prefix sums over
 * the line slot counts, bisected per thread) so the load is balanced even
 * though boundary lines carry far fewer slots than interior ones. Must be
 * called from inside a parallel region. `line_pre` holds the exclusive
 * prefix of line slot counts (length nlines+1, line_pre[0] = 0). */
static void matvec_for(const int64_t *restrict ro, const int64_t *restrict cols,
                       const double *restrict values, const double *restrict x,
                       double *restrict ap, int64_t nx1, int64_t ny1, int64_t nz1,
                       int64_t plane, const int64_t OFF[27], int structured,
                       const int64_t *line_pre) {
    int64_t nlines = nz1 * ny1;
    int64_t tot = line_pre[nlines];
    int64_t lo = 0, hi = nlines;
    int tid = omp_get_thread_num(), nt = omp_get_num_threads();
    if (nt > 1) {
        /* first line index whose prefix exceeds tid*tot/nt, and same for tid+1 */
        int64_t target = (int64_t)tid * tot / nt;
        int64_t a = 0, b = nlines;
        while (a < b) { int64_t m = (a + b) >> 1; if (line_pre[m + 1] <= target) a = m + 1; else b = m; }
        lo = a;
        target = (int64_t)(tid + 1) * tot / nt;
        a = lo; b = nlines;
        while (a < b) { int64_t m = (a + b) >> 1; if (line_pre[m + 1] <= target) a = m + 1; else b = m; }
        hi = a;
    }
    for (int64_t li = lo; li < hi; li++) {
        int64_t iz = li / ny1, iy = li - (li / ny1) * ny1;
        int64_t base = iz * plane + iy * nx1;
        int interior = structured && iz >= 1 && iz <= nz1 - 2 && iy >= 1 && iy <= ny1 - 2;
        if (!interior) {
            for (int64_t ix = 0; ix < nx1; ix++)
                row_csr(ro, cols, values, x, ap, base + ix);
        } else {
            row_csr(ro, cols, values, x, ap, base);
            int64_t nfull = (nx1 - 2) >> 3;
            for (int64_t b = 0; b < nfull; b++)
                block8(ro, values, x, ap, base + 1 + 8 * b, OFF);
            for (int64_t r = base + 1 + 8 * nfull; r < base + nx1 - 1; r++)
                row_intra(ro, values, x, ap, r, OFF);
            row_csr(ro, cols, values, x, ap, base + nx1 - 1);
        }
    }
    /* Plain helper calls have no implicit barrier: sync the team so no thread
     * reads ap before every thread has finished writing its rows. */
    #pragma omp barrier
}

/* Chunked dot body: chunk c sums a[i]*b[i] over [c*sz, min(n, (c+1)*sz)) in
 * index order. Must be called from inside a parallel region. */
static void dot_for(const double *restrict a, const double *restrict b,
                    double *part, int64_t n, int64_t nch, int64_t sz) {
    #pragma omp for schedule(static)
    for (int64_t c = 0; c < nch; c++) {
        int64_t i0 = c * sz;
        int64_t e = i0 + sz;
        if (e > n) e = n;
        double t = 0.0;
        for (int64_t i = i0; i < e; i++) t += a[i] * b[i];
        part[c] = t;
    }
}

/* Combine chunk partials in chunk order. Runs redundantly on every thread of
 * the surrounding region (cheap: at most 64 adds) and yields the same value
 * everywhere. */
static double combine_part(const double *part, int64_t nch) {
    double s = 0.0;
    for (int64_t c = 0; c < nch; c++) s += part[c];
    return s;
}

void minife_fp64(double *restrict b,
                 const int64_t *restrict cols,
                 const int64_t *restrict row_offsets,
                 const double *restrict values,
                 double *restrict x,
                 const int64_t nsteps,
                 const int64_t nx,
                 const int64_t ny,
                 const int64_t nz,
                 uint8_t *restrict workspace,
                 const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    const int64_t nx1 = nx + 1, ny1 = ny + 1, nz1 = nz + 1;
    const int64_t plane = nx1 * ny1;
    const int64_t nrows = plane * nz1;

    double *p = (double *)mk_malloc((size_t)nrows * sizeof(double));
    double *ap = (double *)mk_malloc((size_t)nrows * sizeof(double));
    double *r = (double *)mk_malloc((size_t)nrows * sizeof(double));
    double *part = (double *)mk_malloc(64 * sizeof(double));

    int64_t OFF[27];
    {
        int d = 0;
        for (int64_t dz = -1; dz <= 1; dz++)
            for (int64_t dy = -1; dy <= 1; dy++)
                for (int64_t dx = -1; dx <= 1; dx++)
                    OFF[d++] = dz * plane + dy * nx1 + dx;
    }
    int structured = check_structure(cols, row_offsets, nrows, nx1, ny1, nz1, plane);

    int64_t dnch = (nrows + 32767) >> 15;
    if (dnch < 1) dnch = 1;
    if (dnch > 64) dnch = 64;
    int64_t dsz = (nrows + dnch - 1) / dnch;

    /* exclusive prefix of per-line slot counts, for slot-weighted matvec split */
    int64_t nlines = nz1 * ny1;
    int64_t *line_pre = (int64_t *)mk_malloc((size_t)(nlines + 1) * sizeof(int64_t));
    {
        int64_t acc = 0;
        line_pre[0] = 0;
        for (int64_t li = 0; li < nlines; li++) {
            int64_t base = (li / ny1) * plane + (li - (li / ny1) * ny1) * nx1;
            acc += row_offsets[base + nx1] - row_offsets[base];
            line_pre[li + 1] = acc;
        }
    }

    for (int64_t step = 0; step < nsteps; step++) {
        /* One team per step: prologue (p = x is implicit, ap = A x, r = b - ap,
         * rtrans = r.r) and the whole CG sweep live in one parallel region. */
        #pragma omp parallel
        {
            double rtrans, normr;
            matvec_for(row_offsets, cols, values, x, ap, nx1, ny1, nz1, plane, OFF, structured, line_pre);
            #pragma omp for schedule(static)
            for (int64_t i = 0; i < nrows; i++) r[i] = b[i] + (-1.0) * ap[i];
            dot_for(r, r, part, nrows, dnch, dsz);
            rtrans = combine_part(part, dnch);
            normr = sqrt(rtrans);
            for (int64_t k = 1; k <= MINIFE_MAX_ITER; k++) {
                if (normr <= MINIFE_TOL) break;
                if (k == 1) {
                    #pragma omp for schedule(static)
                    for (int64_t i = 0; i < nrows; i++) p[i] = r[i];
                } else {
                    dot_for(r, r, part, nrows, dnch, dsz);
                    double oldrtrans = rtrans;
                    rtrans = combine_part(part, dnch);
                    double beta = rtrans / oldrtrans;
                    #pragma omp for schedule(static)
                    for (int64_t i = 0; i < nrows; i++) p[i] = (beta * p[i]) + r[i];
                }
                normr = sqrt(rtrans);
                matvec_for(row_offsets, cols, values, p, ap, nx1, ny1, nz1, plane, OFF, structured, line_pre);
                dot_for(ap, p, part, nrows, dnch, dsz);
                double p_ap_dot = combine_part(part, dnch);
                if (p_ap_dot <= 0.0) break;
                double alpha = rtrans / p_ap_dot;
                #pragma omp for schedule(static)
                for (int64_t i = 0; i < nrows; i++) x[i] = x[i] + (alpha * p[i]);
                #pragma omp for schedule(static)
                for (int64_t i = 0; i < nrows; i++) r[i] = r[i] + ((-alpha) * ap[i]);
            }
            #pragma omp for schedule(static)
            for (int64_t i = 0; i < nrows; i++) b[i] = x[i];
        }
    }
    free(p);
    free(ap);
    free(r);
    free(part);
    free(line_pre);
}
