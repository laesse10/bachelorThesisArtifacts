/* BOUT++ high-beta reduced-MHD (peeling-ballooning) right-hand side, nsteps of
 * forward Euler.  Matches bout_elm_pb_numpy.py within rtol=1e-9.
 *
 * v1: scalar, OpenMP parallel over the (x,y) interior, z innermost.
 * The rhs of each point reads the z-neighbours of the old P, Psi, U, so the
 * evolving fields are ping-ponged between steps.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

static const double K_STEP = 1.0e-4;

void bout_elm_pb_fp64(
    const double *restrict B0,
    const double *restrict B0phi_ydown,
    const double *restrict B0phi_yup,
    const double *restrict G1,
    const double *restrict G3,
    const double *restrict J,
    const double *restrict J0,
    const double *restrict Jpar,
    const double *restrict Jpar_ydown,
    const double *restrict Jpar_yup,
    double *restrict P,
    const double *restrict P0,
    const double *restrict P_ydown,
    const double *restrict P_yup,
    double *restrict Psi,
    const double *restrict Psi_ydown,
    const double *restrict Psi_yup,
    double *restrict U,
    const double *restrict U_ydown,
    const double *restrict U_yup,
    const double *restrict d1_dx,
    double *restrict ddt_P,
    double *restrict ddt_Psi,
    double *restrict ddt_U,
    const double *restrict dx,
    const double *restrict dy,
    const double *restrict dz,
    const double *restrict eta,
    const double *restrict g11,
    const double *restrict g13,
    const double *restrict g33,
    const double *restrict g_12,
    const double *restrict g_22,
    const double *restrict g_23,
    const double *restrict phi,
    const double *restrict phi0,
    const double *restrict phi_ydown,
    const double *restrict phi_yup,
    const int64_t NX,
    const int64_t NY,
    const int64_t NZ,
    const double hyperresist,
    const int64_t nsteps,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    if (NX < 6 || NY < 6 || NZ < 2 || nsteps <= 0) return;

    const size_t npts = (size_t)NX * (size_t)NY * (size_t)NZ;
    double *oldP = P, *newP = (double *)malloc(npts * sizeof(double));
    double *oldPsi = Psi, *newPsi = (double *)malloc(npts * sizeof(double));
    double *oldU = U, *newU = (double *)malloc(npts * sizeof(double));
    /* guard cells are read as x/y neighbours of interior points, so both
     * ping-pong slots must start as full copies of the input */
    memcpy(newP, P, npts * sizeof(double));
    memcpy(newPsi, Psi, npts * sizeof(double));
    memcpy(newU, U, npts * sizeof(double));

    for (int64_t s = 0; s < nsteps; ++s) {
        const int last = (s == nsteps - 1);
#pragma omp parallel for collapse(2) schedule(static)
        for (int64_t j = 2; j < NY - 2; ++j)
            for (int64_t i = 2; i < NX - 2; ++i) {
                const int64_t ij = i * NY + j;

                const double dx_c = dx[ij];
                const double dy_c = dy[ij];
                const double dz_c = dz[ij];
                const double d1_dx_c = d1_dx[ij];
                const double J_c = J[ij];
                const double G1_c = G1[ij];
                const double G3_c = G3[ij];
                const double g11_c = g11[ij];
                const double g13_c = g13[ij];
                const double g33_c = g33[ij];
                const double g12_c = g_12[ij];
                const double g22_c = g_22[ij];
                const double g23_c = g_23[ij];
                const double B0_c = B0[ij];

                const double sqrt_g_22 = sqrt(g22_c);
                const double j_sqrt_g_22 = J_c * sqrt_g_22;
                const double b0_sq = B0_c * B0_c;
                const double bracket_denom = (12.0 * dx_c) * dz_c;

                const double phi0_c = phi0[ij];
                const double phi0_xp = phi0[(i + 1) * NY + j];
                const double phi0_xm = phi0[(i - 1) * NY + j];
                const double dphi0_x = phi0_xp - phi0_xm;
                const double dphi0_y = phi0[i * NY + (j + 1)] - phi0[i * NY + (j - 1)];

                const double dj0_x = J0[(i + 1) * NY + j] - J0[(i - 1) * NY + j];
                const double dj0_y = J0[i * NY + (j + 1)] - J0[i * NY + (j - 1)];
                const double dp0_x = P0[(i + 1) * NY + j] - P0[(i - 1) * NY + j];
                const double dp0_y = P0[i * NY + (j + 1)] - P0[i * NY + (j - 1)];

                const double dpdx0 = 0.5 * dphi0_x / dx_c;
                const double dpdy0 = 0.5 * dphi0_y / dy_c;
                const double vx0 = -g23_c * dpdy0;
                const double vy0 = g23_c * dpdx0;
                const double vz0 = g12_c * dpdy0 - g22_c * dpdx0;

                const int64_t base = ij * NZ;
                const int64_t basexm = (i - 1) * NY * NZ + j * NZ;
                const int64_t basexp = (i + 1) * NY * NZ + j * NZ;
                const int64_t baseym = i * NY * NZ + (j - 1) * NZ;
                const int64_t baseyp = i * NY * NZ + (j + 1) * NZ;
                double *npr = newP + base;
                double *nqr = newPsi + base;
                double *nur = newU + base;

                for (int64_t z = 0; z < NZ; ++z) {
                    const int64_t zp = (z + 1 == NZ) ? 0 : z + 1;
                    const int64_t zm = (z == 0) ? NZ - 1 : z - 1;

                    /* ddt_Psi */
                    const double psi_zp = oldPsi[base + zp];
                    const double psi_zm = oldPsi[base + zm];
                    const double grad_par_B0phi = 0.5 * (B0phi_yup[baseyp + z] - B0phi_ydown[baseym + z]) / dy_c / sqrt_g_22;
                    const double jpp = -dphi0_x * (psi_zp - psi_zm);
                    const double jpx = -psi_zp * dphi0_x + psi_zm * dphi0_x;
                    const double jxp = oldPsi[basexp + zp] * (phi0_c - phi0_xp)
                                     - oldPsi[basexm + zm] * (phi0_xm - phi0_c)
                                     - oldPsi[basexm + zp] * (phi0_c - phi0_xm)
                                     + oldPsi[basexp + zm] * (phi0_xp - phi0_c);
                    const double bracket = (jpp + jpx + jxp) / bracket_denom;

                    const double jpar_c = Jpar[base + z];
                    const double jpar_xp = Jpar[basexp + z];
                    const double jpar_xm = Jpar[basexm + z];
                    const double jpar_zp = Jpar[base + zp];
                    const double jpar_zm = Jpar[base + zm];
                    const double jpar_zpx = Jpar[basexp + zp] - Jpar[basexm + zp];
                    const double jpar_zmx = Jpar[basexp + zm] - Jpar[basexm + zm];
                    const double delp2_jpar = (G1_c + d1_dx_c * g11_c) * (jpar_xp - jpar_xm) / (2.0 * dx_c)
                                             + G3_c * (jpar_zp - jpar_zm) / (2.0 * dz_c)
                                             + g11_c * (jpar_xp - 2.0 * jpar_c + jpar_xm) / (dx_c * dx_c)
                                             + g33_c * (jpar_zp - 2.0 * jpar_c + jpar_zm) / (dz_c * dz_c)
                                             + 2.0 * g13_c * (jpar_zpx - jpar_zmx) / (4.0 * dz_c * dx_c);
                    const double eta_c = eta[base + z];
                    const double ddt_Psi_v = -grad_par_B0phi / B0_c
                                           + eta_c * jpar_c
                                           - bracket * B0_c
                                           - eta_c * hyperresist * delp2_jpar;

                    /* ddt_U */
                    const double dpdx_psi = 0.5 * (oldPsi[basexp + z] - oldPsi[basexm + z]) / dx_c;
                    const double dpdy_psi = 0.5 * (Psi_yup[baseyp + z] - Psi_ydown[baseym + z]) / dy_c;
                    const double dpdz_psi = 0.5 * (psi_zp - psi_zm) / dz_c;
                    const double vx_psi = g22_c * dpdz_psi - g23_c * dpdy_psi;
                    const double vy_psi = g23_c * dpdx_psi - g12_c * dpdz_psi;
                    const double b0x_psi_j0 = (vx_psi * dj0_x / (2.0 * dx_c) + vy_psi * dj0_y / (2.0 * dy_c)) / j_sqrt_g_22;
                    const double grad_par_jpar = 0.5 * (Jpar_yup[baseyp + z] - Jpar_ydown[baseym + z]) / dy_c / sqrt_g_22;
                    const double b0x_phi0_u = (vx0 * (oldU[basexp + z] - oldU[basexm + z]) / (2.0 * dx_c)
                                              + vy0 * (U_yup[baseyp + z] - U_ydown[baseym + z]) / (2.0 * dy_c)
                                              + vz0 * (oldU[base + zp] - oldU[base + zm]) / (2.0 * dz_c)) / j_sqrt_g_22;
                    const double ddt_U_v = b0_sq * b0x_psi_j0 - b0_sq * grad_par_jpar - b0x_phi0_u;

                    /* ddt_P */
                    const double dpdx_phi = 0.5 * (phi[basexp + z] - phi[basexm + z]) / dx_c;
                    const double dpdy_phi = 0.5 * (phi_yup[baseyp + z] - phi_ydown[baseym + z]) / dy_c;
                    const double dpdz_phi = 0.5 * (phi[base + zp] - phi[base + zm]) / dz_c;
                    const double vx_phi = g22_c * dpdz_phi - g23_c * dpdy_phi;
                    const double vy_phi = g23_c * dpdx_phi - g12_c * dpdz_phi;
                    const double b0x_phi_p0 = (vx_phi * dp0_x / (2.0 * dx_c) + vy_phi * dp0_y / (2.0 * dy_c)) / j_sqrt_g_22;
                    const double b0x_phi0_p = (vx0 * (oldP[basexp + z] - oldP[basexm + z]) / (2.0 * dx_c)
                                             + vy0 * (P_yup[baseyp + z] - P_ydown[baseym + z]) / (2.0 * dy_c)
                                             + vz0 * (oldP[base + zp] - oldP[base + zm]) / (2.0 * dz_c)) / j_sqrt_g_22;
                    const double ddt_P_v = -b0x_phi_p0 - b0x_phi0_p;

                    nqr[z] = oldPsi[base + z] + K_STEP * ddt_Psi_v;
                    nur[z] = oldU[base + z] + K_STEP * ddt_U_v;
                    npr[z] = oldP[base + z] + K_STEP * ddt_P_v;
                    if (last) {
                        ddt_Psi[base + z] = ddt_Psi_v;
                        ddt_U[base + z] = ddt_U_v;
                        ddt_P[base + z] = ddt_P_v;
                    }
                }
            }
        if (s != nsteps - 1) {
            double *t;
            t = oldP; oldP = newP; newP = t;
            t = oldPsi; oldPsi = newPsi; newPsi = t;
            t = oldU; oldU = newU; newU = t;
        }
    }
    /* the last step's result is in newP/newPsi/newU */
    if (newP != P) {
        memcpy(P, newP, npts * sizeof(double));
        memcpy(Psi, newPsi, npts * sizeof(double));
        memcpy(U, newU, npts * sizeof(double));
    }
    free(newP);
    free(newPsi);
    free(newU);
}
