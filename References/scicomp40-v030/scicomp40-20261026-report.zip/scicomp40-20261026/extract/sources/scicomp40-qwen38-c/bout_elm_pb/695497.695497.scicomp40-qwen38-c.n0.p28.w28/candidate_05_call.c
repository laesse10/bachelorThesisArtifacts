// bout_elm_pb_fp64 -- BOUT++ high-beta ELM peeling-ballooning RHS, nsteps of forward Euler.
// v2: AVX2 4-wide z-vectorization, per-(i,j) precomputed coefficients (reciprocal multiplies),
//     ping-pong double buffering of P/Psi/U, fused in-place update, ddt_* written only on last step.
// The bracket corner sum uses the algebraically identical factored form
//   c1*(Psi_xp[zp]-Psi_xp[zm]) + c3*(Psi_xm[zm]-Psi_xm[zp])   (c1=phi0_c-phi0_xp, c3=phi0_c-phi0_xm)
// and jpp+jpx == -(2*dphi0_x)*(psi_zp-psi_zm) exactly, so results match the reference to rounding.
#define _GNU_SOURCE
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

static const double K_STEP = 1.0e-4;

typedef struct {
    double cD, c1, c3, brinv;
    double id2dx, id2dy, id2dz;
    double cG1, cG3, cg11, cg33, cg13;
    double cgpb, cgj, b0, b0sq, HR;
    double cx1, cy1, cu1, cu2, cu3, ch1, ch2;
    double ga, gb, gc, gd;
} Coef;

// scalar point, z with wrap-aware neighbors (zp, zm)
static inline void pt(
    const Coef *k,
    const double *psic, const double *psixp, const double *psixm, const double *psyu, const double *psyd,
    const double *jpc,  const double *jxp,  const double *jxm,  const double *jyu,  const double *jyd,
    const double *uc,   const double *uxp,  const double *uxm,  const double *uyu,  const double *uyd,
    const double *pc,   const double *pxp,  const double *pxm,  const double *pyu,  const double *pyd,
    const double *fc,   const double *fxp,  const double *fxm,  const double *fyu,  const double *fyd,
    const double *byu,  const double *byd,  const double *eta,
    double *npr, double *nqr, double *nur,
    double *ddtP, double *ddtPsi, double *ddtU,
    int64_t z, int64_t zp, int64_t zm)
{
    const double psi_zp = psic[zp], psi_zm = psic[zm];
    const double dzpsi = psi_zp - psi_zm;
    const double dypsi = psyu[z] - psyd[z];
    const double dxpsi = psixp[z] - psixm[z];

    const double jppjpx = -k->cD * dzpsi;
    const double jxpt = psixp[zp]*k->c1 - psixm[zp]*k->c3 + psixm[zm]*k->c3 - psixp[zm]*k->c1;
    const double bracket = (jppjpx + jxpt) * k->brinv;

    const double jpar_c = jpc[z];
    const double dxx = jxp[z] - jxm[z];
    const double dzj = jpc[zp] - jpc[zm];
    const double lapx = jxp[z] - 2.0*jpar_c + jxm[z];
    const double lapz = jpc[zp] - 2.0*jpar_c + jpc[zm];
    const double zpx = jxp[zp] - jxm[zp];
    const double zmx = jxp[zm] - jxm[zm];
    const double delp2 = k->cG1*dxx + k->cG3*dzj + k->cg11*lapx + k->cg33*lapz + k->cg13*(zpx - zmx);

    const double eta_c = eta[z];
    const double ddt_Psi = -(byu[z] - byd[z]) * k->cgpb + eta_c * jpar_c - bracket * k->b0 - (eta_c * k->HR) * delp2;

    const double vx_psi = k->ga*dzpsi - k->gb*dypsi;
    const double vy_psi = k->gc*dxpsi - k->gd*dzpsi;
    const double b0x_psi_j0 = vx_psi*k->cx1 + vy_psi*k->cy1;
    const double grad_par_jpar = (jyu[z] - jyd[z]) * k->cgj;
    const double b0x_phi0_u = (uxp[z]-uxm[z])*k->cu1 + (uyu[z]-uyd[z])*k->cu2 + (uc[zp]-uc[zm])*k->cu3;
    const double ddt_U = k->b0sq*b0x_psi_j0 - k->b0sq*grad_par_jpar - b0x_phi0_u;

    const double dphi_x = fxp[z] - fxm[z];
    const double dphi_y = fyu[z] - fyd[z];
    const double dphi_z = fc[zp] - fc[zm];
    const double vx_phi = k->ga*dphi_z - k->gb*dphi_y;
    const double vy_phi = k->gc*dphi_x - k->gd*dphi_z;
    const double b0x_phi_p0 = vx_phi*k->ch1 + vy_phi*k->ch2;
    const double b0x_phi0_p = (pxp[z]-pxm[z])*k->cu1 + (pyu[z]-pyd[z])*k->cu2 + (pc[zp]-pc[zm])*k->cu3;
    const double ddt_P = -b0x_phi_p0 - b0x_phi0_p;

    nqr[z] = psic[z] + K_STEP*ddt_Psi;
    nur[z] = uc[z]   + K_STEP*ddt_U;
    npr[z] = pc[z]   + K_STEP*ddt_P;
    if (ddtP != NULL) { ddtP[z] = ddt_P; ddtPsi[z] = ddt_Psi; ddtU[z] = ddt_U; }
}

#define L256(p) _mm256_loadu_pd(p)
#define ST256(p, v) _mm256_storeu_pd((p), (v))
#define B1(x) _mm256_set1_pd(x)

// AVX2 4-wide block z0..z0+3 (z0-1 and z0+4 both valid: no wrap)
static inline void pt4(
    const Coef *k,
    const double *psic, const double *psixp, const double *psixm, const double *psyu, const double *psyd,
    const double *jpc,  const double *jxp,  const double *jxm,  const double *jyu,  const double *jyd,
    const double *uc,   const double *uxp,  const double *uxm,  const double *uyu,  const double *uyd,
    const double *pc,   const double *pxp,  const double *pxm,  const double *pyu,  const double *pyd,
    const double *fc,   const double *fxp,  const double *fxm,  const double *fyu,  const double *fyd,
    const double *byu,  const double *byd,  const double *eta,
    double *npr, double *nqr, double *nur,
    double *ddtP, double *ddtPsi, double *ddtU,
    int64_t z0)
{
    // phase A: psi diffs, bracket, bending velocity for U
    __m256d pszp  = L256(psic + z0 + 1);
    __m256d psmz  = L256(psic + z0 - 1);
    __m256d dzpsi = _mm256_sub_pd(pszp, psmz);
    __m256d dxpsi = _mm256_sub_pd(L256(psixp + z0), L256(psixm + z0));
    __m256d vx1   = _mm256_sub_pd(L256(psixp + z0 + 1), L256(psixp + z0 - 1));
    __m256d vx3   = _mm256_sub_pd(L256(psixm + z0 - 1), L256(psixm + z0 + 1));
    __m256d jppjpx = _mm256_mul_pd(B1(-k->cD), dzpsi);
    __m256d vjxp   = _mm256_fmadd_pd(B1(k->c1), vx1, _mm256_mul_pd(B1(k->c3), vx3));
    __m256d bracket = _mm256_mul_pd(_mm256_add_pd(jppjpx, vjxp), B1(k->brinv));
    __m256d dypsi = _mm256_sub_pd(L256(psyu + z0), L256(psyd + z0));
    __m256d vxpsi = _mm256_fmsub_pd(B1(k->ga), dzpsi, _mm256_mul_pd(B1(k->gb), dypsi));
    __m256d vypsi = _mm256_fmsub_pd(B1(k->gc), dxpsi, _mm256_mul_pd(B1(k->gd), dzpsi));
    __m256d b0xpsi = _mm256_fmadd_pd(B1(k->cx1), vxpsi, _mm256_mul_pd(B1(k->cy1), vypsi));

    // phase B: Jpar laplacian + ddt_Psi
    __m256d jc   = L256(jpc + z0);
    __m256d veta = L256(eta + z0);
    __m256d jxpz = L256(jxp + z0);
    __m256d jxmz = L256(jxm + z0);
    __m256d jczp = L256(jpc + z0 + 1);
    __m256d jczm = L256(jpc + z0 - 1);
    __m256d dxx  = _mm256_sub_pd(jxpz, jxmz);
    __m256d dzj  = _mm256_sub_pd(jczp, jczm);
    __m256d twojc = _mm256_mul_pd(B1(2.0), jc);
    __m256d lapx = _mm256_add_pd(_mm256_sub_pd(jxpz, twojc), jxmz);
    __m256d lapz = _mm256_add_pd(_mm256_sub_pd(jczp, twojc), jczm);
    __m256d zpx  = _mm256_sub_pd(L256(jxp + z0 + 1), L256(jxm + z0 + 1));
    __m256d zmx  = _mm256_sub_pd(L256(jxp + z0 - 1), L256(jxm + z0 - 1));
    __m256d delp2 = _mm256_add_pd(
        _mm256_add_pd(
            _mm256_add_pd(_mm256_add_pd(_mm256_mul_pd(B1(k->cG1), dxx), _mm256_mul_pd(B1(k->cG3), dzj)),
                                       _mm256_mul_pd(B1(k->cg11), lapx)),
                       _mm256_mul_pd(B1(k->cg33), lapz)),
        _mm256_mul_pd(B1(k->cg13), _mm256_sub_pd(zpx, zmx)));
    __m256d gradpJ = _mm256_mul_pd(_mm256_sub_pd(L256(jyu + z0), L256(jyd + z0)), B1(k->cgj));
    __m256d t1 = _mm256_mul_pd(_mm256_sub_pd(L256(byu + z0), L256(byd + z0)), B1(-k->cgpb));
    __m256d t2 = _mm256_mul_pd(veta, jc);
    __m256d t3 = _mm256_mul_pd(bracket, B1(k->b0));
    __m256d t4 = _mm256_mul_pd(_mm256_mul_pd(veta, B1(k->HR)), delp2);
    __m256d vq = _mm256_sub_pd(_mm256_sub_pd(_mm256_add_pd(t1, t2), t3), t4);

    // phase C: U
    __m256d du1 = _mm256_sub_pd(L256(uxp + z0), L256(uxm + z0));
    __m256d du2 = _mm256_sub_pd(L256(uyu + z0), L256(uyd + z0));
    __m256d du3 = _mm256_sub_pd(L256(uc + z0 + 1), L256(uc + z0 - 1));
    __m256d b0xu = _mm256_add_pd(_mm256_add_pd(_mm256_mul_pd(B1(k->cu1), du1),
                                                  _mm256_mul_pd(B1(k->cu2), du2)),
                                              _mm256_mul_pd(B1(k->cu3), du3));
    __m256d vu = _mm256_sub_pd(_mm256_sub_pd(_mm256_mul_pd(B1(k->b0sq), b0xpsi),
                                               _mm256_mul_pd(B1(k->b0sq), gradpJ)), b0xu);

    // phase D: P
    __m256d dphx = _mm256_sub_pd(L256(fxp + z0), L256(fxm + z0));
    __m256d dphy = _mm256_sub_pd(L256(fyu + z0), L256(fyd + z0));
    __m256d dphz = _mm256_sub_pd(L256(fc + z0 + 1), L256(fc + z0 - 1));
    __m256d vxph = _mm256_fmsub_pd(B1(k->ga), dphz, _mm256_mul_pd(B1(k->gb), dphy));
    __m256d vyph = _mm256_fmsub_pd(B1(k->gc), dphx, _mm256_mul_pd(B1(k->gd), dphz));
    __m256d b0xph = _mm256_add_pd(_mm256_mul_pd(B1(k->ch1), vxph), _mm256_mul_pd(B1(k->ch2), vyph));
    __m256d dp1 = _mm256_sub_pd(L256(pxp + z0), L256(pxm + z0));
    __m256d dp2 = _mm256_sub_pd(L256(pyu + z0), L256(pyd + z0));
    __m256d dp3 = _mm256_sub_pd(L256(pc + z0 + 1), L256(pc + z0 - 1));
    __m256d b0x0p = _mm256_add_pd(_mm256_add_pd(_mm256_mul_pd(B1(k->cu1), dp1),
                                                    _mm256_mul_pd(B1(k->cu2), dp2)),
                                                _mm256_mul_pd(B1(k->cu3), dp3));
    __m256d vp = _mm256_sub_pd(_mm256_sub_pd(_mm256_setzero_pd(), b0xph), b0x0p);

    // phase E: updates
    ST256(nqr + z0, _mm256_fmadd_pd(B1(K_STEP), vq, L256(psic + z0)));
    ST256(nur + z0, _mm256_fmadd_pd(B1(K_STEP), vu, L256(uc + z0)));
    ST256(npr + z0, _mm256_fmadd_pd(B1(K_STEP), vp, L256(pc + z0)));
    if (ddtP != NULL) {
        ST256(ddtPsi + z0, vq);
        ST256(ddtU + z0, vu);
        ST256(ddtP + z0, vp);
    }
}

void bout_elm_pb_fp64(
    const double *B0, const double *B0phi_ydown, const double *B0phi_yup,
    const double *G1, const double *G3, const double *J, const double *J0,
    const double *Jpar, const double *Jpar_ydown, const double *Jpar_yup,
    double *P, const double *P0, const double *P_ydown, const double *P_yup,
    double *Psi, const double *Psi_ydown, const double *Psi_yup,
    double *U, const double *U_ydown, const double *U_yup,
    const double *d1_dx, double *ddt_P, double *ddt_Psi, double *ddt_U,
    const double *dx, const double *dy, const double *dz, const double *eta,
    const double *g11, const double *g13, const double *g33,
    const double *g_12, const double *g_22, const double *g_23,
    const double *phi, const double *phi0, const double *phi_ydown, const double *phi_yup,
    int64_t NX, int64_t NY, int64_t NZ,
    double hyperresist, int64_t nsteps,
    uint8_t *workspace, int64_t workspace_size)
{
    (void)workspace; (void)workspace_size;
    if (NX < 6 || NY < 6 || NZ < 2 || nsteps <= 0) return;
    const size_t npts = (size_t)NX * (size_t)NY * (size_t)NZ;
    double *oldP   = P,   *newP   = (double *)malloc(npts * sizeof(double));
    double *oldPsi = Psi, *newPsi = (double *)malloc(npts * sizeof(double));
    double *oldU   = U,   *newU   = (double *)malloc(npts * sizeof(double));
    memcpy(newP, P, npts * 8);
    memcpy(newPsi, Psi, npts * 8);
    memcpy(newU, U, npts * 8);

    const int64_t NYNZ = NY * NZ;

    for (int64_t s = 0; s < nsteps; ++s) {
        const int last = (s == nsteps - 1);
        #pragma omp parallel for collapse(2) schedule(static)
        for (int64_t j = 2; j < NY - 2; ++j)
        for (int64_t i = 2; i < NX - 2; ++i) {
            const int64_t ij = i * NY + j;
            Coef k;
            const double dx_c = dx[ij], dy_c = dy[ij], dz_c = dz[ij];
            const double id2dx = 0.5 / dx_c, id2dy = 0.5 / dy_c, id2dz = 0.5 / dz_c;
            const double g22_c = g_22[ij];
            const double invsqg22 = 1.0 / sqrt(g22_c);
            const double jinv = 1.0 / (J[ij] * sqrt(g22_c));
            const double phic = phi0[ij];
            const double phixp = phi0[(i + 1) * NY + j];
            const double phixm = phi0[(i - 1) * NY + j];
            const double dphix = phixp - phixm;
            k.cD = 2.0 * dphix;
            k.c1 = phic - phixp;
            k.c3 = phic - phixm;
            k.brinv = 1.0 / ((12.0 * dx_c) * dz_c);
            k.id2dx = id2dx; k.id2dy = id2dy; k.id2dz = id2dz;
            k.cG1 = (G1[ij] + d1_dx[ij] * g11[ij]) * id2dx;
            k.cG3 = G3[ij] * id2dz;
            k.cg11 = g11[ij] / (dx_c * dx_c);
            k.cg33 = g33[ij] / (dz_c * dz_c);
            k.cg13 = (2.0 * g13[ij]) / (4.0 * dz_c * dx_c);
            const double B0_c = B0[ij];
            k.cgpb = id2dy * invsqg22 * (1.0 / B0_c);
            k.cgj  = id2dy * invsqg22;
            k.b0 = B0_c;
            k.b0sq = B0_c * B0_c;
            k.HR = hyperresist;
            const double dj0x = J0[(i + 1) * NY + j] - J0[(i - 1) * NY + j];
            const double dj0y = J0[i * NY + (j + 1)] - J0[i * NY + (j - 1)];
            k.cx1 = dj0x * id2dx * jinv;
            k.cy1 = dj0y * id2dy * jinv;
            const double g23_c = g_23[ij], g12_c = g_12[ij];
            const double dphi0y = phi0[i * NY + (j + 1)] - phi0[i * NY + (j - 1)];
            const double dpdx0 = dphix * id2dx;
            const double dpdy0 = dphi0y * id2dy;
            const double vx0 = -g23_c * dpdy0;
            const double vy0 = g23_c * dpdx0;
            const double vz0 = g12_c * dpdy0 - g22_c * dpdx0;
            k.cu1 = vx0 * id2dx * jinv;
            k.cu2 = vy0 * id2dy * jinv;
            k.cu3 = vz0 * id2dz * jinv;
            const double dp0x = P0[(i + 1) * NY + j] - P0[(i - 1) * NY + j];
            const double dp0y = P0[i * NY + (j + 1)] - P0[i * NY + (j - 1)];
            k.ch1 = dp0x * id2dx * jinv;
            k.ch2 = dp0y * id2dy * jinv;
            k.ga = g22_c * id2dz;
            k.gb = g23_c * id2dy;
            k.gc = g23_c * id2dx;
            k.gd = g12_c * id2dz;

            const int64_t base   = ij * NZ;
            const int64_t basexm = (i - 1) * NYNZ + j * NZ;
            const int64_t basexp = (i + 1) * NYNZ + j * NZ;
            const int64_t baseym = i * NYNZ + (j - 1) * NZ;
            const int64_t baseyp = i * NYNZ + (j + 1) * NZ;

            const double *psic = oldPsi + base, *psixp = oldPsi + basexp, *psixm = oldPsi + basexm,
                         *psyu = Psi_yup + baseyp, *psyd = Psi_ydown + baseym;
            const double *jpc = Jpar + base, *jxp = Jpar + basexp, *jxm = Jpar + basexm,
                         *jyu = Jpar_yup + baseyp, *jyd = Jpar_ydown + baseym;
            const double *uc  = oldU + base, *uxp = oldU + basexp, *uxm = oldU + basexm,
                         *uyu = U_yup + baseyp, *uyd = U_ydown + baseym;
            const double *pc  = oldP + base, *pxp = oldP + basexp, *pxm = oldP + basexm,
                         *pyu = P_yup + baseyp, *pyd = P_ydown + baseym;
            const double *fc  = phi + base, *fxp = phi + basexp, *fxm = phi + basexm,
                         *fyu = phi_yup + baseyp, *fyd = phi_ydown + baseym;
            const double *byu = B0phi_yup + baseyp, *byd = B0phi_ydown + baseym;
            const double *et  = eta + base;
            double *npr = newP + base, *nqr = newPsi + base, *nur = newU + base;
            double *dP = last ? ddt_P + base : NULL;
            double *dQ = last ? ddt_Psi + base : NULL;
            double *dU = last ? ddt_U + base : NULL;

            pt(&k, psic, psixp, psixm, psyu, psyd, jpc, jxp, jxm, jyu, jyd,
               uc, uxp, uxm, uyu, uyd, pc, pxp, pxm, pyu, pyd,
               fc, fxp, fxm, fyu, fyd, byu, byd, et,
               npr, nqr, nur, dP, dQ, dU, 0, 1, NZ - 1);
            int64_t z0 = 1;
            for (; z0 + 3 <= NZ - 2; z0 += 4)
                pt4(&k, psic, psixp, psixm, psyu, psyd, jpc, jxp, jxm, jyu, jyd,
                    uc, uxp, uxm, uyu, uyd, pc, pxp, pxm, pyu, pyd,
                    fc, fxp, fxm, fyu, fyd, byu, byd, et,
                    npr, nqr, nur, dP, dQ, dU, z0);
            for (; z0 < NZ; ++z0)
                pt(&k, psic, psixp, psixm, psyu, psyd, jpc, jxp, jxm, jyu, jyd,
                   uc, uxp, uxm, uyu, uyd, pc, pxp, pxm, pyu, pyd,
                   fc, fxp, fxm, fyu, fyd, byu, byd, et,
                   npr, nqr, nur, dP, dQ, dU, z0, (z0 + 1 == NZ) ? 0 : z0 + 1, z0 - 1);
        }
        if (!last) {
            double *t = oldP; oldP = newP; newP = t;
            t = oldPsi; oldPsi = newPsi; newPsi = t;
            t = oldU; oldU = newU; newU = t;
        }
    }
    if (newP != P) {
        memcpy(P, newP, npts * 8);
        memcpy(Psi, newPsi, npts * 8);
        memcpy(U, newU, npts * 8);
    }
    free(newP); free(newPsi); free(newU);
}
