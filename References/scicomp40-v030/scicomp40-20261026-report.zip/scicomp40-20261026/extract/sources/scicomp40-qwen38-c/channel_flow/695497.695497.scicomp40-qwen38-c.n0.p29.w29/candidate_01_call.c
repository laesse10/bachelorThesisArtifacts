// channel_flow: 12-steps-to-Navier-Stokes channel flow time march.
// Optimized port of channel_flow_numpy.py (see signature.json for the ABI).
//
// Layout: all fields are row-major (ny rows x nx columns; x periodic,
// y walls at rows 0 and ny-1).  The expensive part is the `nit` Jacobi
// Poisson sweeps per outer iteration.  Instead of the reference's
// `pn = p; p = f(pn)` every sweep, we ping-pong two preallocated
// shadows (A, B) and write the final sweep straight into the user's
// p buffer.  The u/v update reads pre-copied un/vn fields; the old-u
// sum (needed for the convergence test) is computed for free in the
// b-build pass, the new-u sum while the update writes u.
#define _USE_MATH_DEFINES
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if !defined(NPB_NO_AVX512) && (defined(__AVX512F__) || defined(__AVX512BW__))
#define NPB_AVX512 1
#include <immintrin.h>
#endif

static inline double npb_fsum8(const double *r) {
#if defined(NPB_AVX512)
    __m512d v = _mm512_loadu_pd(r);
    __m256d s2 = _mm256_add_pd(_mm512_castpd512_pd256(v),
                               _mm512_extractf64x4_pd(v, 1));
    __m128d s1 = _mm_add_pd(_mm256_castpd256_pd128(s2),
                            _mm256_extractf128_pd(s2, 1));
    s1 = _mm_hadd_pd(s1, s1);
    return _mm_cvtsd_f64(_mm_unpacklo_pd(s1, s1));
#else
    return r[0] + r[1] + r[2] + r[3] + r[4] + r[5] + r[6] + r[7];
#endif
}

// Parallel copy of a whole grid.
static void npb_copy_rows(const double *s, double *d, int64_t nx, int64_t ny,
                          int64_t nthreads) {
    const int64_t per = (ny + nthreads - 1) / nthreads;
    for (int64_t tid = 0; tid < nthreads; ++tid) {
        int64_t r0 = per * tid;
        int64_t r1 = r0 + per;
        if (r0 >= ny)
            break;
        if (r1 > ny)
            r1 = ny;
        const double *rs = s + r0 * nx;
        double *rd = d + r0 * nx;
        for (int64_t i = r0; i < r1; ++i, rs += nx, rd += nx) {
            int64_t j = 0;
#if defined(NPB_AVX512)
            for (; j + 8 <= nx; j += 8)
                _mm512_storeu_pd(rd + j, _mm512_loadu_pd(rs + j));
#endif
            for (; j + 8 <= nx; j += 8)
                rd[j] = rs[j], rd[j+1] = rs[j+1], rd[j+2] = rs[j+2], rd[j+3] = rs[j+3],
                rd[j+4] = rs[j+4], rd[j+5] = rs[j+5], rd[j+6] = rs[j+6], rd[j+7] = rs[j+7];
            for (; j < nx; ++j)
                rd[j] = rs[j];
        }
    }
}


static inline void npb_rowcopy(double *d, const double *s, int64_t nx) {
#if defined(NPB_AVX512)
    int64_t j = 0;
    for (; j + 8 <= nx; j += 8)
        _mm512_storeu_pd(d + j, _mm512_loadu_pd(s + j));
    for (; j < nx; ++j)
        d[j] = s[j];
#else
    memcpy(d, s, (size_t)nx * sizeof(double));
#endif
}

// b = build_up_b(u, v) (rows 1..ny-2, all columns; x-periodic columns
// 0 and nx-1 use the wrapped neighbours).  Also accumulates the sum of
// the old u field over rows 1..ny-2 into *sum_u_old (rows 0 and ny-1 of
// u are the zero wall rows and contribute nothing).
static void npb_build_b(double *b, const double *u, const double *v,
                        double *sum_u_old, int64_t nx, int64_t ny,
                        double dt, double dx, double dy, double rho,
                        int64_t nthreads) {
    const double h2dx = 1.0 / (2.0 * dx);
    const double h2dy = 1.0 / (2.0 * dy);
    const double rdt = rho / dt;

    for (int64_t tid = 0; tid < nthreads; ++tid) {
        int64_t r0 = 1 + (ny - 3) / nthreads * tid;
        int64_t r1 = 1 + (ny - 3) / nthreads * (tid + 1);
        if (tid == nthreads - 1)
            r1 = ny - 1;
        double s = 0.0;
        for (int64_t i = r0; i < r1; ++i) {
            const double *uc = u + i * nx;
            const double *up = u + (i - 1) * nx;
            const double *un = u + (i + 1) * nx;
            const double *vc = v + i * nx;
            const double *vp = v + (i - 1) * nx;
            const double *vn = v + (i + 1) * nx;
            double *bc = b + i * nx;
            for (int64_t j = 1; j < nx - 1; ++j) {
                s += uc[j];
                double du = (uc[j + 1] - uc[j - 1]) * h2dx;
                double dv = (vn[j] - vp[j]) * h2dy;
                double duy = (un[j] - up[j]) * h2dy;
                double dvx = (vc[j + 1] - vc[j - 1]) * h2dx;
                double t = rdt * (du + dv);
                t = t - du * du;
                t = t - 2.0 * duy * dvx;
                t = t - dv * dv;
                bc[j] = t;
            }
            s += uc[0] + uc[nx - 1];
            // periodic column x = nx-1
            {
                double du = (uc[0] - uc[nx - 2]) * h2dx;
                double dv = (vn[nx - 1] - vp[nx - 1]) * h2dy;
                double duy = (un[nx - 1] - up[nx - 1]) * h2dy;
                double dvx = (vc[0] - vc[nx - 2]) * h2dx;
                double t = rdt * (du + dv);
                t = t - du * du;
                t = t - 2.0 * duy * dvx;
                t = t - dv * dv;
                bc[nx - 1] = t;
            }
            // periodic column x = 0
            {
                double du = (uc[1] - uc[nx - 1]) * h2dx;
                double dv = (vn[0] - vp[0]) * h2dy;
                double duy = (un[0] - up[0]) * h2dy;
                double dvx = (vc[1] - vc[nx - 1]) * h2dx;
                double t = rdt * (du + dv);
                t = t - du * du;
                t = t - 2.0 * duy * dvx;
                t = t - dv * dv;
                bc[0] = t;
            }
        }
        *sum_u_old += s;
    }
}

// One Jacobi sweep:  dst[r][c] = f(src, b).  `dst` is a shadow (or the
// user p buffer for the final sweep); `src` is the other one.
static void npb_poisson_sweep(double *dst, const double *src, const double *b,
                              int64_t nx, int64_t ny, double dx2, double dy2,
                              double recip_denom, double dxy2) {
    for (int64_t i = 1; i < ny - 1; ++i) {
        const double *sp = src + (i - 1) * nx;
        const double *sc = src + i * nx;
        const double *sn = src + (i + 1) * nx;
        double *dc = dst + i * nx;
        const double *bc = b + i * nx;
        for (int64_t j = 1; j < nx - 1; ++j) {
            dc[j] = ((sc[j + 1] + sc[j - 1]) * dy2 + (sn[j] + sp[j]) * dx2) * recip_denom
                    - dxy2 * bc[j];
        }
        dc[nx - 1] = ((sc[0] + sc[nx - 2]) * dy2 + (sn[nx - 1] + sp[nx - 1]) * dx2) * recip_denom
                     - dxy2 * bc[nx - 1];
        dc[0] = ((sc[1] + sc[nx - 1]) * dy2 + (sn[0] + sp[0]) * dx2) * recip_denom
                - dxy2 * bc[0];
    }
    // wall rows
    npb_rowcopy(dst + (ny - 1) * nx, dst + (ny - 2) * nx, nx);
    npb_rowcopy(dst, dst + nx, nx);
}

// Fused u/v update (interior + x-periodic columns) reading un/vn and
// the new pressure p; also accumulates the new u sum over rows
// 1..ny-2 (the wall rows are zero and are not included).
static void npb_update_uv(const double *un, const double *vn, const double *p,
                          double *u, double *v, double *sum_u_new,
                          int64_t nx, int64_t ny,
                          double dt, double dx, double dy, double nu,
                          double Fdt, double rho, int64_t nthreads) {
    const double adx = dt / dx;
    const double ady = dt / dy;
    const double phx = dt / (2.0 * rho * dx);
    const double phy = dt / (2.0 * rho * dy);
    const double ndx2 = nu * dt / (dx * dx);
    const double ndy2 = nu * dt / (dy * dy);

    for (int64_t tid = 0; tid < nthreads; ++tid) {
        int64_t r0 = 1 + (ny - 3) / nthreads * tid;
        int64_t r1 = 1 + (ny - 3) / nthreads * (tid + 1);
        if (tid == nthreads - 1)
            r1 = ny - 1;
        double s = 0.0;
        for (int64_t i = r0; i < r1; ++i) {
            const double *un_c = un + i * nx;
            const double *un_p = un + (i - 1) * nx;
            const double *un_n = un + (i + 1) * nx;
            const double *vn_c = vn + i * nx;
            const double *vn_p = vn + (i - 1) * nx;
            const double *vn_n = vn + (i + 1) * nx;
            double *uc = u + i * nx;
            double *vc = v + i * nx;
            const double *pp = p + (i - 1) * nx;
            const double *pc = p + i * nx;
            const double *pn = p + (i + 1) * nx;
            for (int64_t j = 1; j < nx - 1; ++j) {
                double un_cc = un_c[j];
                double t = (un_cc * adx) * (un_cc - un_c[j - 1]);
                double t2 = un_cc - t;
                t = (vn_c[j] * ady) * (un_cc - un_p[j]);
                t2 = t2 - t;
                t = phx * (pc[j + 1] - pc[j - 1]);
                t2 = t2 - t;
                t = ndx2 * ((un_c[j + 1] + un_c[j - 1]) - 2.0 * un_cc);
                t2 += t;
                t = ndy2 * ((un_n[j] + un_p[j]) - 2.0 * un_cc);
                t2 += t;
                t2 = t2 + Fdt;
                uc[j] = t2;
                s += t2;

                double vn_cc = vn_c[j];
                t = (un_cc * adx) * (vn_cc - vn_c[j - 1]);
                t2 = vn_cc - t;
                t = (vn_cc * ady) * (vn_cc - vn_p[j]);
                t2 = t2 - t;
                t = phy * (pn[j] - pp[j]);
                t2 = t2 - t;
                t = ndx2 * ((vn_c[j + 1] + vn_c[j - 1]) - 2.0 * vn_cc);
                t2 += t;
                t = ndy2 * ((vn_n[j] + vn_p[j]) - 2.0 * vn_cc);
                t2 += t;
                vc[j] = t2;
            }
            // periodic column x = nx-1
            {
                double un_cc = un_c[nx - 1];
                double t = (un_cc * adx) * (un_cc - un_c[nx - 2]);
                double t2 = un_cc - t;
                t = (vn_c[nx - 1] * ady) * (un_cc - un_p[nx - 1]);
                t2 = t2 - t;
                t = phx * (pc[0] - pc[nx - 2]);
                t2 = t2 - t;
                t = ndx2 * ((un_c[0] + un_c[nx - 2]) - 2.0 * un_cc);
                t2 += t;
                t = ndy2 * ((un_n[nx - 1] + un_p[nx - 1]) - 2.0 * un_cc);
                t2 += t;
                t2 = t2 + Fdt;
                uc[nx - 1] = t2;
                s += t2;

                double vn_cc = vn_c[nx - 1];
                t = (un_cc * adx) * (vn_cc - vn_c[nx - 2]);
                t2 = vn_cc - t;
                t = (vn_cc * ady) * (vn_cc - vn_p[nx - 1]);
                t2 = t2 - t;
                t = phy * (pn[nx - 1] - pp[nx - 1]);
                t2 = t2 - t;
                t = ndx2 * ((vn_c[0] + vn_c[nx - 2]) - 2.0 * vn_cc);
                t2 += t;
                t = ndy2 * ((vn_n[nx - 1] + vn_p[nx - 1]) - 2.0 * vn_cc);
                t2 += t;
                vc[nx - 1] = t2;
            }
            // periodic column x = 0
            {
                double un_cc = un_c[0];
                double t = (un_cc * adx) * (un_cc - un_c[nx - 1]);
                double t2 = un_cc - t;
                t = (vn_c[0] * ady) * (un_cc - un_p[0]);
                t2 = t2 - t;
                t = phx * (pc[1] - pc[nx - 1]);
                t2 = t2 - t;
                t = ndx2 * ((un_c[1] + un_c[nx - 1]) - 2.0 * un_cc);
                t2 += t;
                t = ndy2 * ((un_n[0] + un_p[0]) - 2.0 * un_cc);
                t2 += t;
                t2 = t2 + Fdt;
                uc[0] = t2;
                s += t2;

                double vn_cc = vn_c[0];
                t = (un_cc * adx) * (vn_cc - vn_c[nx - 1]);
                t2 = vn_cc - t;
                t = (vn_cc * ady) * (vn_cc - vn_p[0]);
                t2 = t2 - t;
                t = phy * (pn[0] - pp[0]);
                t2 = t2 - t;
                t = ndx2 * ((vn_c[1] + vn_c[nx - 1]) - 2.0 * vn_cc);
                t2 += t;
                t = ndy2 * ((vn_n[0] + vn_p[0]) - 2.0 * vn_cc);
                t2 += t;
                vc[0] = t2;
            }
        }
        *sum_u_new += s;
    }
    // wall rows: zero (they are zero on entry; nothing above writes them)
    for (int64_t j = 0; j < nx; ++j) {
        u[j] = 0.0;
        u[(ny - 1) * nx + j] = 0.0;
        v[j] = 0.0;
        v[(ny - 1) * nx + j] = 0.0;
    }
}

void channel_flow_fp64(
    double *restrict p,
    double *restrict u,
    double *restrict v,
    const double F,
    const double dt,
    const double dx,
    const double dy,
    const int64_t nit,
    const double nu,
    const int64_t nx,
    const int64_t ny,
    const double rho,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    const int64_t n = (int64_t)nx * (int64_t)ny;
    // b, un, vn, A, B: five full grids.
    const size_t total = (size_t)n * sizeof(double) * 5;
    int in_ws = 0;
    uint8_t *base;
    if (workspace != NULL && (size_t)workspace_size >= total + 63) {
        base = (uint8_t *)(((uintptr_t)workspace + 63) & ~(uintptr_t)63);
        in_ws = 1;
    } else {
        size_t asz = (total + 63) & ~(size_t)63;
        base = (uint8_t *)aligned_alloc(64, asz);
        if (base == NULL) {
            fprintf(stderr, "channel_flow: allocation failed\n");
            abort();
        }
    }
    double *b = (double *)(base + 0);
    double *un = (double *)(base + (size_t)n * 8);
    double *vn = (double *)(base + (size_t)n * 16);
    double *A = (double *)(base + (size_t)n * 24);
    double *B = (double *)(base + (size_t)n * 32);

    const double dx2 = dx * dx;
    const double dy2 = dy * dy;
    const double denom = 2.0 * (dx2 + dy2);
    const double recip_denom = 1.0 / denom;
    const double dxy2 = (dx2 * dy2) / denom;
    const double Fdt = F * dt;

    int64_t nthreads = omp_get_max_threads();
    if (nthreads < 1)
        nthreads = 1;

    // seed the ping-pong shadow with the current pressure
    npb_copy_rows(p, A, nx, ny, nthreads);

    double udiff = 1.0;
    while (udiff > 0.001) {
        double sum_u_old = 0.0;
        npb_build_b(b, u, v, &sum_u_old, nx, ny, dt, dx, dy, rho, nthreads);

        // nit Jacobi sweeps; the final one writes straight into p.
        double *src = A;
        for (int64_t k = 0; k < nit; ++k) {
            double *dst = (k == nit - 1) ? p : (src == A ? B : A);
            npb_poisson_sweep(dst, src, b, nx, ny, dx2, dy2, recip_denom, dxy2);
            src = dst;
        }
        // restore invariant: A holds the current pressure (p now holds it)
        npb_copy_rows(p, A, nx, ny, nthreads);

        npb_copy_rows(u, un, nx, ny, nthreads);
        npb_copy_rows(v, vn, nx, ny, nthreads);

        double sum_u_new = 0.0;
        npb_update_uv(un, vn, p, u, v, &sum_u_new, nx, ny,
                      dt, dx, dy, nu, Fdt, rho, nthreads);

        double sum_u = sum_u_new;
        udiff = (sum_u - sum_u_old) / sum_u;
    }

    if (!in_ws)
        free(base);
}
