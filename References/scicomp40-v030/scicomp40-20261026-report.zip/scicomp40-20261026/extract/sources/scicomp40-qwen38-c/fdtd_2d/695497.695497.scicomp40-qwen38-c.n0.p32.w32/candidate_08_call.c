#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

/*
 * FDTD 2D Yee-grid update, single fused pass per timestep.
 *
 * Rows 1..NX-1 are split into one contiguous block per thread.  Inside a
 * block, row i is processed as
 *   1. ey row i update   (reads hz rows i, i-1 -- still the old state)
 *   2. ex row i update   (reads hz row i -- old)
 *   3. hz row i-1 update (reads ex/ey rows i-1, i -- the fresh values,
 *                         which this thread just wrote and are L2-resident,
 *                         and hz row i-1 -- old)
 * so each row costs one DRAM read of hz(i), ex(i), ey(i) and one write of
 * hz(i-1), ex(i), ey(i): 6.0 doubles per cell per step instead of 12.0
 * for two full passes.  hz(i-1) is read for the ey difference one row
 * earlier and updated one row later, so it is served from L2 in between.
 *
 * The only cross-thread dependency: the hz row B-1 of a block [B..E] needs
 * the fresh ex/ey of row B-1 produced by the previous thread, so that one
 * row is deferred to the end of the block behind a release/acquire flag.
 * Expression trees are identical to the sequential reference.
 */
void fdtd_2d_fp64(double *restrict ex, double *restrict ey,
                  const double *restrict fict, double *restrict hz,
                  const int64_t NX, const int64_t NY, const int64_t TMAX,
                  const double ex_courant, const double ey_courant,
                  const double hz_courant,
                  uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace; (void)workspace_size;
    if (TMAX <= 0 || NX <= 0 || NY <= 0) return;

    static int64_t *flag = NULL;
    static int64_t flagcap = 0;
    if (NX > flagcap) {
        int64_t cap = NX < 1024 ? 1024 : NX;
        int64_t *nf = realloc(flag, (size_t)cap * sizeof(int64_t));
        if (!nf) {
            fprintf(stderr, "out of memory\n");
            abort();
        }
        flag = nf;
        flagcap = cap;
    }
    memset(flag, 0, (size_t)NX * sizeof(int64_t));

    const double c0 = ex_courant, c1 = ey_courant, c2 = hz_courant;

    for (int64_t t = 0; t < TMAX; ++t) {
        const double f = fict[t];
        const int64_t sid = t + 1;

        #pragma omp parallel
        {
            const int nt = omp_get_num_threads();
            const int tid = omp_get_thread_num();

            /* boundary conditions of row 0: set before the block work */
            if (tid == 0) {
                for (int64_t j = 0; j < NY; ++j) ey[j] = f;
                if (NY >= 2) {
                    double *ex0 = ex;
                    const double *hz0 = hz;
                    for (int64_t j = 1; j < NY; ++j)
                        ex0[j] -= c0 * (hz0[j] - hz0[j - 1]);
                }
                __atomic_store_n(&flag[0], sid, __ATOMIC_RELEASE);
            }

            const int64_t B = (NX - 1) * (int64_t)tid / (int64_t)nt + 1;
            const int64_t E = (NX - 1) * (int64_t)(tid + 1) / (int64_t)nt;

            if (B <= E) {
                for (int64_t i = B; i <= E; ++i) {
                    double *exi = ex + i * NY;
                    double *eyi = ey + i * NY;
                    const double *hzi = hz + i * NY;
                    double *hzm = hz + (i - 1) * NY;   /* old hz row i-1 */
                    eyi[0] -= c1 * (hzi[0] - hzm[0]);
                    for (int64_t j = 1; j < NY; ++j) {
                        eyi[j] -= c1 * (hzi[j] - hzm[j]);
                        exi[j] -= c0 * (hzi[j] - hzi[j - 1]);
                    }
                    if (i != B || tid == 0) {
                        const double *exm = ex + (i - 1) * NY;
                        const double *eym = ey + (i - 1) * NY;
                        for (int64_t j = 0; j < NY - 1; ++j) {
                            hzm[j] -= c2 * (((exm[j + 1] - exm[j]) + eyi[j]) - eym[j]);
                        }
                    }
                }
                if (tid > 0) {
                    /* deferred hz row B-1: needs fresh ex/ey row B-1 (prev thread) */
                    while (__atomic_load_n(&flag[B - 1], __ATOMIC_ACQUIRE) != sid)
                        _mm_pause();
                    const double *exm = ex + (B - 1) * NY;
                    const double *eym = ey + (B - 1) * NY;
                    double *hzm = hz + (B - 1) * NY;
                    const double *eyi = ey + B * NY;
                    for (int64_t j = 0; j < NY - 1; ++j) {
                        hzm[j] -= c2 * (((exm[j + 1] - exm[j]) + eyi[j]) - eym[j]);
                    }
                }
                __atomic_store_n(&flag[E], sid, __ATOMIC_RELEASE);
            }
        }
    }
}
