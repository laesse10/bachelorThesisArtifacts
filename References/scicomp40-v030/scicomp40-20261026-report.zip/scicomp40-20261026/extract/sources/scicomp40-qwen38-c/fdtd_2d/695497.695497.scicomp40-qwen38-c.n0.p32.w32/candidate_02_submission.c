#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

/*
 * FDTD 2D Yee-grid update.  Each timestep:
 *   ey[0,:]  = fict[t]
 *   ey[1:,:] -= ey_c * (hz[1:,:] - hz[:-1,:])
 *   ex[:,1:] -= ex_c * (hz[:,1:] - hz[:,:-1])
 *   hz[:-1,:-1] -= hz_c * ((ex[:-1,1:] - ex[:-1,:-1]) + ey[1:,:-1] - ey[:-1,:-1])
 *
 * Two passes per step:
 *   pass 1: ex/ey updates -- read hz only (the state of step t-1)
 *   pass 2: hz interior update -- read the freshly updated ex/ey
 * This mirrors the sequential reference exactly (same expression trees),
 * saving one reread of ex/ey versus three independent passes.
 */
void fdtd_2d_fp64(double *restrict ex, double *restrict ey,
                  const double *restrict fict, double *restrict hz,
                  const int64_t NX, const int64_t NY, const int64_t TMAX,
                  const double ex_courant, const double ey_courant,
                  const double hz_courant,
                  uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace; (void)workspace_size;
    if (TMAX <= 0 || NX <= 0 || NY <= 0) return;

    for (int64_t t = 0; t < TMAX; ++t) {
        const double f = fict[t];
        for (int64_t si1 = 0; si1 < NY; ++si1) ey[si1] = f;

        /* Pass 1: ex and ey updates; hz is only read in this pass. */
        #pragma omp parallel for schedule(static)
        for (int64_t si0 = 0; si0 < NX; ++si0) {
            double *exi = ex + si0 * NY;
            const double *hzn = hz + si0 * NY;
            if (si0 > 0) {
                double *eyi = ey + si0 * NY;
                const double *hzp = hz + (si0 - 1) * NY;
                eyi[0] -= (ey_courant * (hzn[0] - hzp[0]));
                for (int64_t si1 = 1; si1 < NY; ++si1) {
                    eyi[si1] -= (ey_courant * (hzn[si1] - hzp[si1]));
                    exi[si1] -= (ex_courant * (hzn[si1] - hzn[si1 - 1]));
                }
            } else {
                for (int64_t si1 = 1; si1 < NY; ++si1)
                    exi[si1] -= (ex_courant * (hzn[si1] - hzn[si1 - 1]));
            }
        }
        /* Pass 2: hz interior update from the freshly updated ex/ey. */
        #pragma omp parallel for schedule(static)
        for (int64_t si0 = 0; si0 < (NX - 1); ++si0) {
            double *exi = ex + si0 * NY;
            double *eyi = ey + si0 * NY;
            double *hzi = hz + si0 * NY;
            const double *eyn = eyi + NY;
            for (int64_t si1 = 0; si1 < (NY - 1); ++si1) {
                hzi[si1] -= (hz_courant * (((exi[si1 + 1] - exi[si1]) + eyn[si1]) - eyi[si1]));
            }
        }
    }
}
