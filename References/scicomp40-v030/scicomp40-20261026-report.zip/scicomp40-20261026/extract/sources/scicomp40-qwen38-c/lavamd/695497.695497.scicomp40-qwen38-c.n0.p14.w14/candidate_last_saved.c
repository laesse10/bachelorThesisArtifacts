// Optimized lavaMD force kernel (AVX-512, OpenMP).
//
// Semantics (identical to the reference):
//   for each box l:
//     i particles = home box particles [first_i, first_i + ppb)
//     j set       = home box ++ listed neighbor boxes (in list order), each ppb particles
//     r2  = w_i + w_j - (x_i x_j + y_i y_j + z_i z_j)
//     v   = exp(-2 alpha^2 r2)
//     fv[i,0] += sum_j q_j v
//     fv[i,k] += sum_j q_j (2v) (c_i - c_j),  k = 1..3
#include <stdint.h>
#include <stdlib.h>
#include <immintrin.h>
#include <omp.h>

// 8-wide double exp via x = k*ln2 + r reduction and degree-12 Taylor of e^r.
// k = rint(x/ln2) (banker's rounding, via double->int->double cvt) already
// guarantees |r| <= ln2/2 + O(1e-14) for all |x| < 1e3, and the Taylor below
// covers that range to ~1e-15 rel, so no range fixup is needed.
static inline __m512d vexp8(__m512d x) {
  const __m512d c1   = _mm512_set1_pd(1.44269504088896340736);  /* 1/ln2  */
  const __m512d ln2  = _mm512_set1_pd(0.69314718055994530942);
  const __m512d zero = _mm512_setzero_pd();
  __m256i ki = _mm512_cvtpd_epi32(_mm512_mul_pd(x, c1));  /* round to nearest, ties to even */
  __m512d k  = _mm512_cvtepi32_pd(ki);
  __m512d r  = _mm512_fnmadd_pd(k, ln2, x);               /* x - k*ln2 */
  __m512d p = _mm512_set1_pd(2.0876756987868141e-09);            /* 1/12! */
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(2.5052108385441720e-08));  /* 1/11! */
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(2.7557319223985893e-07));  /* 1/10! */
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(2.7557319223985893e-06));  /* 1/9!  */
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(2.4801587301587302e-05));  /* 1/8!  */
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(1.9841269841269841e-04));  /* 1/7!  */
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(1.3888888888888888e-03));  /* 1/6!  */
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(8.3333333333333331e-03));  /* 1/5!  */
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(4.1666666666666664e-02));  /* 1/4!  */
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(1.6666666666666666e-01));  /* 1/3!  */
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(0.5));
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(1.0));
  p = _mm512_fmadd_pd(p, r, _mm512_set1_pd(1.0));
  ki = _mm256_add_epi32(ki, _mm256_set1_epi32(1023));
  ki = _mm256_max_epi32(ki, _mm256_setzero_si256());
  ki = _mm256_min_epi32(ki, _mm256_set1_epi32(2047));
  __m512i e64 = _mm512_cvtepi32_epi64(ki);
  __m512d twok = _mm512_castsi512_pd(_mm512_slli_epi64(e64, 52));
  __m512d res = _mm512_mul_pd(p, twok);
  __mmask8 uf = _mm512_cmp_pd_mask(k, _mm512_set1_pd(-1023.0), _CMP_LT_OQ);
  return _mm512_mask_blend_pd(uf, res, zero);
}

void lavamd_fp64(const int32_t *restrict box_offsets, double *restrict fv,
                 const int32_t *restrict neighbor_counts,
                 const int32_t *restrict neighbor_list,
                 const double *restrict qv, const double *restrict rv,
                 const double alpha, const int64_t max_neighbors,
                 const int64_t n_boxes, const int64_t particles_per_box,
                 uint8_t *restrict workspace, const int64_t workspace_size) {
  (void)workspace;
  (void)workspace_size;
  if (n_boxes <= 0 || particles_per_box <= 0) return;
  const double a2 = (2.0 * alpha) * alpha;  /* matches reference: (2a)^2 = 4a^2 */
  const __m512d a2v = _mm512_set1_pd(a2);
  const __m512d zero = _mm512_setzero_pd();
  const int ppb = (int)particles_per_box;

#pragma omp parallel
  {
    const int nt = omp_get_num_threads();
    int64_t chunk = n_boxes / (nt * 128);
    if (chunk < 1) chunk = 1;
#pragma omp for schedule(dynamic, chunk)
    for (int64_t l = 0; l < n_boxes; ++l) {
      const int64_t first_i = box_offsets[l];
      const int cnt = (int)neighbor_counts[l];
      const int32_t *nl = neighbor_list + l * max_neighbors;
      const double *rvi = rv + first_i * 4;

      for (int i = 0; i < ppb; ++i) {
        const double *ri4 = rvi + i * 4;
        const __m512d wiv = _mm512_set1_pd(ri4[0]);
        const __m512d xiv = _mm512_set1_pd(ri4[1]);
        const __m512d yiv = _mm512_set1_pd(ri4[2]);
        const __m512d ziv = _mm512_set1_pd(ri4[3]);
        const __m512d twx = _mm512_add_pd(xiv, xiv);
        const __m512d twy = _mm512_add_pd(yiv, yiv);
        const __m512d twz = _mm512_add_pd(ziv, ziv);
        __m512d t0 = zero, t1 = zero, t2 = zero, t3 = zero;

        for (int m = 0; m <= cnt; ++m) {
          const int64_t jb = (m == 0) ? first_i : box_offsets[nl[m - 1]];
          const double *rj = rv + jb * 4;
          const double *qj = qv + jb;
          for (int jj0 = 0; jj0 < ppb; jj0 += 8) {
            const int rem = ppb - jj0;
            const __mmask8 ms = (rem >= 8) ? 0xFF : (__mmask8)((1u << rem) - 1u);
            /* rv is AoS: [w,x,y,z] per particle, so lane k of these 4
             * contiguous loads is component w/x/y/z of particle k. */
            const __m512d wj = _mm512_maskz_loadu_pd(ms, rj + jj0 * 4);
            const __m512d xj = _mm512_maskz_loadu_pd(ms, rj + jj0 * 4 + 1);
            const __m512d yj = _mm512_maskz_loadu_pd(ms, rj + jj0 * 4 + 2);
            const __m512d zj = _mm512_maskz_loadu_pd(ms, rj + jj0 * 4 + 3);
            const __m512d qv8 = _mm512_maskz_loadu_pd(ms, qj + jj0);

            __m512d r2 = _mm512_add_pd(wiv, wj);
            r2 = _mm512_fnmadd_pd(xj, xiv, r2);
            r2 = _mm512_fnmadd_pd(yj, yiv, r2);
            r2 = _mm512_fnmadd_pd(zj, ziv, r2);
            const __m512d e = vexp8(_mm512_fnmadd_pd(a2v, r2, zero));  /* -a2*r2 */
            const __m512d s = _mm512_mul_pd(qv8, e);
            const __m512d d2x = _mm512_sub_pd(twx, _mm512_add_pd(xj, xj));
            const __m512d d2y = _mm512_sub_pd(twy, _mm512_add_pd(yj, yj));
            const __m512d d2z = _mm512_sub_pd(twz, _mm512_add_pd(zj, zj));
            t0 = _mm512_add_pd(t0, s);
            t1 = _mm512_add_pd(t1, _mm512_mul_pd(s, d2x));
            t2 = _mm512_add_pd(t2, _mm512_mul_pd(s, d2y));
            t3 = _mm512_add_pd(t3, _mm512_mul_pd(s, d2z));
          }
        }

        double *fo = fv + first_i * 4 + i * 4;
        fo[0] += _mm512_reduce_add_pd(t0);
        fo[1] += _mm512_reduce_add_pd(t1);
        fo[2] += _mm512_reduce_add_pd(t2);
        fo[3] += _mm512_reduce_add_pd(t3);
      }
    }
  }
}
