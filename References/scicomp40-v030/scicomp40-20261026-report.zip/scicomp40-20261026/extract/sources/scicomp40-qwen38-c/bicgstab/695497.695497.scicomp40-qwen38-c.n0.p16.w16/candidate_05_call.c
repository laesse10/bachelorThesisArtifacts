/* Version A: no cache, parallel int64-idx SPMV only */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define BICGSTAB_MAX_ITER 250
#define BICGSTAB_RTOL 1.0e-06
#define BICGSTAB_ATOL 1.0e-12

static double  *w_p = NULL, *w_v = NULL, *w_s = NULL, *w_t = NULL, *w_r = NULL, *w_rt = NULL;
static int64_t  w_cap = 0;

static double dot64(const double *restrict a, const double *restrict b, const int64_t N) {
    double s = 0.0;
    #pragma omp parallel for reduction(+:s) schedule(static)
    for (int64_t j = 0; j < N; j++) s += a[j] * b[j];
    return s;
}

static double nrm64(const double *restrict a, const int64_t N) {
    double s = 0.0;
    #pragma omp parallel for reduction(+:s) schedule(static)
    for (int64_t j = 0; j < N; j++) s += a[j] * a[j];
    return sqrt(s);
}

void bicgstab_csr_fp64(const double *restrict A_data, const int64_t *restrict A_indices,
                       const int64_t *restrict A_indptr, const double *restrict b,
                       double *restrict x, const int64_t N, const int64_t nnz,
                       uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace; (void)workspace_size; (void)nnz;
    if (N <= 0) return;
    if (N > w_cap) {
        double *np = malloc((size_t)N*8), *nv = malloc((size_t)N*8), *ns = malloc((size_t)N*8),
               *nt2 = malloc((size_t)N*8), *nr = malloc((size_t)N*8), *nrt = malloc((size_t)N*8);
        if (!np||!nv||!ns||!nt2||!nr||!nrt) abort();
        free(w_p);free(w_v);free(w_s);free(w_t);free(w_r);free(w_rt);
        w_p=np;w_v=nv;w_s=ns;w_t=nt2;w_r=nr;w_rt=nrt;w_cap=N;
    }
    double *p=w_p,*v=w_v,*s=w_s,*t=w_t,*r=w_r,*rt=w_rt;
    const double stop = BICGSTAB_ATOL + BICGSTAB_RTOL * nrm64(b, N);
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < N; i++) {
        double acc = 0.0;
        for (int64_t k = A_indptr[i]; k < A_indptr[i+1]; k++) acc += A_data[k] * x[A_indices[k]];
        r[i] = b[i] - acc;
    }
    memcpy(rt, r, (size_t)N*8);
    memset(p, 0, (size_t)N*8);
    memset(v, 0, (size_t)N*8);
    double rho_prev = 1.0, alpha = 1.0, omega = 1.0;
    for (int it = 0; it < BICGSTAB_MAX_ITER; it++) {
        const double rho = dot64(rt, r, N);
        const double beta = (rho / rho_prev) * (alpha / omega);
        #pragma omp parallel for schedule(static)
        for (int64_t j = 0; j < N; j++) p[j] = (r[j] + (beta * (p[j] - (omega * v[j]))));
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < N; i++) {
            double acc = 0.0;
            for (int64_t k = A_indptr[i]; k < A_indptr[i+1]; k++) acc += A_data[k] * p[A_indices[k]];
            v[i] = acc;
        }
        const double rtv = dot64(rt, v, N);
        alpha = rho / rtv;
        #pragma omp parallel for schedule(static)
        for (int64_t j = 0; j < N; j++) s[j] = (r[j] - (alpha * v[j]));
        #pragma omp parallel for schedule(static)
        for (int64_t i = 0; i < N; i++) {
            double acc = 0.0;
            for (int64_t k = A_indptr[i]; k < A_indptr[i+1]; k++) acc += A_data[k] * s[A_indices[k]];
            t[i] = acc;
        }
        double ts = 0.0, tt = 0.0;
        #pragma omp parallel for reduction(+:ts,tt) schedule(static)
        for (int64_t j = 0; j < N; j++) { ts += t[j]*s[j]; tt += t[j]*t[j]; }
        omega = ts / tt;
        #pragma omp parallel for schedule(static)
        for (int64_t j = 0; j < N; j++) {
            x[j] += ((alpha * p[j]) + (omega * s[j]));
            r[j] = (s[j] - (omega * t[j]));
        }
        if (nrm64(r, N) < stop) break;
        rho_prev = rho;
    }
}