/* SeisSol ADER-DG volume contraction:
 *   Q[b,k,p] += sum_{d,l,q} kDivM[d,k,l] * I[b,l,q] * star[d,q,p]
 * nb = 84, nQ = 9 (fixed). kDivM and star are sparse (real SeisSol patterns);
 * the nonzero pattern is detected at entry (zero factors are skipped exactly:
 * for finite operands a zero product is exactly +/-0.0 and adds nothing).
 *
 * Two-stage contraction per batch element:
 *   T[d][l][p] = sum_q I[b,l,q] * star[d,q][p]           (84x9 per d)
 *   Q[b,k][p] += sum_{(k,l) live in kDivM[d]} c * T[d][l][p]
 * T rows are padded to 128B (16 doubles) and the array is 64B-aligned so the
 * 8-wide (p=0..7) parts are aligned 512-bit memory ops; p=8 rides along as a
 * scalar lane. Stage 2 uses 10 independent accumulators so the two 512-bit
 * FMA pipes stay throughput-bound, and the Q row is loaded into the first
 * accumulator so no final Q-add is needed.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

#define NB 84
#define NQ 9
#define TROWS 16                 /* padded T row length (doubles) */
#define TSTRIDE (NB * TROWS)

#define A9(u) \
    double u##_0 = 0.0, u##_1 = 0.0, u##_2 = 0.0, u##_3 = 0.0, \
         u##_4 = 0.0, u##_5 = 0.0, u##_6 = 0.0, u##_7 = 0.0, u##_8 = 0.0

#define FM8(u, v, s) \
    u##_0 = fma(v, (s)[0], u##_0); \
    u##_1 = fma(v, (s)[1], u##_1); \
    u##_2 = fma(v, (s)[2], u##_2); \
    u##_3 = fma(v, (s)[3], u##_3); \
    u##_4 = fma(v, (s)[4], u##_4); \
    u##_5 = fma(v, (s)[5], u##_5); \
    u##_6 = fma(v, (s)[6], u##_6); \
    u##_7 = fma(v, (s)[7], u##_7)

#define STEP(i, n) \
    do { \
        const double *tj = (const double *)T + flatoff[k][(n)]; \
        double cj = flatc[k][(n)]; \
        a##i = _mm512_fmadd_pd(_mm512_set1_pd(cj), _mm512_load_pd(tj), a##i); \
        b##i = fma(cj, tj[8], b##i); \
    } while (0)



static int rowcnt[3][NB];
static int rowidx[3][NB][NB];
static double rowcoef[3][NB][NB];
static int flatcnt[NB];
static uint8_t flatl[NB][3 * NB];
static uint8_t flatd[NB][3 * NB];
static double flatc[NB][3 * NB];
static int32_t flatoff[NB][3 * NB]; /* (l*84 + d) * TROWS in bytes */
static double Srow8[3][NQ][8];
static double Ss8[3][NQ];
static uint8_t q8list[3][NQ];
static int q8cnt[3];
static int q8live[3][NQ];        /* q has any nonzero in p = 0..7 */

void seissol_tensor_contraction_fp64(
    const double *restrict I, double *restrict Q,
    const double *restrict kDivM, const double *restrict star,
    const int64_t batch, uint8_t *restrict workspace, const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    if (batch <= 0) return;

    /* ---- phase 0: detect sparse structure (serial, ~21k elements) ---- */
    for (int d = 0; d < 3; d++) {
        q8cnt[d] = 0;
        for (int q = 0; q < NQ; q++) {
            const double *sp = star + (size_t)d * NQ * NQ + (size_t)q * NQ;
            int live = 0;
            for (int p = 0; p < 8; p++) {
                Srow8[d][q][p] = sp[p];
                live |= (sp[p] != 0.0);
            }
            q8live[d][q] = live;
            Ss8[d][q] = sp[NQ - 1];
            if (Ss8[d][q] != 0.0) q8list[d][q8cnt[d]++] = (uint8_t)q;
        }
    }
    for (int d = 0; d < 3; d++) {
        const double *kd = kDivM + (size_t)d * NB * NB;
        for (int k = 0; k < NB; k++) {
            const double *rm = kd + (size_t)k * NB;
            int cnt = 0;
            for (int l = 0; l < NB; l++) {
                double v = rm[l];
                if (v != 0.0) {
                    rowidx[d][k][cnt] = l;
                    rowcoef[d][k][cnt] = v;
                    cnt++;
                }
            }
            rowcnt[d][k] = cnt;
        }
    }
    for (int k = 0; k < NB; k++) {
        int n = 0;
        for (int d = 0; d < 3; d++) {
            for (int i = 0; i < rowcnt[d][k]; i++) {
                flatd[k][n] = (uint8_t)d;
                flatl[k][n] = (uint8_t)rowidx[d][k][i];
                flatc[k][n] = rowcoef[d][k][i];
                flatoff[k][n] = (int32_t)((d * NB + rowidx[d][k][i]) * TROWS);
                n++;
            }
        }
        flatcnt[k] = n;
    }

    #pragma omp parallel for schedule(static)
    for (int64_t b = 0; b < batch; b++) {
        const double *restrict Ib = I + (size_t)b * (NB * NQ);
        double *restrict Qb = Q + (size_t)b * (NB * NQ);
        double T[3][NB][TROWS] __attribute__((aligned(64)));

        /* prefetch the next batch element's I/Q streams */
        {
            const double *ni = Ib + 756;
            double *nq = Qb + 756;
            for (int j = 0; j < 16; j++) {
                __builtin_prefetch(ni + j * 8, 0, 1);
                __builtin_prefetch(nq + j * 8, 1, 1);
            }
        }

        /* ---- stage 1: T[d][l][p] = sum_q Ib[l][q] * star[d][q][p] ----
         * q outermost: the (d,u) = 12 partial-sum chains are independent. */
        for (int lb = 0; lb < NB; lb += 4) {
            A9(t00); A9(t01); A9(t02); A9(t03);
            A9(t10); A9(t11); A9(t12); A9(t13);
            A9(t20); A9(t21); A9(t22); A9(t23);
            for (int q = 0; q < NQ - 1; q++) {
                double v0 = Ib[(lb + 0) * NQ + q];
                double v1 = Ib[(lb + 1) * NQ + q];
                double v2 = Ib[(lb + 2) * NQ + q];
                double v3 = Ib[(lb + 3) * NQ + q];
                if (q8live[0][q]) {
                    const double *sr = Srow8[0][q];
                    FM8(t00, v0, sr); FM8(t01, v1, sr); FM8(t02, v2, sr); FM8(t03, v3, sr);
                }
                if (q8live[1][q]) {
                    const double *sr = Srow8[1][q];
                    FM8(t10, v0, sr); FM8(t11, v1, sr); FM8(t12, v2, sr); FM8(t13, v3, sr);
                }
                if (q8live[2][q]) {
                    const double *sr = Srow8[2][q];
                    FM8(t20, v0, sr); FM8(t21, v1, sr); FM8(t22, v2, sr); FM8(t23, v3, sr);
                }
            }
            {
                double v0 = Ib[(lb + 0) * NQ + NQ - 1];
                double v1 = Ib[(lb + 1) * NQ + NQ - 1];
                double v2 = Ib[(lb + 2) * NQ + NQ - 1];
                double v3 = Ib[(lb + 3) * NQ + NQ - 1];
                if (q8live[0][NQ - 1]) {
                    const double *sr = Srow8[0][NQ - 1];
                    FM8(t00, v0, sr); FM8(t01, v1, sr); FM8(t02, v2, sr); FM8(t03, v3, sr);
                }
                if (q8live[1][NQ - 1]) {
                    const double *sr = Srow8[1][NQ - 1];
                    FM8(t10, v0, sr); FM8(t11, v1, sr); FM8(t12, v2, sr); FM8(t13, v3, sr);
                }
                if (q8live[2][NQ - 1]) {
                    const double *sr = Srow8[2][NQ - 1];
                    FM8(t20, v0, sr); FM8(t21, v1, sr); FM8(t22, v2, sr); FM8(t23, v3, sr);
                }
            }
            for (int qi = 0; qi < q8cnt[0]; qi++) {
                int q = q8list[0][qi];
                double s = Ss8[0][q];
                t00_8 = fma(Ib[(lb + 0) * NQ + q], s, t00_8);
                t01_8 = fma(Ib[(lb + 1) * NQ + q], s, t01_8);
                t02_8 = fma(Ib[(lb + 2) * NQ + q], s, t02_8);
                t03_8 = fma(Ib[(lb + 3) * NQ + q], s, t03_8);
            }
            for (int qi = 0; qi < q8cnt[1]; qi++) {
                int q = q8list[1][qi];
                double s = Ss8[1][q];
                t10_8 = fma(Ib[(lb + 0) * NQ + q], s, t10_8);
                t11_8 = fma(Ib[(lb + 1) * NQ + q], s, t11_8);
                t12_8 = fma(Ib[(lb + 2) * NQ + q], s, t12_8);
                t13_8 = fma(Ib[(lb + 3) * NQ + q], s, t13_8);
            }
            for (int qi = 0; qi < q8cnt[2]; qi++) {
                int q = q8list[2][qi];
                double s = Ss8[2][q];
                t20_8 = fma(Ib[(lb + 0) * NQ + q], s, t20_8);
                t21_8 = fma(Ib[(lb + 1) * NQ + q], s, t21_8);
                t22_8 = fma(Ib[(lb + 2) * NQ + q], s, t22_8);
                t23_8 = fma(Ib[(lb + 3) * NQ + q], s, t23_8);
            }
            T[0][lb + 0][0] = t00_0; T[0][lb + 0][1] = t00_1; T[0][lb + 0][2] = t00_2;
            T[0][lb + 0][3] = t00_3; T[0][lb + 0][4] = t00_4; T[0][lb + 0][5] = t00_5;
            T[0][lb + 0][6] = t00_6; T[0][lb + 0][7] = t00_7; T[0][lb + 0][8] = t00_8;
            T[0][lb + 1][0] = t01_0; T[0][lb + 1][1] = t01_1; T[0][lb + 1][2] = t01_2;
            T[0][lb + 1][3] = t01_3; T[0][lb + 1][4] = t01_4; T[0][lb + 1][5] = t01_5;
            T[0][lb + 1][6] = t01_6; T[0][lb + 1][7] = t01_7; T[0][lb + 1][8] = t01_8;
            T[0][lb + 2][0] = t02_0; T[0][lb + 2][1] = t02_1; T[0][lb + 2][2] = t02_2;
            T[0][lb + 2][3] = t02_3; T[0][lb + 2][4] = t02_4; T[0][lb + 2][5] = t02_5;
            T[0][lb + 2][6] = t02_6; T[0][lb + 2][7] = t02_7; T[0][lb + 2][8] = t02_8;
            T[0][lb + 3][0] = t03_0; T[0][lb + 3][1] = t03_1; T[0][lb + 3][2] = t03_2;
            T[0][lb + 3][3] = t03_3; T[0][lb + 3][4] = t03_4; T[0][lb + 3][5] = t03_5;
            T[0][lb + 3][6] = t03_6; T[0][lb + 3][7] = t03_7; T[0][lb + 3][8] = t03_8;
            T[1][lb + 0][0] = t10_0; T[1][lb + 0][1] = t10_1; T[1][lb + 0][2] = t10_2;
            T[1][lb + 0][3] = t10_3; T[1][lb + 0][4] = t10_4; T[1][lb + 0][5] = t10_5;
            T[1][lb + 0][6] = t10_6; T[1][lb + 0][7] = t10_7; T[1][lb + 0][8] = t10_8;
            T[1][lb + 1][0] = t11_0; T[1][lb + 1][1] = t11_1; T[1][lb + 1][2] = t11_2;
            T[1][lb + 1][3] = t11_3; T[1][lb + 1][4] = t11_4; T[1][lb + 1][5] = t11_5;
            T[1][lb + 1][6] = t11_6; T[1][lb + 1][7] = t11_7; T[1][lb + 1][8] = t11_8;
            T[1][lb + 2][0] = t12_0; T[1][lb + 2][1] = t12_1; T[1][lb + 2][2] = t12_2;
            T[1][lb + 2][3] = t12_3; T[1][lb + 2][4] = t12_4; T[1][lb + 2][5] = t12_5;
            T[1][lb + 2][6] = t12_6; T[1][lb + 2][7] = t12_7; T[1][lb + 2][8] = t12_8;
            T[1][lb + 3][0] = t13_0; T[1][lb + 3][1] = t13_1; T[1][lb + 3][2] = t13_2;
            T[1][lb + 3][3] = t13_3; T[1][lb + 3][4] = t13_4; T[1][lb + 3][5] = t13_5;
            T[1][lb + 3][6] = t13_6; T[1][lb + 3][7] = t13_7; T[1][lb + 3][8] = t13_8;
            T[2][lb + 0][0] = t20_0; T[2][lb + 0][1] = t20_1; T[2][lb + 0][2] = t20_2;
            T[2][lb + 0][3] = t20_3; T[2][lb + 0][4] = t20_4; T[2][lb + 0][5] = t20_5;
            T[2][lb + 0][6] = t20_6; T[2][lb + 0][7] = t20_7; T[2][lb + 0][8] = t20_8;
            T[2][lb + 1][0] = t21_0; T[2][lb + 1][1] = t21_1; T[2][lb + 1][2] = t21_2;
            T[2][lb + 1][3] = t21_3; T[2][lb + 1][4] = t21_4; T[2][lb + 1][5] = t21_5;
            T[2][lb + 1][6] = t21_6; T[2][lb + 1][7] = t21_7; T[2][lb + 1][8] = t21_8;
            T[2][lb + 2][0] = t22_0; T[2][lb + 2][1] = t22_1; T[2][lb + 2][2] = t22_2;
            T[2][lb + 2][3] = t22_3; T[2][lb + 2][4] = t22_4; T[2][lb + 2][5] = t22_5;
            T[2][lb + 2][6] = t22_6; T[2][lb + 2][7] = t22_7; T[2][lb + 2][8] = t22_8;
            T[2][lb + 3][0] = t23_0; T[2][lb + 3][1] = t23_1; T[2][lb + 3][2] = t23_2;
            T[2][lb + 3][3] = t23_3; T[2][lb + 3][4] = t23_4; T[2][lb + 3][5] = t23_5;
            T[2][lb + 3][6] = t23_6; T[2][lb + 3][7] = t23_7; T[2][lb + 3][8] = t23_8;
        }

        /* ---- stage 2: Qb[k][p] += sum_{(d,l) live} c * T[d][l][p] ----
         * 10 independent accumulators (intrinsic form: no scalar-setup
         * shuffles); a0/b0 seeded from the Q row. */
        for (int k = 0; k < NB; k++) {
            size_t qb = (size_t)k * NQ;
            __m512d a0, a1, a2, a3, a4, a5, a6, a7, a8, a9;
            double b0, b1, b2, b3, b4, b5, b6, b7, b8, b9;
            a0 = _mm512_loadu_pd(Qb + qb);
            b0 = Qb[qb + 8];
            a1 = _mm512_setzero_pd(); b1 = 0.0;
            a2 = _mm512_setzero_pd(); b2 = 0.0;
            a3 = _mm512_setzero_pd(); b3 = 0.0;
            a4 = _mm512_setzero_pd(); b4 = 0.0;
            a5 = _mm512_setzero_pd(); b5 = 0.0;
            a6 = _mm512_setzero_pd(); b6 = 0.0;
            a7 = _mm512_setzero_pd(); b7 = 0.0;
            a8 = _mm512_setzero_pd(); b8 = 0.0;
            a9 = _mm512_setzero_pd(); b9 = 0.0;
            const int cnt = flatcnt[k];
            int n = 0;
            for (; n + 10 <= cnt; n += 10) {
                STEP(0, n + 0);
                STEP(1, n + 1);
                STEP(2, n + 2);
                STEP(3, n + 3);
                STEP(4, n + 4);
                STEP(5, n + 5);
                STEP(6, n + 6);
                STEP(7, n + 7);
                STEP(8, n + 8);
                STEP(9, n + 9);
            }
            for (; n < cnt; n++) STEP(0, n);
            __m512d s01 = _mm512_add_pd(a0, a1);
            __m512d s23 = _mm512_add_pd(a2, a3);
            __m512d s45 = _mm512_add_pd(a4, a5);
            __m512d s67 = _mm512_add_pd(a6, a7);
            __m512d s89 = _mm512_add_pd(a8, a9);
            __m512d u01 = _mm512_add_pd(s01, s23);
            __m512d u23 = _mm512_add_pd(s45, s67);
            __m512d f0123 = _mm512_add_pd(u01, u23);
            _mm512_storeu_pd(Qb + qb, _mm512_add_pd(f0123, s89));
            double t01 = b0 + b1, t23 = b2 + b3, t45 = b4 + b5;
            double t67 = b6 + b7, t89 = b8 + b9;
            double u0123 = (t01 + t23) + (t45 + t67);
            Qb[qb + 8] = u0123 + t89;
        }
    }
}
