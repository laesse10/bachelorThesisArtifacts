/* SeisSol ADER-DG volume contraction:
 *   Q[b,k,p] += sum_{d,l,q} kDivM[d,k,l] * I[b,l,q] * star[d,q,p]
 * nb = 84, nQ = 9 (fixed). kDivM and star are sparse (real SeisSol patterns);
 * the nonzero pattern is detected at entry (zero factors are skipped exactly:
 * for finite operands a zero product is exactly +/-0.0 and adds nothing).
 *
 * Two-stage contraction per batch element:
 *   T[d][l][p] = sum_q I[b,l,q] * star[d,q][p]           (84x9 per d)
 *   Q[b,k][p] += sum_{(k,l) live in kDivM[d]} c * T[d][l][p]
 * T rows are padded to 128B (16 doubles) and the array is 64B-aligned so the
 * 8-wide (p=0..7) parts are aligned 512-bit memory ops; p=8 rides along as a
 * scalar lane. Stage 2 uses 10 independent accumulators so the two 512-bit
 * FMA pipes stay throughput-bound, and the Q row is loaded into the first
 * accumulator so no final Q-add is needed.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define NB 84
#define NQ 9
#define TROWS 16                 /* padded T row length (doubles) */
#define TSTRIDE (NB * TROWS)

#define A9(u) \
    double u##_0 = 0.0, u##_1 = 0.0, u##_2 = 0.0, u##_3 = 0.0, \
         u##_4 = 0.0, u##_5 = 0.0, u##_6 = 0.0, u##_7 = 0.0, u##_8 = 0.0

#define FM8(u, v, s) \
    u##_0 = fma(v, (s)[0], u##_0); \
    u##_1 = fma(v, (s)[1], u##_1); \
    u##_2 = fma(v, (s)[2], u##_2); \
    u##_3 = fma(v, (s)[3], u##_3); \
    u##_4 = fma(v, (s)[4], u##_4); \
    u##_5 = fma(v, (s)[5], u##_5); \
    u##_6 = fma(v, (s)[6], u##_6); \
    u##_7 = fma(v, (s)[7], u##_7)

#define ITER9(U, n) \
    do { \
        const double *tj = (const double *)T + (size_t)flatd[k][(n)] * TSTRIDE + (size_t)flatl[k][(n)] * TROWS; \
        double cj = flatc[k][(n)]; \
        U##_0 = fma(cj, tj[0], U##_0); \
        U##_1 = fma(cj, tj[1], U##_1); \
        U##_2 = fma(cj, tj[2], U##_2); \
        U##_3 = fma(cj, tj[3], U##_3); \
        U##_4 = fma(cj, tj[4], U##_4); \
        U##_5 = fma(cj, tj[5], U##_5); \
        U##_6 = fma(cj, tj[6], U##_6); \
        U##_7 = fma(cj, tj[7], U##_7); \
        U##_8 = fma(cj, tj[8], U##_8); \
    } while (0)

#define COMB10(P) \
    (((f0_##P + f1_##P) + (f2_##P + f3_##P)) + \
     (((f4_##P + f5_##P) + (f6_##P + f7_##P)) + (f8_##P + f9_##P)))

static int rowcnt[3][NB];
static int rowidx[3][NB][NB];
static double rowcoef[3][NB][NB];
static int flatcnt[NB];
static uint8_t flatl[NB][3 * NB];
static uint8_t flatd[NB][3 * NB];
static double flatc[NB][3 * NB];
static double Srow8[3][NQ][8];
static double Ss8[3][NQ];
static uint8_t q8list[3][NQ];
static int q8cnt[3];
static int q8live[3][NQ];        /* q has any nonzero in p = 0..7 */

void seissol_tensor_contraction_fp64(
    const double *restrict I, double *restrict Q,
    const double *restrict kDivM, const double *restrict star,
    const int64_t batch, uint8_t *restrict workspace, const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    if (batch <= 0) return;

    /* ---- phase 0: detect sparse structure (serial, ~21k elements) ---- */
    for (int d = 0; d < 3; d++) {
        q8cnt[d] = 0;
        for (int q = 0; q < NQ; q++) {
            const double *sp = star + (size_t)d * NQ * NQ + (size_t)q * NQ;
            int live = 0;
            for (int p = 0; p < 8; p++) {
                Srow8[d][q][p] = sp[p];
                live |= (sp[p] != 0.0);
            }
            q8live[d][q] = live;
            Ss8[d][q] = sp[NQ - 1];
            if (Ss8[d][q] != 0.0) q8list[d][q8cnt[d]++] = (uint8_t)q;
        }
    }
    for (int d = 0; d < 3; d++) {
        const double *kd = kDivM + (size_t)d * NB * NB;
        for (int k = 0; k < NB; k++) {
            const double *rm = kd + (size_t)k * NB;
            int cnt = 0;
            for (int l = 0; l < NB; l++) {
                double v = rm[l];
                if (v != 0.0) {
                    rowidx[d][k][cnt] = l;
                    rowcoef[d][k][cnt] = v;
                    cnt++;
                }
            }
            rowcnt[d][k] = cnt;
        }
    }
    for (int k = 0; k < NB; k++) {
        int n = 0;
        for (int d = 0; d < 3; d++) {
            for (int i = 0; i < rowcnt[d][k]; i++) {
                flatd[k][n] = (uint8_t)d;
                flatl[k][n] = (uint8_t)rowidx[d][k][i];
                flatc[k][n] = rowcoef[d][k][i];
                n++;
            }
        }
        flatcnt[k] = n;
    }

    #pragma omp parallel for schedule(static)
    for (int64_t b = 0; b < batch; b++) {
        const double *restrict Ib = I + (size_t)b * (NB * NQ);
        double *restrict Qb = Q + (size_t)b * (NB * NQ);
        double T[3][NB][TROWS] __attribute__((aligned(64)));

        /* ---- stage 1: T[d][l][p] = sum_q Ib[l][q] * star[d][q][p] ----
         * q outermost: the (d,u) = 12 partial-sum chains are independent. */
        for (int lb = 0; lb < NB; lb += 4) {
            A9(t00); A9(t01); A9(t02); A9(t03);
            A9(t10); A9(t11); A9(t12); A9(t13);
            A9(t20); A9(t21); A9(t22); A9(t23);
            for (int q = 0; q < NQ - 1; q++) {
                double v0 = Ib[(lb + 0) * NQ + q];
                double v1 = Ib[(lb + 1) * NQ + q];
                double v2 = Ib[(lb + 2) * NQ + q];
                double v3 = Ib[(lb + 3) * NQ + q];
                if (q8live[0][q]) {
                    const double *sr = Srow8[0][q];
                    FM8(t00, v0, sr); FM8(t01, v1, sr); FM8(t02, v2, sr); FM8(t03, v3, sr);
                }
                if (q8live[1][q]) {
                    const double *sr = Srow8[1][q];
                    FM8(t10, v0, sr); FM8(t11, v1, sr); FM8(t12, v2, sr); FM8(t13, v3, sr);
                }
                if (q8live[2][q]) {
                    const double *sr = Srow8[2][q];
                    FM8(t20, v0, sr); FM8(t21, v1, sr); FM8(t22, v2, sr); FM8(t23, v3, sr);
                }
            }
            {
                double v0 = Ib[(lb + 0) * NQ + NQ - 1];
                double v1 = Ib[(lb + 1) * NQ + NQ - 1];
                double v2 = Ib[(lb + 2) * NQ + NQ - 1];
                double v3 = Ib[(lb + 3) * NQ + NQ - 1];
                if (q8live[0][NQ - 1]) {
                    const double *sr = Srow8[0][NQ - 1];
                    FM8(t00, v0, sr); FM8(t01, v1, sr); FM8(t02, v2, sr); FM8(t03, v3, sr);
                }
                if (q8live[1][NQ - 1]) {
                    const double *sr = Srow8[1][NQ - 1];
                    FM8(t10, v0, sr); FM8(t11, v1, sr); FM8(t12, v2, sr); FM8(t13, v3, sr);
                }
                if (q8live[2][NQ - 1]) {
                    const double *sr = Srow8[2][NQ - 1];
                    FM8(t20, v0, sr); FM8(t21, v1, sr); FM8(t22, v2, sr); FM8(t23, v3, sr);
                }
            }
            for (int qi = 0; qi < q8cnt[0]; qi++) {
                int q = q8list[0][qi];
                double s = Ss8[0][q];
                t00_8 = fma(Ib[(lb + 0) * NQ + q], s, t00_8);
                t01_8 = fma(Ib[(lb + 1) * NQ + q], s, t01_8);
                t02_8 = fma(Ib[(lb + 2) * NQ + q], s, t02_8);
                t03_8 = fma(Ib[(lb + 3) * NQ + q], s, t03_8);
            }
            for (int qi = 0; qi < q8cnt[1]; qi++) {
                int q = q8list[1][qi];
                double s = Ss8[1][q];
                t10_8 = fma(Ib[(lb + 0) * NQ + q], s, t10_8);
                t11_8 = fma(Ib[(lb + 1) * NQ + q], s, t11_8);
                t12_8 = fma(Ib[(lb + 2) * NQ + q], s, t12_8);
                t13_8 = fma(Ib[(lb + 3) * NQ + q], s, t13_8);
            }
            for (int qi = 0; qi < q8cnt[2]; qi++) {
                int q = q8list[2][qi];
                double s = Ss8[2][q];
                t20_8 = fma(Ib[(lb + 0) * NQ + q], s, t20_8);
                t21_8 = fma(Ib[(lb + 1) * NQ + q], s, t21_8);
                t22_8 = fma(Ib[(lb + 2) * NQ + q], s, t22_8);
                t23_8 = fma(Ib[(lb + 3) * NQ + q], s, t23_8);
            }
            T[0][lb + 0][0] = t00_0; T[0][lb + 0][1] = t00_1; T[0][lb + 0][2] = t00_2;
            T[0][lb + 0][3] = t00_3; T[0][lb + 0][4] = t00_4; T[0][lb + 0][5] = t00_5;
            T[0][lb + 0][6] = t00_6; T[0][lb + 0][7] = t00_7; T[0][lb + 0][8] = t00_8;
            T[0][lb + 1][0] = t01_0; T[0][lb + 1][1] = t01_1; T[0][lb + 1][2] = t01_2;
            T[0][lb + 1][3] = t01_3; T[0][lb + 1][4] = t01_4; T[0][lb + 1][5] = t01_5;
            T[0][lb + 1][6] = t01_6; T[0][lb + 1][7] = t01_7; T[0][lb + 1][8] = t01_8;
            T[0][lb + 2][0] = t02_0; T[0][lb + 2][1] = t02_1; T[0][lb + 2][2] = t02_2;
            T[0][lb + 2][3] = t02_3; T[0][lb + 2][4] = t02_4; T[0][lb + 2][5] = t02_5;
            T[0][lb + 2][6] = t02_6; T[0][lb + 2][7] = t02_7; T[0][lb + 2][8] = t02_8;
            T[0][lb + 3][0] = t03_0; T[0][lb + 3][1] = t03_1; T[0][lb + 3][2] = t03_2;
            T[0][lb + 3][3] = t03_3; T[0][lb + 3][4] = t03_4; T[0][lb + 3][5] = t03_5;
            T[0][lb + 3][6] = t03_6; T[0][lb + 3][7] = t03_7; T[0][lb + 3][8] = t03_8;
            T[1][lb + 0][0] = t10_0; T[1][lb + 0][1] = t10_1; T[1][lb + 0][2] = t10_2;
            T[1][lb + 0][3] = t10_3; T[1][lb + 0][4] = t10_4; T[1][lb + 0][5] = t10_5;
            T[1][lb + 0][6] = t10_6; T[1][lb + 0][7] = t10_7; T[1][lb + 0][8] = t10_8;
            T[1][lb + 1][0] = t11_0; T[1][lb + 1][1] = t11_1; T[1][lb + 1][2] = t11_2;
            T[1][lb + 1][3] = t11_3; T[1][lb + 1][4] = t11_4; T[1][lb + 1][5] = t11_5;
            T[1][lb + 1][6] = t11_6; T[1][lb + 1][7] = t11_7; T[1][lb + 1][8] = t11_8;
            T[1][lb + 2][0] = t12_0; T[1][lb + 2][1] = t12_1; T[1][lb + 2][2] = t12_2;
            T[1][lb + 2][3] = t12_3; T[1][lb + 2][4] = t12_4; T[1][lb + 2][5] = t12_5;
            T[1][lb + 2][6] = t12_6; T[1][lb + 2][7] = t12_7; T[1][lb + 2][8] = t12_8;
            T[1][lb + 3][0] = t13_0; T[1][lb + 3][1] = t13_1; T[1][lb + 3][2] = t13_2;
            T[1][lb + 3][3] = t13_3; T[1][lb + 3][4] = t13_4; T[1][lb + 3][5] = t13_5;
            T[1][lb + 3][6] = t13_6; T[1][lb + 3][7] = t13_7; T[1][lb + 3][8] = t13_8;
            T[2][lb + 0][0] = t20_0; T[2][lb + 0][1] = t20_1; T[2][lb + 0][2] = t20_2;
            T[2][lb + 0][3] = t20_3; T[2][lb + 0][4] = t20_4; T[2][lb + 0][5] = t20_5;
            T[2][lb + 0][6] = t20_6; T[2][lb + 0][7] = t20_7; T[2][lb + 0][8] = t20_8;
            T[2][lb + 1][0] = t21_0; T[2][lb + 1][1] = t21_1; T[2][lb + 1][2] = t21_2;
            T[2][lb + 1][3] = t21_3; T[2][lb + 1][4] = t21_4; T[2][lb + 1][5] = t21_5;
            T[2][lb + 1][6] = t21_6; T[2][lb + 1][7] = t21_7; T[2][lb + 1][8] = t21_8;
            T[2][lb + 2][0] = t22_0; T[2][lb + 2][1] = t22_1; T[2][lb + 2][2] = t22_2;
            T[2][lb + 2][3] = t22_3; T[2][lb + 2][4] = t22_4; T[2][lb + 2][5] = t22_5;
            T[2][lb + 2][6] = t22_6; T[2][lb + 2][7] = t22_7; T[2][lb + 2][8] = t22_8;
            T[2][lb + 3][0] = t23_0; T[2][lb + 3][1] = t23_1; T[2][lb + 3][2] = t23_2;
            T[2][lb + 3][3] = t23_3; T[2][lb + 3][4] = t23_4; T[2][lb + 3][5] = t23_5;
            T[2][lb + 3][6] = t23_6; T[2][lb + 3][7] = t23_7; T[2][lb + 3][8] = t23_8;
        }

        /* ---- stage 2: Qb[k][p] += sum_{(d,l) live} c * T[d][l][p] ----
         * 10 independent accumulators; f0 seeded from the Q row. */
        for (int k = 0; k < NB; k++) {
            A9(f1); A9(f2); A9(f3); A9(f4); A9(f5); A9(f6); A9(f7); A9(f8); A9(f9);
            size_t qb = (size_t)k * NQ;
            double f0_0 = Qb[qb + 0], f0_1 = Qb[qb + 1], f0_2 = Qb[qb + 2],
                   f0_3 = Qb[qb + 3], f0_4 = Qb[qb + 4], f0_5 = Qb[qb + 5],
                   f0_6 = Qb[qb + 6], f0_7 = Qb[qb + 7], f0_8 = Qb[qb + 8];
            const int cnt = flatcnt[k];
            int n = 0;
            for (; n + 10 <= cnt; n += 10) {
                ITER9(f0, n + 0);
                ITER9(f1, n + 1);
                ITER9(f2, n + 2);
                ITER9(f3, n + 3);
                ITER9(f4, n + 4);
                ITER9(f5, n + 5);
                ITER9(f6, n + 6);
                ITER9(f7, n + 7);
                ITER9(f8, n + 8);
                ITER9(f9, n + 9);
            }
            for (; n < cnt; n++) ITER9(f0, n);
            Qb[qb + 0] = COMB10(0);
            Qb[qb + 1] = COMB10(1);
            Qb[qb + 2] = COMB10(2);
            Qb[qb + 3] = COMB10(3);
            Qb[qb + 4] = COMB10(4);
            Qb[qb + 5] = COMB10(5);
            Qb[qb + 6] = COMB10(6);
            Qb[qb + 7] = COMB10(7);
            Qb[qb + 8] = COMB10(8);
        }
    }
}
