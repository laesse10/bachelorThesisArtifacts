/* SeisSol ADER-DG volume contraction:
 *   Q[b,k,p] += sum_{d,l,q} kDivM[d,k,l] * I[b,l,q] * star[d,q,p]
 * nb = 84, nQ = 9 (fixed). kDivM and star are sparse (real SeisSol patterns);
 * the nonzero pattern is detected at entry (zero factors are skipped exactly:
 * for finite operands a zero product is exactly +/-0.0 and adds nothing).
 *
 * Two-stage contraction per batch element:
 *   T[d][l][p] = sum_q I[b,l,q] * star[d][q][p]           (84x9 per d, in L1)
 *   Q[b,k][p] += sum_{(k,l) live in kDivM[d]} c * T[d][l][p]
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define NB 84
#define NQ 9
#define TSTRIDE (NB * NQ)

#define A9(u) \
    double u##_0 = 0.0, u##_1 = 0.0, u##_2 = 0.0, u##_3 = 0.0, \
         u##_4 = 0.0, u##_5 = 0.0, u##_6 = 0.0, u##_7 = 0.0, u##_8 = 0.0

#define FM8(u, v, s) \
    u##_0 = fma(v, (s)[0], u##_0); \
    u##_1 = fma(v, (s)[1], u##_1); \
    u##_2 = fma(v, (s)[2], u##_2); \
    u##_3 = fma(v, (s)[3], u##_3); \
    u##_4 = fma(v, (s)[4], u##_4); \
    u##_5 = fma(v, (s)[5], u##_5); \
    u##_6 = fma(v, (s)[6], u##_6); \
    u##_7 = fma(v, (s)[7], u##_7)

#define ITER9(U, n) \
    do { \
        const double *tj = (const double *)T + (size_t)flatd[k][(n)] * TSTRIDE + (size_t)flatl[k][(n)] * NQ; \
        double cj = flatc[k][(n)]; \
        U##_0 = fma(cj, tj[0], U##_0); \
        U##_1 = fma(cj, tj[1], U##_1); \
        U##_2 = fma(cj, tj[2], U##_2); \
        U##_3 = fma(cj, tj[3], U##_3); \
        U##_4 = fma(cj, tj[4], U##_4); \
        U##_5 = fma(cj, tj[5], U##_5); \
        U##_6 = fma(cj, tj[6], U##_6); \
        U##_7 = fma(cj, tj[7], U##_7); \
        U##_8 = fma(cj, tj[8], U##_8); \
    } while (0)

#define COMB8(P) ((f0_##P + f1_##P) + (f2_##P + f3_##P)) + ((f4_##P + f5_##P) + (f6_##P + f7_##P))

static int rowcnt[3][NB];
static int rowidx[3][NB][NB];
static double rowcoef[3][NB][NB];
static int flatcnt[NB];
static uint8_t flatl[NB][3 * NB];
static uint8_t flatd[NB][3 * NB];
static double flatc[NB][3 * NB];
static double Srow8[3][NQ][8];
static double Ss8[3][NQ];
static uint8_t q8list[3][NQ];
static int q8cnt[3];

void seissol_tensor_contraction_fp64(
    const double *restrict I, double *restrict Q,
    const double *restrict kDivM, const double *restrict star,
    const int64_t batch, uint8_t *restrict workspace, const int64_t workspace_size)
{
    (void)workspace;
    (void)workspace_size;
    if (batch <= 0) return;

    /* ---- phase 0: detect sparse structure (serial, ~21k elements) ---- */
    for (int d = 0; d < 3; d++) {
        q8cnt[d] = 0;
        for (int q = 0; q < NQ; q++) {
            const double *sp = star + (size_t)d * NQ * NQ + (size_t)q * NQ;
            for (int p = 0; p < 8; p++) Srow8[d][q][p] = sp[p];
            Ss8[d][q] = sp[NQ - 1];
            if (Ss8[d][q] != 0.0) q8list[d][q8cnt[d]++] = (uint8_t)q;
        }
    }
    for (int d = 0; d < 3; d++) {
        const double *kd = kDivM + (size_t)d * NB * NB;
        for (int k = 0; k < NB; k++) {
            const double *rm = kd + (size_t)k * NB;
            int cnt = 0;
            for (int l = 0; l < NB; l++) {
                double v = rm[l];
                if (v != 0.0) {
                    rowidx[d][k][cnt] = l;
                    rowcoef[d][k][cnt] = v;
                    cnt++;
                }
            }
            rowcnt[d][k] = cnt;
        }
    }
    for (int k = 0; k < NB; k++) {
        int n = 0;
        for (int d = 0; d < 3; d++) {
            for (int i = 0; i < rowcnt[d][k]; i++) {
                flatd[k][n] = (uint8_t)d;
                flatl[k][n] = (uint8_t)rowidx[d][k][i];
                flatc[k][n] = rowcoef[d][k][i];
                n++;
            }
        }
        flatcnt[k] = n;
    }

    #pragma omp parallel for schedule(static)
    for (int64_t b = 0; b < batch; b++) {
        const double *restrict Ib = I + (size_t)b * TSTRIDE;
        double *restrict Qb = Q + (size_t)b * TSTRIDE;
        double T[3][NB][NQ];

        /* ---- stage 1: T[d][l][p] = sum_q Ib[l][q] * star[d][q][p] ---- */
        for (int lb = 0; lb < NB; lb += 4) {
            for (int d = 0; d < 3; d++) {
                A9(u0); A9(u1); A9(u2); A9(u3);
                for (int q = 0; q < NQ - 1; q++) {
                    const double *sr = Srow8[d][q];
                    double v0 = Ib[(lb + 0) * NQ + q];
                    double v1 = Ib[(lb + 1) * NQ + q];
                    double v2 = Ib[(lb + 2) * NQ + q];
                    double v3 = Ib[(lb + 3) * NQ + q];
                    FM8(u0, v0, sr);
                    FM8(u1, v1, sr);
                    FM8(u2, v2, sr);
                    FM8(u3, v3, sr);
                }
                {
                    const double *sr = Srow8[d][NQ - 1];
                    double v0 = Ib[(lb + 0) * NQ + NQ - 1];
                    double v1 = Ib[(lb + 1) * NQ + NQ - 1];
                    double v2 = Ib[(lb + 2) * NQ + NQ - 1];
                    double v3 = Ib[(lb + 3) * NQ + NQ - 1];
                    FM8(u0, v0, sr);
                    FM8(u1, v1, sr);
                    FM8(u2, v2, sr);
                    FM8(u3, v3, sr);
                }
                for (int qi = 0; qi < q8cnt[d]; qi++) {
                    int q = q8list[d][qi];
                    double s = Ss8[d][q];
                    u0_8 = fma(Ib[(lb + 0) * NQ + q], s, u0_8);
                    u1_8 = fma(Ib[(lb + 1) * NQ + q], s, u1_8);
                    u2_8 = fma(Ib[(lb + 2) * NQ + q], s, u2_8);
                    u3_8 = fma(Ib[(lb + 3) * NQ + q], s, u3_8);
                }
                T[d][lb + 0][0] = u0_0; T[d][lb + 0][1] = u0_1; T[d][lb + 0][2] = u0_2;
                T[d][lb + 0][3] = u0_3; T[d][lb + 0][4] = u0_4; T[d][lb + 0][5] = u0_5;
                T[d][lb + 0][6] = u0_6; T[d][lb + 0][7] = u0_7; T[d][lb + 0][8] = u0_8;
                T[d][lb + 1][0] = u1_0; T[d][lb + 1][1] = u1_1; T[d][lb + 1][2] = u1_2;
                T[d][lb + 1][3] = u1_3; T[d][lb + 1][4] = u1_4; T[d][lb + 1][5] = u1_5;
                T[d][lb + 1][6] = u1_6; T[d][lb + 1][7] = u1_7; T[d][lb + 1][8] = u1_8;
                T[d][lb + 2][0] = u2_0; T[d][lb + 2][1] = u2_1; T[d][lb + 2][2] = u2_2;
                T[d][lb + 2][3] = u2_3; T[d][lb + 2][4] = u2_4; T[d][lb + 2][5] = u2_5;
                T[d][lb + 2][6] = u2_6; T[d][lb + 2][7] = u2_7; T[d][lb + 2][8] = u2_8;
                T[d][lb + 3][0] = u3_0; T[d][lb + 3][1] = u3_1; T[d][lb + 3][2] = u3_2;
                T[d][lb + 3][3] = u3_3; T[d][lb + 3][4] = u3_4; T[d][lb + 3][5] = u3_5;
                T[d][lb + 3][6] = u3_6; T[d][lb + 3][7] = u3_7; T[d][lb + 3][8] = u3_8;
            }
        }

        /* ---- stage 2: Qb[k][p] += sum_{(d,l) live} c * T[d][l][p] ---- */
        for (int k = 0; k < NB; k++) {
            A9(f0); A9(f1); A9(f2); A9(f3);
            A9(f4); A9(f5); A9(f6); A9(f7);
            const int cnt = flatcnt[k];
            int n = 0;
            for (; n + 8 <= cnt; n += 8) {
                ITER9(f0, n + 0);
                ITER9(f1, n + 1);
                ITER9(f2, n + 2);
                ITER9(f3, n + 3);
                ITER9(f4, n + 4);
                ITER9(f5, n + 5);
                ITER9(f6, n + 6);
                ITER9(f7, n + 7);
            }
            for (; n < cnt; n++) ITER9(f0, n);
            size_t qb = (size_t)k * NQ;
            Qb[qb + 0] = COMB8(0) + Qb[qb + 0];
            Qb[qb + 1] = COMB8(1) + Qb[qb + 1];
            Qb[qb + 2] = COMB8(2) + Qb[qb + 2];
            Qb[qb + 3] = COMB8(3) + Qb[qb + 3];
            Qb[qb + 4] = COMB8(4) + Qb[qb + 4];
            Qb[qb + 5] = COMB8(5) + Qb[qb + 5];
            Qb[qb + 6] = COMB8(6) + Qb[qb + 6];
            Qb[qb + 7] = COMB8(7) + Qb[qb + 7];
            Qb[qb + 8] = COMB8(8) + Qb[qb + 8];
        }
    }
}
