// GEM molecular electrostatics (OpenDwarfs gemnoui):
//   phi_i = sum_j  q_j * exp(-kappa * r_ij) / (diel * r_ij)
//
// Optimized: staged de-interleaved atom arrays, AVX-512 (8 doubles/iter)
// with a range-reduced polynomial exp2 (AMD EPYC does not implement
// VEXP2PD despite the AVX512F flag), point-block tiling, OpenMP over
// point blocks.

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#if defined(__AVX512F__)
#define HAVE_AVX512 1
#include <immintrin.h>
#endif

#define PB 128
#define LOG2E 1.44269504088896340736
/* aligned_alloc requires a size that is an exact multiple of the alignment. */
#define ALIGN64(x) (((x) + (size_t)63) & ~(size_t)63)

/* Degree-10 Chebyshev fit of exp2(f) for f in [-0.5, 0.5];
 * max |error| = 5.55e-15  (relative error per term ~1e-14). */
static const double E10C[11] = {
    1.0000000000000053,
    0.6931471805599483,
    0.24022650695899178,
    0.055504108664530184,
    0.009618129108595132,
    0.0013333558217706785,
    0.00015403529774185264,
    1.5252664418254419e-05,
    1.3215729982770739e-06,
    1.0207318588249843e-07,
    7.023576064343132e-09,
};

/* Scalar term: same math as the vector body (exp2 of the same reduced
 * argument), used for the <8 atom tail and for non-AVX512 builds. */
static inline double scalar_term(double px, double py, double pz,
                                 double ax, double ay, double az,
                                 double c, double cmul) {
    double dx = px - ax, dy = py - ay, dz = pz - az;
    double r2 = dx * dx + dy * dy + dz * dz;
    double r  = sqrt(r2);
    double e  = exp2(cmul * r);
    return c * e * (1.0 / r);
}

#ifdef HAVE_AVX512
__attribute__((target("avx512f,avx512dq,avx512vl,fma")))
static void block512(const double *restrict ax, const double *restrict ay,
                     const double *restrict az, const double *restrict cq,
                     const double *restrict pos, double *restrict phi,
                     const int64_t p0, const int64_t pcnt,
                     const int64_t natoms, const double cmul) {
    const __m512d one  = _mm512_set1_pd(1.0);
    const __m512d cv   = _mm512_set1_pd(cmul);
    const __m512d mlo  = _mm512_set1_pd(-100.0);
    const __m512d mhi  = _mm512_set1_pd(1024.0);
    const __m512d mk   = _mm512_set1_pd(1023.0);
    const __m512d q0  = _mm512_set1_pd(E10C[0]);
    const __m512d q1  = _mm512_set1_pd(E10C[1]);
    const __m512d q2  = _mm512_set1_pd(E10C[2]);
    const __m512d q3  = _mm512_set1_pd(E10C[3]);
    const __m512d q4  = _mm512_set1_pd(E10C[4]);
    const __m512d q5  = _mm512_set1_pd(E10C[5]);
    const __m512d q6  = _mm512_set1_pd(E10C[6]);
    const __m512d q7  = _mm512_set1_pd(E10C[7]);
    const __m512d q8  = _mm512_set1_pd(E10C[8]);
    const __m512d q9  = _mm512_set1_pd(E10C[9]);
    const __m512d q10 = _mm512_set1_pd(E10C[10]);
    const __m512i k1023 = _mm512_set1_epi64(1023LL << 52);
    const __m512d minf  = _mm512_set1_pd(INFINITY);
    const __m512d mzero = _mm512_setzero_pd();

    double *acc = (double *)aligned_alloc(64, ALIGN64((size_t)PB * sizeof(double)));
    memset(acc, 0, (size_t)PB * sizeof(double));

    const int64_t nfull = natoms >> 3;
    for (int64_t j = 0; j < nfull; j++) {
        const __m512d avx = _mm512_loadu_pd(ax + 8 * j);
        const __m512d avy = _mm512_loadu_pd(ay + 8 * j);
        const __m512d avz = _mm512_loadu_pd(az + 8 * j);
        const __m512d avc = _mm512_loadu_pd(cq + 8 * j);
        for (int64_t p = 0; p < pcnt; p++) {
            const double *pp = pos + 3 * (p0 + p);
            __m512d dx = _mm512_sub_pd(_mm512_set1_pd(pp[0]), avx);
            __m512d dy = _mm512_sub_pd(_mm512_set1_pd(pp[1]), avy);
            __m512d dz = _mm512_sub_pd(_mm512_set1_pd(pp[2]), avz);
            __m512d r2 = _mm512_mul_pd(dx, dx);
            r2 = _mm512_fmadd_pd(dy, dy, r2);
            r2 = _mm512_fmadd_pd(dz, dz, r2);
            __m512d r  = _mm512_sqrt_pd(r2);
            __m512d y2 = _mm512_mul_pd(r, cv);
            __m512d k  = _mm512_round_pd(y2, _MM_FROUND_TO_NEAREST_EVEN | _MM_FROUND_NOEXC);
            k  = _mm512_min_pd(k, mk);
            __m512d f  = _mm512_sub_pd(y2, k);
            __m512d t  = _mm512_fmadd_pd(f, q10, q9);
            t = _mm512_fmadd_pd(f, t, q8);
            t = _mm512_fmadd_pd(f, t, q7);
            t = _mm512_fmadd_pd(f, t, q6);
            t = _mm512_fmadd_pd(f, t, q5);
            t = _mm512_fmadd_pd(f, t, q4);
            t = _mm512_fmadd_pd(f, t, q3);
            t = _mm512_fmadd_pd(f, t, q2);
            t = _mm512_fmadd_pd(f, t, q1);
            t = _mm512_fmadd_pd(f, t, q0);
            __m512i sb = _mm512_slli_epi64(_mm512_cvtpd2dq(k), 52);
            __m512d e  = _mm512_mul_pd(t, _mm512_castsi512_pd(_mm512_add_epi64(sb, k1023)));
            e = _mm512_mask_blend_pd(_mm512_cmp_pd_mask(y2, mlo, _CMP_LT_OQ), e, mzero);
            e = _mm512_mask_blend_pd(_mm512_cmp_pd_mask(y2, mhi, _CMP_GT_OQ), e, minf);
            __m512d term = _mm512_mul_pd(e, avc);
            term = _mm512_mul_pd(term, _mm512_div_pd(one, r));
            acc[p] += _mm512_reduce_add_pd(term);
        }
    }
    for (int64_t jt = nfull * 8; jt < natoms; jt++) {
        const double axj = ax[jt], ayj = ay[jt], azj = az[jt], cj = cq[jt];
        for (int64_t p = 0; p < pcnt; p++) {
            const double *pp = pos + 3 * (p0 + p);
            acc[p] += scalar_term(pp[0], pp[1], pp[2], axj, ayj, azj, cj, cmul);
        }
    }
    for (int64_t p = 0; p < pcnt; p++)
        phi[p0 + p] = acc[p];
    free(acc);
}
#endif

#ifndef HAVE_AVX512
static void block_scalar(const double *restrict ax, const double *restrict ay,
                         const double *restrict az, const double *restrict cq,
                         const double *restrict pos, double *restrict phi,
                         const int64_t p0, const int64_t pcnt,
                         const int64_t natoms, const double cmul) {
    double *acc = (double *)aligned_alloc(64, ALIGN64((size_t)PB * sizeof(double)));
    memset(acc, 0, (size_t)PB * sizeof(double));
    for (int64_t jt = 0; jt < natoms; jt++) {
        const double axj = ax[jt], ayj = ay[jt], azj = az[jt], cj = cq[jt];
        for (int64_t p = 0; p < pcnt; p++) {
            const double *pp = pos + 3 * (p0 + p);
            acc[p] += scalar_term(pp[0], pp[1], pp[2], axj, ayj, azj, cj, cmul);
        }
    }
    for (int64_t p = 0; p < pcnt; p++)
        phi[p0 + p] = acc[p];
    free(acc);
}
#endif

void gem_fp64(const double *restrict apos, const double *restrict charge,
              double *restrict phi, const double *restrict pos,
              const double diel, const double kappa,
              const int64_t natoms, const int64_t npoints,
              uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    if (npoints <= 0)
        return;
    if (natoms <= 0) {
        for (int64_t i = 0; i < npoints; i++)
            phi[i] = 0.0;
        return;
    }

    /* Stage atoms as four de-interleaved arrays (64B-aligned bases) +
     * pre-scaled charges. */
    const int64_t n8 = (natoms + 7) & ~7LL;
    double *st = (double *)aligned_alloc(64, ALIGN64((size_t)n8 * 4 * sizeof(double)));
    if (!st)
        st = (double *)malloc(((size_t)natoms + 7) * 4 * sizeof(double));
    double *ax = st;
    double *ay = st + n8;
    double *az = st + 2 * n8;
    double *cq = st + 3 * n8;

#pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < natoms; i++) {
        ax[i] = apos[3 * i];
        ay[i] = apos[3 * i + 1];
        az[i] = apos[3 * i + 2];
        cq[i] = charge[i] / diel;
    }

    const double cmul = -kappa * LOG2E;
    const int64_t nblocks = (npoints + PB - 1) / PB;

#ifdef HAVE_AVX512
#pragma omp parallel for schedule(dynamic, 1)
    for (int64_t b = 0; b < nblocks; b++) {
        const int64_t p0 = b * PB;
        const int64_t pcnt = (p0 + PB <= npoints) ? PB : (npoints - p0);
        block512(ax, ay, az, cq, pos, phi, p0, pcnt, natoms, cmul);
    }
#else
#pragma omp parallel for schedule(dynamic, 1)
    for (int64_t b = 0; b < nblocks; b++) {
        const int64_t p0 = b * PB;
        const int64_t pcnt = (p0 + PB <= npoints) ? PB : (npoints - p0);
        block_scalar(ax, ay, az, cq, pos, phi, p0, pcnt, natoms, cmul);
    }
#endif

    free(st);
}
