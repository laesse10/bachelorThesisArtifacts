#define _GNU_SOURCE
/* heat_3d: explicit 3D heat equation, ping-pong A/B update of the (N-2)^3 interior
 * with the 7-point (2nd-order, 3-axis) stencil for TSTEPS full steps.
 *
 * Optimized: one streaming thread per NUMA package of the visible CPUs (pinned),
 * each thread owns a contiguous slab of i; AVX-512 along k. Per element:
 *   r = alpha*(p+m+lp+lm+kp+km - 6c) + c
 * (algebraically identical to the reference's
 *   r = ((alpha*(p - 2c + m) + alpha*(lp - 2c + lm)) + alpha*(kp - 2c + km)) + c
 * ; re-association + FMA deviates by ~1e-15 absolute, far inside the
 *   1e-11 atol / 1e-9 rtol tolerance), with c = A[i,j,k],
 *   p/m = i+1/i-1, lp/lm = j+1/j-1, kp/km = k+1/k-1.
 *
 * Threads are a small persistent pool (created lazily on the first call, with
 * retries under resource pressure, falling back to serial). The OpenMP runtime
 * is deliberately not used so a failed thread creation can never abort the run.
 * All libc entry points used below are declared manually (identical to the
 * standard prototypes) because the strict-POSIX build of this track hides
 * several of the normal prototypes on some systems.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <stdatomic.h>

#if defined(__has_include)
#  if __has_include(<asm/unistd.h>)
#    include <asm/unistd.h>
#  endif
#endif
#ifndef __NR_sched_getaffinity
#  define __NR_sched_getaffinity 204
#endif
#ifndef __NR_sched_setaffinity
#  define __NR_sched_setaffinity 203
#endif

/* libc entry points (prototypes hidden under strict POSIX on some glibcs). */
extern long syscall(long number, ...);
extern int nanosleep(const struct timespec *req, struct timespec *rem);

#ifdef __AVX512F__
#include <immintrin.h>
#endif

#define H3D_MAXW 16

/* ---------- visibility / affinity (128-byte mask, 1024 bits) ---------- */
struct h3d_cpumask { unsigned long long w[16]; };
static int h3d_cpu_get(struct h3d_cpumask *m) {
    /* this platform returns a small positive value on success; only negatives
     * are errors */
    long rc = syscall(__NR_sched_getaffinity, 0, (long)sizeof(*m), (long)m);
    return rc < 0 ? -1 : 0;
}
static void h3d_pin(int cpu) {
    struct h3d_cpumask s;
    for (int i = 0; i < 16; i++) s.w[i] = 0;
    s.w[cpu >> 6] = 1ull << (cpu & 63);
    syscall(__NR_sched_setaffinity, 0, (long)sizeof(s), (long)&s);
}
static void h3d_usleep(unsigned long us) {
    struct timespec ts;
    ts.tv_sec = (long)(us / 1000000UL);
    ts.tv_nsec = (long)(us % 1000000UL) * 1000L;
    nanosleep(&ts, NULL);
}

/* one visible CPU per NUMA package */
static int h3d_cpus[H3D_MAXW + 1];
static int h3d_ncpus = 0;
static int h3d_inited = 0;
static void h3d_detect(void) {
    if (h3d_inited) return;
    h3d_inited = 1;
    struct h3d_cpumask set;
    for (int i = 0; i < 16; i++) set.w[i] = 0;
    if (h3d_cpu_get(&set) != 0) return;
    int list[H3D_MAXW * 8], n = 0;
    for (int c = 0; c < 1024 && n < (int)(sizeof list / sizeof *list); c++)
        if ((set.w[c >> 6] >> (c & 63)) & 1) list[n++] = c;
    int pkg[H3D_MAXW + 1], npkg = 0;
    for (int i = 0; i < n; i++) {
        char path[80];
        snprintf(path, sizeof path,
                 "/sys/devices/system/cpu/cpu%d/topology/physical_package_id", list[i]);
        int p = -1;
        FILE *f = fopen(path, "r");
        if (f) { if (fscanf(f, "%d", &p) != 1) p = -1; fclose(f); }
        int found = 0;
        for (int j = 0; j < npkg; j++) if (pkg[j] == p) { found = 1; break; }
        if (!found && npkg < H3D_MAXW + 1) { pkg[npkg] = p; h3d_cpus[npkg++] = list[i]; }
    }
    h3d_ncpus = npkg;
}

/* ---------------------------- worker pool ---------------------------- */
typedef struct {
    const double *A;
    double *B;
    double alpha;
    int64_t N, i0, i1;
} Task;

static atomic_int h3d_taskid = 0;
static atomic_int h3d_done = 0;
static Task h3d_tasks[H3D_MAXW + 1];
static pthread_t h3d_workers[H3D_MAXW];
static int h3d_nw = 0;

/* process slab i in [i0, i1) of one half step */
static void h3d_slab(const Task *tk) {
    const int64_t N = tk->N, L = N - 2, N2 = N * N;
    const double alpha = tk->alpha;
    const double *restrict A = tk->A;
    double *restrict B = tk->B;
    for (int64_t i = tk->i0; i < tk->i1; i++) {
        const int64_t ib = i * N2;
        for (int64_t j = 1; j < N - 1; j++) {
            const int64_t base = ib + j * N;
            const double *restrict c  = A + base + 1;
            const double *restrict p  = c + N2;
            const double *restrict m  = c - N2;
            const double *restrict lp = c + N;
            const double *restrict lm = c - N;
            const double *restrict kp = c + 1;
            const double *restrict km = c - 1;
            double *restrict o = B + base + 1;
            int64_t k = 1;
#ifdef __AVX512F__
            /* r = alpha*(p+m+lp+lm+kp+km - 6c) + c
             * (algebraically identical to the reference; re-association + FMA
             *  costs ~1e-15 absolute, far inside the 1e-11/1e-9 tolerance) */
            __m512d va = _mm512_set1_pd(alpha);
            __m512d v6 = _mm512_set1_pd(6.0);
            for (; k + 7 <= L; k += 8) {
                __m512d cc  = _mm512_loadu_pd(c + k - 1);
                __m512d pm  = _mm512_add_pd(_mm512_loadu_pd(p + k - 1),
                                            _mm512_loadu_pd(m + k - 1));
                __m512d lpm = _mm512_add_pd(_mm512_loadu_pd(lp + k - 1),
                                            _mm512_loadu_pd(lm + k - 1));
                __m512d kpm = _mm512_add_pd(_mm512_loadu_pd(kp + k - 1),
                                            _mm512_loadu_pd(km + k - 1));
                __m512d s1  = _mm512_add_pd(_mm512_add_pd(pm, lpm), kpm);
                __m512d s6  = _mm512_fnmadd_pd(v6, cc, s1); /* s1 - 6c  */
                __m512d r   = _mm512_fmadd_pd(va, s6, cc);  /* a*s6 + c */
                _mm512_storeu_pd(o + k - 1, r);
            }
#endif
            for (; k <= L; k++) {
                double cc = c[k - 1];
                double s1 = (p[k - 1] + m[k - 1]) + (lp[k - 1] + lm[k - 1])
                          + (kp[k - 1] + km[k - 1]);
                double s6 = __builtin_fma(-6.0, cc, s1);
                o[k - 1] = __builtin_fma(alpha, s6, cc);
            }
        }
    }
}

static void *h3d_worker(void *arg) {
    int id = (int)(intptr_t)arg;
    h3d_pin(h3d_cpus[id]);
    int last = 0;
    for (;;) {
        int t = atomic_load_explicit(&h3d_taskid, memory_order_acquire);
        if (t == last) { h3d_usleep(20); continue; }
        last = t;
        h3d_slab(&h3d_tasks[id]);
        atomic_fetch_add_explicit(&h3d_done, 1, memory_order_release);
    }
    pthread_exit(NULL);
}

/* try to (re)start the pool; EAGAIN is retried with backoff */
static void h3d_try_start(void) {
    int want = h3d_ncpus > H3D_MAXW + 1 ? H3D_MAXW : h3d_ncpus - 1;
    if (want < 0) want = 0;
    if (h3d_nw >= want) return;
    for (int attempt = 0; attempt < 4 && h3d_nw < want; attempt++) {
        for (int i = h3d_nw; i < want; i++) {
            int rc = pthread_create(&h3d_workers[i], NULL, h3d_worker, (void *)(intptr_t)i);
            if (rc == 0) {
                h3d_nw++;
            } else {
                if (rc == EAGAIN) h3d_usleep(10000);
                return;
            }
        }
    }
}

/* one half step: B interior <- stencil(A) */
static void h3d_pass(const double *restrict A, double *restrict B,
                     int64_t N, double alpha) {
    int nt = h3d_nw + 1;
    int64_t span = N - 2;
    int64_t chunk = (span + nt - 1) / nt;
    if (nt > 1 && chunk > 0) {
        int id = 0;
        int64_t i0 = 1;
        for (; i0 < N - 1 && id <= h3d_nw; i0 += chunk, id++) {
            int64_t i1 = i0 + chunk;
            if (i1 > N - 1) i1 = N - 1;
            h3d_tasks[id].A = A;
            h3d_tasks[id].B = B;
            h3d_tasks[id].alpha = alpha;
            h3d_tasks[id].N = N;
            h3d_tasks[id].i0 = i0;
            h3d_tasks[id].i1 = i1;
        }
        h3d_done = 0;
        h3d_taskid++;
        h3d_slab(&h3d_tasks[h3d_nw]);
        while (atomic_load_explicit(&h3d_done, memory_order_acquire) < h3d_nw) {
#if defined(__x86_64__)
            __builtin_ia32_pause();
#endif
        }
    } else {
        Task tk;
        tk.A = A; tk.B = B; tk.alpha = alpha; tk.N = N;
        tk.i0 = 1; tk.i1 = N - 1;
        h3d_slab(&tk);
    }
}

void heat_3d_fp64(double *restrict A, double *restrict B, const int64_t N,
                  const int64_t TSTEPS, const double alpha,
                  uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    if (N < 3 || TSTEPS <= 0) return;
    h3d_detect();
    if (h3d_ncpus > 1) {
        h3d_try_start();
        if (h3d_nw > 0) h3d_pin(h3d_cpus[h3d_nw]);
    }
    for (int64_t t = 0; t < TSTEPS; t++) {
        h3d_pass(A, B, N, alpha);
        h3d_pass(B, A, N, alpha);
    }
}
