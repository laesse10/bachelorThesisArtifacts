/* QuaTrEx RGF selected solve -- optimized implementation.
 *
 * Strategy:
 *  - energies (NE) are independent: OpenMP parallel over e.
 *  - all dense block ops go through OpenBLAS (single-threaded per call,
 *    safe to call concurrently from many OMP threads).
 *  - the running retarded diagonals xr_d are stored directly in the
 *    x_retarded_diag output (the backward sweep updates them in place and
 *    the final values are exactly the requested output).
 *  - xl_d / xg_d running diagonals live in per-thread scratch.
 *  - scratch: use the judge-provided workspace when it is large enough,
 *    otherwise a plain malloc.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <omp.h>

typedef double _Complex zcx;

enum { Z_ROW = 101, Z_N = 111, Z_CH = 113 };
void cblas_zgemm(int order, int ta, int tb, int m, int n, int k,
                 const double *alpha, const zcx *A, int lda,
                 const zcx *B, int ldb, const double *beta, zcx *C, int ldc);
void openblas_set_num_threads(int nthreads);

static const double ONE = 1.0, ZERO = 0.0;

static inline void gemm_n(int n, const zcx *A, const zcx *B, zcx *C)
{
    cblas_zgemm(Z_ROW, Z_N, Z_N, (int)n, (int)n, (int)n, &ONE, A, (int)n,
                B, (int)n, &ZERO, C, (int)n);
}
static inline void gemm_nch(int n, const zcx *A, const zcx *B, zcx *C)
{
    cblas_zgemm(Z_ROW, Z_N, Z_CH, (int)n, (int)n, (int)n, &ONE, A, (int)n,
                B, (int)n, &ZERO, C, (int)n);
}

/* Complex LU with partial pivoting (row-major, in place).
 * Returns 0 on success, k+1 (1-based) on a zero pivot. */
static int zlu(zcx *A, int n, int *ipiv)
{
    for (int k = 0; k < n; k++) {
        int p = k;
        double best = creal(A[k*n+k]) * creal(A[k*n+k])
                     + cimag(A[k*n+k]) * cimag(A[k*n+k]);
        for (int r = k + 1; r < n; r++) {
            double v = creal(A[r*n+k]) * creal(A[r*n+k])
                     + cimag(A[r*n+k]) * cimag(A[r*n+k]);
            if (v > best) { best = v; p = r; }
        }
        ipiv[k] = p + 1;
        if (p != k) {
            /* swap only the not-yet-factored part (cols k..n-1); the
             * columns left of k hold stored L multipliers */
            for (int c = k; c < n; c++) {
                zcx t = A[k*n+c]; A[k*n+c] = A[p*n+c]; A[p*n+c] = t;
            }
        }
        zcx d = A[k*n+k];
        if (d == 0.0) return k + 1;
        for (int r = k + 1; r < n; r++) {
            zcx f = A[r*n+k] / d;
            A[r*n+k] = f;
            zcx *Ar = A + r*n + k + 1, *Ak = A + k*n + k + 1;
            for (int c = k + 1; c < n; c++) Ar[c-k-1] -= f * Ak[c-k-1];
        }
    }
    return 0;
}

/* Solve A X = B in place for the LU from zlu (row-major, unit diag L).
 * B has n columns (nrhs == n). */
static void zlusolv(zcx *A, const int *ipiv, zcx *B, int n)
{
    for (int k = 0; k < n; k++) {
        int p = ipiv[k] - 1;
        if (p != k) {
            for (int c = 0; c < n; c++) {
                zcx t = B[k*n+c]; B[k*n+c] = B[p*n+c]; B[p*n+c] = t;
            }
        }
    }
    for (int k = 0; k < n; k++) {
        for (int r = k + 1; r < n; r++) {
            zcx f = A[r*n+k];
            zcx *Br = B + r*n, *Bk = B + k*n;
            for (int c = 0; c < n; c++) Br[c] -= f * Bk[c];
        }
    }
    for (int k = n - 1; k >= 0; k--) {
        zcx d = A[k*n+k];
        zcx *Bk = B + k*n;
        for (int c = 0; c < n; c++) Bk[c] /= d;
        for (int r = 0; r < k; r++) {
            zcx f = A[r*n+k];
            zcx *Br = B + r*n;
            for (int c = 0; c < n; c++) Br[c] -= f * Bk[c];
        }
    }
}

/* R = inv(M): LU + solve for identity, row-major in/out. */
static inline void zinv(int n, const zcx *M, const zcx *ID, zcx *W,
                        zcx *BIV, int *ipiv, zcx *R)
{
    memcpy(W, M, (size_t)n * n * sizeof(zcx));
    zlu(W, n, ipiv);
    memcpy(BIV, ID, (size_t)n * n * sizeof(zcx));
    zlusolv(W, ipiv, BIV, n);
    if (R != BIV) memcpy(R, BIV, (size_t)n * n * sizeof(zcx));
}

/* per-thread scratch layout, in n^2-complex units:
 *   [0, 2NB)                xld_d / xgd_d  (NB blocks each)
 *   [2NB, 2NB+10)           F0..F9
 *   [2NB+10, 2NB+12)        W, BIV
 *   total 2*NB + 12
 */
#define PER_THREAD(n2, NB) ((2 * (NB) + 12) * (n2))

void quatrex_rgf_fp64(
    const double _Complex *restrict a_diag,
    const double _Complex *restrict a_lower,
    const double _Complex *restrict a_upper,
    const double _Complex *restrict sigma_greater_diag,
    const double _Complex *restrict sigma_greater_upper,
    const double _Complex *restrict sigma_lesser_diag,
    const double _Complex *restrict sigma_lesser_upper,
    double _Complex *restrict x_greater_diag,
    double _Complex *restrict x_greater_lower,
    double _Complex *restrict x_greater_upper,
    double _Complex *restrict x_lesser_diag,
    double _Complex *restrict x_lesser_lower,
    double _Complex *restrict x_lesser_upper,
    double _Complex *restrict x_retarded_diag,
    const int64_t BS,
    const int64_t NB,
    const int64_t NE,
    uint8_t *restrict workspace,
    const int64_t workspace_size)
{
    static int init_done = 0;
    if (!init_done) {
        /* Keep OpenBLAS single-threaded per call (we provide the
         * parallelism) and trigger one-time init outside the work. */
        openblas_set_num_threads(1);
        zcx a[16], b[16], c[16];
        for (int i = 0; i < 16; i++) { a[i] = 1.0; b[i] = 2.0; c[i] = 0.0; }
        cblas_zgemm(Z_ROW, Z_N, Z_N, 4, 4, 4, &ONE, a, 4, b, 4, &ZERO, c, 4);
        init_done = 1;
    }

    if (NE <= 0 || NB <= 0 || BS <= 0) return;
    const int64_t n = BS, n2 = n * n;

    int nt = (int)omp_get_max_threads();
    if (nt > (int)NE) nt = (int)NE;
    if (nt < 1) nt = 1;

    const int64_t per_thread = PER_THREAD(n2, NB);
    const int64_t need = (int64_t)nt * per_thread * (int64_t)sizeof(zcx)
                          + (int64_t)nt * n * 2 * (int64_t)sizeof(int)
                          + n2 * (int64_t)sizeof(zcx); /* ipiv + identity */

    zcx *base;
    int *ipivs;
    zcx *ID;
    int base_owned = 0;
    if (workspace != NULL && workspace_size >= need) {
        base = (zcx *)workspace;
        ipivs = (int *)(workspace + (size_t)nt * per_thread * sizeof(zcx));
        ID = (zcx *)(ipivs + (size_t)nt * n * 2);
    } else {
        base = (zcx *)malloc((size_t)need);
        base_owned = 1;
        ipivs = (int *)(base + (int64_t)nt * per_thread);
        ID = (zcx *)(ipivs + (size_t)nt * n * 2);
    }
    if (base == NULL) return;
    for (int64_t i = 0; i < n2; i++) ID[i] = (i % n == i / n) ? 1.0 : 0.0;

#pragma omp parallel num_threads(nt)
    {
        const int64_t t = omp_get_thread_num();
        zcx *S = base + t * per_thread;
        int *ipiv = ipivs + t * n;
        zcx *XLD = S;
        zcx *XGD = S + NB * n2;
        zcx *F0 = S + 2 * NB * n2;
        zcx *F1 = F0 + n2;
        zcx *F2 = F1 + n2;
        zcx *F3 = F2 + n2;
        zcx *F4 = F3 + n2;
        zcx *F5 = F4 + n2;
        zcx *F6 = F5 + n2;
        zcx *F7 = F6 + n2;
        zcx *F8 = F7 + n2;
        zcx *F9 = F8 + n2;
        zcx *W = F9 + n2;
        zcx *BIV = W + n2;

#pragma omp for schedule(static)
        for (int64_t e = 0; e < NE; e++) {
            const zcx *Ad  = a_diag  + e * NB * n2;
            const zcx *Al  = a_lower + e * (NB - 1) * n2;
            const zcx *Au  = a_upper + e * (NB - 1) * n2;
            const zcx *SGd = sigma_greater_diag + e * NB * n2;
            const zcx *SGu = sigma_greater_upper + e * (NB - 1) * n2;
            const zcx *SLd = sigma_lesser_diag + e * NB * n2;
            const zcx *SLu = sigma_lesser_upper + e * (NB - 1) * n2;
            zcx *XGd = x_greater_diag + e * NB * n2;
            zcx *XGl = x_greater_lower + e * (NB - 1) * n2;
            zcx *XGu = x_greater_upper + e * (NB - 1) * n2;
            zcx *XLd = x_lesser_diag + e * NB * n2;
            zcx *XLl = x_lesser_lower + e * (NB - 1) * n2;
            zcx *XLu = x_lesser_upper + e * (NB - 1) * n2;
            zcx *XRd = x_retarded_diag + e * NB * n2;

            /* ---- first block ---- */
            zinv(n, Ad, ID, W, BIV, ipiv, XRd);
            gemm_n(n, BIV, SLd, F0);   /* F0 = R @ SL_d */
            gemm_nch(n, F0, BIV, XLD); /* XLD_0 */
            gemm_n(n, BIV, SGd, F0);   /* F0 = R @ SG_d */
            gemm_nch(n, F0, BIV, XGD); /* XGD_0 */

            /* ---- forward sweep ---- */
            for (int64_t i = 0; i < NB - 1; i++) {
                const int64_t j = i + 1;
                const zcx *Ali  = Al + i * n2;
                const zcx *Aui  = Au + i * n2;
                const zcx *Adr  = Ad + j * n2;
                const zcx *SLu_i = SLu + i * n2;
                const zcx *SGu_i = SGu + i * n2;
                const zcx *SLd_j = SLd + j * n2;
                const zcx *SGd_j = SGd + j * n2;
                zcx *Xri = XRd + i * n2;
                zcx *Xrj = XRd + j * n2;

                gemm_n(n, Ali, Xri, F0);        /* F0 = Al @ XR_i */
                gemm_n(n, F0, Aui, F1);         /* F1 = F0 @ Au */
                for (int64_t r = 0; r < n2; r++) W[r] = Adr[r] - F1[r];
                zinv(n, W, ID, W, BIV, ipiv, Xrj); /* R = inv, -> XR_j */

                gemm_n(n, F0, SLu_i, F2);       /* F2 = F0 @ SLu */
                gemm_n(n, F0, SGu_i, F3);       /* F3 = F0 @ SGu */

                gemm_n(n, Ali, XLD + i * n2, F4);
                gemm_nch(n, F4, Ali, F5);
                for (int64_t r = 0; r < n; r++)
                    for (int64_t c = 0; c < n; c++)
                        F6[r*n+c] = SLd_j[r*n+c] + F5[r*n+c] - F2[r*n+c]
                                     + conj(F2[c*n+r]);
                gemm_n(n, BIV, F6, F7);
                gemm_nch(n, F7, BIV, XLD + j * n2);

                gemm_n(n, Ali, XGD + i * n2, F4);
                gemm_nch(n, F4, Ali, F5);
                for (int64_t r = 0; r < n; r++)
                    for (int64_t c = 0; c < n; c++)
                        F6[r*n+c] = SGd_j[r*n+c] + F5[r*n+c] - F3[r*n+c]
                                     + conj(F3[c*n+r]);
                gemm_n(n, BIV, F6, F7);
                gemm_nch(n, F7, BIV, XGD + j * n2);
            }

            /* ---- last diagonal outputs ---- */
            {
                const zcx *xg = XGD + (NB - 1) * n2;
                const zcx *xl = XLD + (NB - 1) * n2;
                for (int64_t r = 0; r < n; r++)
                    for (int64_t c = 0; c < n; c++) {
                        XGd[(NB-1)*n2 + r*n+c] = 0.5 * (xg[r*n+c] - conj(xg[c*n+r]));
                        XLd[(NB-1)*n2 + r*n+c] = 0.5 * (xl[r*n+c] - conj(xl[c*n+r]));
                    }
            }

            /* ---- backward sweep ---- */
            for (int64_t i = NB - 2; i >= 0; i--) {
                const int64_t j = i + 1;
                const zcx *Ali  = Al + i * n2;
                const zcx *Aui  = Au + i * n2;
                const zcx *SLu_i = SLu + i * n2;
                const zcx *SGu_i = SGu + i * n2;
                zcx *Xri = XRd + i * n2;
                zcx *Xrj = XRd + j * n2;
                zcx *Xli = XLD + i * n2;
                zcx *Xlj = XLD + j * n2;
                zcx *Xgi = XGD + i * n2;
                zcx *Xgj = XGD + j * n2;

                gemm_n(n, Xri, Aui, F0);   /* F0 = T1 = XR_i @ Au */
                gemm_n(n, Xrj, Ali, F1);   /* F1 = T2 = XR_j @ Al */
                gemm_n(n, F0, F1, F2);     /* F2 = T4 = T1 @ T2 */
                gemm_n(n, F0, Xrj, F3);    /* F3 = T3 = T1 @ XR_j */

                /* ---- lesser ---- */
                gemm_n(n, F2, Xli, F4);    /* F4 = T4 @ Xl_i */
                gemm_n(n, Xri, SLu_i, F5); /* F5 = P = XR_i @ SLu */
                gemm_nch(n, F5, F3, F6);   /* F6 = P @ T3^H */
                for (int64_t r = 0; r < n2; r++) F6[r] = F4[r] - F6[r]; /* t1 */
                for (int64_t r = 0; r < n; r++)
                    for (int64_t c = 0; c < n; c++)
                        F4[r*n+c] = F6[r*n+c] - conj(F6[c*n+r]); /* temp_1x */
                gemm_n(n, F0, Xlj, F7);    /* F7 = temp_2x = T1 @ Xl_j */
                gemm_nch(n, F5, Xrj, F8);  /* F8 = P @ XR_j^H */
                gemm_nch(n, Xli, F1, F9);  /* F9 = Xl_i @ T2^H */
                for (int64_t r = 0; r < n2; r++)
                    XLu[i*n2+r] = -F7[r] - F9[r] + F8[r]; /* x_lesser_upper */
                for (int64_t r = 0; r < n; r++)
                    for (int64_t c = 0; c < n; c++)
                        XLl[i*n2+r*n+c] = -conj(XLu[i*n2+c*n+r]);
                gemm_nch(n, F7, F0, F9);   /* F9 = temp_2x @ T1^H */
                for (int64_t r = 0; r < n2; r++) F9[r] = Xli[r] + F9[r] + F4[r];
                memcpy(Xli, F9, n2 * sizeof(zcx));       /* Xl_i = t3 */
                for (int64_t r = 0; r < n; r++)
                    for (int64_t c = 0; c < n; c++)
                        XLd[i*n2+r*n+c] = 0.5 * (F9[r*n+c] - conj(F9[c*n+r]));

                /* ---- greater ---- */
                gemm_n(n, F2, Xgi, F4);
                gemm_n(n, Xri, SGu_i, F5);
                gemm_nch(n, F5, F3, F6);
                for (int64_t r = 0; r < n2; r++) F6[r] = F4[r] - F6[r];
                for (int64_t r = 0; r < n; r++)
                    for (int64_t c = 0; c < n; c++)
                        F4[r*n+c] = F6[r*n+c] - conj(F6[c*n+r]); /* temp_1x */
                gemm_n(n, F0, Xgj, F7);
                gemm_nch(n, F5, Xrj, F8);
                gemm_nch(n, Xgi, F1, F9);
                for (int64_t r = 0; r < n2; r++)
                    XGu[i*n2+r] = -F7[r] - F9[r] + F8[r];
                for (int64_t r = 0; r < n; r++)
                    for (int64_t c = 0; c < n; c++)
                        XGl[i*n2+r*n+c] = -conj(XGu[i*n2+c*n+r]);
                gemm_nch(n, F7, F0, F9);   /* F9 = temp_2x @ T1^H */
                for (int64_t r = 0; r < n2; r++) F9[r] = Xgi[r] + F9[r] + F4[r];
                memcpy(Xgi, F9, n2 * sizeof(zcx));
                for (int64_t r = 0; r < n; r++)
                    for (int64_t c = 0; c < n; c++)
                        XGd[i*n2+r*n+c] = 0.5 * (F9[r*n+c] - conj(F9[c*n+r]));

                /* ---- retarded (last: reads the old XR_i) ---- */
                gemm_n(n, F2, Xri, F0);
                for (int64_t r = 0; r < n2; r++) Xri[r] += F0[r];
            }
        }
    }

    if (base_owned) free(base);
}
