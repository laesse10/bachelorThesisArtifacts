/* Optimized FV3 x-direction PPM advective flux (fv3_xppm).
 *
 * Design: the nsteps advection steps are applied per-column streaming sweeps.
 * A sweep for interface i needs al[i-1], al[i], al[i+1] (from the OLD q) and
 * old q[i-1], q[i]. Only old q[i-1] and old q[i] are carried as row buffers
 * (B0/B1, rotated each sweep); al[i-1] and al[i] are carried in two rotating
 * buffers (X/Y) and al[i+1] is computed on the fly into a third rotating
 * buffer. Each OpenMP thread streams a disjoint flat (j,k) slice of every
 * row, so threads never touch the same memory and no synchronization is
 * needed; every element's arithmetic is the exact expression sequence of the
 * reference implementation (same order of operations and associativity).
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define PPM_P1 0.5833333333333334
#define PPM_P2 (-0.08333333333333333)
#define PPM_C1 (-0.14285714285714285)
#define PPM_C2 0.7857142857142857
#define PPM_C3 0.35714285714285715

typedef struct {
  double *restrict q;
  const double *restrict courant;
  const double *restrict dxa;
  double *restrict xf;
  int64_t M;
  int64_t f0;
  int64_t L;
  int64_t Lmax;
  int64_t nx;
  int64_t ni;
  int has_edge;
  double *slots;   /* 5*L: X, Y, RT, B0, B1 */
  double *E;       /* 6*L edge value rows (has_edge only) */
  int ecol[6];     /* column of each E row */
  double *CC;      /* nx*L local copy of the courant slice, or NULL */
} TCtx;

static inline const double *edge_row(const TCtx *t, int64_t col) {
  for (int s = 5; s >= 0; --s)
    if (t->ecol[s] == col) return t->E + (int64_t)s * t->L;
  return NULL;
}

/* al[v] = P1*(q[v-1]+q[v]) + P2*(q[v-2]+q[v+1])  (reference order) */
static inline void al_norm(double *restrict o, const double *restrict a1,
                           const double *restrict a0, const double *restrict a2,
                           const double *restrict p1, int64_t L) {
  for (int64_t j = 0; j < L; ++j)
    o[j] = PPM_P1 * (a1[j] + a0[j]) + PPM_P2 * (a2[j] + p1[j]);
}

/* grid_type < 3 edge rows, in the reference's if/if/if (ia, ib, ic) write order */
static void compute_edges(TCtx *t) {
  const int64_t M = t->M, L = t->L, f0 = t->f0;
  const double *q = t->q, *dxa = t->dxa;
  const int64_t col[6] = {2, t->ni + 2, 3, t->ni + 3, 4, t->ni + 4};
  const int kind[6] = {0, 0, 1, 1, 2, 2};
  for (int s = 0; s < 6; ++s) {
    int64_t v = col[s];
    const double *qm2 = q + (v - 2) * M + f0;
    const double *qm1 = q + (v - 1) * M + f0;
    const double *q0  = q + v * M + f0;
    const double *qp1 = q + (v + 1) * M + f0;
    const double *xm2 = dxa + (v - 2) * M + f0;
    const double *xm1 = dxa + (v - 1) * M + f0;
    const double *x0  = dxa + v * M + f0;
    const double *xp1 = dxa + (v + 1) * M + f0;
    double *o = t->E + (int64_t)s * L;
    if (kind[s] == 0) {
      for (int64_t j = 0; j < L; ++j)
        o[j] = ((PPM_C1 * qm2[j]) + (PPM_C2 * qm1[j])) + (PPM_C3 * q0[j]);
    } else if (kind[s] == 1) {
      for (int64_t j = 0; j < L; ++j) {
        double lft = (((2.0 * xm1[j] + xm2[j]) * qm1[j]) - (xm1[j] * qm2[j])) / (xm2[j] + xm1[j]);
        double rgt = (((2.0 * x0[j] + xp1[j]) * q0[j]) - (x0[j] * qp1[j])) / (x0[j] + xp1[j]);
        o[j] = 0.5 * (lft + rgt);
      }
    } else {
      for (int64_t j = 0; j < L; ++j)
        o[j] = ((PPM_C3 * qm1[j]) + (PPM_C2 * q0[j])) + (PPM_C1 * qp1[j]);
    }
  }
}

#define DEFINE_HOT(M5C, UPC) \
static void hot_##M5C##_##UPC(double *restrict Xs, double *restrict Ys, double *restrict Rs, \
                              double *restrict B0s, double *restrict B1s, const double *restrict Cs, \
                              double *restrict CFs, const double *restrict Cm1s, \
                              const double *restrict CFm1s, double *restrict Qs, int64_t L) { \
  for (int64_t j = 0; j < L; ++j) { \
    double a  = Xs[j]; \
    double al = Ys[j]; \
    double r  = Rs[j]; \
    double bo = B0s[j]; \
    double bi = B1s[j]; \
    double c0 = Cs[j]; \
    double bl  = al - bi; \
    double br  = r - bi; \
    double b0  = bl + br; \
    double bl1 = a - bo; \
    double br1 = al - bo; \
    double b01 = bl1 + br1; \
    int m5  = M5C ? ((bl * br) < 0.0) : ((3.0 * fabs(b0)) < fabs(bl - br)); \
    int m51 = M5C ? ((bl1 * br1) < 0.0) : ((3.0 * fabs(b01)) < fabs(bl1 - br1)); \
    double mask = (double)(m5 | m51); \
    double xv; \
    if (c0 > 0.0) xv = bo + ((1.0 - c0) * (br1 - (c0 * b01))) * mask; \
    else          xv = bi + ((1.0 + c0) * (bl + (c0 * b0))) * mask; \
    CFs[j] = xv; \
    if (UPC) Qs[j] -= Cm1s[j] * (xv - CFm1s[j]); \
  } \
}
DEFINE_HOT(0, 0)
DEFINE_HOT(0, 1)
DEFINE_HOT(1, 0)
DEFINE_HOT(1, 1)

static void run_thread(TCtx *t, int m5, int nsteps) {
  const int64_t M = t->M, L = t->L, LM = t->Lmax, f0 = t->f0, ni = t->ni;
  double *q = t->q;
  const double *cur = t->courant;
  const double *CCb = t->CC;
  double *Xs  = t->slots + 0 * L;
  double *Ys  = t->slots + 1 * L;
  double *RTs = t->slots + 2 * L;
  double *B0s = t->slots + 3 * L;
  double *B1s = t->slots + 4 * L;

  for (int step = 0; step < nsteps; ++step) {
    if (t->has_edge) compute_edges(t);

    const double *e2 = t->has_edge ? edge_row(t, 2) : NULL;
    if (e2) { for (int64_t j = 0; j < L; ++j) Xs[j] = e2[j]; }
    else al_norm(Xs, q + 1 * M + f0, q + 2 * M + f0, q + 0 * M + f0, q + 3 * M + f0, L);

    const double *e3 = t->has_edge ? edge_row(t, 3) : NULL;
    if (e3) { for (int64_t j = 0; j < L; ++j) Ys[j] = e3[j]; }
    else al_norm(Ys, q + 2 * M + f0, q + 3 * M + f0, q + 1 * M + f0, q + 4 * M + f0, L);

    {
      const double *r2 = q + 2 * M + f0;
      const double *r3 = q + 3 * M + f0;
      for (int64_t j = 0; j < L; ++j) { B0s[j] = r2[j]; B1s[j] = r3[j]; }
    }

    for (int64_t i = 3; i <= ni + 3; ++i) {
      const double *q1s = q + (i + 1) * M + f0;
      const double *q2s = q + (i + 2) * M + f0;
      const double *e = t->has_edge ? edge_row(t, i + 1) : NULL;
      if (e) { for (int64_t j = 0; j < L; ++j) RTs[j] = e[j]; }
      else al_norm(RTs, B1s, q1s, B0s, q2s, L);
      const double *Cs = CCb ? CCb + i * LM : cur + i * M + f0;
      double *CFs = t->xf + i * M + f0;
      if (i == 3) {
        if (m5) hot_1_0(Xs, Ys, RTs, B0s, B1s, Cs, CFs, NULL, NULL, NULL, L);
        else    hot_0_0(Xs, Ys, RTs, B0s, B1s, Cs, CFs, NULL, NULL, NULL, L);
      } else {
        const double *Cm1s = CCb ? CCb + (i - 1) * LM : cur + (i - 1) * M + f0;
        const double *CFm1s = t->xf + (i - 1) * M + f0;
        double *Qs = q + (i - 1) * M + f0;
        if (m5) hot_1_1(Xs, Ys, RTs, B0s, B1s, Cs, CFs, Cm1s, CFm1s, Qs, L);
        else    hot_0_1(Xs, Ys, RTs, B0s, B1s, Cs, CFs, Cm1s, CFm1s, Qs, L);
      }
      double *tmp;
      tmp = Xs; Xs = Ys; Ys = RTs; RTs = tmp;
      tmp = B0s; B0s = B1s; B1s = tmp;
      for (int64_t j = 0; j < L; ++j) B1s[j] = q1s[j];
    }
  }
}

static size_t round64(size_t n) { return (n + 63) & ~(size_t)63; }

void fv3_xppm_fp64(const double *restrict courant, const double *restrict dxa,
                   double *restrict q, double *restrict xflux,
                   const int64_t grid_type, const int64_t iord,
                   const int64_t ni, const int64_t nj, const int64_t nk,
                   const int64_t nsteps, uint8_t *restrict workspace,
                   const int64_t workspace_size) {
  (void)workspace; (void)workspace_size;
  if (nsteps <= 0 || ni <= 0 || nj <= 0 || nk <= 0) return;
  const int64_t nhalo = 3;
  const int64_t nx = nhalo + ni + nhalo;
  const int64_t M = nj * nk;
  const int has_edge = (grid_type < 3) ? 1 : 0;
  const int m5 = (llabs(iord) == 5) ? 1 : 0;

  int T = (int)omp_get_max_threads();
  if (T > 64) T = 64;
  if (T > (int)M) T = (int)M;
  if (T < 1) T = 1;

  const int64_t base = M / T, rem = M % T;
  const int64_t Lmax = base + (rem > 0 ? 1 : 0);

  /* Team is created before the per-thread allocations, so thread stacks are
   * reserved while the address-space quota of this process is still free. */
  #pragma omp parallel num_threads(T)
  {
    const int t = omp_get_thread_num();
    const int64_t f0 = (int64_t)t * base + (t < (int)rem ? (int64_t)t : rem);
    const int64_t L = base + (t < (int)rem ? 1 : 0);
    double *slots = (double *)aligned_alloc(64, round64((size_t)5 * Lmax * 8));
    double *Eb = has_edge ? (double *)aligned_alloc(64, round64((size_t)6 * Lmax * 8)) : NULL;
    double *CC = NULL;
    if (slots && (!has_edge || Eb)) {
      CC = (double *)aligned_alloc(64, round64((size_t)nx * (size_t)Lmax * 8));
      if (CC) {
        for (int64_t i = 0; i < nx; ++i)
          memcpy(CC + i * Lmax, courant + i * M + f0, (size_t)L * 8);
      }
      TCtx tc;
      tc.q = q;
      tc.courant = courant;
      tc.dxa = dxa;
      tc.xf = xflux;
      tc.M = M;
      tc.f0 = f0;
      tc.L = L;
      tc.Lmax = Lmax;
      tc.nx = nx;
      tc.ni = ni;
      tc.has_edge = has_edge;
      tc.slots = slots;
      tc.E = Eb;
      tc.ecol[0] = 2;
      tc.ecol[1] = (int)ni + 2;
      tc.ecol[2] = 3;
      tc.ecol[3] = (int)ni + 3;
      tc.ecol[4] = 4;
      tc.ecol[5] = (int)ni + 4;
      tc.CC = CC;
      run_thread(&tc, m5, (int)nsteps);
    }
    free(slots);
    free(Eb);
    free(CC);
  }
}
