// Optimized 2D Jacobi (5-point stencil) alternating sweep.
// v2: fused 2-pass step. Pass 1: B = 0.2 L(A) (5-tap, NT stores, row prefetch).
// Pass 2: A = 0.2 L(B), computed for interior rows as the 13-point 0.04 L^2(A)
// stencil, re-reading A from L3/L2 (chunk-local, one A fabric read per step)
// instead of re-reading freshly written B from memory. Rows that are not valid
// for the 13-point form (chunk start, j=1 column, row N-2) use the exact
// 5-point formula on the freshly computed B. A-new rows are written back with
// a 2-row delay (per-thread ring in workspace) so the 13-point reads of A_old
// rows i-2..i-1 see pre-update values.
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#if defined(__AVX512F__) || defined(__AVX2__)
#include <immintrin.h>
#endif
#if defined(__AVX512F__)
#define JAVX 512
#elif defined(__AVX2__)
#define JAVX 256
#else
#define JAVX 0
#endif

#define FM 16 /* rows per chunk */

#if JAVX == 512

/* d[1..N-2] = 0.2*(s1 + s1sh + s2 + s0), non-temporal stores, optional row-ahead
 * prefetch of s3. `pf` row pointer must be valid when pf != 0. */
static inline void row5_nt(const double *s0, const double *s1, const double *s2,
                           const double *s3, double *d, int64_t N, int64_t i, int pf) {
    const __m512d c02 = _mm512_set1_pd(0.2);
    const int64_t iN = i * N;
    const int64_t a = (8 - (iN & 7)) & 7;
    int64_t L = (a >= 1) ? a : 8;
    const int64_t Jmax = N - 9;
    int64_t R = (Jmax >= L) ? (L + ((Jmax - L) & ~7)) : L - 1;
    int64_t j = 1;
    if (R >= L) {
        for (; j < L; ++j) d[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
        if (pf) {
            for (; j <= R; j += 8) {
                __m512d x = _mm512_loadu_pd(s1 + j);
                x = _mm512_add_pd(x, _mm512_loadu_pd(s1 + j - 1));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s1 + j + 1));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s2 + j));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s0 + j));
                x = _mm512_mul_pd(x, c02);
                _mm512_stream_pd(d + j, x);
                _mm_prefetch((const char *)(s3 + j), _MM_HINT_T0);
            }
        } else {
            for (; j <= R; j += 8) {
                __m512d x = _mm512_loadu_pd(s1 + j);
                x = _mm512_add_pd(x, _mm512_loadu_pd(s1 + j - 1));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s1 + j + 1));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s2 + j));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s0 + j));
                x = _mm512_mul_pd(x, c02);
                _mm512_stream_pd(d + j, x);
            }
        }
        for (; j <= N - 2; ++j) d[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
    } else {
        for (; j <= N - 2; ++j) d[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
    }
}

/* w[1..N-2] = 0.2*(s1 + s1sh + s2 + s0), normal stores into scratch row w. */
static inline void row5_w(const double *s0, const double *s1, const double *s2,
                          double *w, int64_t N) {
    const __m512d c02 = _mm512_set1_pd(0.2);
    int64_t j = 1;
    for (; j + 8 <= N - 1; j += 8) {
        __m512d x = _mm512_loadu_pd(s1 + j);
        x = _mm512_add_pd(x, _mm512_loadu_pd(s1 + j - 1));
        x = _mm512_add_pd(x, _mm512_loadu_pd(s1 + j + 1));
        x = _mm512_add_pd(x, _mm512_loadu_pd(s2 + j));
        x = _mm512_add_pd(x, _mm512_loadu_pd(s0 + j));
        x = _mm512_mul_pd(x, c02);
        _mm512_storeu_pd(w + j, x);
    }
    for (; j <= N - 2; ++j) w[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
}

/* 13-point stencil row: w[j] = 0.04 L^2(A)[i,j] for j = 2..N-2 (SIMD, normal
 * stores), w[1] left untouched (caller handles column 1). Rows m2..p2 are A rows
 * i-2..i+2. */
static inline void row13_w(const double *m2, const double *m1, const double *m0,
                           const double *p1, const double *p2, double *w, int64_t N) {
    const __m512d c20 = _mm512_set1_pd(0.20), c08 = _mm512_set1_pd(0.08),
                  c04 = _mm512_set1_pd(0.04);
    int64_t j = 2;
    for (; j + 8 <= N - 1; j += 8) {
        __m512d c  = _mm512_loadu_pd(m0 + j);
        __m512d t1 = _mm512_add_pd(_mm512_loadu_pd(m0 + j - 1), _mm512_loadu_pd(m0 + j + 1));
        t1 = _mm512_add_pd(t1, _mm512_add_pd(_mm512_loadu_pd(m1 + j), _mm512_loadu_pd(p1 + j)));
        __m512d t3 = _mm512_add_pd(_mm512_loadu_pd(m1 + j - 1), _mm512_loadu_pd(m1 + j + 1));
        t3 = _mm512_add_pd(t3, _mm512_add_pd(_mm512_loadu_pd(p1 + j - 1), _mm512_loadu_pd(p1 + j + 1)));
        __m512d t5 = _mm512_add_pd(_mm512_add_pd(_mm512_loadu_pd(m0 + j - 2), _mm512_loadu_pd(m0 + j + 2)),
                                   _mm512_add_pd(_mm512_loadu_pd(m2 + j), _mm512_loadu_pd(p2 + j)));
        __m512d x = _mm512_mul_pd(c, c20);
        x = _mm512_fmadd_pd(t1, c08, x);
        x = _mm512_fmadd_pd(t3, c08, x);
        x = _mm512_fmadd_pd(t5, c04, x);
        _mm512_storeu_pd(w + j, x);
    }
    for (; j <= N - 2; ++j)
        w[j] = 0.2 * m0[j]
             + 0.08 * (m0[j-1] + m0[j+1] + m1[j] + p1[j])
             + 0.08 * (m1[j-1] + m1[j+1] + p1[j-1] + p1[j+1])
             + 0.04 * (m0[j-2] + m0[j+2] + m2[j] + p2[j]);
}

/* exact 5-point value for column j=1 on freshly computed B rows b0, b1, b2. */
static inline double b5_col1(const double *b0, const double *b1, const double *b2) {
    return 0.2 * (b1[1] + b1[0] + b1[2] + b2[1] + b0[1]);
}

/* d[jmin..N-2] = w[jmin..N-2] (d = A row i), NT aligned windows, normal tails. */
static inline void copy_row_nt(const double *w, double *d, int64_t N, int64_t i, int64_t jmin) {
    const int64_t iN = i * N;
    const int64_t a = (8 - (iN & 7)) & 7;
    int64_t L = (a >= 1) ? a : 8;
    if (L < jmin) L = jmin + ((jmin - L + 7) & 7);
    const int64_t Jmax = N - 9;
    int64_t R = (Jmax >= L) ? (L + ((Jmax - L) & ~7)) : L - 1;
    int64_t j = jmin;
    if (R >= L) {
        for (; j < L; ++j) d[j] = w[j];
        for (; j <= R; j += 8) _mm512_stream_pd(d + j, _mm512_loadu_pd(w + j));
        for (; j <= N - 2; ++j) d[j] = w[j];
    } else {
        for (; j <= N - 2; ++j) d[j] = w[j];
    }
}

static inline void prefetch_row(const double *r, int64_t N) {
    for (int64_t j = 0; j + 8 <= N; j += 8) _mm_prefetch((const char *)(r + j), _MM_HINT_T0);
}

#endif /* JAVX == 512 */
