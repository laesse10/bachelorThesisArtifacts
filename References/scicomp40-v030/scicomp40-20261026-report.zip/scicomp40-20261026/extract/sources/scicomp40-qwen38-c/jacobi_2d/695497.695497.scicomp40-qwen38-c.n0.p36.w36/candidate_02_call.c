// Optimized 2D Jacobi (5-point stencil) alternating sweep.
// Row-partitioned OpenMP + SIMD (AVX-512/AVX2/scalar) with non-temporal
// interior stores and row-ahead prefetching.
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#if defined(__AVX512F__) || defined(__AVX2__)
#include <immintrin.h>
#endif

#if defined(__AVX512F__)
#define JAVX 512
#elif defined(__AVX2__)
#define JAVX 256
#else
#define JAVX 0
#endif

#if JAVX == 512
static inline void jac_row(const double *s0, const double *s1, const double *s2,
                           const double *s3, double *d, int64_t N, int64_t i,
                           const int64_t last_row) {
    const __m512d c02 = _mm512_set1_pd(0.2);
    const int64_t iN = i * N;
    const int64_t a = (8 - (iN & 7)) & 7;          /* j offset giving 64B-aligned d[j] */
    int64_t L = (a >= 1) ? a : 8;                  /* first aligned j >= 1             */
    const int64_t Jmax = N - 9;                    /* window [j, j+8) inside [1, N-2]  */
    int64_t R = (Jmax >= L) ? (L + ((Jmax - L) & ~7)) : L - 1;
    int64_t j = 1;
    if (R >= L) {
        for (; j < L; ++j)
            d[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
        if (i + 2 <= last_row) {
            for (; j <= R; j += 8) {
                __m512d x = _mm512_loadu_pd(s1 + j);
                x = _mm512_add_pd(x, _mm512_loadu_pd(s1 + j - 1));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s1 + j + 1));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s2 + j));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s0 + j));
                x = _mm512_mul_pd(x, c02);
                _mm512_stream_pd(d + j, x);
                _mm_prefetch((const char *)(s3 + j), _MM_HINT_T0);
            }
        } else {
            for (; j <= R; j += 8) {
                __m512d x = _mm512_loadu_pd(s1 + j);
                x = _mm512_add_pd(x, _mm512_loadu_pd(s1 + j - 1));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s1 + j + 1));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s2 + j));
                x = _mm512_add_pd(x, _mm512_loadu_pd(s0 + j));
                x = _mm512_mul_pd(x, c02);
                _mm512_stream_pd(d + j, x);
            }
        }
        for (; j <= N - 2; ++j)
            d[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
    } else {
        for (; j <= N - 2; ++j)
            d[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
    }
}
#elif JAVX == 256
static inline void jac_row(const double *s0, const double *s1, const double *s2,
                           const double *s3, double *d, int64_t N, int64_t i,
                           const int64_t last_row) {
    (void)s3;
    const __m256d c02 = _mm256_set1_pd(0.2);
    const int64_t iN = i * N;
    const int64_t a = (4 - (iN & 3)) & 3;
    int64_t L = (a >= 1) ? a : 4;
    const int64_t Jmax = N - 5;
    int64_t R = (Jmax >= L) ? (L + ((Jmax - L) & ~3)) : L - 1;
    int64_t j = 1;
    if (R >= L) {
        for (; j < L; ++j)
            d[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
        for (; j <= R; j += 4) {
            __m256d x = _mm256_loadu_pd(s1 + j);
            x = _mm256_add_pd(x, _mm256_loadu_pd(s1 + j - 1));
            x = _mm256_add_pd(x, _mm256_loadu_pd(s1 + j + 1));
            x = _mm256_add_pd(x, _mm256_loadu_pd(s2 + j));
            x = _mm256_add_pd(x, _mm256_loadu_pd(s0 + j));
            x = _mm256_mul_pd(x, c02);
            _mm256_stream_pd(d + j, x);
        }
        for (; j <= N - 2; ++j)
            d[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
    } else {
        for (; j <= N - 2; ++j)
            d[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
    }
}
#else
static inline void jac_row(const double *s0, const double *s1, const double *s2,
                           const double *s3, double *d, int64_t N, int64_t i,
                           const int64_t last_row) {
    (void)s3; (void)last_row; (void)i;
    for (int64_t j = 1; j <= N - 2; ++j)
        d[j] = 0.2 * (s1[j] + s1[j-1] + s1[j+1] + s2[j] + s0[j]);
}
#endif

void jacobi_2d_fp64(double *restrict A, double *restrict B, const int64_t N, const int64_t TSTEPS,
                    uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace; (void)workspace_size;
    if (N < 3 || TSTEPS <= 0) return;
    const int64_t rows = N - 2;
    #pragma omp parallel
    {
        const int nt = omp_get_num_threads();
        const int tid = omp_get_thread_num();
        const int64_t b = (rows * tid) / nt;
        const int64_t e = (rows * (tid + 1)) / nt;
        for (int64_t t = 0; t < TSTEPS; ++t) {
            for (int64_t k = b; k < e; ++k) {
                const int64_t i = k + 1;
                jac_row(A + (i-1)*N, A + i*N, A + (i+1)*N, A + (i+2)*N,
                        B + i*N, N, i, N - 1);
            }
            #pragma omp barrier
            for (int64_t k = b; k < e; ++k) {
                const int64_t i = k + 1;
                jac_row(B + (i-1)*N, B + i*N, B + (i+1)*N, B + (i+2)*N,
                        A + i*N, N, i, N - 1);
            }
            #pragma omp barrier
        }
    }
}
