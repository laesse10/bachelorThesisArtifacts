/* Rayleigh-Ritz subspace projection and rotation.
 *
 * h_sub = X^T W, s_sub = X^T X (tall-skinny Grams), symmetrize,
 * L = chol(s_sub), Linv = inv(L), M = Linv h_sub Linv^T,
 * (w, U) = eigh(M) with sign-gauge fix, C = Linv^T U, Xrot = X C, evals = w.
 *
 * Optimizations vs reference:
 *  - one fused pass over X and W computes both Grams (no transposes, no copies);
 *  - LAPACK (dpotrf/dtrtri/dsyevd) for the k x k pieces;
 *  - the final rotation is a hand-rolled OpenMP outer-product kernel.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <omp.h>

static int g_dbg = -1;
static void dbg(const char *tag, const double *p, int64_t n) {
    if (g_dbg < 0) g_dbg = (getenv("RR_DBG") != NULL);
    if (!g_dbg) return;
    double m = 0; int nn = 0;
    for (int64_t i = 0; i < n; i++) {
        double v = p[i];
        if (v != v) nn++;
        if (v > m) m = v;
    }
    fprintf(stderr, "[dbg] %s: first=%.6g %.6g max=%.6g nan=%lld n=%lld\n",
            tag, p[0], p[n > 1 ? 1 : 0], m, (long long)nn, (long long)n);
}
/* LAPACK (column-major Fortran ABI, provided by the linked OpenBLAS). */
extern void dpotrf_(char *uplo, const int *n, double *a, const int *lda, int *info);
extern void dtrtri_(char *uplo, char *diag, const int *n, double *a, const int *lda, int *info);
extern void dsyevd_(char *jobz, char *uplo, const int *n, double *a, const int *lda,
                    double *w, double *work, const int *lwork, int *iwork, const int *liwork,
                    int *info);

/* Small row-major GEMM: C = A B  (n x n), rows split over threads. */
static void gemm_rm(const double *restrict A, const double *restrict B,
                    double *restrict C, int64_t n, int nt) {
    int64_t chunk = (n + nt - 1) / nt;
    #pragma omp parallel num_threads(nt)
    {
        int64_t r0 = (int64_t)omp_get_thread_num() * chunk;
        int64_t r1 = r0 + chunk; if (r1 > n) r1 = n;
        for (int64_t i = r0; i < r1; i++) {
            double *cr = C + i * n;
            for (int64_t j = 0; j < n; j++) cr[j] = 0.0;
            for (int64_t p = 0; p < n; p++) {
                double ap = A[i * n + p];
                const double *br = B + p * n;
                for (int64_t j = 0; j < n; j++) cr[j] += ap * br[j];
            }
        }
    }
}

void rayleigh_ritz_rotation_fp64(const double *restrict W, const double *restrict X,
                                 double *restrict Xrot, double *restrict evals,
                                 const int64_t k, const int64_t ngrid,
                                 uint8_t *restrict workspace,
                                 const int64_t workspace_size) {
    int nt = omp_get_max_threads();
    if (nt < 1) nt = 1;
    int64_t ki = (int64_t)k;

    /* scratch: 7 k^2 buffers (H,S,Tbuf,D,M,U,C), per-thread Ht/St (2*nt k^2),
       eig work (12k doubles) + iwork (12k ints). */
    int64_t k2 = k * k;
    int64_t nbuf = 7 * k2 + 2 * (int64_t)nt * k2; /* 7 k^2 + per-thread Ht/St */
    int64_t nw = k + 12 * k;                      /* eigvalues + dsyevd work */
    int64_t need = (nbuf + nw) * (int64_t)sizeof(double)
                 + 12 * k * (int64_t)sizeof(int) + 64;
    double *buf, *buf_raw = NULL;
    int *iwork;
    int used_ws = (workspace != NULL) && (workspace_size >= need);
    if (used_ws) {
        buf = (double *)(((uintptr_t)workspace + 63) & ~(uintptr_t)63);
        iwork = (int *)(buf + nbuf + nw);
    } else {
        buf_raw = (double *)malloc((size_t)need + 64);
        if (!buf_raw) {
            fprintf(stderr, "rayleigh_ritz_rotation: out of memory (%lld bytes)\n",
                    (long long)need);
            abort();
        }
        buf = (double *)(((uintptr_t)buf_raw + 63) & ~(uintptr_t)63);
        iwork = (int *)(buf + nbuf + nw);
    }
    double *H = buf, *S = buf + k2, *Tbuf = buf + 2 * k2, *D = buf + 3 * k2,
           *M = buf + 4 * k2, *U = buf + 5 * k2, *C = buf + 6 * k2;
    double *Ht_all = buf + 7 * k2;       /* per-thread Gram accumulators */
    double *w = Ht_all + 2 * (int64_t)nt * k2; /* eigvalues, k */
    double *work = w + k;                /* dsyevd work, 12k */

    /* ---- Phase 1: fused Grams, one pass over X and W ---- */
    for (int64_t ij = 0; ij < k2; ij++) { H[ij] = 0.0; S[ij] = 0.0; }
    #pragma omp parallel num_threads(nt)
    {
        int64_t tid = omp_get_thread_num();
        double *restrict Ht = Ht_all + tid * k2;
        double *restrict St = Ht_all + ((int64_t)nt + tid) * k2;
        for (int64_t ij = 0; ij < k2; ij++) { Ht[ij] = 0.0; St[ij] = 0.0; }
        int64_t r0 = (ngrid * tid) / nt, r1 = (ngrid * (tid + 1)) / nt;
        for (int64_t r = r0; r < r1; r++) {
            const double *restrict xr = X + r * ki;
            const double *restrict wr = W + r * ki;
            for (int64_t i = 0; i < k; i++) {
                double xi = xr[i];
                double *hi = Ht + i * k;
                double *si = St + i * k;
                for (int64_t j = 0; j < k; j++) {
                    hi[j] += xi * wr[j];
                    si[j] += xi * xr[j];
                }
            }
        }
        #pragma omp critical
        {
            for (int64_t ij = 0; ij < k2; ij++) { H[ij] += Ht[ij]; S[ij] += St[ij]; }
        }
    }

    dbg("H", H, k2); dbg("S", S, k2);
    /* ---- Phase 2: k x k algebra ---- */
    for (int64_t i = 0; i < k; i++)
        for (int64_t j = i + 1; j < k; j++) {
            double h = 0.5 * (H[i * k + j] + H[j * k + i]);
            double s = 0.5 * (S[i * k + j] + S[j * k + i]);
            H[i * k + j] = h; H[j * k + i] = h;
            S[i * k + j] = s; S[j * k + i] = s;
        }

    /* S row-major symmetric; column-major view is S^T = S.
       dpotrf('L') overwrites the buffer with lower L (cm view): S = L L^T.
       dtrtri('L','N') then inverts it: buffer cm view = Linv, so the
       row-major read of the buffer is Linv^T. */
    int info = 0, n32 = (int)k;
    dbg("S_pre_chol", S, k2);
    dpotrf_((char *)"L", &n32, S, &n32, &info);
    fprintf(stderr, "[dbg] dpotrf info=%d diag: %.6g %.6g %.6g\n", info, S[0], S[k*1+1], S[k*2+2]);
    dtrtri_((char *)"L", (char *)"N", &n32, S, &n32, &info);
    dbg("S_post_tri", S, k2);
    /* Buffer cm view is now Linv (lower); its row-major upper triangle IS
       Linv^T. LAPACK leaves the unreferenced triangle untouched, so build
       Tbuf = Linv^T explicitly. */
    for (int64_t i = 0; i < k; i++)
        for (int64_t j = 0; j < k; j++)
            Tbuf[i * k + j] = (i <= j) ? S[i * k + j] : 0.0;

    /* Linv = Tbuf^T, then M = (Linv H) Linv^T with contiguous row-major gemms. */
    for (int64_t i = 0; i < k; i++)
        for (int64_t j = 0; j < k; j++) D[i * k + j] = Tbuf[j * k + i];
    gemm_rm(D, H, U, ki, nt);        /* U := Linv @ H */
    gemm_rm(U, Tbuf, M, ki, nt);     /* M := (Linv H) @ Linv^T */

    for (int64_t i = 0; i < k; i++)
        for (int64_t j = i + 1; j < k; j++) {
            double m = 0.5 * (M[i * k + j] + M[j * k + i]);
            M[i * k + j] = m; M[j * k + i] = m;
        }

    dbg("M", M, k2);
    int lwork = 12 * k, liwork = 12 * k;
    dsyevd_((char *)"V", (char *)"U", &n32, M, &n32, w, work, &lwork, iwork, &liwork, &info);
    fprintf(stderr, "[dbg] dsyevd info=%d w0=%.9g w1=%.9g\n", info, w[0], w[1]);
    dbg("V", M, k2); dbg("w", w, k);

    for (int64_t i = 0; i < k; i++)
        for (int64_t j = 0; j < k; j++) U[i * k + j] = M[i + j * k];
    for (int64_t j = 0; j < k; j++) {
        double best = -1.0; int64_t bi = 0;
        for (int64_t i = 0; i < k; i++) {
            double a = U[i * k + j]; if (a < 0) a = -a;
            if (a > best) { best = a; bi = i; }
        }
        double sgn = U[bi * k + j] < 0.0 ? -1.0 : 1.0;
        for (int64_t i = 0; i < k; i++) U[i * k + j] *= sgn;
    }
    gemm_rm(Tbuf, U, C, ki, nt); /* C = (Linv^T) U row-major = Linv^T U */

    /* ---- Phase 3: rotation Xrot = X C ---- */
    #pragma omp parallel num_threads(nt)
    {
        int64_t tid = omp_get_thread_num();
        int64_t r0 = (ngrid * tid) / nt, r1 = (ngrid * (tid + 1)) / nt;
        for (int64_t r = r0; r < r1; r++) {
            const double *restrict xr = X + r * ki;
            double *orow = Xrot + r * ki;
            for (int64_t j = 0; j < k; j++) orow[j] = 0.0;
            for (int64_t i = 0; i < k; i++) {
                double ci = xr[i];
                const double *cr = C + i * k;
                for (int64_t j = 0; j < k; j++) orow[j] += ci * cr[j];
            }
        }
    }
    memcpy(evals, w, (size_t)k * sizeof(double));
    if (!used_ws) free(buf_raw);
}
