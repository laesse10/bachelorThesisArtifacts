// hpcagent_bench -- optimized GEMM:  C := alpha * A @ B + beta * C
// A: NI x NK (row-major), B: NK x NJ (row-major), C: NI x NJ (row-major)
//
// AVX-512 blocked GEMM (Zen4: 2 zmm FMA/cycle):
//   - per thread: contiguous 48-column j-panels
//   - i-panels M1=64 rows keep A panel (12.5 MB) + B j-panel (9.4 MB) in one
//     32 MB L3 slice (A shared by all threads of the same i-panel)
//   - micro-tile MR=2 rows x NR=48 cols, scalar k loop:
//       2 scalar A loads + 2 broadcasts + 6 zmm loadu + 12 FMAs ~ 7 cyc/k
//       -> ~27 FLOP/cycle per thread
//   - n-tail (<8 cols) via scalar FMAs; all 512-bit ops are loadu/storeu
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

#define MR 2
#define NR 48
#define M1 64

static inline void scale_vec(double *restrict X, int64_t n, double s) {
    if (s == 1.0) return;
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < n; i++) X[i] *= s;
}

void gemm_fp64(
    const double *restrict A,
    const double *restrict B,
    double *restrict C,
    const int64_t NI,
    const int64_t NJ,
    const int64_t NK,
    const double alpha,
    const double beta,
    uint8_t *restrict workspace,
    const int64_t workspace_size) {
    (void)workspace; (void)workspace_size;
    const int64_t m = NI, n = NJ, k = NK;
    if (m <= 0 || n <= 0) return;

    if (alpha == 0.0) {              // C := beta * C
        scale_vec(C, m * n, beta);
        return;
    }
    if (k <= 0) {                    // A@B := 0  ->  C := beta * C
        scale_vec(C, m * n, beta);
        return;
    }

    if (m < 16 || n < 32 || k < 16) { // tiny: serial triple loop
        for (int64_t i = 0; i < m; i++)
            for (int64_t j = 0; j < n; j++) {
                double s = 0;
                for (int64_t kk = 0; kk < k; kk++)
                    s += A[i * k + kk] * B[kk * n + j];
                C[i * n + j] = alpha * s + beta * C[i * n + j];
            }
        return;
    }

    const int T = omp_get_max_threads();
    const int64_t total_jp = (n + NR - 1) / NR;

    #pragma omp parallel
    {
        const int t = omp_get_thread_num();
        const int64_t per = (total_jp + T - 1) / T;
        int64_t jp0 = t * per, jp1 = jp0 + per;
        if (jp0 > total_jp) jp0 = total_jp;
        if (jp1 > total_jp) jp1 = total_jp;

        for (int64_t m0 = 0; m0 < m; m0 += M1) {
            const int64_t m1 = m0 + M1 < m ? M1 : m - m0;
            for (int64_t i0 = m0; i0 < m0 + m1; i0 += MR) {
                const int rows = (i0 + MR <= m) ? MR : (int)(m - i0);
                for (int64_t jp = jp0; jp < jp1; jp++) {
                    const int64_t jcol = jp * NR;
                    const int cols = (jcol + NR <= n) ? NR : (int)(n - jcol);
                    const int ng = cols / 8;
                    const int tail = cols - ng * 8;
                    if (ng <= 0 && tail <= 0) continue;
                    const double *B0 = B + jcol;
                    double *C0 = C + i0 * n + jcol;
                    const double *ar[MR];
                    for (int r = 0; r < rows; r++) ar[r] = A + (i0 + r) * k;

                    if (rows == 2 && ng == 6) {
                        // ---- hot path: full 2x48 panel, acc in registers --
                        __m512d c00 = _mm512_setzero_pd(), c01 = _mm512_setzero_pd(),
                                 c02 = _mm512_setzero_pd(), c03 = _mm512_setzero_pd(),
                                 c04 = _mm512_setzero_pd(), c05 = _mm512_setzero_pd();
                        __m512d c10 = _mm512_setzero_pd(), c11 = _mm512_setzero_pd(),
                                 c12 = _mm512_setzero_pd(), c13 = _mm512_setzero_pd(),
                                 c14 = _mm512_setzero_pd(), c15 = _mm512_setzero_pd();
                        const double *a0 = ar[0], *a1 = ar[1];
                        const double *bp = B0;
                        const int kk = (int)k;
                        for (int i = 0; i < kk; i++) {
                            __m512d b0 = _mm512_loadu_pd(bp);
                            __m512d b1 = _mm512_loadu_pd(bp + 8);
                            __m512d b2 = _mm512_loadu_pd(bp + 16);
                            __m512d b3 = _mm512_loadu_pd(bp + 24);
                            __m512d b4 = _mm512_loadu_pd(bp + 32);
                            __m512d b5 = _mm512_loadu_pd(bp + 40);
                            bp += n;
                            __m512d z = _mm512_set1_pd(a0[0]);
                            a0 += k;
                            c00 = _mm512_fmadd_pd(z, b0, c00);
                            c01 = _mm512_fmadd_pd(z, b1, c01);
                            c02 = _mm512_fmadd_pd(z, b2, c02);
                            c03 = _mm512_fmadd_pd(z, b3, c03);
                            c04 = _mm512_fmadd_pd(z, b4, c04);
                            c05 = _mm512_fmadd_pd(z, b5, c05);
                            z = _mm512_set1_pd(a1[0]);
                            a1 += k;
                            c10 = _mm512_fmadd_pd(z, b0, c10);
                            c11 = _mm512_fmadd_pd(z, b1, c11);
                            c12 = _mm512_fmadd_pd(z, b2, c12);
                            c13 = _mm512_fmadd_pd(z, b3, c13);
                            c14 = _mm512_fmadd_pd(z, b4, c14);
                            c15 = _mm512_fmadd_pd(z, b5, c15);
                        }
                        double *Cr0 = C0, *Cr1 = C0 + n;
                        if (beta == 0.0) {
                            if (alpha == 1.0) {
                                _mm512_storeu_pd(Cr0,     c00);
                                _mm512_storeu_pd(Cr0 + 8,  c01);
                                _mm512_storeu_pd(Cr0 + 16, c02);
                                _mm512_storeu_pd(Cr0 + 24, c03);
                                _mm512_storeu_pd(Cr0 + 32, c04);
                                _mm512_storeu_pd(Cr0 + 40, c05);
                                _mm512_storeu_pd(Cr1,     c10);
                                _mm512_storeu_pd(Cr1 + 8,  c11);
                                _mm512_storeu_pd(Cr1 + 16, c12);
                                _mm512_storeu_pd(Cr1 + 24, c13);
                                _mm512_storeu_pd(Cr1 + 32, c14);
                                _mm512_storeu_pd(Cr1 + 40, c15);
                            } else {
                                __m512d za = _mm512_set1_pd(alpha);
                                _mm512_storeu_pd(Cr0,     _mm512_mul_pd(za, c00));
                                _mm512_storeu_pd(Cr0 + 8,  _mm512_mul_pd(za, c01));
                                _mm512_storeu_pd(Cr0 + 16, _mm512_mul_pd(za, c02));
                                _mm512_storeu_pd(Cr0 + 24, _mm512_mul_pd(za, c03));
                                _mm512_storeu_pd(Cr0 + 32, _mm512_mul_pd(za, c04));
                                _mm512_storeu_pd(Cr0 + 40, _mm512_mul_pd(za, c05));
                                _mm512_storeu_pd(Cr1,     _mm512_mul_pd(za, c10));
                                _mm512_storeu_pd(Cr1 + 8,  _mm512_mul_pd(za, c11));
                                _mm512_storeu_pd(Cr1 + 16, _mm512_mul_pd(za, c12));
                                _mm512_storeu_pd(Cr1 + 24, _mm512_mul_pd(za, c13));
                                _mm512_storeu_pd(Cr1 + 32, _mm512_mul_pd(za, c14));
                                _mm512_storeu_pd(Cr1 + 40, _mm512_mul_pd(za, c15));
                            }
                        } else {
                            __m512d za = _mm512_set1_pd(alpha), zb = _mm512_set1_pd(beta);
                            __m512d v;
                            v = _mm512_loadu_pd(Cr0);     c00 = _mm512_fmadd_pd(za, c00, _mm512_mul_pd(zb, v));
                            v = _mm512_loadu_pd(Cr0 + 8);  c01 = _mm512_fmadd_pd(za, c01, _mm512_mul_pd(zb, v));
                            v = _mm512_loadu_pd(Cr0 + 16); c02 = _mm512_fmadd_pd(za, c02, _mm512_mul_pd(zb, v));
                            v = _mm512_loadu_pd(Cr0 + 24); c03 = _mm512_fmadd_pd(za, c03, _mm512_mul_pd(zb, v));
                            v = _mm512_loadu_pd(Cr0 + 32); c04 = _mm512_fmadd_pd(za, c04, _mm512_mul_pd(zb, v));
                            v = _mm512_loadu_pd(Cr0 + 40); c05 = _mm512_fmadd_pd(za, c05, _mm512_mul_pd(zb, v));
                            _mm512_storeu_pd(Cr0,     c00);
                            _mm512_storeu_pd(Cr0 + 8,  c01);
                            _mm512_storeu_pd(Cr0 + 16, c02);
                            _mm512_storeu_pd(Cr0 + 24, c03);
                            _mm512_storeu_pd(Cr0 + 32, c04);
                            _mm512_storeu_pd(Cr0 + 40, c05);
                            v = _mm512_loadu_pd(Cr1);     c10 = _mm512_fmadd_pd(za, c10, _mm512_mul_pd(zb, v));
                            v = _mm512_loadu_pd(Cr1 + 8);  c11 = _mm512_fmadd_pd(za, c11, _mm512_mul_pd(zb, v));
                            v = _mm512_loadu_pd(Cr1 + 16); c12 = _mm512_fmadd_pd(za, c12, _mm512_mul_pd(zb, v));
                            v = _mm512_loadu_pd(Cr1 + 24); c13 = _mm512_fmadd_pd(za, c13, _mm512_mul_pd(zb, v));
                            v = _mm512_loadu_pd(Cr1 + 32); c14 = _mm512_fmadd_pd(za, c14, _mm512_mul_pd(zb, v));
                            v = _mm512_loadu_pd(Cr1 + 40); c15 = _mm512_fmadd_pd(za, c15, _mm512_mul_pd(zb, v));
                            _mm512_storeu_pd(Cr1,     c10);
                            _mm512_storeu_pd(Cr1 + 8,  c11);
                            _mm512_storeu_pd(Cr1 + 16, c12);
                            _mm512_storeu_pd(Cr1 + 24, c13);
                            _mm512_storeu_pd(Cr1 + 32, c14);
                            _mm512_storeu_pd(Cr1 + 40, c15);
                        }
                        continue;
                    }

                    __m512d acc[MR][NR / 8];
                    memset(acc, 0, sizeof acc);

                    if (rows == 2) {
                        // ---- 2 x (ng*8) panel, scalar tail ---------------
                        const double *a0 = ar[0], *a1 = ar[1];
                        const int kk = (int)k;
                        double t0[8] = {0}, t1[8] = {0};
                        if (ng == 0) {
                            const double *b0 = B0;
                            for (int i = 0; i < kk; i++) {
                                for (int jt = 0; jt < tail; jt++) {
                                    t0[jt] += a0[0] * b0[jt];
                                    t1[jt] += a1[0] * b0[jt];
                                }
                                a0 += k; a1 += k; b0 += n;
                            }
                        } else {
                            __m512d b[NR / 8];
                            for (int i = 0; i < kk; i++) {
                                for (int jg = 0; jg < ng; jg++)
                                    b[jg] = _mm512_loadu_pd(B0 + (int64_t)i * n + jg * 8);
                                double x0 = a0[0], x1 = a1[0];
                                const double *bt = B0 + (int64_t)i * n + ng * 8;
                                for (int jt = 0; jt < tail; jt++) {
                                    t0[jt] += x0 * bt[jt];
                                    t1[jt] += x1 * bt[jt];
                                }
                                a0 += k; a1 += k;
                                __m512d z0 = _mm512_set1_pd(x0);
                                for (int jg = 0; jg < ng; jg++)
                                    acc[0][jg] = _mm512_fmadd_pd(z0, b[jg], acc[0][jg]);
                                __m512d z1 = _mm512_set1_pd(x1);
                                for (int jg = 0; jg < ng; jg++)
                                    acc[1][jg] = _mm512_fmadd_pd(z1, b[jg], acc[1][jg]);
                            }
                        }
                        if (tail > 0) {
                            for (int jt = 0; jt < tail; jt++) {
                                int64_t idx = ng * 8 + jt;
                                double c0 = C0[idx], c1 = C0[n + idx];
                                C0[idx] = (alpha == 1.0) ? t0[jt] + beta * c0
                                                          : alpha * t0[jt] + beta * c0;
                                C0[n + idx] = (alpha == 1.0) ? t1[jt] + beta * c1
                                                             : alpha * t1[jt] + beta * c1;
                            }
                        }
                    } else {
                        // ---- single-row panel -----------------------------
                        const double *a0 = ar[0];
                        const int kk = (int)k;
                        double t0[8] = {0};
                        if (ng == 0) {
                            for (int i = 0; i < kk; i++) {
                                for (int jt = 0; jt < tail; jt++)
                                    t0[jt] += a0[0] * B0[(int64_t)i * n + jt];
                                a0 += k;
                            }
                        } else {
                            __m512d b[NR / 8];
                            for (int i = 0; i < kk; i++) {
                                for (int jg = 0; jg < ng; jg++)
                                    b[jg] = _mm512_loadu_pd(B0 + (int64_t)i * n + jg * 8);
                                double x0 = a0[0];
                                for (int jt = 0; jt < tail; jt++)
                                    t0[jt] += x0 * (B0 + (int64_t)i * n + ng * 8)[jt];
                                a0 += k;
                                __m512d z0 = _mm512_set1_pd(x0);
                                for (int jg = 0; jg < ng; jg++)
                                    acc[0][jg] = _mm512_fmadd_pd(z0, b[jg], acc[0][jg]);
                            }
                        }
                        if (tail > 0) {
                            for (int jt = 0; jt < tail; jt++) {
                                int64_t idx = ng * 8 + jt;
                                double c0 = C0[idx];
                                C0[idx] = (alpha == 1.0) ? t0[jt] + beta * c0
                                                         : alpha * t0[jt] + beta * c0;
                            }
                        }
                    }

                    // ---- epilogue for the generic paths -------------------
                    for (int r = 0; r < rows; r++) {
                        double *Cr = C0 + (int64_t)r * n;
                        if (beta == 0.0) {
                            if (alpha == 1.0) {
                                for (int jg = 0; jg < ng; jg++) _mm512_storeu_pd(Cr + jg * 8, acc[r][jg]);
                            } else {
                                __m512d za = _mm512_set1_pd(alpha);
                                for (int jg = 0; jg < ng; jg++) _mm512_storeu_pd(Cr + jg * 8, _mm512_mul_pd(za, acc[r][jg]));
                            }
                        } else {
                            __m512d za = _mm512_set1_pd(alpha), zb = _mm512_set1_pd(beta);
                            for (int jg = 0; jg < ng; jg++) {
                                __m512d cv = _mm512_loadu_pd(Cr + jg * 8);
                                cv = _mm512_fmadd_pd(za, acc[r][jg], _mm512_mul_pd(zb, cv));
                                _mm512_storeu_pd(Cr + jg * 8, cv);
                            }
                        }
                    }
                }
            }
        }
    }
}
