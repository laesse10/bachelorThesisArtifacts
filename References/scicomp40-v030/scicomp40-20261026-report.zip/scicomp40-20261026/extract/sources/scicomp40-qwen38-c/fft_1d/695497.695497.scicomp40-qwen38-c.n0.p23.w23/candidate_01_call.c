/* fft_1d: y = fft(x); z = ifft(y) == x.
 *
 * Strategy:
 *  - Use FFTW (linked in the judge build) with its OpenMP thread module,
 *    loaded at runtime via dlopen so the fixed judge link line is respected.
 *  - Forward DFT out-of-place x -> y, backward DFT out-of-place y -> z
 *    (y is only read by the backward transform, so no scratch buffer and
 *    no copies are needed at all).
 *  - Plans are cached keyed on (N, x, y, z) since FFTW plans bind to the
 *    exact pointers: within one input the warmup + timed calls hit the cache.
 *  - The 1/N unnormalization of the backward transform is a single
 *    vectorized OpenMP pass over z.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <fftw3.h>
#include <dlfcn.h>
#include <omp.h>

typedef struct {
    int64_t n;
    const void *x;
    const void *y;
    const void *z;
    fftw_plan fwd;
    fftw_plan bwd;
} plan_entry;

#define NPLAN 16
static plan_entry g_plans[NPLAN];
static int g_nt = 0;              /* fftw thread count in effect */
static int g_nt_tried = 0;

/* Load FFTW's OpenMP thread module (the judge links only -lfftw3) and
 * set the global FFTW thread count. The module registers itself in the
 * main library via a constructor, so merely loading it enables threaded
 * planning. Falls back to single-threaded if unavailable. */
static void init_fftw_threads(void) {
    if (g_nt_tried) return;
    g_nt_tried = 1;
    int T = omp_get_max_threads();
    if (T < 1) T = 1;
    static const char *cands[3] = {
        "libfftw3_omp.so.3",
        "libfftw3_omp.so",
        "/opt/view/lib/libfftw3_omp.so.3",
    };
    for (int i = 0; i < 3; i++) {
        void *h = dlopen(cands[i], RTLD_NOW | RTLD_GLOBAL);
        if (!h) continue;
        int (*setnt)(int) = (int (*)(int))dlsym(h, "fftw_plan_with_nthreads");
        if (setnt && setnt(T)) {
            g_nt = T;
            return;
        }
        /* module loaded but refused: keep it loaded, keep trying */
    }
}

static plan_entry *plan_find(int64_t n, const void *x, const void *y, const void *z,
                             fftw_complex *inbuf) {
    for (int i = 0; i < NPLAN; i++) {
        plan_entry *e = &g_plans[i];
        if (e->n == n && e->x == x && e->y == y && e->z == z) return e;
    }
    /* miss: take a slot round-robin, replacing the oldest */
    static int slot = 0;
    plan_entry *e = &g_plans[slot];
    slot = (slot + 1) & (NPLAN - 1);
    if (e->fwd) { fftw_destroy_plan(e->fwd); e->fwd = NULL; }
    if (e->bwd) { fftw_destroy_plan(e->bwd); e->bwd = NULL; }
    e->n = n;
    e->x = x;
    e->y = y;
    e->z = z;
    e->fwd = fftw_plan_dft_1d((int)n, (fftw_complex *)x, (fftw_complex *)y,
                              FFTW_FORWARD, FFTW_ESTIMATE);
    /* backward reads y, writes z; the inbuf argument is unused when in != out */
    (void)inbuf;
    e->bwd = fftw_plan_dft_1d((int)n, (fftw_complex *)y, (fftw_complex *)z,
                              FFTW_BACKWARD, FFTW_ESTIMATE);
    return e;
}

void fft_1d_fp64(const double _Complex *restrict x, double _Complex *restrict y,
                 double _Complex *restrict z, const int64_t N,
                 uint8_t *restrict workspace, const int64_t workspace_size) {
    (void)workspace;
    (void)workspace_size;
    if (N <= 0) return;
    if (N == 1) {
        y[0] = x[0];
        z[0] = x[0];
        return;
    }
    init_fftw_threads();
    plan_entry *e = plan_find(N, (const void *)x, (const void *)y, (const void *)z, NULL);
    if (!e || !e->fwd || !e->bwd) return; /* planning failed: leave outputs untouched */
    fftw_execute(e->fwd);                  /* y = fft(x)            */
    fftw_execute(e->bwd);                  /* z = N * ifft(y)      */
    const double invN = 1.0 / (double)N;
    #pragma omp parallel for schedule(static)
    for (int64_t i = 0; i < N; i++) {
        z[i] *= invN;
    }
}
