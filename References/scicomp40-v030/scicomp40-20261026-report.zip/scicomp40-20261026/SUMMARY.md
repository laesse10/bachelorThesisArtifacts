# scicomp40 C, v0.3.0 resubmit (jobs 695497 qwen38, 695498 oss120b)

Two setups, 40 scicomp kernels each, C language, multi-submission, preset S+fuzz, 20 h agent budget, one MI300A node.

| | qwen38-c (695497) | oss120b-c (695498) |
|---|---|---|
| job wall | 22 h 40 m | 7 h 09 m |
| agents ended | 38 timeout at 20 h, 2 on their own | 40 on their own (median 2.2 h) |
| kernels with a verified answer | 28 / 40 | 20 / 40 |
| geomean speedup over best of GCC/Numba (verified) | 1.11x (CI 0.82-1.66), 12 wins / 16 losses | 1.03x (CI 0.70-1.95), 8 wins / 12 losses |
| billed tokens per agent (geomean) | 1.30 M | 0.31 M |
| tool calls | 4279 (115 / agent median) | 2652 (53 / agent median) |
| tool calls that errored | 635 | 592 |
| `score` calls: correct / all / client timeout 1800 s | 38 / 64 / 22 | 14 / 145 / 110 |
| `submit` calls: correct / all / client timeout 1800 s | 9 / 26 / 12 | 2 / 26 / 20 |
| runs owed a final grade (`grade-under`) | 10 | 19 |

Largest speedups: seissol_batched_gemm 23.9x (qwen38) / 19.1x (oss120b), triangle_count 15.9x (oss120b),
seissol_tensor_contraction 4.5x, dwt2d 3.5x, fft_1d 2.8x, warpx_field_gather 2.7x (qwen38).
Per-kernel numbers: `plots/kernel-speedups-kernels.csv`; per-run numbers: `plots/kernel-runs.csv`.

## Contents

- `extract/` `hpcagent-bench extract` output: `llr40_observations.csv` (375 rows), `observations.sqlite`, sources + index
- `plots/` `hpcagent-bench plot kernel-speedups` and `kernel-runs` (pdf, png, csv tables)
- `tool_calls/tool_calls.csv` every tool call (setup, kernel, index, tool, input and result clipped to 400 chars, error flag)
- `tool_calls/agents.csv` per agent: result, turns, wall, tokens, calls per tool, errors, score/submit counts
- `databases/` results and judge DBs of both jobs (read them read-only)
- `scripts/tool_calls.py` the extractor (rerun: `python3 scripts/tool_calls.py <out>`)

## Issues found

1. **MCP tool calls time out at 1800 s before the judge answers.** 129 `score`, 35 `profile`, 32 `submit` calls ended with
   claude-code's "sent no response or progress for 1800s". oss120b lost 110 of 145 scores this way. The judge kept grading
   (the extract has the late grades), but the agent saw a failure and often stopped or resubmitted. Whole-application
   grades queue behind one judge's slots; either the tool must send progress, or the per-call budget/judge slots must fit
   the slowest kernels (seissol, cp2k, fv3_xppm, kleinman_bylander, nussinov lead).
2. **`profile` refuses every size in a fuzzed run.** `service.profile_size` rejects any `size` when the run's preset is
   `fuzzed` and reports it as `size 'M' is not one of S, M, L, XL`. Seen for examinimd and others. It should resolve
   against the fuzz anchor rung, and the message must not blame the agent's valid size.
3. **29 runs owe a final grade** (submissions with no mw4x5 grade): the figures draw them as pending and
   `kernel-runs --table` refuses. Needs `hpcagent-bench grade-under` on both jobs before any statistic.
4. **oss120b quits early and calls tools that do not exist.** All 40 agents ended by themselves after a median of 2.2 h
   of the 20 h budget; 21 never submitted. 36 calls went to absent tools (`Find`, `Search`, `Grep`, `ListFiles`,
   `Bash<|channel|>commentary`: harmony channel text leaking into the tool name), 49 Bash calls had unparseable input.
5. **qwen38 never ends on its own**: 38/40 ran to the 20 h kill. 20 kernels never got a submit call.
6. **Bash's 2-minute default timeout kills local runs** (208 timed-out commands, exit 143), mostly agents timing full
   kernels themselves instead of using `score`.
7. **`plot kernel-runs --title` crashes**: the title is drawn at 20 pt and `style.save` refuses text outside 5.5-8 pt.
8. The figure styles report overlapping tick labels at the 5.5 pt floor for 40 kernels (cosmetic).
